<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-09-28 04:14:56 --> Config Class Initialized
INFO - 2018-09-28 04:14:56 --> Hooks Class Initialized
DEBUG - 2018-09-28 04:14:56 --> UTF-8 Support Enabled
INFO - 2018-09-28 04:14:56 --> Utf8 Class Initialized
INFO - 2018-09-28 04:14:56 --> URI Class Initialized
INFO - 2018-09-28 04:14:56 --> Router Class Initialized
INFO - 2018-09-28 04:14:56 --> Output Class Initialized
INFO - 2018-09-28 04:14:56 --> Security Class Initialized
DEBUG - 2018-09-28 04:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 04:14:56 --> Input Class Initialized
INFO - 2018-09-28 04:14:56 --> Language Class Initialized
INFO - 2018-09-28 04:14:56 --> Loader Class Initialized
INFO - 2018-09-28 04:14:56 --> Helper loaded: url_helper
INFO - 2018-09-28 04:14:56 --> Helper loaded: form_helper
INFO - 2018-09-28 04:14:56 --> Helper loaded: html_helper
INFO - 2018-09-28 04:14:56 --> Database Driver Class Initialized
INFO - 2018-09-28 04:14:56 --> Form Validation Class Initialized
DEBUG - 2018-09-28 04:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 04:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 04:14:56 --> Model "User_model" initialized
INFO - 2018-09-28 04:14:56 --> Model "Project_model" initialized
INFO - 2018-09-28 04:14:56 --> Model "Tasks_model" initialized
INFO - 2018-09-28 04:14:56 --> Model "Lists_model" initialized
INFO - 2018-09-28 04:14:56 --> Controller Class Initialized
INFO - 2018-09-28 04:14:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 04:14:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-28 04:14:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 04:14:56 --> Final output sent to browser
DEBUG - 2018-09-28 04:14:56 --> Total execution time: 0.2550
INFO - 2018-09-28 04:15:29 --> Config Class Initialized
INFO - 2018-09-28 04:15:29 --> Hooks Class Initialized
DEBUG - 2018-09-28 04:15:29 --> UTF-8 Support Enabled
INFO - 2018-09-28 04:15:29 --> Utf8 Class Initialized
INFO - 2018-09-28 04:15:29 --> URI Class Initialized
INFO - 2018-09-28 04:15:29 --> Router Class Initialized
INFO - 2018-09-28 04:15:29 --> Output Class Initialized
INFO - 2018-09-28 04:15:29 --> Security Class Initialized
DEBUG - 2018-09-28 04:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 04:15:29 --> Input Class Initialized
INFO - 2018-09-28 04:15:29 --> Language Class Initialized
INFO - 2018-09-28 04:15:29 --> Loader Class Initialized
INFO - 2018-09-28 04:15:29 --> Helper loaded: url_helper
INFO - 2018-09-28 04:15:29 --> Helper loaded: form_helper
INFO - 2018-09-28 04:15:29 --> Helper loaded: html_helper
INFO - 2018-09-28 04:15:29 --> Database Driver Class Initialized
INFO - 2018-09-28 04:15:29 --> Form Validation Class Initialized
DEBUG - 2018-09-28 04:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 04:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 04:15:29 --> Model "User_model" initialized
INFO - 2018-09-28 04:15:29 --> Model "Project_model" initialized
INFO - 2018-09-28 04:15:29 --> Model "Tasks_model" initialized
INFO - 2018-09-28 04:15:29 --> Model "Lists_model" initialized
INFO - 2018-09-28 04:15:29 --> Controller Class Initialized
INFO - 2018-09-28 04:15:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 04:15:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-28 04:15:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 04:15:29 --> Final output sent to browser
DEBUG - 2018-09-28 04:15:29 --> Total execution time: 0.0930
INFO - 2018-09-28 04:15:42 --> Config Class Initialized
INFO - 2018-09-28 04:15:42 --> Hooks Class Initialized
DEBUG - 2018-09-28 04:15:42 --> UTF-8 Support Enabled
INFO - 2018-09-28 04:15:42 --> Utf8 Class Initialized
INFO - 2018-09-28 04:15:42 --> URI Class Initialized
INFO - 2018-09-28 04:15:42 --> Router Class Initialized
INFO - 2018-09-28 04:15:42 --> Output Class Initialized
INFO - 2018-09-28 04:15:42 --> Security Class Initialized
DEBUG - 2018-09-28 04:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 04:15:42 --> Input Class Initialized
INFO - 2018-09-28 04:15:42 --> Language Class Initialized
INFO - 2018-09-28 04:15:42 --> Loader Class Initialized
INFO - 2018-09-28 04:15:42 --> Helper loaded: url_helper
INFO - 2018-09-28 04:15:42 --> Helper loaded: form_helper
INFO - 2018-09-28 04:15:42 --> Helper loaded: html_helper
INFO - 2018-09-28 04:15:42 --> Database Driver Class Initialized
INFO - 2018-09-28 04:15:42 --> Form Validation Class Initialized
DEBUG - 2018-09-28 04:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 04:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 04:15:42 --> Model "User_model" initialized
INFO - 2018-09-28 04:15:42 --> Model "Project_model" initialized
INFO - 2018-09-28 04:15:42 --> Model "Tasks_model" initialized
INFO - 2018-09-28 04:15:42 --> Model "Lists_model" initialized
INFO - 2018-09-28 04:15:42 --> Controller Class Initialized
INFO - 2018-09-28 04:15:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 04:15:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-28 04:15:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 04:15:42 --> Final output sent to browser
DEBUG - 2018-09-28 04:15:42 --> Total execution time: 0.1100
INFO - 2018-09-28 08:46:18 --> Config Class Initialized
INFO - 2018-09-28 08:46:18 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:46:19 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:46:19 --> Utf8 Class Initialized
INFO - 2018-09-28 08:46:19 --> URI Class Initialized
INFO - 2018-09-28 08:46:19 --> Router Class Initialized
INFO - 2018-09-28 08:46:19 --> Output Class Initialized
INFO - 2018-09-28 08:46:19 --> Security Class Initialized
DEBUG - 2018-09-28 08:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:46:19 --> Input Class Initialized
INFO - 2018-09-28 08:46:19 --> Language Class Initialized
INFO - 2018-09-28 08:46:20 --> Loader Class Initialized
INFO - 2018-09-28 08:46:20 --> Helper loaded: url_helper
INFO - 2018-09-28 08:46:20 --> Helper loaded: form_helper
INFO - 2018-09-28 08:46:20 --> Helper loaded: html_helper
INFO - 2018-09-28 08:46:20 --> Database Driver Class Initialized
INFO - 2018-09-28 08:46:21 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:46:21 --> Model "User_model" initialized
INFO - 2018-09-28 08:46:21 --> Model "Project_model" initialized
INFO - 2018-09-28 08:46:21 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:46:21 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:46:21 --> Controller Class Initialized
INFO - 2018-09-28 08:46:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:46:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-28 08:46:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:46:21 --> Final output sent to browser
DEBUG - 2018-09-28 08:46:21 --> Total execution time: 3.0852
INFO - 2018-09-28 08:46:48 --> Config Class Initialized
INFO - 2018-09-28 08:46:48 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:46:48 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:46:48 --> Utf8 Class Initialized
INFO - 2018-09-28 08:46:48 --> URI Class Initialized
INFO - 2018-09-28 08:46:48 --> Router Class Initialized
INFO - 2018-09-28 08:46:48 --> Output Class Initialized
INFO - 2018-09-28 08:46:48 --> Security Class Initialized
DEBUG - 2018-09-28 08:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:46:48 --> Input Class Initialized
INFO - 2018-09-28 08:46:48 --> Language Class Initialized
INFO - 2018-09-28 08:46:48 --> Loader Class Initialized
INFO - 2018-09-28 08:46:48 --> Helper loaded: url_helper
INFO - 2018-09-28 08:46:48 --> Helper loaded: form_helper
INFO - 2018-09-28 08:46:48 --> Helper loaded: html_helper
INFO - 2018-09-28 08:46:48 --> Database Driver Class Initialized
INFO - 2018-09-28 08:46:48 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:46:48 --> Model "User_model" initialized
INFO - 2018-09-28 08:46:48 --> Model "Project_model" initialized
INFO - 2018-09-28 08:46:48 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:46:48 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:46:48 --> Controller Class Initialized
INFO - 2018-09-28 08:46:48 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:46:48 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-28 08:46:48 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:46:48 --> Final output sent to browser
DEBUG - 2018-09-28 08:46:48 --> Total execution time: 0.0330
INFO - 2018-09-28 08:46:58 --> Config Class Initialized
INFO - 2018-09-28 08:46:58 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:46:58 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:46:58 --> Utf8 Class Initialized
INFO - 2018-09-28 08:46:58 --> URI Class Initialized
INFO - 2018-09-28 08:46:58 --> Router Class Initialized
INFO - 2018-09-28 08:46:58 --> Output Class Initialized
INFO - 2018-09-28 08:46:58 --> Security Class Initialized
DEBUG - 2018-09-28 08:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:46:58 --> Input Class Initialized
INFO - 2018-09-28 08:46:58 --> Language Class Initialized
INFO - 2018-09-28 08:46:58 --> Loader Class Initialized
INFO - 2018-09-28 08:46:58 --> Helper loaded: url_helper
INFO - 2018-09-28 08:46:58 --> Helper loaded: form_helper
INFO - 2018-09-28 08:46:58 --> Helper loaded: html_helper
INFO - 2018-09-28 08:46:58 --> Database Driver Class Initialized
INFO - 2018-09-28 08:46:58 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:46:58 --> Model "User_model" initialized
INFO - 2018-09-28 08:46:58 --> Model "Project_model" initialized
INFO - 2018-09-28 08:46:58 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:46:58 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:46:58 --> Controller Class Initialized
ERROR - 2018-09-28 08:46:59 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\code_igniter\application\views\project_views\layouts\main.php 31
ERROR - 2018-09-28 08:46:59 --> Severity: Notice --> Undefined variable: list_library D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 70
INFO - 2018-09-28 08:46:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:46:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:46:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:46:59 --> Final output sent to browser
DEBUG - 2018-09-28 08:46:59 --> Total execution time: 0.5130
INFO - 2018-09-28 08:47:23 --> Config Class Initialized
INFO - 2018-09-28 08:47:23 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:47:23 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:47:23 --> Utf8 Class Initialized
INFO - 2018-09-28 08:47:23 --> URI Class Initialized
INFO - 2018-09-28 08:47:23 --> Router Class Initialized
INFO - 2018-09-28 08:47:23 --> Output Class Initialized
INFO - 2018-09-28 08:47:23 --> Security Class Initialized
DEBUG - 2018-09-28 08:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:47:23 --> Input Class Initialized
INFO - 2018-09-28 08:47:23 --> Language Class Initialized
INFO - 2018-09-28 08:47:23 --> Loader Class Initialized
INFO - 2018-09-28 08:47:23 --> Helper loaded: url_helper
INFO - 2018-09-28 08:47:23 --> Helper loaded: form_helper
INFO - 2018-09-28 08:47:23 --> Helper loaded: html_helper
INFO - 2018-09-28 08:47:23 --> Database Driver Class Initialized
INFO - 2018-09-28 08:47:23 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:47:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:47:23 --> Model "User_model" initialized
INFO - 2018-09-28 08:47:23 --> Model "Project_model" initialized
INFO - 2018-09-28 08:47:23 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:47:23 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:47:23 --> Controller Class Initialized
ERROR - 2018-09-28 08:47:23 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\code_igniter\application\views\project_views\layouts\main.php 31
ERROR - 2018-09-28 08:47:23 --> Severity: Notice --> Undefined variable: list_library D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 70
INFO - 2018-09-28 08:47:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:47:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:47:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:47:23 --> Final output sent to browser
DEBUG - 2018-09-28 08:47:23 --> Total execution time: 0.0380
INFO - 2018-09-28 08:47:40 --> Config Class Initialized
INFO - 2018-09-28 08:47:40 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:47:40 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:47:40 --> Utf8 Class Initialized
INFO - 2018-09-28 08:47:40 --> URI Class Initialized
INFO - 2018-09-28 08:47:40 --> Router Class Initialized
INFO - 2018-09-28 08:47:40 --> Output Class Initialized
INFO - 2018-09-28 08:47:40 --> Security Class Initialized
DEBUG - 2018-09-28 08:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:47:40 --> Input Class Initialized
INFO - 2018-09-28 08:47:40 --> Language Class Initialized
INFO - 2018-09-28 08:47:40 --> Loader Class Initialized
INFO - 2018-09-28 08:47:40 --> Helper loaded: url_helper
INFO - 2018-09-28 08:47:40 --> Helper loaded: form_helper
INFO - 2018-09-28 08:47:40 --> Helper loaded: html_helper
INFO - 2018-09-28 08:47:40 --> Database Driver Class Initialized
INFO - 2018-09-28 08:47:40 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:47:40 --> Model "User_model" initialized
INFO - 2018-09-28 08:47:40 --> Model "Project_model" initialized
INFO - 2018-09-28 08:47:40 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:47:40 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:47:40 --> Controller Class Initialized
INFO - 2018-09-28 08:47:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:47:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-28 08:47:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:47:40 --> Final output sent to browser
DEBUG - 2018-09-28 08:47:40 --> Total execution time: 0.0520
INFO - 2018-09-28 08:47:41 --> Config Class Initialized
INFO - 2018-09-28 08:47:41 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:47:41 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:47:41 --> Utf8 Class Initialized
INFO - 2018-09-28 08:47:41 --> URI Class Initialized
INFO - 2018-09-28 08:47:41 --> Router Class Initialized
INFO - 2018-09-28 08:47:41 --> Output Class Initialized
INFO - 2018-09-28 08:47:41 --> Security Class Initialized
DEBUG - 2018-09-28 08:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:47:41 --> Input Class Initialized
INFO - 2018-09-28 08:47:41 --> Language Class Initialized
INFO - 2018-09-28 08:47:41 --> Loader Class Initialized
INFO - 2018-09-28 08:47:41 --> Helper loaded: url_helper
INFO - 2018-09-28 08:47:41 --> Helper loaded: form_helper
INFO - 2018-09-28 08:47:41 --> Helper loaded: html_helper
INFO - 2018-09-28 08:47:41 --> Database Driver Class Initialized
INFO - 2018-09-28 08:47:41 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:47:41 --> Model "User_model" initialized
INFO - 2018-09-28 08:47:41 --> Model "Project_model" initialized
INFO - 2018-09-28 08:47:41 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:47:41 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:47:41 --> Controller Class Initialized
ERROR - 2018-09-28 08:47:41 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\code_igniter\application\views\project_views\layouts\main.php 31
ERROR - 2018-09-28 08:47:41 --> Severity: Notice --> Undefined variable: list_library D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 70
INFO - 2018-09-28 08:47:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:47:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:47:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:47:41 --> Final output sent to browser
DEBUG - 2018-09-28 08:47:41 --> Total execution time: 0.0660
INFO - 2018-09-28 08:47:54 --> Config Class Initialized
INFO - 2018-09-28 08:47:54 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:47:54 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:47:54 --> Utf8 Class Initialized
INFO - 2018-09-28 08:47:54 --> URI Class Initialized
INFO - 2018-09-28 08:47:54 --> Router Class Initialized
INFO - 2018-09-28 08:47:54 --> Output Class Initialized
INFO - 2018-09-28 08:47:54 --> Security Class Initialized
DEBUG - 2018-09-28 08:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:47:54 --> Input Class Initialized
INFO - 2018-09-28 08:47:54 --> Language Class Initialized
INFO - 2018-09-28 08:47:54 --> Loader Class Initialized
INFO - 2018-09-28 08:47:54 --> Helper loaded: url_helper
INFO - 2018-09-28 08:47:54 --> Helper loaded: form_helper
INFO - 2018-09-28 08:47:54 --> Helper loaded: html_helper
INFO - 2018-09-28 08:47:54 --> Database Driver Class Initialized
INFO - 2018-09-28 08:47:54 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:47:54 --> Model "User_model" initialized
INFO - 2018-09-28 08:47:54 --> Model "Project_model" initialized
INFO - 2018-09-28 08:47:54 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:47:54 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:47:54 --> Controller Class Initialized
ERROR - 2018-09-28 08:47:54 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\code_igniter\application\views\project_views\layouts\main.php 31
ERROR - 2018-09-28 08:47:54 --> Severity: Notice --> Undefined variable: list_library D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 70
INFO - 2018-09-28 08:47:54 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:47:54 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:47:54 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:47:54 --> Final output sent to browser
DEBUG - 2018-09-28 08:47:54 --> Total execution time: 0.0710
INFO - 2018-09-28 08:49:24 --> Config Class Initialized
INFO - 2018-09-28 08:49:24 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:49:24 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:49:24 --> Utf8 Class Initialized
INFO - 2018-09-28 08:49:24 --> URI Class Initialized
INFO - 2018-09-28 08:49:24 --> Router Class Initialized
INFO - 2018-09-28 08:49:24 --> Output Class Initialized
INFO - 2018-09-28 08:49:24 --> Security Class Initialized
DEBUG - 2018-09-28 08:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:49:24 --> Input Class Initialized
INFO - 2018-09-28 08:49:24 --> Language Class Initialized
INFO - 2018-09-28 08:49:24 --> Loader Class Initialized
INFO - 2018-09-28 08:49:24 --> Helper loaded: url_helper
INFO - 2018-09-28 08:49:24 --> Helper loaded: form_helper
INFO - 2018-09-28 08:49:24 --> Helper loaded: html_helper
INFO - 2018-09-28 08:49:24 --> Database Driver Class Initialized
INFO - 2018-09-28 08:49:24 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:49:24 --> Model "User_model" initialized
INFO - 2018-09-28 08:49:24 --> Model "Project_model" initialized
INFO - 2018-09-28 08:49:24 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:49:24 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:49:24 --> Controller Class Initialized
ERROR - 2018-09-28 08:49:24 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\code_igniter\application\views\project_views\layouts\main.php 31
ERROR - 2018-09-28 08:49:24 --> Severity: Notice --> Undefined variable: list_library D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 70
INFO - 2018-09-28 08:49:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:49:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:49:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:49:24 --> Final output sent to browser
DEBUG - 2018-09-28 08:49:24 --> Total execution time: 0.0650
INFO - 2018-09-28 08:49:26 --> Config Class Initialized
INFO - 2018-09-28 08:49:26 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:49:26 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:49:26 --> Utf8 Class Initialized
INFO - 2018-09-28 08:49:26 --> URI Class Initialized
INFO - 2018-09-28 08:49:26 --> Router Class Initialized
INFO - 2018-09-28 08:49:26 --> Output Class Initialized
INFO - 2018-09-28 08:49:26 --> Security Class Initialized
DEBUG - 2018-09-28 08:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:49:26 --> Input Class Initialized
INFO - 2018-09-28 08:49:26 --> Language Class Initialized
INFO - 2018-09-28 08:49:26 --> Loader Class Initialized
INFO - 2018-09-28 08:49:26 --> Helper loaded: url_helper
INFO - 2018-09-28 08:49:26 --> Helper loaded: form_helper
INFO - 2018-09-28 08:49:26 --> Helper loaded: html_helper
INFO - 2018-09-28 08:49:26 --> Database Driver Class Initialized
INFO - 2018-09-28 08:49:26 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:49:26 --> Model "User_model" initialized
INFO - 2018-09-28 08:49:26 --> Model "Project_model" initialized
INFO - 2018-09-28 08:49:26 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:49:26 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:49:26 --> Controller Class Initialized
INFO - 2018-09-28 08:49:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:49:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-28 08:49:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:49:26 --> Final output sent to browser
DEBUG - 2018-09-28 08:49:26 --> Total execution time: 0.0530
INFO - 2018-09-28 08:49:27 --> Config Class Initialized
INFO - 2018-09-28 08:49:27 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:49:27 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:49:27 --> Utf8 Class Initialized
INFO - 2018-09-28 08:49:27 --> URI Class Initialized
INFO - 2018-09-28 08:49:27 --> Router Class Initialized
INFO - 2018-09-28 08:49:27 --> Output Class Initialized
INFO - 2018-09-28 08:49:27 --> Security Class Initialized
DEBUG - 2018-09-28 08:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:49:27 --> Input Class Initialized
INFO - 2018-09-28 08:49:27 --> Language Class Initialized
INFO - 2018-09-28 08:49:27 --> Loader Class Initialized
INFO - 2018-09-28 08:49:27 --> Helper loaded: url_helper
INFO - 2018-09-28 08:49:27 --> Helper loaded: form_helper
INFO - 2018-09-28 08:49:27 --> Helper loaded: html_helper
INFO - 2018-09-28 08:49:27 --> Database Driver Class Initialized
INFO - 2018-09-28 08:49:27 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:49:27 --> Model "User_model" initialized
INFO - 2018-09-28 08:49:27 --> Model "Project_model" initialized
INFO - 2018-09-28 08:49:27 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:49:27 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:49:27 --> Controller Class Initialized
ERROR - 2018-09-28 08:49:27 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\code_igniter\application\views\project_views\layouts\main.php 31
ERROR - 2018-09-28 08:49:27 --> Severity: Notice --> Undefined variable: list_library D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 70
INFO - 2018-09-28 08:49:27 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:49:27 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:49:27 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:49:27 --> Final output sent to browser
DEBUG - 2018-09-28 08:49:27 --> Total execution time: 0.0660
INFO - 2018-09-28 08:50:28 --> Config Class Initialized
INFO - 2018-09-28 08:50:28 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:50:28 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:50:28 --> Utf8 Class Initialized
INFO - 2018-09-28 08:50:28 --> URI Class Initialized
INFO - 2018-09-28 08:50:28 --> Router Class Initialized
INFO - 2018-09-28 08:50:28 --> Output Class Initialized
INFO - 2018-09-28 08:50:28 --> Security Class Initialized
DEBUG - 2018-09-28 08:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:50:28 --> Input Class Initialized
INFO - 2018-09-28 08:50:28 --> Language Class Initialized
INFO - 2018-09-28 08:50:28 --> Loader Class Initialized
INFO - 2018-09-28 08:50:28 --> Helper loaded: url_helper
INFO - 2018-09-28 08:50:28 --> Helper loaded: form_helper
INFO - 2018-09-28 08:50:28 --> Helper loaded: html_helper
INFO - 2018-09-28 08:50:28 --> Database Driver Class Initialized
INFO - 2018-09-28 08:50:28 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:50:28 --> Model "User_model" initialized
INFO - 2018-09-28 08:50:28 --> Model "Project_model" initialized
INFO - 2018-09-28 08:50:28 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:50:28 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:50:28 --> Controller Class Initialized
INFO - 2018-09-28 08:50:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:50:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-28 08:50:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:50:28 --> Final output sent to browser
DEBUG - 2018-09-28 08:50:28 --> Total execution time: 0.0520
INFO - 2018-09-28 08:52:28 --> Config Class Initialized
INFO - 2018-09-28 08:52:28 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:52:28 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:52:28 --> Utf8 Class Initialized
INFO - 2018-09-28 08:52:28 --> URI Class Initialized
INFO - 2018-09-28 08:52:28 --> Router Class Initialized
INFO - 2018-09-28 08:52:28 --> Output Class Initialized
INFO - 2018-09-28 08:52:28 --> Security Class Initialized
DEBUG - 2018-09-28 08:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:52:28 --> Input Class Initialized
INFO - 2018-09-28 08:52:28 --> Language Class Initialized
INFO - 2018-09-28 08:52:28 --> Loader Class Initialized
INFO - 2018-09-28 08:52:28 --> Helper loaded: url_helper
INFO - 2018-09-28 08:52:28 --> Helper loaded: form_helper
INFO - 2018-09-28 08:52:28 --> Helper loaded: html_helper
INFO - 2018-09-28 08:52:28 --> Database Driver Class Initialized
INFO - 2018-09-28 08:52:28 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:52:28 --> Model "User_model" initialized
INFO - 2018-09-28 08:52:28 --> Model "Project_model" initialized
INFO - 2018-09-28 08:52:28 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:52:28 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:52:28 --> Controller Class Initialized
ERROR - 2018-09-28 08:52:28 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\code_igniter\application\views\project_views\layouts\main.php 31
ERROR - 2018-09-28 08:52:28 --> Severity: Notice --> Undefined variable: list_library D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 70
INFO - 2018-09-28 08:52:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:52:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:52:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:52:28 --> Final output sent to browser
DEBUG - 2018-09-28 08:52:28 --> Total execution time: 0.0500
INFO - 2018-09-28 08:52:38 --> Config Class Initialized
INFO - 2018-09-28 08:52:38 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:52:38 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:52:38 --> Utf8 Class Initialized
INFO - 2018-09-28 08:52:38 --> URI Class Initialized
INFO - 2018-09-28 08:52:38 --> Router Class Initialized
INFO - 2018-09-28 08:52:38 --> Output Class Initialized
INFO - 2018-09-28 08:52:38 --> Security Class Initialized
DEBUG - 2018-09-28 08:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:52:38 --> Input Class Initialized
INFO - 2018-09-28 08:52:38 --> Language Class Initialized
INFO - 2018-09-28 08:52:38 --> Loader Class Initialized
INFO - 2018-09-28 08:52:38 --> Helper loaded: url_helper
INFO - 2018-09-28 08:52:38 --> Helper loaded: form_helper
INFO - 2018-09-28 08:52:38 --> Helper loaded: html_helper
INFO - 2018-09-28 08:52:38 --> Database Driver Class Initialized
INFO - 2018-09-28 08:52:38 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:52:38 --> Model "User_model" initialized
INFO - 2018-09-28 08:52:38 --> Model "Project_model" initialized
INFO - 2018-09-28 08:52:38 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:52:38 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:52:38 --> Controller Class Initialized
ERROR - 2018-09-28 08:52:38 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\code_igniter\application\views\project_views\layouts\main.php 31
INFO - 2018-09-28 08:52:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:52:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:52:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:52:38 --> Final output sent to browser
DEBUG - 2018-09-28 08:52:38 --> Total execution time: 0.0390
INFO - 2018-09-28 08:53:19 --> Config Class Initialized
INFO - 2018-09-28 08:53:19 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:53:19 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:53:19 --> Utf8 Class Initialized
INFO - 2018-09-28 08:53:19 --> URI Class Initialized
INFO - 2018-09-28 08:53:19 --> Router Class Initialized
INFO - 2018-09-28 08:53:19 --> Output Class Initialized
INFO - 2018-09-28 08:53:19 --> Security Class Initialized
DEBUG - 2018-09-28 08:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:53:19 --> Input Class Initialized
INFO - 2018-09-28 08:53:19 --> Language Class Initialized
INFO - 2018-09-28 08:53:19 --> Loader Class Initialized
INFO - 2018-09-28 08:53:19 --> Helper loaded: url_helper
INFO - 2018-09-28 08:53:19 --> Helper loaded: form_helper
INFO - 2018-09-28 08:53:19 --> Helper loaded: html_helper
INFO - 2018-09-28 08:53:19 --> Database Driver Class Initialized
INFO - 2018-09-28 08:53:19 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:53:19 --> Model "User_model" initialized
INFO - 2018-09-28 08:53:19 --> Model "Project_model" initialized
INFO - 2018-09-28 08:53:19 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:53:19 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:53:19 --> Controller Class Initialized
INFO - 2018-09-28 08:53:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:53:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:53:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:53:19 --> Final output sent to browser
DEBUG - 2018-09-28 08:53:19 --> Total execution time: 0.0440
INFO - 2018-09-28 08:53:21 --> Config Class Initialized
INFO - 2018-09-28 08:53:21 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:53:21 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:53:21 --> Utf8 Class Initialized
INFO - 2018-09-28 08:53:21 --> URI Class Initialized
INFO - 2018-09-28 08:53:21 --> Router Class Initialized
INFO - 2018-09-28 08:53:21 --> Output Class Initialized
INFO - 2018-09-28 08:53:21 --> Security Class Initialized
DEBUG - 2018-09-28 08:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:53:21 --> Input Class Initialized
INFO - 2018-09-28 08:53:21 --> Language Class Initialized
INFO - 2018-09-28 08:53:21 --> Loader Class Initialized
INFO - 2018-09-28 08:53:21 --> Helper loaded: url_helper
INFO - 2018-09-28 08:53:21 --> Helper loaded: form_helper
INFO - 2018-09-28 08:53:21 --> Helper loaded: html_helper
INFO - 2018-09-28 08:53:21 --> Database Driver Class Initialized
INFO - 2018-09-28 08:53:21 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:53:21 --> Model "User_model" initialized
INFO - 2018-09-28 08:53:21 --> Model "Project_model" initialized
INFO - 2018-09-28 08:53:21 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:53:21 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:53:21 --> Controller Class Initialized
INFO - 2018-09-28 08:53:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:53:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:53:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:53:21 --> Final output sent to browser
DEBUG - 2018-09-28 08:53:21 --> Total execution time: 0.0390
INFO - 2018-09-28 08:53:22 --> Config Class Initialized
INFO - 2018-09-28 08:53:22 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:53:22 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:53:22 --> Utf8 Class Initialized
INFO - 2018-09-28 08:53:22 --> URI Class Initialized
INFO - 2018-09-28 08:53:22 --> Router Class Initialized
INFO - 2018-09-28 08:53:22 --> Output Class Initialized
INFO - 2018-09-28 08:53:22 --> Security Class Initialized
DEBUG - 2018-09-28 08:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:53:22 --> Input Class Initialized
INFO - 2018-09-28 08:53:22 --> Language Class Initialized
INFO - 2018-09-28 08:53:22 --> Loader Class Initialized
INFO - 2018-09-28 08:53:22 --> Helper loaded: url_helper
INFO - 2018-09-28 08:53:22 --> Helper loaded: form_helper
INFO - 2018-09-28 08:53:22 --> Helper loaded: html_helper
INFO - 2018-09-28 08:53:22 --> Database Driver Class Initialized
INFO - 2018-09-28 08:53:22 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:53:22 --> Model "User_model" initialized
INFO - 2018-09-28 08:53:22 --> Model "Project_model" initialized
INFO - 2018-09-28 08:53:22 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:53:22 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:53:22 --> Controller Class Initialized
INFO - 2018-09-28 08:53:22 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:53:22 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-28 08:53:22 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:53:22 --> Final output sent to browser
DEBUG - 2018-09-28 08:53:22 --> Total execution time: 0.0500
INFO - 2018-09-28 08:53:23 --> Config Class Initialized
INFO - 2018-09-28 08:53:23 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:53:23 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:53:23 --> Utf8 Class Initialized
INFO - 2018-09-28 08:53:23 --> URI Class Initialized
INFO - 2018-09-28 08:53:23 --> Router Class Initialized
INFO - 2018-09-28 08:53:23 --> Output Class Initialized
INFO - 2018-09-28 08:53:23 --> Security Class Initialized
DEBUG - 2018-09-28 08:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:53:23 --> Input Class Initialized
INFO - 2018-09-28 08:53:23 --> Language Class Initialized
INFO - 2018-09-28 08:53:23 --> Loader Class Initialized
INFO - 2018-09-28 08:53:23 --> Helper loaded: url_helper
INFO - 2018-09-28 08:53:23 --> Helper loaded: form_helper
INFO - 2018-09-28 08:53:23 --> Helper loaded: html_helper
INFO - 2018-09-28 08:53:23 --> Database Driver Class Initialized
INFO - 2018-09-28 08:53:23 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:53:23 --> Model "User_model" initialized
INFO - 2018-09-28 08:53:23 --> Model "Project_model" initialized
INFO - 2018-09-28 08:53:23 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:53:23 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:53:23 --> Controller Class Initialized
INFO - 2018-09-28 08:53:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:53:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:53:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:53:23 --> Final output sent to browser
DEBUG - 2018-09-28 08:53:23 --> Total execution time: 0.0390
INFO - 2018-09-28 08:53:32 --> Config Class Initialized
INFO - 2018-09-28 08:53:32 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:53:32 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:53:32 --> Utf8 Class Initialized
INFO - 2018-09-28 08:53:32 --> URI Class Initialized
INFO - 2018-09-28 08:53:32 --> Router Class Initialized
INFO - 2018-09-28 08:53:32 --> Output Class Initialized
INFO - 2018-09-28 08:53:32 --> Security Class Initialized
DEBUG - 2018-09-28 08:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:53:32 --> Input Class Initialized
INFO - 2018-09-28 08:53:32 --> Language Class Initialized
INFO - 2018-09-28 08:53:32 --> Loader Class Initialized
INFO - 2018-09-28 08:53:32 --> Helper loaded: url_helper
INFO - 2018-09-28 08:53:32 --> Helper loaded: form_helper
INFO - 2018-09-28 08:53:32 --> Helper loaded: html_helper
INFO - 2018-09-28 08:53:32 --> Database Driver Class Initialized
INFO - 2018-09-28 08:53:32 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:53:32 --> Model "User_model" initialized
INFO - 2018-09-28 08:53:32 --> Model "Project_model" initialized
INFO - 2018-09-28 08:53:32 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:53:32 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:53:32 --> Controller Class Initialized
ERROR - 2018-09-28 08:53:32 --> Severity: Notice --> Undefined variable: list_library D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 70
INFO - 2018-09-28 08:53:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:53:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:53:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:53:32 --> Final output sent to browser
DEBUG - 2018-09-28 08:53:32 --> Total execution time: 0.0560
INFO - 2018-09-28 08:54:25 --> Config Class Initialized
INFO - 2018-09-28 08:54:25 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:54:25 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:54:25 --> Utf8 Class Initialized
INFO - 2018-09-28 08:54:25 --> URI Class Initialized
INFO - 2018-09-28 08:54:25 --> Router Class Initialized
INFO - 2018-09-28 08:54:25 --> Output Class Initialized
INFO - 2018-09-28 08:54:25 --> Security Class Initialized
DEBUG - 2018-09-28 08:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:54:25 --> Input Class Initialized
INFO - 2018-09-28 08:54:25 --> Language Class Initialized
INFO - 2018-09-28 08:54:25 --> Loader Class Initialized
INFO - 2018-09-28 08:54:25 --> Helper loaded: url_helper
INFO - 2018-09-28 08:54:25 --> Helper loaded: form_helper
INFO - 2018-09-28 08:54:25 --> Helper loaded: html_helper
INFO - 2018-09-28 08:54:25 --> Database Driver Class Initialized
INFO - 2018-09-28 08:54:25 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:54:25 --> Model "User_model" initialized
INFO - 2018-09-28 08:54:25 --> Model "Project_model" initialized
INFO - 2018-09-28 08:54:25 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:54:25 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:54:25 --> Controller Class Initialized
INFO - 2018-09-28 08:54:25 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-28 08:54:25 --> Severity: Notice --> Undefined variable: list_library D:\xampp\htdocs\code_igniter\application\views\project_views\layouts\main.php 101
INFO - 2018-09-28 08:54:25 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:54:25 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:54:25 --> Final output sent to browser
DEBUG - 2018-09-28 08:54:25 --> Total execution time: 0.0650
INFO - 2018-09-28 08:54:26 --> Config Class Initialized
INFO - 2018-09-28 08:54:26 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:54:26 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:54:26 --> Utf8 Class Initialized
INFO - 2018-09-28 08:54:26 --> URI Class Initialized
INFO - 2018-09-28 08:54:26 --> Router Class Initialized
INFO - 2018-09-28 08:54:27 --> Output Class Initialized
INFO - 2018-09-28 08:54:27 --> Security Class Initialized
DEBUG - 2018-09-28 08:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:54:27 --> Input Class Initialized
INFO - 2018-09-28 08:54:27 --> Language Class Initialized
INFO - 2018-09-28 08:54:27 --> Loader Class Initialized
INFO - 2018-09-28 08:54:27 --> Helper loaded: url_helper
INFO - 2018-09-28 08:54:27 --> Helper loaded: form_helper
INFO - 2018-09-28 08:54:27 --> Helper loaded: html_helper
INFO - 2018-09-28 08:54:27 --> Database Driver Class Initialized
INFO - 2018-09-28 08:54:27 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:54:27 --> Model "User_model" initialized
INFO - 2018-09-28 08:54:27 --> Model "Project_model" initialized
INFO - 2018-09-28 08:54:27 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:54:27 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:54:27 --> Controller Class Initialized
INFO - 2018-09-28 08:54:27 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:54:27 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-28 08:54:27 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:54:27 --> Final output sent to browser
DEBUG - 2018-09-28 08:54:27 --> Total execution time: 0.0590
INFO - 2018-09-28 08:54:28 --> Config Class Initialized
INFO - 2018-09-28 08:54:28 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:54:28 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:54:28 --> Utf8 Class Initialized
INFO - 2018-09-28 08:54:28 --> URI Class Initialized
INFO - 2018-09-28 08:54:28 --> Router Class Initialized
INFO - 2018-09-28 08:54:28 --> Output Class Initialized
INFO - 2018-09-28 08:54:28 --> Security Class Initialized
DEBUG - 2018-09-28 08:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:54:28 --> Input Class Initialized
INFO - 2018-09-28 08:54:28 --> Language Class Initialized
INFO - 2018-09-28 08:54:28 --> Loader Class Initialized
INFO - 2018-09-28 08:54:28 --> Helper loaded: url_helper
INFO - 2018-09-28 08:54:28 --> Helper loaded: form_helper
INFO - 2018-09-28 08:54:28 --> Helper loaded: html_helper
INFO - 2018-09-28 08:54:28 --> Database Driver Class Initialized
INFO - 2018-09-28 08:54:28 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:54:28 --> Model "User_model" initialized
INFO - 2018-09-28 08:54:28 --> Model "Project_model" initialized
INFO - 2018-09-28 08:54:28 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:54:28 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:54:28 --> Controller Class Initialized
INFO - 2018-09-28 08:54:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-28 08:54:28 --> Severity: Notice --> Undefined variable: list_library D:\xampp\htdocs\code_igniter\application\views\project_views\layouts\main.php 101
INFO - 2018-09-28 08:54:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:54:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:54:28 --> Final output sent to browser
DEBUG - 2018-09-28 08:54:28 --> Total execution time: 0.0540
INFO - 2018-09-28 08:54:44 --> Config Class Initialized
INFO - 2018-09-28 08:54:44 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:54:44 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:54:44 --> Utf8 Class Initialized
INFO - 2018-09-28 08:54:44 --> URI Class Initialized
INFO - 2018-09-28 08:54:44 --> Router Class Initialized
INFO - 2018-09-28 08:54:44 --> Output Class Initialized
INFO - 2018-09-28 08:54:44 --> Security Class Initialized
DEBUG - 2018-09-28 08:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:54:44 --> Input Class Initialized
INFO - 2018-09-28 08:54:44 --> Language Class Initialized
INFO - 2018-09-28 08:54:44 --> Loader Class Initialized
INFO - 2018-09-28 08:54:44 --> Helper loaded: url_helper
INFO - 2018-09-28 08:54:44 --> Helper loaded: form_helper
INFO - 2018-09-28 08:54:44 --> Helper loaded: html_helper
INFO - 2018-09-28 08:54:44 --> Database Driver Class Initialized
INFO - 2018-09-28 08:54:44 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:54:44 --> Model "User_model" initialized
INFO - 2018-09-28 08:54:44 --> Model "Project_model" initialized
INFO - 2018-09-28 08:54:44 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:54:44 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:54:44 --> Controller Class Initialized
INFO - 2018-09-28 08:54:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-28 08:54:44 --> Severity: Notice --> Undefined variable: list_library D:\xampp\htdocs\code_igniter\application\views\project_views\layouts\main.php 101
INFO - 2018-09-28 08:54:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
ERROR - 2018-09-28 08:54:44 --> Severity: Notice --> Undefined variable: list_library D:\xampp\htdocs\code_igniter\application\views\project_views\layouts\main.php 107
INFO - 2018-09-28 08:54:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:54:44 --> Final output sent to browser
DEBUG - 2018-09-28 08:54:44 --> Total execution time: 0.0600
INFO - 2018-09-28 08:54:53 --> Config Class Initialized
INFO - 2018-09-28 08:54:53 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:54:53 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:54:53 --> Utf8 Class Initialized
INFO - 2018-09-28 08:54:53 --> URI Class Initialized
INFO - 2018-09-28 08:54:53 --> Router Class Initialized
INFO - 2018-09-28 08:54:53 --> Output Class Initialized
INFO - 2018-09-28 08:54:53 --> Security Class Initialized
DEBUG - 2018-09-28 08:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:54:53 --> Input Class Initialized
INFO - 2018-09-28 08:54:53 --> Language Class Initialized
INFO - 2018-09-28 08:54:53 --> Loader Class Initialized
INFO - 2018-09-28 08:54:53 --> Helper loaded: url_helper
INFO - 2018-09-28 08:54:53 --> Helper loaded: form_helper
INFO - 2018-09-28 08:54:53 --> Helper loaded: html_helper
INFO - 2018-09-28 08:54:53 --> Database Driver Class Initialized
INFO - 2018-09-28 08:54:53 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:54:53 --> Model "User_model" initialized
INFO - 2018-09-28 08:54:53 --> Model "Project_model" initialized
INFO - 2018-09-28 08:54:53 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:54:53 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:54:53 --> Controller Class Initialized
INFO - 2018-09-28 08:54:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-28 08:54:53 --> Severity: Notice --> Undefined variable: list_library D:\xampp\htdocs\code_igniter\application\views\project_views\layouts\main.php 101
INFO - 2018-09-28 08:54:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:54:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:54:53 --> Final output sent to browser
DEBUG - 2018-09-28 08:54:53 --> Total execution time: 0.0530
INFO - 2018-09-28 08:55:25 --> Config Class Initialized
INFO - 2018-09-28 08:55:25 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:55:25 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:55:25 --> Utf8 Class Initialized
INFO - 2018-09-28 08:55:25 --> URI Class Initialized
INFO - 2018-09-28 08:55:25 --> Router Class Initialized
INFO - 2018-09-28 08:55:25 --> Output Class Initialized
INFO - 2018-09-28 08:55:25 --> Security Class Initialized
DEBUG - 2018-09-28 08:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:55:25 --> Input Class Initialized
INFO - 2018-09-28 08:55:25 --> Language Class Initialized
INFO - 2018-09-28 08:55:25 --> Loader Class Initialized
INFO - 2018-09-28 08:55:25 --> Helper loaded: url_helper
INFO - 2018-09-28 08:55:25 --> Helper loaded: form_helper
INFO - 2018-09-28 08:55:25 --> Helper loaded: html_helper
INFO - 2018-09-28 08:55:25 --> Database Driver Class Initialized
INFO - 2018-09-28 08:55:25 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:55:25 --> Model "User_model" initialized
INFO - 2018-09-28 08:55:25 --> Model "Project_model" initialized
INFO - 2018-09-28 08:55:25 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:55:25 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:55:25 --> Controller Class Initialized
INFO - 2018-09-28 08:55:25 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-28 08:55:25 --> Severity: Notice --> Undefined variable: list_library D:\xampp\htdocs\code_igniter\application\views\project_views\layouts\main.php 101
ERROR - 2018-09-28 08:55:25 --> Severity: Notice --> Undefined variable: list_library D:\xampp\htdocs\code_igniter\application\views\project_views\users\register_view.php 60
INFO - 2018-09-28 08:55:25 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:55:25 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:55:25 --> Final output sent to browser
DEBUG - 2018-09-28 08:55:25 --> Total execution time: 0.0400
INFO - 2018-09-28 08:55:42 --> Config Class Initialized
INFO - 2018-09-28 08:55:42 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:55:42 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:55:42 --> Utf8 Class Initialized
INFO - 2018-09-28 08:55:42 --> URI Class Initialized
INFO - 2018-09-28 08:55:42 --> Router Class Initialized
INFO - 2018-09-28 08:55:42 --> Output Class Initialized
INFO - 2018-09-28 08:55:42 --> Security Class Initialized
DEBUG - 2018-09-28 08:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:55:42 --> Input Class Initialized
INFO - 2018-09-28 08:55:42 --> Language Class Initialized
INFO - 2018-09-28 08:55:42 --> Loader Class Initialized
INFO - 2018-09-28 08:55:42 --> Helper loaded: url_helper
INFO - 2018-09-28 08:55:42 --> Helper loaded: form_helper
INFO - 2018-09-28 08:55:42 --> Helper loaded: html_helper
INFO - 2018-09-28 08:55:42 --> Database Driver Class Initialized
INFO - 2018-09-28 08:55:42 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:55:42 --> Model "User_model" initialized
INFO - 2018-09-28 08:55:42 --> Model "Project_model" initialized
INFO - 2018-09-28 08:55:42 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:55:42 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:55:42 --> Controller Class Initialized
INFO - 2018-09-28 08:55:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-28 08:55:42 --> Severity: Notice --> Undefined variable: list_library D:\xampp\htdocs\code_igniter\application\views\project_views\layouts\main.php 101
INFO - 2018-09-28 08:55:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:55:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:55:42 --> Final output sent to browser
DEBUG - 2018-09-28 08:55:42 --> Total execution time: 0.0450
INFO - 2018-09-28 08:56:00 --> Config Class Initialized
INFO - 2018-09-28 08:56:00 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:56:00 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:56:00 --> Utf8 Class Initialized
INFO - 2018-09-28 08:56:00 --> URI Class Initialized
INFO - 2018-09-28 08:56:00 --> Router Class Initialized
INFO - 2018-09-28 08:56:00 --> Output Class Initialized
INFO - 2018-09-28 08:56:00 --> Security Class Initialized
DEBUG - 2018-09-28 08:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:56:00 --> Input Class Initialized
INFO - 2018-09-28 08:56:00 --> Language Class Initialized
INFO - 2018-09-28 08:56:00 --> Loader Class Initialized
INFO - 2018-09-28 08:56:00 --> Helper loaded: url_helper
INFO - 2018-09-28 08:56:00 --> Helper loaded: form_helper
INFO - 2018-09-28 08:56:00 --> Helper loaded: html_helper
INFO - 2018-09-28 08:56:00 --> Database Driver Class Initialized
INFO - 2018-09-28 08:56:00 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:56:00 --> Model "User_model" initialized
INFO - 2018-09-28 08:56:00 --> Model "Project_model" initialized
INFO - 2018-09-28 08:56:00 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:56:00 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:56:00 --> Controller Class Initialized
INFO - 2018-09-28 08:56:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:56:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:56:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:56:00 --> Final output sent to browser
DEBUG - 2018-09-28 08:56:00 --> Total execution time: 0.0480
INFO - 2018-09-28 08:56:02 --> Config Class Initialized
INFO - 2018-09-28 08:56:02 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:56:02 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:56:02 --> Utf8 Class Initialized
INFO - 2018-09-28 08:56:02 --> URI Class Initialized
INFO - 2018-09-28 08:56:02 --> Router Class Initialized
INFO - 2018-09-28 08:56:02 --> Output Class Initialized
INFO - 2018-09-28 08:56:02 --> Security Class Initialized
DEBUG - 2018-09-28 08:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:56:02 --> Input Class Initialized
INFO - 2018-09-28 08:56:02 --> Language Class Initialized
INFO - 2018-09-28 08:56:02 --> Loader Class Initialized
INFO - 2018-09-28 08:56:02 --> Helper loaded: url_helper
INFO - 2018-09-28 08:56:02 --> Helper loaded: form_helper
INFO - 2018-09-28 08:56:02 --> Helper loaded: html_helper
INFO - 2018-09-28 08:56:02 --> Database Driver Class Initialized
INFO - 2018-09-28 08:56:02 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:56:02 --> Model "User_model" initialized
INFO - 2018-09-28 08:56:02 --> Model "Project_model" initialized
INFO - 2018-09-28 08:56:02 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:56:02 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:56:02 --> Controller Class Initialized
INFO - 2018-09-28 08:56:02 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:56:02 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:56:02 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:56:02 --> Final output sent to browser
DEBUG - 2018-09-28 08:56:02 --> Total execution time: 0.0620
INFO - 2018-09-28 08:56:03 --> Config Class Initialized
INFO - 2018-09-28 08:56:03 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:56:03 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:56:03 --> Utf8 Class Initialized
INFO - 2018-09-28 08:56:03 --> URI Class Initialized
INFO - 2018-09-28 08:56:03 --> Router Class Initialized
INFO - 2018-09-28 08:56:03 --> Output Class Initialized
INFO - 2018-09-28 08:56:03 --> Security Class Initialized
DEBUG - 2018-09-28 08:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:56:03 --> Input Class Initialized
INFO - 2018-09-28 08:56:03 --> Language Class Initialized
INFO - 2018-09-28 08:56:03 --> Loader Class Initialized
INFO - 2018-09-28 08:56:03 --> Helper loaded: url_helper
INFO - 2018-09-28 08:56:03 --> Helper loaded: form_helper
INFO - 2018-09-28 08:56:03 --> Helper loaded: html_helper
INFO - 2018-09-28 08:56:03 --> Database Driver Class Initialized
INFO - 2018-09-28 08:56:03 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:56:03 --> Model "User_model" initialized
INFO - 2018-09-28 08:56:03 --> Model "Project_model" initialized
INFO - 2018-09-28 08:56:03 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:56:03 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:56:03 --> Controller Class Initialized
INFO - 2018-09-28 08:56:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:56:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:56:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:56:03 --> Final output sent to browser
DEBUG - 2018-09-28 08:56:03 --> Total execution time: 0.0560
INFO - 2018-09-28 08:56:04 --> Config Class Initialized
INFO - 2018-09-28 08:56:04 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:56:04 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:56:04 --> Utf8 Class Initialized
INFO - 2018-09-28 08:56:04 --> URI Class Initialized
INFO - 2018-09-28 08:56:04 --> Router Class Initialized
INFO - 2018-09-28 08:56:04 --> Output Class Initialized
INFO - 2018-09-28 08:56:04 --> Security Class Initialized
DEBUG - 2018-09-28 08:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:56:04 --> Input Class Initialized
INFO - 2018-09-28 08:56:04 --> Language Class Initialized
INFO - 2018-09-28 08:56:04 --> Loader Class Initialized
INFO - 2018-09-28 08:56:04 --> Helper loaded: url_helper
INFO - 2018-09-28 08:56:04 --> Helper loaded: form_helper
INFO - 2018-09-28 08:56:04 --> Helper loaded: html_helper
INFO - 2018-09-28 08:56:04 --> Database Driver Class Initialized
INFO - 2018-09-28 08:56:04 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:56:04 --> Model "User_model" initialized
INFO - 2018-09-28 08:56:04 --> Model "Project_model" initialized
INFO - 2018-09-28 08:56:04 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:56:04 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:56:04 --> Controller Class Initialized
INFO - 2018-09-28 08:56:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:56:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:56:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:56:04 --> Final output sent to browser
DEBUG - 2018-09-28 08:56:04 --> Total execution time: 0.0570
INFO - 2018-09-28 08:56:04 --> Config Class Initialized
INFO - 2018-09-28 08:56:04 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:56:04 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:56:04 --> Utf8 Class Initialized
INFO - 2018-09-28 08:56:04 --> URI Class Initialized
INFO - 2018-09-28 08:56:04 --> Router Class Initialized
INFO - 2018-09-28 08:56:04 --> Output Class Initialized
INFO - 2018-09-28 08:56:04 --> Security Class Initialized
DEBUG - 2018-09-28 08:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:56:04 --> Input Class Initialized
INFO - 2018-09-28 08:56:04 --> Language Class Initialized
INFO - 2018-09-28 08:56:04 --> Loader Class Initialized
INFO - 2018-09-28 08:56:04 --> Helper loaded: url_helper
INFO - 2018-09-28 08:56:04 --> Helper loaded: form_helper
INFO - 2018-09-28 08:56:04 --> Helper loaded: html_helper
INFO - 2018-09-28 08:56:04 --> Database Driver Class Initialized
INFO - 2018-09-28 08:56:04 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:56:04 --> Model "User_model" initialized
INFO - 2018-09-28 08:56:04 --> Model "Project_model" initialized
INFO - 2018-09-28 08:56:04 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:56:04 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:56:04 --> Controller Class Initialized
INFO - 2018-09-28 08:56:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:56:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:56:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:56:04 --> Final output sent to browser
DEBUG - 2018-09-28 08:56:04 --> Total execution time: 0.0350
INFO - 2018-09-28 08:56:04 --> Config Class Initialized
INFO - 2018-09-28 08:56:04 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:56:04 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:56:04 --> Utf8 Class Initialized
INFO - 2018-09-28 08:56:04 --> URI Class Initialized
INFO - 2018-09-28 08:56:04 --> Router Class Initialized
INFO - 2018-09-28 08:56:04 --> Output Class Initialized
INFO - 2018-09-28 08:56:04 --> Security Class Initialized
DEBUG - 2018-09-28 08:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:56:04 --> Input Class Initialized
INFO - 2018-09-28 08:56:04 --> Language Class Initialized
INFO - 2018-09-28 08:56:04 --> Loader Class Initialized
INFO - 2018-09-28 08:56:04 --> Helper loaded: url_helper
INFO - 2018-09-28 08:56:04 --> Helper loaded: form_helper
INFO - 2018-09-28 08:56:04 --> Helper loaded: html_helper
INFO - 2018-09-28 08:56:04 --> Database Driver Class Initialized
INFO - 2018-09-28 08:56:04 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:56:04 --> Model "User_model" initialized
INFO - 2018-09-28 08:56:04 --> Model "Project_model" initialized
INFO - 2018-09-28 08:56:04 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:56:04 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:56:04 --> Controller Class Initialized
INFO - 2018-09-28 08:56:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:56:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:56:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:56:04 --> Final output sent to browser
DEBUG - 2018-09-28 08:56:04 --> Total execution time: 0.0430
INFO - 2018-09-28 08:56:05 --> Config Class Initialized
INFO - 2018-09-28 08:56:05 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:56:05 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:56:05 --> Utf8 Class Initialized
INFO - 2018-09-28 08:56:05 --> URI Class Initialized
INFO - 2018-09-28 08:56:05 --> Router Class Initialized
INFO - 2018-09-28 08:56:05 --> Output Class Initialized
INFO - 2018-09-28 08:56:05 --> Security Class Initialized
DEBUG - 2018-09-28 08:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:56:05 --> Input Class Initialized
INFO - 2018-09-28 08:56:05 --> Language Class Initialized
INFO - 2018-09-28 08:56:05 --> Loader Class Initialized
INFO - 2018-09-28 08:56:05 --> Helper loaded: url_helper
INFO - 2018-09-28 08:56:05 --> Helper loaded: form_helper
INFO - 2018-09-28 08:56:05 --> Helper loaded: html_helper
INFO - 2018-09-28 08:56:05 --> Database Driver Class Initialized
INFO - 2018-09-28 08:56:05 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:56:05 --> Model "User_model" initialized
INFO - 2018-09-28 08:56:05 --> Model "Project_model" initialized
INFO - 2018-09-28 08:56:05 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:56:05 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:56:05 --> Controller Class Initialized
INFO - 2018-09-28 08:56:05 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:56:05 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:56:05 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:56:05 --> Final output sent to browser
DEBUG - 2018-09-28 08:56:05 --> Total execution time: 0.0440
INFO - 2018-09-28 08:56:06 --> Config Class Initialized
INFO - 2018-09-28 08:56:06 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:56:06 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:56:06 --> Utf8 Class Initialized
INFO - 2018-09-28 08:56:06 --> URI Class Initialized
INFO - 2018-09-28 08:56:06 --> Router Class Initialized
INFO - 2018-09-28 08:56:06 --> Output Class Initialized
INFO - 2018-09-28 08:56:06 --> Security Class Initialized
DEBUG - 2018-09-28 08:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:56:06 --> Input Class Initialized
INFO - 2018-09-28 08:56:06 --> Language Class Initialized
INFO - 2018-09-28 08:56:06 --> Loader Class Initialized
INFO - 2018-09-28 08:56:06 --> Helper loaded: url_helper
INFO - 2018-09-28 08:56:06 --> Helper loaded: form_helper
INFO - 2018-09-28 08:56:06 --> Helper loaded: html_helper
INFO - 2018-09-28 08:56:06 --> Database Driver Class Initialized
INFO - 2018-09-28 08:56:06 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:56:06 --> Model "User_model" initialized
INFO - 2018-09-28 08:56:06 --> Model "Project_model" initialized
INFO - 2018-09-28 08:56:06 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:56:06 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:56:06 --> Controller Class Initialized
INFO - 2018-09-28 08:56:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:56:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-28 08:56:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:56:06 --> Final output sent to browser
DEBUG - 2018-09-28 08:56:06 --> Total execution time: 0.0390
INFO - 2018-09-28 08:56:07 --> Config Class Initialized
INFO - 2018-09-28 08:56:07 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:56:07 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:56:07 --> Utf8 Class Initialized
INFO - 2018-09-28 08:56:07 --> URI Class Initialized
INFO - 2018-09-28 08:56:07 --> Router Class Initialized
INFO - 2018-09-28 08:56:07 --> Output Class Initialized
INFO - 2018-09-28 08:56:07 --> Security Class Initialized
DEBUG - 2018-09-28 08:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:56:07 --> Input Class Initialized
INFO - 2018-09-28 08:56:07 --> Language Class Initialized
INFO - 2018-09-28 08:56:07 --> Loader Class Initialized
INFO - 2018-09-28 08:56:07 --> Helper loaded: url_helper
INFO - 2018-09-28 08:56:07 --> Helper loaded: form_helper
INFO - 2018-09-28 08:56:07 --> Helper loaded: html_helper
INFO - 2018-09-28 08:56:07 --> Database Driver Class Initialized
INFO - 2018-09-28 08:56:07 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:56:07 --> Model "User_model" initialized
INFO - 2018-09-28 08:56:07 --> Model "Project_model" initialized
INFO - 2018-09-28 08:56:07 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:56:07 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:56:07 --> Controller Class Initialized
INFO - 2018-09-28 08:56:07 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:56:07 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:56:07 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:56:07 --> Final output sent to browser
DEBUG - 2018-09-28 08:56:07 --> Total execution time: 0.0380
INFO - 2018-09-28 08:56:08 --> Config Class Initialized
INFO - 2018-09-28 08:56:08 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:56:08 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:56:08 --> Utf8 Class Initialized
INFO - 2018-09-28 08:56:08 --> URI Class Initialized
INFO - 2018-09-28 08:56:08 --> Router Class Initialized
INFO - 2018-09-28 08:56:08 --> Output Class Initialized
INFO - 2018-09-28 08:56:08 --> Security Class Initialized
DEBUG - 2018-09-28 08:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:56:08 --> Input Class Initialized
INFO - 2018-09-28 08:56:08 --> Language Class Initialized
INFO - 2018-09-28 08:56:08 --> Loader Class Initialized
INFO - 2018-09-28 08:56:08 --> Helper loaded: url_helper
INFO - 2018-09-28 08:56:08 --> Helper loaded: form_helper
INFO - 2018-09-28 08:56:08 --> Helper loaded: html_helper
INFO - 2018-09-28 08:56:08 --> Database Driver Class Initialized
INFO - 2018-09-28 08:56:08 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:56:08 --> Model "User_model" initialized
INFO - 2018-09-28 08:56:08 --> Model "Project_model" initialized
INFO - 2018-09-28 08:56:08 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:56:08 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:56:08 --> Controller Class Initialized
INFO - 2018-09-28 08:56:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:56:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-28 08:56:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:56:08 --> Final output sent to browser
DEBUG - 2018-09-28 08:56:08 --> Total execution time: 0.0600
INFO - 2018-09-28 08:56:09 --> Config Class Initialized
INFO - 2018-09-28 08:56:09 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:56:09 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:56:09 --> Utf8 Class Initialized
INFO - 2018-09-28 08:56:09 --> URI Class Initialized
INFO - 2018-09-28 08:56:09 --> Router Class Initialized
INFO - 2018-09-28 08:56:09 --> Output Class Initialized
INFO - 2018-09-28 08:56:09 --> Security Class Initialized
DEBUG - 2018-09-28 08:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:56:09 --> Input Class Initialized
INFO - 2018-09-28 08:56:09 --> Language Class Initialized
INFO - 2018-09-28 08:56:09 --> Loader Class Initialized
INFO - 2018-09-28 08:56:09 --> Helper loaded: url_helper
INFO - 2018-09-28 08:56:09 --> Helper loaded: form_helper
INFO - 2018-09-28 08:56:09 --> Helper loaded: html_helper
INFO - 2018-09-28 08:56:09 --> Database Driver Class Initialized
INFO - 2018-09-28 08:56:09 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:56:09 --> Model "User_model" initialized
INFO - 2018-09-28 08:56:09 --> Model "Project_model" initialized
INFO - 2018-09-28 08:56:09 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:56:09 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:56:09 --> Controller Class Initialized
INFO - 2018-09-28 08:56:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:56:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:56:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:56:09 --> Final output sent to browser
DEBUG - 2018-09-28 08:56:09 --> Total execution time: 0.0560
INFO - 2018-09-28 08:56:10 --> Config Class Initialized
INFO - 2018-09-28 08:56:10 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:56:10 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:56:10 --> Utf8 Class Initialized
INFO - 2018-09-28 08:56:10 --> URI Class Initialized
INFO - 2018-09-28 08:56:10 --> Router Class Initialized
INFO - 2018-09-28 08:56:10 --> Output Class Initialized
INFO - 2018-09-28 08:56:10 --> Security Class Initialized
DEBUG - 2018-09-28 08:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:56:10 --> Input Class Initialized
INFO - 2018-09-28 08:56:10 --> Language Class Initialized
INFO - 2018-09-28 08:56:10 --> Loader Class Initialized
INFO - 2018-09-28 08:56:10 --> Helper loaded: url_helper
INFO - 2018-09-28 08:56:10 --> Helper loaded: form_helper
INFO - 2018-09-28 08:56:10 --> Helper loaded: html_helper
INFO - 2018-09-28 08:56:10 --> Database Driver Class Initialized
INFO - 2018-09-28 08:56:10 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:56:10 --> Model "User_model" initialized
INFO - 2018-09-28 08:56:10 --> Model "Project_model" initialized
INFO - 2018-09-28 08:56:10 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:56:10 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:56:10 --> Controller Class Initialized
INFO - 2018-09-28 08:56:10 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:56:10 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-28 08:56:10 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:56:10 --> Final output sent to browser
DEBUG - 2018-09-28 08:56:10 --> Total execution time: 0.0610
INFO - 2018-09-28 08:56:11 --> Config Class Initialized
INFO - 2018-09-28 08:56:11 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:56:11 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:56:11 --> Utf8 Class Initialized
INFO - 2018-09-28 08:56:11 --> URI Class Initialized
INFO - 2018-09-28 08:56:11 --> Router Class Initialized
INFO - 2018-09-28 08:56:11 --> Output Class Initialized
INFO - 2018-09-28 08:56:11 --> Security Class Initialized
DEBUG - 2018-09-28 08:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:56:11 --> Input Class Initialized
INFO - 2018-09-28 08:56:11 --> Language Class Initialized
INFO - 2018-09-28 08:56:11 --> Loader Class Initialized
INFO - 2018-09-28 08:56:11 --> Helper loaded: url_helper
INFO - 2018-09-28 08:56:11 --> Helper loaded: form_helper
INFO - 2018-09-28 08:56:11 --> Helper loaded: html_helper
INFO - 2018-09-28 08:56:11 --> Database Driver Class Initialized
INFO - 2018-09-28 08:56:12 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:56:12 --> Model "User_model" initialized
INFO - 2018-09-28 08:56:12 --> Model "Project_model" initialized
INFO - 2018-09-28 08:56:12 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:56:12 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:56:12 --> Controller Class Initialized
INFO - 2018-09-28 08:56:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:56:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:56:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:56:12 --> Final output sent to browser
DEBUG - 2018-09-28 08:56:12 --> Total execution time: 0.0560
INFO - 2018-09-28 08:56:13 --> Config Class Initialized
INFO - 2018-09-28 08:56:13 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:56:13 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:56:13 --> Utf8 Class Initialized
INFO - 2018-09-28 08:56:13 --> URI Class Initialized
INFO - 2018-09-28 08:56:13 --> Router Class Initialized
INFO - 2018-09-28 08:56:13 --> Output Class Initialized
INFO - 2018-09-28 08:56:13 --> Security Class Initialized
DEBUG - 2018-09-28 08:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:56:13 --> Input Class Initialized
INFO - 2018-09-28 08:56:13 --> Language Class Initialized
INFO - 2018-09-28 08:56:13 --> Loader Class Initialized
INFO - 2018-09-28 08:56:13 --> Helper loaded: url_helper
INFO - 2018-09-28 08:56:13 --> Helper loaded: form_helper
INFO - 2018-09-28 08:56:13 --> Helper loaded: html_helper
INFO - 2018-09-28 08:56:13 --> Database Driver Class Initialized
INFO - 2018-09-28 08:56:13 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:56:13 --> Model "User_model" initialized
INFO - 2018-09-28 08:56:13 --> Model "Project_model" initialized
INFO - 2018-09-28 08:56:13 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:56:13 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:56:13 --> Controller Class Initialized
INFO - 2018-09-28 08:56:13 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:56:13 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-28 08:56:13 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:56:13 --> Final output sent to browser
DEBUG - 2018-09-28 08:56:13 --> Total execution time: 0.0800
INFO - 2018-09-28 08:56:15 --> Config Class Initialized
INFO - 2018-09-28 08:56:15 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:56:15 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:56:15 --> Utf8 Class Initialized
INFO - 2018-09-28 08:56:15 --> URI Class Initialized
INFO - 2018-09-28 08:56:15 --> Router Class Initialized
INFO - 2018-09-28 08:56:15 --> Output Class Initialized
INFO - 2018-09-28 08:56:15 --> Security Class Initialized
DEBUG - 2018-09-28 08:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:56:15 --> Input Class Initialized
INFO - 2018-09-28 08:56:15 --> Language Class Initialized
INFO - 2018-09-28 08:56:15 --> Loader Class Initialized
INFO - 2018-09-28 08:56:15 --> Helper loaded: url_helper
INFO - 2018-09-28 08:56:15 --> Helper loaded: form_helper
INFO - 2018-09-28 08:56:15 --> Helper loaded: html_helper
INFO - 2018-09-28 08:56:15 --> Database Driver Class Initialized
INFO - 2018-09-28 08:56:15 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:56:15 --> Model "User_model" initialized
INFO - 2018-09-28 08:56:15 --> Model "Project_model" initialized
INFO - 2018-09-28 08:56:15 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:56:15 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:56:15 --> Controller Class Initialized
INFO - 2018-09-28 08:56:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:56:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:56:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:56:15 --> Final output sent to browser
DEBUG - 2018-09-28 08:56:15 --> Total execution time: 0.0510
INFO - 2018-09-28 08:58:15 --> Config Class Initialized
INFO - 2018-09-28 08:58:15 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:58:15 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:58:15 --> Utf8 Class Initialized
INFO - 2018-09-28 08:58:15 --> URI Class Initialized
INFO - 2018-09-28 08:58:15 --> Router Class Initialized
INFO - 2018-09-28 08:58:15 --> Output Class Initialized
INFO - 2018-09-28 08:58:15 --> Security Class Initialized
DEBUG - 2018-09-28 08:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:58:15 --> Input Class Initialized
INFO - 2018-09-28 08:58:15 --> Language Class Initialized
INFO - 2018-09-28 08:58:15 --> Loader Class Initialized
INFO - 2018-09-28 08:58:15 --> Helper loaded: url_helper
INFO - 2018-09-28 08:58:15 --> Helper loaded: form_helper
INFO - 2018-09-28 08:58:15 --> Helper loaded: html_helper
INFO - 2018-09-28 08:58:15 --> Database Driver Class Initialized
INFO - 2018-09-28 08:58:15 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:58:15 --> Model "User_model" initialized
INFO - 2018-09-28 08:58:15 --> Model "Project_model" initialized
INFO - 2018-09-28 08:58:15 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:58:15 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:58:15 --> Controller Class Initialized
INFO - 2018-09-28 08:58:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:58:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:58:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:58:15 --> Final output sent to browser
DEBUG - 2018-09-28 08:58:15 --> Total execution time: 0.0410
INFO - 2018-09-28 08:58:28 --> Config Class Initialized
INFO - 2018-09-28 08:58:28 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:58:28 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:58:28 --> Utf8 Class Initialized
INFO - 2018-09-28 08:58:28 --> URI Class Initialized
INFO - 2018-09-28 08:58:28 --> Router Class Initialized
INFO - 2018-09-28 08:58:28 --> Output Class Initialized
INFO - 2018-09-28 08:58:28 --> Security Class Initialized
DEBUG - 2018-09-28 08:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:58:28 --> Input Class Initialized
INFO - 2018-09-28 08:58:28 --> Language Class Initialized
INFO - 2018-09-28 08:58:28 --> Loader Class Initialized
INFO - 2018-09-28 08:58:28 --> Helper loaded: url_helper
INFO - 2018-09-28 08:58:28 --> Helper loaded: form_helper
INFO - 2018-09-28 08:58:28 --> Helper loaded: html_helper
INFO - 2018-09-28 08:58:28 --> Database Driver Class Initialized
INFO - 2018-09-28 08:58:28 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:58:28 --> Model "User_model" initialized
INFO - 2018-09-28 08:58:28 --> Model "Project_model" initialized
INFO - 2018-09-28 08:58:28 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:58:28 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:58:28 --> Controller Class Initialized
INFO - 2018-09-28 08:58:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:58:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:58:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:58:28 --> Final output sent to browser
DEBUG - 2018-09-28 08:58:28 --> Total execution time: 0.0500
INFO - 2018-09-28 08:58:29 --> Config Class Initialized
INFO - 2018-09-28 08:58:29 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:58:29 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:58:29 --> Utf8 Class Initialized
INFO - 2018-09-28 08:58:29 --> URI Class Initialized
INFO - 2018-09-28 08:58:29 --> Router Class Initialized
INFO - 2018-09-28 08:58:29 --> Output Class Initialized
INFO - 2018-09-28 08:58:29 --> Security Class Initialized
DEBUG - 2018-09-28 08:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:58:29 --> Input Class Initialized
INFO - 2018-09-28 08:58:29 --> Language Class Initialized
INFO - 2018-09-28 08:58:29 --> Loader Class Initialized
INFO - 2018-09-28 08:58:29 --> Helper loaded: url_helper
INFO - 2018-09-28 08:58:29 --> Helper loaded: form_helper
INFO - 2018-09-28 08:58:29 --> Helper loaded: html_helper
INFO - 2018-09-28 08:58:29 --> Database Driver Class Initialized
INFO - 2018-09-28 08:58:29 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:58:29 --> Model "User_model" initialized
INFO - 2018-09-28 08:58:29 --> Model "Project_model" initialized
INFO - 2018-09-28 08:58:29 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:58:29 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:58:29 --> Controller Class Initialized
INFO - 2018-09-28 08:58:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:58:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:58:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:58:29 --> Final output sent to browser
DEBUG - 2018-09-28 08:58:29 --> Total execution time: 0.0500
INFO - 2018-09-28 08:58:52 --> Config Class Initialized
INFO - 2018-09-28 08:58:52 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:58:52 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:58:52 --> Utf8 Class Initialized
INFO - 2018-09-28 08:58:52 --> URI Class Initialized
INFO - 2018-09-28 08:58:52 --> Router Class Initialized
INFO - 2018-09-28 08:58:52 --> Output Class Initialized
INFO - 2018-09-28 08:58:52 --> Security Class Initialized
DEBUG - 2018-09-28 08:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:58:52 --> Input Class Initialized
INFO - 2018-09-28 08:58:52 --> Language Class Initialized
INFO - 2018-09-28 08:58:52 --> Loader Class Initialized
INFO - 2018-09-28 08:58:52 --> Helper loaded: url_helper
INFO - 2018-09-28 08:58:52 --> Helper loaded: form_helper
INFO - 2018-09-28 08:58:52 --> Helper loaded: html_helper
INFO - 2018-09-28 08:58:52 --> Database Driver Class Initialized
INFO - 2018-09-28 08:58:52 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:58:52 --> Model "User_model" initialized
INFO - 2018-09-28 08:58:52 --> Model "Project_model" initialized
INFO - 2018-09-28 08:58:52 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:58:52 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:58:52 --> Controller Class Initialized
INFO - 2018-09-28 08:58:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:58:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:58:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:58:52 --> Final output sent to browser
DEBUG - 2018-09-28 08:58:52 --> Total execution time: 0.0620
INFO - 2018-09-28 08:58:52 --> Config Class Initialized
INFO - 2018-09-28 08:58:52 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:58:52 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:58:52 --> Utf8 Class Initialized
INFO - 2018-09-28 08:58:52 --> URI Class Initialized
INFO - 2018-09-28 08:58:52 --> Router Class Initialized
INFO - 2018-09-28 08:58:52 --> Output Class Initialized
INFO - 2018-09-28 08:58:52 --> Security Class Initialized
DEBUG - 2018-09-28 08:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:58:52 --> Input Class Initialized
INFO - 2018-09-28 08:58:52 --> Language Class Initialized
INFO - 2018-09-28 08:58:52 --> Loader Class Initialized
INFO - 2018-09-28 08:58:52 --> Helper loaded: url_helper
INFO - 2018-09-28 08:58:52 --> Helper loaded: form_helper
INFO - 2018-09-28 08:58:52 --> Helper loaded: html_helper
INFO - 2018-09-28 08:58:52 --> Database Driver Class Initialized
INFO - 2018-09-28 08:58:52 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:58:52 --> Model "User_model" initialized
INFO - 2018-09-28 08:58:52 --> Model "Project_model" initialized
INFO - 2018-09-28 08:58:52 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:58:52 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:58:52 --> Controller Class Initialized
INFO - 2018-09-28 08:58:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:58:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-28 08:58:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:58:52 --> Final output sent to browser
DEBUG - 2018-09-28 08:58:52 --> Total execution time: 0.0490
INFO - 2018-09-28 08:58:53 --> Config Class Initialized
INFO - 2018-09-28 08:58:53 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:58:53 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:58:53 --> Utf8 Class Initialized
INFO - 2018-09-28 08:58:53 --> URI Class Initialized
INFO - 2018-09-28 08:58:53 --> Router Class Initialized
INFO - 2018-09-28 08:58:53 --> Output Class Initialized
INFO - 2018-09-28 08:58:53 --> Security Class Initialized
DEBUG - 2018-09-28 08:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:58:53 --> Input Class Initialized
INFO - 2018-09-28 08:58:53 --> Language Class Initialized
INFO - 2018-09-28 08:58:53 --> Loader Class Initialized
INFO - 2018-09-28 08:58:53 --> Helper loaded: url_helper
INFO - 2018-09-28 08:58:53 --> Helper loaded: form_helper
INFO - 2018-09-28 08:58:53 --> Helper loaded: html_helper
INFO - 2018-09-28 08:58:53 --> Database Driver Class Initialized
INFO - 2018-09-28 08:58:53 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:58:53 --> Model "User_model" initialized
INFO - 2018-09-28 08:58:53 --> Model "Project_model" initialized
INFO - 2018-09-28 08:58:53 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:58:53 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:58:53 --> Controller Class Initialized
INFO - 2018-09-28 08:58:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:58:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:58:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:58:53 --> Final output sent to browser
DEBUG - 2018-09-28 08:58:53 --> Total execution time: 0.0590
INFO - 2018-09-28 08:59:18 --> Config Class Initialized
INFO - 2018-09-28 08:59:18 --> Hooks Class Initialized
DEBUG - 2018-09-28 08:59:18 --> UTF-8 Support Enabled
INFO - 2018-09-28 08:59:18 --> Utf8 Class Initialized
INFO - 2018-09-28 08:59:18 --> URI Class Initialized
INFO - 2018-09-28 08:59:18 --> Router Class Initialized
INFO - 2018-09-28 08:59:18 --> Output Class Initialized
INFO - 2018-09-28 08:59:18 --> Security Class Initialized
DEBUG - 2018-09-28 08:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 08:59:18 --> Input Class Initialized
INFO - 2018-09-28 08:59:18 --> Language Class Initialized
INFO - 2018-09-28 08:59:18 --> Loader Class Initialized
INFO - 2018-09-28 08:59:18 --> Helper loaded: url_helper
INFO - 2018-09-28 08:59:18 --> Helper loaded: form_helper
INFO - 2018-09-28 08:59:18 --> Helper loaded: html_helper
INFO - 2018-09-28 08:59:18 --> Database Driver Class Initialized
INFO - 2018-09-28 08:59:18 --> Form Validation Class Initialized
DEBUG - 2018-09-28 08:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 08:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 08:59:18 --> Model "User_model" initialized
INFO - 2018-09-28 08:59:18 --> Model "Project_model" initialized
INFO - 2018-09-28 08:59:18 --> Model "Tasks_model" initialized
INFO - 2018-09-28 08:59:18 --> Model "Lists_model" initialized
INFO - 2018-09-28 08:59:18 --> Controller Class Initialized
INFO - 2018-09-28 08:59:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 08:59:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 08:59:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 08:59:18 --> Final output sent to browser
DEBUG - 2018-09-28 08:59:18 --> Total execution time: 0.0530
INFO - 2018-09-28 09:00:05 --> Config Class Initialized
INFO - 2018-09-28 09:00:05 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:00:05 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:00:05 --> Utf8 Class Initialized
INFO - 2018-09-28 09:00:05 --> URI Class Initialized
INFO - 2018-09-28 09:00:05 --> Router Class Initialized
INFO - 2018-09-28 09:00:05 --> Output Class Initialized
INFO - 2018-09-28 09:00:05 --> Security Class Initialized
DEBUG - 2018-09-28 09:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:00:05 --> Input Class Initialized
INFO - 2018-09-28 09:00:05 --> Language Class Initialized
INFO - 2018-09-28 09:00:05 --> Loader Class Initialized
INFO - 2018-09-28 09:00:05 --> Helper loaded: url_helper
INFO - 2018-09-28 09:00:05 --> Helper loaded: form_helper
INFO - 2018-09-28 09:00:05 --> Helper loaded: html_helper
INFO - 2018-09-28 09:00:05 --> Database Driver Class Initialized
INFO - 2018-09-28 09:00:05 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:00:05 --> Model "User_model" initialized
INFO - 2018-09-28 09:00:05 --> Model "Project_model" initialized
INFO - 2018-09-28 09:00:05 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:00:05 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:00:05 --> Controller Class Initialized
INFO - 2018-09-28 09:00:05 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:00:05 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 09:00:05 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:00:05 --> Final output sent to browser
DEBUG - 2018-09-28 09:00:05 --> Total execution time: 0.0400
INFO - 2018-09-28 09:00:25 --> Config Class Initialized
INFO - 2018-09-28 09:00:25 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:00:25 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:00:25 --> Utf8 Class Initialized
INFO - 2018-09-28 09:00:25 --> URI Class Initialized
INFO - 2018-09-28 09:00:25 --> Router Class Initialized
INFO - 2018-09-28 09:00:25 --> Output Class Initialized
INFO - 2018-09-28 09:00:25 --> Security Class Initialized
DEBUG - 2018-09-28 09:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:00:25 --> Input Class Initialized
INFO - 2018-09-28 09:00:25 --> Language Class Initialized
INFO - 2018-09-28 09:00:25 --> Loader Class Initialized
INFO - 2018-09-28 09:00:25 --> Helper loaded: url_helper
INFO - 2018-09-28 09:00:25 --> Helper loaded: form_helper
INFO - 2018-09-28 09:00:25 --> Helper loaded: html_helper
INFO - 2018-09-28 09:00:25 --> Database Driver Class Initialized
INFO - 2018-09-28 09:00:25 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:00:25 --> Model "User_model" initialized
INFO - 2018-09-28 09:00:25 --> Model "Project_model" initialized
INFO - 2018-09-28 09:00:25 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:00:25 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:00:25 --> Controller Class Initialized
INFO - 2018-09-28 09:00:25 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:00:25 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 09:00:25 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:00:25 --> Final output sent to browser
DEBUG - 2018-09-28 09:00:25 --> Total execution time: 0.0460
INFO - 2018-09-28 09:00:38 --> Config Class Initialized
INFO - 2018-09-28 09:00:38 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:00:38 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:00:38 --> Utf8 Class Initialized
INFO - 2018-09-28 09:00:38 --> URI Class Initialized
INFO - 2018-09-28 09:00:38 --> Router Class Initialized
INFO - 2018-09-28 09:00:38 --> Output Class Initialized
INFO - 2018-09-28 09:00:38 --> Security Class Initialized
DEBUG - 2018-09-28 09:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:00:38 --> Input Class Initialized
INFO - 2018-09-28 09:00:38 --> Language Class Initialized
INFO - 2018-09-28 09:00:38 --> Loader Class Initialized
INFO - 2018-09-28 09:00:38 --> Helper loaded: url_helper
INFO - 2018-09-28 09:00:38 --> Helper loaded: form_helper
INFO - 2018-09-28 09:00:38 --> Helper loaded: html_helper
INFO - 2018-09-28 09:00:38 --> Database Driver Class Initialized
INFO - 2018-09-28 09:00:38 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:00:38 --> Model "User_model" initialized
INFO - 2018-09-28 09:00:38 --> Model "Project_model" initialized
INFO - 2018-09-28 09:00:38 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:00:38 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:00:38 --> Controller Class Initialized
ERROR - 2018-09-28 09:00:38 --> Severity: Notice --> Undefined variable: This D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\users.php 9
ERROR - 2018-09-28 09:00:38 --> Severity: Notice --> Trying to get property 'uri' of non-object D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\users.php 9
ERROR - 2018-09-28 09:00:38 --> Severity: error --> Exception: Call to a member function segment() on null D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\users.php 9
INFO - 2018-09-28 09:00:45 --> Config Class Initialized
INFO - 2018-09-28 09:00:45 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:00:45 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:00:45 --> Utf8 Class Initialized
INFO - 2018-09-28 09:00:45 --> URI Class Initialized
INFO - 2018-09-28 09:00:45 --> Router Class Initialized
INFO - 2018-09-28 09:00:45 --> Output Class Initialized
INFO - 2018-09-28 09:00:45 --> Security Class Initialized
DEBUG - 2018-09-28 09:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:00:45 --> Input Class Initialized
INFO - 2018-09-28 09:00:45 --> Language Class Initialized
INFO - 2018-09-28 09:00:45 --> Loader Class Initialized
INFO - 2018-09-28 09:00:45 --> Helper loaded: url_helper
INFO - 2018-09-28 09:00:45 --> Helper loaded: form_helper
INFO - 2018-09-28 09:00:45 --> Helper loaded: html_helper
INFO - 2018-09-28 09:00:45 --> Database Driver Class Initialized
INFO - 2018-09-28 09:00:45 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:00:45 --> Model "User_model" initialized
INFO - 2018-09-28 09:00:45 --> Model "Project_model" initialized
INFO - 2018-09-28 09:00:45 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:00:45 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:00:45 --> Controller Class Initialized
INFO - 2018-09-28 09:00:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:00:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 09:00:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:00:45 --> Final output sent to browser
DEBUG - 2018-09-28 09:00:45 --> Total execution time: 0.0380
INFO - 2018-09-28 09:00:58 --> Config Class Initialized
INFO - 2018-09-28 09:00:58 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:00:58 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:00:58 --> Utf8 Class Initialized
INFO - 2018-09-28 09:00:58 --> URI Class Initialized
INFO - 2018-09-28 09:00:58 --> Router Class Initialized
INFO - 2018-09-28 09:00:58 --> Output Class Initialized
INFO - 2018-09-28 09:00:58 --> Security Class Initialized
DEBUG - 2018-09-28 09:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:00:58 --> Input Class Initialized
INFO - 2018-09-28 09:00:58 --> Language Class Initialized
INFO - 2018-09-28 09:00:58 --> Loader Class Initialized
INFO - 2018-09-28 09:00:58 --> Helper loaded: url_helper
INFO - 2018-09-28 09:00:58 --> Helper loaded: form_helper
INFO - 2018-09-28 09:00:58 --> Helper loaded: html_helper
INFO - 2018-09-28 09:00:58 --> Database Driver Class Initialized
INFO - 2018-09-28 09:00:58 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:00:58 --> Model "User_model" initialized
INFO - 2018-09-28 09:00:58 --> Model "Project_model" initialized
INFO - 2018-09-28 09:00:58 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:00:58 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:00:58 --> Controller Class Initialized
INFO - 2018-09-28 09:00:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:00:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 09:00:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:00:58 --> Final output sent to browser
DEBUG - 2018-09-28 09:00:58 --> Total execution time: 0.0410
INFO - 2018-09-28 09:01:13 --> Config Class Initialized
INFO - 2018-09-28 09:01:13 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:01:13 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:01:13 --> Utf8 Class Initialized
INFO - 2018-09-28 09:01:13 --> URI Class Initialized
INFO - 2018-09-28 09:01:13 --> Router Class Initialized
INFO - 2018-09-28 09:01:13 --> Output Class Initialized
INFO - 2018-09-28 09:01:13 --> Security Class Initialized
DEBUG - 2018-09-28 09:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:01:13 --> Input Class Initialized
INFO - 2018-09-28 09:01:13 --> Language Class Initialized
INFO - 2018-09-28 09:01:13 --> Loader Class Initialized
INFO - 2018-09-28 09:01:13 --> Helper loaded: url_helper
INFO - 2018-09-28 09:01:13 --> Helper loaded: form_helper
INFO - 2018-09-28 09:01:13 --> Helper loaded: html_helper
INFO - 2018-09-28 09:01:13 --> Database Driver Class Initialized
INFO - 2018-09-28 09:01:13 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:01:13 --> Model "User_model" initialized
INFO - 2018-09-28 09:01:13 --> Model "Project_model" initialized
INFO - 2018-09-28 09:01:13 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:01:13 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:01:13 --> Controller Class Initialized
INFO - 2018-09-28 09:01:13 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:01:13 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 09:01:13 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:01:13 --> Final output sent to browser
DEBUG - 2018-09-28 09:01:13 --> Total execution time: 0.0390
INFO - 2018-09-28 09:01:31 --> Config Class Initialized
INFO - 2018-09-28 09:01:31 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:01:31 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:01:31 --> Utf8 Class Initialized
INFO - 2018-09-28 09:01:31 --> URI Class Initialized
INFO - 2018-09-28 09:01:31 --> Router Class Initialized
INFO - 2018-09-28 09:01:31 --> Output Class Initialized
INFO - 2018-09-28 09:01:31 --> Security Class Initialized
DEBUG - 2018-09-28 09:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:01:31 --> Input Class Initialized
INFO - 2018-09-28 09:01:31 --> Language Class Initialized
INFO - 2018-09-28 09:01:31 --> Loader Class Initialized
INFO - 2018-09-28 09:01:31 --> Helper loaded: url_helper
INFO - 2018-09-28 09:01:31 --> Helper loaded: form_helper
INFO - 2018-09-28 09:01:31 --> Helper loaded: html_helper
INFO - 2018-09-28 09:01:31 --> Database Driver Class Initialized
INFO - 2018-09-28 09:01:31 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:01:31 --> Model "User_model" initialized
INFO - 2018-09-28 09:01:31 --> Model "Project_model" initialized
INFO - 2018-09-28 09:01:31 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:01:31 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:01:31 --> Controller Class Initialized
INFO - 2018-09-28 09:01:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:01:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 09:01:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:01:31 --> Final output sent to browser
DEBUG - 2018-09-28 09:01:31 --> Total execution time: 0.0510
INFO - 2018-09-28 09:01:31 --> Config Class Initialized
INFO - 2018-09-28 09:01:31 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:01:31 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:01:31 --> Utf8 Class Initialized
INFO - 2018-09-28 09:01:31 --> URI Class Initialized
INFO - 2018-09-28 09:01:31 --> Router Class Initialized
INFO - 2018-09-28 09:01:31 --> Output Class Initialized
INFO - 2018-09-28 09:01:31 --> Security Class Initialized
DEBUG - 2018-09-28 09:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:01:31 --> Input Class Initialized
INFO - 2018-09-28 09:01:31 --> Language Class Initialized
INFO - 2018-09-28 09:01:31 --> Loader Class Initialized
INFO - 2018-09-28 09:01:31 --> Helper loaded: url_helper
INFO - 2018-09-28 09:01:31 --> Helper loaded: form_helper
INFO - 2018-09-28 09:01:31 --> Helper loaded: html_helper
INFO - 2018-09-28 09:01:31 --> Database Driver Class Initialized
INFO - 2018-09-28 09:01:31 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:01:31 --> Model "User_model" initialized
INFO - 2018-09-28 09:01:31 --> Model "Project_model" initialized
INFO - 2018-09-28 09:01:31 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:01:31 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:01:31 --> Controller Class Initialized
INFO - 2018-09-28 09:01:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:01:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 09:01:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:01:31 --> Final output sent to browser
DEBUG - 2018-09-28 09:01:31 --> Total execution time: 0.0630
INFO - 2018-09-28 09:01:32 --> Config Class Initialized
INFO - 2018-09-28 09:01:32 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:01:32 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:01:32 --> Utf8 Class Initialized
INFO - 2018-09-28 09:01:32 --> URI Class Initialized
INFO - 2018-09-28 09:01:32 --> Router Class Initialized
INFO - 2018-09-28 09:01:32 --> Output Class Initialized
INFO - 2018-09-28 09:01:32 --> Security Class Initialized
DEBUG - 2018-09-28 09:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:01:32 --> Input Class Initialized
INFO - 2018-09-28 09:01:32 --> Language Class Initialized
INFO - 2018-09-28 09:01:32 --> Loader Class Initialized
INFO - 2018-09-28 09:01:32 --> Helper loaded: url_helper
INFO - 2018-09-28 09:01:32 --> Helper loaded: form_helper
INFO - 2018-09-28 09:01:32 --> Helper loaded: html_helper
INFO - 2018-09-28 09:01:32 --> Database Driver Class Initialized
INFO - 2018-09-28 09:01:32 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:01:32 --> Model "User_model" initialized
INFO - 2018-09-28 09:01:32 --> Model "Project_model" initialized
INFO - 2018-09-28 09:01:32 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:01:32 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:01:32 --> Controller Class Initialized
INFO - 2018-09-28 09:01:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:01:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-28 09:01:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:01:32 --> Final output sent to browser
DEBUG - 2018-09-28 09:01:32 --> Total execution time: 0.0520
INFO - 2018-09-28 09:01:33 --> Config Class Initialized
INFO - 2018-09-28 09:01:33 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:01:33 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:01:33 --> Utf8 Class Initialized
INFO - 2018-09-28 09:01:33 --> URI Class Initialized
INFO - 2018-09-28 09:01:33 --> Router Class Initialized
INFO - 2018-09-28 09:01:33 --> Output Class Initialized
INFO - 2018-09-28 09:01:33 --> Security Class Initialized
DEBUG - 2018-09-28 09:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:01:33 --> Input Class Initialized
INFO - 2018-09-28 09:01:33 --> Language Class Initialized
INFO - 2018-09-28 09:01:33 --> Loader Class Initialized
INFO - 2018-09-28 09:01:33 --> Helper loaded: url_helper
INFO - 2018-09-28 09:01:33 --> Helper loaded: form_helper
INFO - 2018-09-28 09:01:33 --> Helper loaded: html_helper
INFO - 2018-09-28 09:01:33 --> Database Driver Class Initialized
INFO - 2018-09-28 09:01:33 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:01:33 --> Model "User_model" initialized
INFO - 2018-09-28 09:01:33 --> Model "Project_model" initialized
INFO - 2018-09-28 09:01:33 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:01:33 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:01:33 --> Controller Class Initialized
INFO - 2018-09-28 09:01:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:01:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 09:01:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:01:33 --> Final output sent to browser
DEBUG - 2018-09-28 09:01:33 --> Total execution time: 0.0570
INFO - 2018-09-28 09:01:40 --> Config Class Initialized
INFO - 2018-09-28 09:01:40 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:01:40 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:01:40 --> Utf8 Class Initialized
INFO - 2018-09-28 09:01:40 --> URI Class Initialized
INFO - 2018-09-28 09:01:40 --> Router Class Initialized
INFO - 2018-09-28 09:01:40 --> Output Class Initialized
INFO - 2018-09-28 09:01:40 --> Security Class Initialized
DEBUG - 2018-09-28 09:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:01:40 --> Input Class Initialized
INFO - 2018-09-28 09:01:40 --> Language Class Initialized
INFO - 2018-09-28 09:01:40 --> Loader Class Initialized
INFO - 2018-09-28 09:01:40 --> Helper loaded: url_helper
INFO - 2018-09-28 09:01:40 --> Helper loaded: form_helper
INFO - 2018-09-28 09:01:40 --> Helper loaded: html_helper
INFO - 2018-09-28 09:01:40 --> Database Driver Class Initialized
INFO - 2018-09-28 09:01:40 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:01:40 --> Model "User_model" initialized
INFO - 2018-09-28 09:01:40 --> Model "Project_model" initialized
INFO - 2018-09-28 09:01:40 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:01:40 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:01:40 --> Controller Class Initialized
INFO - 2018-09-28 09:01:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:01:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 09:01:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:01:40 --> Final output sent to browser
DEBUG - 2018-09-28 09:01:40 --> Total execution time: 0.0480
INFO - 2018-09-28 09:01:42 --> Config Class Initialized
INFO - 2018-09-28 09:01:42 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:01:42 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:01:42 --> Utf8 Class Initialized
INFO - 2018-09-28 09:01:42 --> URI Class Initialized
INFO - 2018-09-28 09:01:42 --> Router Class Initialized
INFO - 2018-09-28 09:01:42 --> Output Class Initialized
INFO - 2018-09-28 09:01:42 --> Security Class Initialized
DEBUG - 2018-09-28 09:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:01:42 --> Input Class Initialized
INFO - 2018-09-28 09:01:42 --> Language Class Initialized
INFO - 2018-09-28 09:01:42 --> Loader Class Initialized
INFO - 2018-09-28 09:01:42 --> Helper loaded: url_helper
INFO - 2018-09-28 09:01:42 --> Helper loaded: form_helper
INFO - 2018-09-28 09:01:42 --> Helper loaded: html_helper
INFO - 2018-09-28 09:01:42 --> Database Driver Class Initialized
INFO - 2018-09-28 09:01:42 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:01:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:01:42 --> Model "User_model" initialized
INFO - 2018-09-28 09:01:42 --> Model "Project_model" initialized
INFO - 2018-09-28 09:01:42 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:01:42 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:01:42 --> Controller Class Initialized
INFO - 2018-09-28 09:01:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:01:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 09:01:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:01:42 --> Final output sent to browser
DEBUG - 2018-09-28 09:01:42 --> Total execution time: 0.0350
INFO - 2018-09-28 09:01:42 --> Config Class Initialized
INFO - 2018-09-28 09:01:42 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:01:42 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:01:42 --> Utf8 Class Initialized
INFO - 2018-09-28 09:01:42 --> URI Class Initialized
INFO - 2018-09-28 09:01:42 --> Router Class Initialized
INFO - 2018-09-28 09:01:42 --> Output Class Initialized
INFO - 2018-09-28 09:01:42 --> Security Class Initialized
DEBUG - 2018-09-28 09:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:01:42 --> Input Class Initialized
INFO - 2018-09-28 09:01:42 --> Language Class Initialized
INFO - 2018-09-28 09:01:42 --> Loader Class Initialized
INFO - 2018-09-28 09:01:42 --> Helper loaded: url_helper
INFO - 2018-09-28 09:01:42 --> Helper loaded: form_helper
INFO - 2018-09-28 09:01:42 --> Helper loaded: html_helper
INFO - 2018-09-28 09:01:42 --> Database Driver Class Initialized
INFO - 2018-09-28 09:01:42 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:01:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:01:42 --> Model "User_model" initialized
INFO - 2018-09-28 09:01:42 --> Model "Project_model" initialized
INFO - 2018-09-28 09:01:42 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:01:42 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:01:42 --> Controller Class Initialized
INFO - 2018-09-28 09:01:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:01:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 09:01:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:01:42 --> Final output sent to browser
DEBUG - 2018-09-28 09:01:42 --> Total execution time: 0.0390
INFO - 2018-09-28 09:01:43 --> Config Class Initialized
INFO - 2018-09-28 09:01:43 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:01:43 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:01:43 --> Utf8 Class Initialized
INFO - 2018-09-28 09:01:43 --> URI Class Initialized
INFO - 2018-09-28 09:01:43 --> Router Class Initialized
INFO - 2018-09-28 09:01:43 --> Output Class Initialized
INFO - 2018-09-28 09:01:43 --> Security Class Initialized
DEBUG - 2018-09-28 09:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:01:43 --> Input Class Initialized
INFO - 2018-09-28 09:01:43 --> Language Class Initialized
INFO - 2018-09-28 09:01:43 --> Loader Class Initialized
INFO - 2018-09-28 09:01:43 --> Helper loaded: url_helper
INFO - 2018-09-28 09:01:43 --> Helper loaded: form_helper
INFO - 2018-09-28 09:01:43 --> Helper loaded: html_helper
INFO - 2018-09-28 09:01:43 --> Database Driver Class Initialized
INFO - 2018-09-28 09:01:43 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:01:43 --> Model "User_model" initialized
INFO - 2018-09-28 09:01:43 --> Model "Project_model" initialized
INFO - 2018-09-28 09:01:43 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:01:43 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:01:43 --> Controller Class Initialized
INFO - 2018-09-28 09:01:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:01:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-28 09:01:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:01:43 --> Final output sent to browser
DEBUG - 2018-09-28 09:01:43 --> Total execution time: 0.0490
INFO - 2018-09-28 09:01:44 --> Config Class Initialized
INFO - 2018-09-28 09:01:44 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:01:44 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:01:44 --> Utf8 Class Initialized
INFO - 2018-09-28 09:01:44 --> URI Class Initialized
INFO - 2018-09-28 09:01:44 --> Router Class Initialized
INFO - 2018-09-28 09:01:44 --> Output Class Initialized
INFO - 2018-09-28 09:01:44 --> Security Class Initialized
DEBUG - 2018-09-28 09:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:01:44 --> Input Class Initialized
INFO - 2018-09-28 09:01:44 --> Language Class Initialized
INFO - 2018-09-28 09:01:44 --> Loader Class Initialized
INFO - 2018-09-28 09:01:44 --> Helper loaded: url_helper
INFO - 2018-09-28 09:01:44 --> Helper loaded: form_helper
INFO - 2018-09-28 09:01:44 --> Helper loaded: html_helper
INFO - 2018-09-28 09:01:44 --> Database Driver Class Initialized
INFO - 2018-09-28 09:01:44 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:01:44 --> Model "User_model" initialized
INFO - 2018-09-28 09:01:44 --> Model "Project_model" initialized
INFO - 2018-09-28 09:01:44 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:01:44 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:01:44 --> Controller Class Initialized
INFO - 2018-09-28 09:01:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:01:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 09:01:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:01:44 --> Final output sent to browser
DEBUG - 2018-09-28 09:01:44 --> Total execution time: 0.0610
INFO - 2018-09-28 09:01:48 --> Config Class Initialized
INFO - 2018-09-28 09:01:48 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:01:48 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:01:48 --> Utf8 Class Initialized
INFO - 2018-09-28 09:01:48 --> URI Class Initialized
INFO - 2018-09-28 09:01:48 --> Router Class Initialized
INFO - 2018-09-28 09:01:48 --> Output Class Initialized
INFO - 2018-09-28 09:01:48 --> Security Class Initialized
DEBUG - 2018-09-28 09:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:01:48 --> Input Class Initialized
INFO - 2018-09-28 09:01:48 --> Language Class Initialized
INFO - 2018-09-28 09:01:48 --> Loader Class Initialized
INFO - 2018-09-28 09:01:48 --> Helper loaded: url_helper
INFO - 2018-09-28 09:01:48 --> Helper loaded: form_helper
INFO - 2018-09-28 09:01:48 --> Helper loaded: html_helper
INFO - 2018-09-28 09:01:48 --> Database Driver Class Initialized
INFO - 2018-09-28 09:01:48 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:01:48 --> Model "User_model" initialized
INFO - 2018-09-28 09:01:48 --> Model "Project_model" initialized
INFO - 2018-09-28 09:01:48 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:01:48 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:01:48 --> Controller Class Initialized
INFO - 2018-09-28 09:01:48 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:01:48 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 09:01:48 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:01:48 --> Final output sent to browser
DEBUG - 2018-09-28 09:01:48 --> Total execution time: 0.0510
INFO - 2018-09-28 09:01:51 --> Config Class Initialized
INFO - 2018-09-28 09:01:51 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:01:51 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:01:51 --> Utf8 Class Initialized
INFO - 2018-09-28 09:01:51 --> URI Class Initialized
INFO - 2018-09-28 09:01:51 --> Router Class Initialized
INFO - 2018-09-28 09:01:51 --> Output Class Initialized
INFO - 2018-09-28 09:01:51 --> Security Class Initialized
DEBUG - 2018-09-28 09:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:01:51 --> Input Class Initialized
INFO - 2018-09-28 09:01:51 --> Language Class Initialized
INFO - 2018-09-28 09:01:51 --> Loader Class Initialized
INFO - 2018-09-28 09:01:51 --> Helper loaded: url_helper
INFO - 2018-09-28 09:01:51 --> Helper loaded: form_helper
INFO - 2018-09-28 09:01:51 --> Helper loaded: html_helper
INFO - 2018-09-28 09:01:51 --> Database Driver Class Initialized
INFO - 2018-09-28 09:01:51 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:01:51 --> Model "User_model" initialized
INFO - 2018-09-28 09:01:51 --> Model "Project_model" initialized
INFO - 2018-09-28 09:01:51 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:01:51 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:01:51 --> Controller Class Initialized
INFO - 2018-09-28 09:01:51 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:01:51 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-28 09:01:51 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:01:51 --> Final output sent to browser
DEBUG - 2018-09-28 09:01:51 --> Total execution time: 0.0510
INFO - 2018-09-28 09:01:53 --> Config Class Initialized
INFO - 2018-09-28 09:01:53 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:01:53 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:01:53 --> Utf8 Class Initialized
INFO - 2018-09-28 09:01:53 --> URI Class Initialized
INFO - 2018-09-28 09:01:53 --> Router Class Initialized
INFO - 2018-09-28 09:01:53 --> Output Class Initialized
INFO - 2018-09-28 09:01:53 --> Security Class Initialized
DEBUG - 2018-09-28 09:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:01:53 --> Input Class Initialized
INFO - 2018-09-28 09:01:53 --> Language Class Initialized
INFO - 2018-09-28 09:01:53 --> Loader Class Initialized
INFO - 2018-09-28 09:01:53 --> Helper loaded: url_helper
INFO - 2018-09-28 09:01:53 --> Helper loaded: form_helper
INFO - 2018-09-28 09:01:53 --> Helper loaded: html_helper
INFO - 2018-09-28 09:01:53 --> Database Driver Class Initialized
INFO - 2018-09-28 09:01:53 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:01:53 --> Model "User_model" initialized
INFO - 2018-09-28 09:01:53 --> Model "Project_model" initialized
INFO - 2018-09-28 09:01:53 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:01:53 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:01:53 --> Controller Class Initialized
INFO - 2018-09-28 09:01:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:01:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 09:01:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:01:53 --> Final output sent to browser
DEBUG - 2018-09-28 09:01:53 --> Total execution time: 0.0530
INFO - 2018-09-28 09:01:57 --> Config Class Initialized
INFO - 2018-09-28 09:01:57 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:01:57 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:01:57 --> Utf8 Class Initialized
INFO - 2018-09-28 09:01:57 --> URI Class Initialized
INFO - 2018-09-28 09:01:57 --> Router Class Initialized
INFO - 2018-09-28 09:01:57 --> Output Class Initialized
INFO - 2018-09-28 09:01:57 --> Security Class Initialized
DEBUG - 2018-09-28 09:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:01:57 --> Input Class Initialized
INFO - 2018-09-28 09:01:57 --> Language Class Initialized
INFO - 2018-09-28 09:01:57 --> Loader Class Initialized
INFO - 2018-09-28 09:01:57 --> Helper loaded: url_helper
INFO - 2018-09-28 09:01:57 --> Helper loaded: form_helper
INFO - 2018-09-28 09:01:57 --> Helper loaded: html_helper
INFO - 2018-09-28 09:01:57 --> Database Driver Class Initialized
INFO - 2018-09-28 09:01:57 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:01:57 --> Model "User_model" initialized
INFO - 2018-09-28 09:01:57 --> Model "Project_model" initialized
INFO - 2018-09-28 09:01:57 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:01:57 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:01:57 --> Controller Class Initialized
INFO - 2018-09-28 09:01:57 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:01:57 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-28 09:01:57 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:01:57 --> Final output sent to browser
DEBUG - 2018-09-28 09:01:57 --> Total execution time: 0.0560
INFO - 2018-09-28 09:01:59 --> Config Class Initialized
INFO - 2018-09-28 09:01:59 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:01:59 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:01:59 --> Utf8 Class Initialized
INFO - 2018-09-28 09:01:59 --> URI Class Initialized
INFO - 2018-09-28 09:01:59 --> Router Class Initialized
INFO - 2018-09-28 09:01:59 --> Output Class Initialized
INFO - 2018-09-28 09:01:59 --> Security Class Initialized
DEBUG - 2018-09-28 09:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:01:59 --> Input Class Initialized
INFO - 2018-09-28 09:01:59 --> Language Class Initialized
INFO - 2018-09-28 09:01:59 --> Loader Class Initialized
INFO - 2018-09-28 09:01:59 --> Helper loaded: url_helper
INFO - 2018-09-28 09:01:59 --> Helper loaded: form_helper
INFO - 2018-09-28 09:01:59 --> Helper loaded: html_helper
INFO - 2018-09-28 09:01:59 --> Database Driver Class Initialized
INFO - 2018-09-28 09:01:59 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:01:59 --> Model "User_model" initialized
INFO - 2018-09-28 09:01:59 --> Model "Project_model" initialized
INFO - 2018-09-28 09:01:59 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:01:59 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:01:59 --> Controller Class Initialized
INFO - 2018-09-28 09:01:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:01:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-28 09:01:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:01:59 --> Final output sent to browser
DEBUG - 2018-09-28 09:01:59 --> Total execution time: 0.0520
INFO - 2018-09-28 09:02:01 --> Config Class Initialized
INFO - 2018-09-28 09:02:01 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:02:01 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:02:01 --> Utf8 Class Initialized
INFO - 2018-09-28 09:02:01 --> URI Class Initialized
INFO - 2018-09-28 09:02:01 --> Router Class Initialized
INFO - 2018-09-28 09:02:01 --> Output Class Initialized
INFO - 2018-09-28 09:02:01 --> Security Class Initialized
DEBUG - 2018-09-28 09:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:02:01 --> Input Class Initialized
INFO - 2018-09-28 09:02:01 --> Language Class Initialized
INFO - 2018-09-28 09:02:01 --> Loader Class Initialized
INFO - 2018-09-28 09:02:01 --> Helper loaded: url_helper
INFO - 2018-09-28 09:02:01 --> Helper loaded: form_helper
INFO - 2018-09-28 09:02:01 --> Helper loaded: html_helper
INFO - 2018-09-28 09:02:01 --> Database Driver Class Initialized
INFO - 2018-09-28 09:02:01 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:02:01 --> Model "User_model" initialized
INFO - 2018-09-28 09:02:01 --> Model "Project_model" initialized
INFO - 2018-09-28 09:02:01 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:02:01 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:02:01 --> Controller Class Initialized
INFO - 2018-09-28 09:02:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:02:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 09:02:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:02:01 --> Final output sent to browser
DEBUG - 2018-09-28 09:02:01 --> Total execution time: 0.0410
INFO - 2018-09-28 09:02:04 --> Config Class Initialized
INFO - 2018-09-28 09:02:04 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:02:04 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:02:04 --> Utf8 Class Initialized
INFO - 2018-09-28 09:02:04 --> URI Class Initialized
INFO - 2018-09-28 09:02:04 --> Router Class Initialized
INFO - 2018-09-28 09:02:04 --> Output Class Initialized
INFO - 2018-09-28 09:02:04 --> Security Class Initialized
DEBUG - 2018-09-28 09:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:02:04 --> Input Class Initialized
INFO - 2018-09-28 09:02:04 --> Language Class Initialized
INFO - 2018-09-28 09:02:04 --> Loader Class Initialized
INFO - 2018-09-28 09:02:04 --> Helper loaded: url_helper
INFO - 2018-09-28 09:02:04 --> Helper loaded: form_helper
INFO - 2018-09-28 09:02:04 --> Helper loaded: html_helper
INFO - 2018-09-28 09:02:04 --> Database Driver Class Initialized
INFO - 2018-09-28 09:02:04 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:02:04 --> Model "User_model" initialized
INFO - 2018-09-28 09:02:04 --> Model "Project_model" initialized
INFO - 2018-09-28 09:02:04 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:02:04 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:02:04 --> Controller Class Initialized
INFO - 2018-09-28 09:02:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:02:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-28 09:02:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:02:04 --> Final output sent to browser
DEBUG - 2018-09-28 09:02:04 --> Total execution time: 0.0520
INFO - 2018-09-28 09:02:05 --> Config Class Initialized
INFO - 2018-09-28 09:02:05 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:02:05 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:02:05 --> Utf8 Class Initialized
INFO - 2018-09-28 09:02:05 --> URI Class Initialized
INFO - 2018-09-28 09:02:05 --> Router Class Initialized
INFO - 2018-09-28 09:02:05 --> Output Class Initialized
INFO - 2018-09-28 09:02:05 --> Security Class Initialized
DEBUG - 2018-09-28 09:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:02:05 --> Input Class Initialized
INFO - 2018-09-28 09:02:05 --> Language Class Initialized
INFO - 2018-09-28 09:02:05 --> Loader Class Initialized
INFO - 2018-09-28 09:02:05 --> Helper loaded: url_helper
INFO - 2018-09-28 09:02:05 --> Helper loaded: form_helper
INFO - 2018-09-28 09:02:05 --> Helper loaded: html_helper
INFO - 2018-09-28 09:02:05 --> Database Driver Class Initialized
INFO - 2018-09-28 09:02:05 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:02:05 --> Model "User_model" initialized
INFO - 2018-09-28 09:02:05 --> Model "Project_model" initialized
INFO - 2018-09-28 09:02:05 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:02:05 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:02:05 --> Controller Class Initialized
INFO - 2018-09-28 09:02:05 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:02:05 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 09:02:05 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:02:05 --> Final output sent to browser
DEBUG - 2018-09-28 09:02:05 --> Total execution time: 0.0510
INFO - 2018-09-28 09:08:41 --> Config Class Initialized
INFO - 2018-09-28 09:08:41 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:08:41 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:08:41 --> Utf8 Class Initialized
INFO - 2018-09-28 09:08:41 --> URI Class Initialized
INFO - 2018-09-28 09:08:41 --> Router Class Initialized
INFO - 2018-09-28 09:08:41 --> Output Class Initialized
INFO - 2018-09-28 09:08:41 --> Security Class Initialized
DEBUG - 2018-09-28 09:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:08:41 --> Input Class Initialized
INFO - 2018-09-28 09:08:41 --> Language Class Initialized
INFO - 2018-09-28 09:08:41 --> Loader Class Initialized
INFO - 2018-09-28 09:08:41 --> Helper loaded: url_helper
INFO - 2018-09-28 09:08:41 --> Helper loaded: form_helper
INFO - 2018-09-28 09:08:41 --> Helper loaded: html_helper
INFO - 2018-09-28 09:08:41 --> Database Driver Class Initialized
INFO - 2018-09-28 09:08:41 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:08:41 --> Model "User_model" initialized
INFO - 2018-09-28 09:08:41 --> Model "Project_model" initialized
INFO - 2018-09-28 09:08:41 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:08:41 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:08:41 --> Controller Class Initialized
INFO - 2018-09-28 09:08:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:08:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 09:08:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:08:41 --> Final output sent to browser
DEBUG - 2018-09-28 09:08:41 --> Total execution time: 0.1000
INFO - 2018-09-28 09:09:21 --> Config Class Initialized
INFO - 2018-09-28 09:09:21 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:09:21 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:09:21 --> Utf8 Class Initialized
INFO - 2018-09-28 09:09:21 --> URI Class Initialized
INFO - 2018-09-28 09:09:21 --> Router Class Initialized
INFO - 2018-09-28 09:09:21 --> Output Class Initialized
INFO - 2018-09-28 09:09:21 --> Security Class Initialized
DEBUG - 2018-09-28 09:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:09:21 --> Input Class Initialized
INFO - 2018-09-28 09:09:21 --> Language Class Initialized
INFO - 2018-09-28 09:09:21 --> Loader Class Initialized
INFO - 2018-09-28 09:09:21 --> Helper loaded: url_helper
INFO - 2018-09-28 09:09:21 --> Helper loaded: form_helper
INFO - 2018-09-28 09:09:21 --> Helper loaded: html_helper
INFO - 2018-09-28 09:09:21 --> Database Driver Class Initialized
INFO - 2018-09-28 09:09:21 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:09:21 --> Model "User_model" initialized
INFO - 2018-09-28 09:09:21 --> Model "Project_model" initialized
INFO - 2018-09-28 09:09:21 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:09:21 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:09:21 --> Controller Class Initialized
INFO - 2018-09-28 09:09:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:09:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 09:09:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:09:21 --> Final output sent to browser
DEBUG - 2018-09-28 09:09:21 --> Total execution time: 0.0600
INFO - 2018-09-28 09:09:28 --> Config Class Initialized
INFO - 2018-09-28 09:09:28 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:09:28 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:09:28 --> Utf8 Class Initialized
INFO - 2018-09-28 09:09:28 --> URI Class Initialized
INFO - 2018-09-28 09:09:28 --> Router Class Initialized
INFO - 2018-09-28 09:09:28 --> Output Class Initialized
INFO - 2018-09-28 09:09:28 --> Security Class Initialized
DEBUG - 2018-09-28 09:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:09:28 --> Input Class Initialized
INFO - 2018-09-28 09:09:28 --> Language Class Initialized
INFO - 2018-09-28 09:09:28 --> Loader Class Initialized
INFO - 2018-09-28 09:09:28 --> Helper loaded: url_helper
INFO - 2018-09-28 09:09:28 --> Helper loaded: form_helper
INFO - 2018-09-28 09:09:28 --> Helper loaded: html_helper
INFO - 2018-09-28 09:09:28 --> Database Driver Class Initialized
INFO - 2018-09-28 09:09:28 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:09:28 --> Model "User_model" initialized
INFO - 2018-09-28 09:09:28 --> Model "Project_model" initialized
INFO - 2018-09-28 09:09:28 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:09:28 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:09:28 --> Controller Class Initialized
INFO - 2018-09-28 09:09:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:09:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 09:09:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:09:28 --> Final output sent to browser
DEBUG - 2018-09-28 09:09:28 --> Total execution time: 0.0350
INFO - 2018-09-28 09:10:04 --> Config Class Initialized
INFO - 2018-09-28 09:10:04 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:10:04 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:10:04 --> Utf8 Class Initialized
INFO - 2018-09-28 09:10:04 --> URI Class Initialized
INFO - 2018-09-28 09:10:04 --> Router Class Initialized
INFO - 2018-09-28 09:10:04 --> Output Class Initialized
INFO - 2018-09-28 09:10:04 --> Security Class Initialized
DEBUG - 2018-09-28 09:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:10:04 --> Input Class Initialized
INFO - 2018-09-28 09:10:04 --> Language Class Initialized
INFO - 2018-09-28 09:10:04 --> Loader Class Initialized
INFO - 2018-09-28 09:10:04 --> Helper loaded: url_helper
INFO - 2018-09-28 09:10:04 --> Helper loaded: form_helper
INFO - 2018-09-28 09:10:04 --> Helper loaded: html_helper
INFO - 2018-09-28 09:10:04 --> Database Driver Class Initialized
INFO - 2018-09-28 09:10:04 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:10:04 --> Model "User_model" initialized
INFO - 2018-09-28 09:10:04 --> Model "Project_model" initialized
INFO - 2018-09-28 09:10:04 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:10:04 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:10:04 --> Controller Class Initialized
INFO - 2018-09-28 09:10:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:10:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 09:10:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:10:04 --> Final output sent to browser
DEBUG - 2018-09-28 09:10:04 --> Total execution time: 0.1130
INFO - 2018-09-28 09:10:54 --> Config Class Initialized
INFO - 2018-09-28 09:10:54 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:10:54 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:10:54 --> Utf8 Class Initialized
INFO - 2018-09-28 09:10:54 --> URI Class Initialized
INFO - 2018-09-28 09:10:54 --> Router Class Initialized
INFO - 2018-09-28 09:10:54 --> Output Class Initialized
INFO - 2018-09-28 09:10:54 --> Security Class Initialized
DEBUG - 2018-09-28 09:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:10:54 --> Input Class Initialized
INFO - 2018-09-28 09:10:54 --> Language Class Initialized
INFO - 2018-09-28 09:10:54 --> Loader Class Initialized
INFO - 2018-09-28 09:10:54 --> Helper loaded: url_helper
INFO - 2018-09-28 09:10:54 --> Helper loaded: form_helper
INFO - 2018-09-28 09:10:54 --> Helper loaded: html_helper
INFO - 2018-09-28 09:10:54 --> Database Driver Class Initialized
INFO - 2018-09-28 09:10:54 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:10:54 --> Model "User_model" initialized
INFO - 2018-09-28 09:10:54 --> Model "Project_model" initialized
INFO - 2018-09-28 09:10:54 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:10:54 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:10:54 --> Controller Class Initialized
INFO - 2018-09-28 09:10:54 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-28 09:10:54 --> Severity: error --> Exception: syntax error, unexpected '(int)' (int) (T_INT_CAST) D:\xampp\htdocs\code_igniter\application\views\project_views\users\register_view.php 63
INFO - 2018-09-28 09:11:04 --> Config Class Initialized
INFO - 2018-09-28 09:11:04 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:11:04 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:11:04 --> Utf8 Class Initialized
INFO - 2018-09-28 09:11:04 --> URI Class Initialized
INFO - 2018-09-28 09:11:04 --> Router Class Initialized
INFO - 2018-09-28 09:11:04 --> Output Class Initialized
INFO - 2018-09-28 09:11:04 --> Security Class Initialized
DEBUG - 2018-09-28 09:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:11:04 --> Input Class Initialized
INFO - 2018-09-28 09:11:04 --> Language Class Initialized
INFO - 2018-09-28 09:11:04 --> Loader Class Initialized
INFO - 2018-09-28 09:11:04 --> Helper loaded: url_helper
INFO - 2018-09-28 09:11:04 --> Helper loaded: form_helper
INFO - 2018-09-28 09:11:04 --> Helper loaded: html_helper
INFO - 2018-09-28 09:11:04 --> Database Driver Class Initialized
INFO - 2018-09-28 09:11:04 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:11:04 --> Model "User_model" initialized
INFO - 2018-09-28 09:11:04 --> Model "Project_model" initialized
INFO - 2018-09-28 09:11:04 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:11:04 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:11:04 --> Controller Class Initialized
INFO - 2018-09-28 09:11:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-28 09:11:04 --> Severity: error --> Exception: syntax error, unexpected '(int)' (int) (T_INT_CAST) D:\xampp\htdocs\code_igniter\application\views\project_views\users\register_view.php 63
INFO - 2018-09-28 09:11:15 --> Config Class Initialized
INFO - 2018-09-28 09:11:15 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:11:15 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:11:15 --> Utf8 Class Initialized
INFO - 2018-09-28 09:11:15 --> URI Class Initialized
INFO - 2018-09-28 09:11:15 --> Router Class Initialized
INFO - 2018-09-28 09:11:15 --> Output Class Initialized
INFO - 2018-09-28 09:11:15 --> Security Class Initialized
DEBUG - 2018-09-28 09:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:11:15 --> Input Class Initialized
INFO - 2018-09-28 09:11:15 --> Language Class Initialized
INFO - 2018-09-28 09:11:15 --> Loader Class Initialized
INFO - 2018-09-28 09:11:15 --> Helper loaded: url_helper
INFO - 2018-09-28 09:11:15 --> Helper loaded: form_helper
INFO - 2018-09-28 09:11:15 --> Helper loaded: html_helper
INFO - 2018-09-28 09:11:15 --> Database Driver Class Initialized
INFO - 2018-09-28 09:11:15 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:11:15 --> Model "User_model" initialized
INFO - 2018-09-28 09:11:15 --> Model "Project_model" initialized
INFO - 2018-09-28 09:11:15 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:11:15 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:11:15 --> Controller Class Initialized
INFO - 2018-09-28 09:11:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:11:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 09:11:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:11:15 --> Final output sent to browser
DEBUG - 2018-09-28 09:11:15 --> Total execution time: 0.0350
INFO - 2018-09-28 09:12:26 --> Config Class Initialized
INFO - 2018-09-28 09:12:26 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:12:26 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:12:26 --> Utf8 Class Initialized
INFO - 2018-09-28 09:12:26 --> URI Class Initialized
INFO - 2018-09-28 09:12:26 --> Router Class Initialized
INFO - 2018-09-28 09:12:26 --> Output Class Initialized
INFO - 2018-09-28 09:12:26 --> Security Class Initialized
DEBUG - 2018-09-28 09:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:12:26 --> Input Class Initialized
INFO - 2018-09-28 09:12:26 --> Language Class Initialized
INFO - 2018-09-28 09:12:26 --> Loader Class Initialized
INFO - 2018-09-28 09:12:26 --> Helper loaded: url_helper
INFO - 2018-09-28 09:12:26 --> Helper loaded: form_helper
INFO - 2018-09-28 09:12:26 --> Helper loaded: html_helper
INFO - 2018-09-28 09:12:26 --> Database Driver Class Initialized
INFO - 2018-09-28 09:12:26 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:12:26 --> Model "User_model" initialized
INFO - 2018-09-28 09:12:26 --> Model "Project_model" initialized
INFO - 2018-09-28 09:12:26 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:12:26 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:12:26 --> Controller Class Initialized
INFO - 2018-09-28 09:12:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:12:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 09:12:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:12:26 --> Final output sent to browser
DEBUG - 2018-09-28 09:12:26 --> Total execution time: 0.0520
INFO - 2018-09-28 09:14:05 --> Config Class Initialized
INFO - 2018-09-28 09:14:05 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:14:05 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:14:05 --> Utf8 Class Initialized
INFO - 2018-09-28 09:14:05 --> URI Class Initialized
INFO - 2018-09-28 09:14:05 --> Router Class Initialized
INFO - 2018-09-28 09:14:05 --> Output Class Initialized
INFO - 2018-09-28 09:14:05 --> Security Class Initialized
DEBUG - 2018-09-28 09:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:14:05 --> Input Class Initialized
INFO - 2018-09-28 09:14:05 --> Language Class Initialized
INFO - 2018-09-28 09:14:05 --> Loader Class Initialized
INFO - 2018-09-28 09:14:05 --> Helper loaded: url_helper
INFO - 2018-09-28 09:14:05 --> Helper loaded: form_helper
INFO - 2018-09-28 09:14:05 --> Helper loaded: html_helper
INFO - 2018-09-28 09:14:05 --> Database Driver Class Initialized
INFO - 2018-09-28 09:14:05 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:14:05 --> Model "User_model" initialized
INFO - 2018-09-28 09:14:05 --> Model "Project_model" initialized
INFO - 2018-09-28 09:14:05 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:14:05 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:14:05 --> Controller Class Initialized
INFO - 2018-09-28 09:14:05 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:14:05 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 09:14:05 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:14:05 --> Final output sent to browser
DEBUG - 2018-09-28 09:14:05 --> Total execution time: 0.0580
INFO - 2018-09-28 09:14:07 --> Config Class Initialized
INFO - 2018-09-28 09:14:07 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:14:07 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:14:07 --> Utf8 Class Initialized
INFO - 2018-09-28 09:14:07 --> URI Class Initialized
INFO - 2018-09-28 09:14:07 --> Router Class Initialized
INFO - 2018-09-28 09:14:07 --> Output Class Initialized
INFO - 2018-09-28 09:14:07 --> Security Class Initialized
DEBUG - 2018-09-28 09:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:14:07 --> Input Class Initialized
INFO - 2018-09-28 09:14:07 --> Language Class Initialized
INFO - 2018-09-28 09:14:07 --> Loader Class Initialized
INFO - 2018-09-28 09:14:07 --> Helper loaded: url_helper
INFO - 2018-09-28 09:14:07 --> Helper loaded: form_helper
INFO - 2018-09-28 09:14:07 --> Helper loaded: html_helper
INFO - 2018-09-28 09:14:07 --> Database Driver Class Initialized
INFO - 2018-09-28 09:14:07 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:14:07 --> Model "User_model" initialized
INFO - 2018-09-28 09:14:07 --> Model "Project_model" initialized
INFO - 2018-09-28 09:14:07 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:14:07 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:14:07 --> Controller Class Initialized
INFO - 2018-09-28 09:14:07 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:14:07 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-28 09:14:07 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:14:07 --> Final output sent to browser
DEBUG - 2018-09-28 09:14:07 --> Total execution time: 0.0490
INFO - 2018-09-28 09:14:08 --> Config Class Initialized
INFO - 2018-09-28 09:14:08 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:14:08 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:14:08 --> Utf8 Class Initialized
INFO - 2018-09-28 09:14:08 --> URI Class Initialized
INFO - 2018-09-28 09:14:08 --> Router Class Initialized
INFO - 2018-09-28 09:14:08 --> Output Class Initialized
INFO - 2018-09-28 09:14:08 --> Security Class Initialized
DEBUG - 2018-09-28 09:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:14:08 --> Input Class Initialized
INFO - 2018-09-28 09:14:08 --> Language Class Initialized
INFO - 2018-09-28 09:14:08 --> Loader Class Initialized
INFO - 2018-09-28 09:14:08 --> Helper loaded: url_helper
INFO - 2018-09-28 09:14:08 --> Helper loaded: form_helper
INFO - 2018-09-28 09:14:08 --> Helper loaded: html_helper
INFO - 2018-09-28 09:14:08 --> Database Driver Class Initialized
INFO - 2018-09-28 09:14:08 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:14:08 --> Model "User_model" initialized
INFO - 2018-09-28 09:14:08 --> Model "Project_model" initialized
INFO - 2018-09-28 09:14:08 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:14:08 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:14:08 --> Controller Class Initialized
INFO - 2018-09-28 09:14:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:14:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 09:14:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:14:08 --> Final output sent to browser
DEBUG - 2018-09-28 09:14:08 --> Total execution time: 0.0570
INFO - 2018-09-28 09:14:18 --> Config Class Initialized
INFO - 2018-09-28 09:14:18 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:14:18 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:14:18 --> Utf8 Class Initialized
INFO - 2018-09-28 09:14:18 --> URI Class Initialized
INFO - 2018-09-28 09:14:18 --> Router Class Initialized
INFO - 2018-09-28 09:14:18 --> Output Class Initialized
INFO - 2018-09-28 09:14:18 --> Security Class Initialized
DEBUG - 2018-09-28 09:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:14:18 --> Input Class Initialized
INFO - 2018-09-28 09:14:18 --> Language Class Initialized
INFO - 2018-09-28 09:14:18 --> Loader Class Initialized
INFO - 2018-09-28 09:14:18 --> Helper loaded: url_helper
INFO - 2018-09-28 09:14:18 --> Helper loaded: form_helper
INFO - 2018-09-28 09:14:18 --> Helper loaded: html_helper
INFO - 2018-09-28 09:14:18 --> Database Driver Class Initialized
INFO - 2018-09-28 09:14:18 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:14:18 --> Model "User_model" initialized
INFO - 2018-09-28 09:14:18 --> Model "Project_model" initialized
INFO - 2018-09-28 09:14:18 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:14:18 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:14:18 --> Controller Class Initialized
INFO - 2018-09-28 09:14:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:14:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 09:14:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:14:18 --> Final output sent to browser
DEBUG - 2018-09-28 09:14:18 --> Total execution time: 0.0500
INFO - 2018-09-28 09:14:19 --> Config Class Initialized
INFO - 2018-09-28 09:14:19 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:14:19 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:14:19 --> Utf8 Class Initialized
INFO - 2018-09-28 09:14:19 --> URI Class Initialized
INFO - 2018-09-28 09:14:19 --> Router Class Initialized
INFO - 2018-09-28 09:14:19 --> Output Class Initialized
INFO - 2018-09-28 09:14:19 --> Security Class Initialized
DEBUG - 2018-09-28 09:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:14:19 --> Input Class Initialized
INFO - 2018-09-28 09:14:19 --> Language Class Initialized
INFO - 2018-09-28 09:14:19 --> Loader Class Initialized
INFO - 2018-09-28 09:14:19 --> Helper loaded: url_helper
INFO - 2018-09-28 09:14:19 --> Helper loaded: form_helper
INFO - 2018-09-28 09:14:19 --> Helper loaded: html_helper
INFO - 2018-09-28 09:14:19 --> Database Driver Class Initialized
INFO - 2018-09-28 09:14:19 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:14:19 --> Model "User_model" initialized
INFO - 2018-09-28 09:14:19 --> Model "Project_model" initialized
INFO - 2018-09-28 09:14:19 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:14:19 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:14:19 --> Controller Class Initialized
INFO - 2018-09-28 09:14:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:14:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-28 09:14:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:14:19 --> Final output sent to browser
DEBUG - 2018-09-28 09:14:19 --> Total execution time: 0.0650
INFO - 2018-09-28 09:14:19 --> Config Class Initialized
INFO - 2018-09-28 09:14:20 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:14:20 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:14:20 --> Utf8 Class Initialized
INFO - 2018-09-28 09:14:20 --> URI Class Initialized
INFO - 2018-09-28 09:14:20 --> Router Class Initialized
INFO - 2018-09-28 09:14:20 --> Output Class Initialized
INFO - 2018-09-28 09:14:20 --> Security Class Initialized
DEBUG - 2018-09-28 09:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:14:20 --> Input Class Initialized
INFO - 2018-09-28 09:14:20 --> Language Class Initialized
INFO - 2018-09-28 09:14:20 --> Loader Class Initialized
INFO - 2018-09-28 09:14:20 --> Helper loaded: url_helper
INFO - 2018-09-28 09:14:20 --> Helper loaded: form_helper
INFO - 2018-09-28 09:14:20 --> Helper loaded: html_helper
INFO - 2018-09-28 09:14:20 --> Database Driver Class Initialized
INFO - 2018-09-28 09:14:20 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:14:20 --> Model "User_model" initialized
INFO - 2018-09-28 09:14:20 --> Model "Project_model" initialized
INFO - 2018-09-28 09:14:20 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:14:20 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:14:20 --> Controller Class Initialized
INFO - 2018-09-28 09:14:20 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:14:20 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 09:14:20 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:14:20 --> Final output sent to browser
DEBUG - 2018-09-28 09:14:20 --> Total execution time: 0.0560
INFO - 2018-09-28 09:14:25 --> Config Class Initialized
INFO - 2018-09-28 09:14:25 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:14:25 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:14:25 --> Utf8 Class Initialized
INFO - 2018-09-28 09:14:25 --> URI Class Initialized
INFO - 2018-09-28 09:14:25 --> Router Class Initialized
INFO - 2018-09-28 09:14:25 --> Output Class Initialized
INFO - 2018-09-28 09:14:25 --> Security Class Initialized
DEBUG - 2018-09-28 09:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:14:25 --> Input Class Initialized
INFO - 2018-09-28 09:14:25 --> Language Class Initialized
INFO - 2018-09-28 09:14:25 --> Loader Class Initialized
INFO - 2018-09-28 09:14:25 --> Helper loaded: url_helper
INFO - 2018-09-28 09:14:25 --> Helper loaded: form_helper
INFO - 2018-09-28 09:14:25 --> Helper loaded: html_helper
INFO - 2018-09-28 09:14:25 --> Database Driver Class Initialized
INFO - 2018-09-28 09:14:25 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:14:25 --> Model "User_model" initialized
INFO - 2018-09-28 09:14:25 --> Model "Project_model" initialized
INFO - 2018-09-28 09:14:25 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:14:25 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:14:25 --> Controller Class Initialized
INFO - 2018-09-28 09:14:25 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:14:25 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 09:14:25 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:14:25 --> Final output sent to browser
DEBUG - 2018-09-28 09:14:25 --> Total execution time: 0.0360
INFO - 2018-09-28 09:14:26 --> Config Class Initialized
INFO - 2018-09-28 09:14:26 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:14:26 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:14:26 --> Utf8 Class Initialized
INFO - 2018-09-28 09:14:26 --> URI Class Initialized
INFO - 2018-09-28 09:14:26 --> Router Class Initialized
INFO - 2018-09-28 09:14:26 --> Output Class Initialized
INFO - 2018-09-28 09:14:26 --> Security Class Initialized
DEBUG - 2018-09-28 09:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:14:26 --> Input Class Initialized
INFO - 2018-09-28 09:14:26 --> Language Class Initialized
INFO - 2018-09-28 09:14:26 --> Loader Class Initialized
INFO - 2018-09-28 09:14:26 --> Helper loaded: url_helper
INFO - 2018-09-28 09:14:26 --> Helper loaded: form_helper
INFO - 2018-09-28 09:14:26 --> Helper loaded: html_helper
INFO - 2018-09-28 09:14:26 --> Database Driver Class Initialized
INFO - 2018-09-28 09:14:26 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:14:26 --> Model "User_model" initialized
INFO - 2018-09-28 09:14:26 --> Model "Project_model" initialized
INFO - 2018-09-28 09:14:26 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:14:26 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:14:26 --> Controller Class Initialized
INFO - 2018-09-28 09:14:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:14:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-28 09:14:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:14:26 --> Final output sent to browser
DEBUG - 2018-09-28 09:14:26 --> Total execution time: 0.0380
INFO - 2018-09-28 09:14:27 --> Config Class Initialized
INFO - 2018-09-28 09:14:27 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:14:27 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:14:27 --> Utf8 Class Initialized
INFO - 2018-09-28 09:14:27 --> URI Class Initialized
INFO - 2018-09-28 09:14:27 --> Router Class Initialized
INFO - 2018-09-28 09:14:27 --> Output Class Initialized
INFO - 2018-09-28 09:14:27 --> Security Class Initialized
DEBUG - 2018-09-28 09:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:14:27 --> Input Class Initialized
INFO - 2018-09-28 09:14:27 --> Language Class Initialized
INFO - 2018-09-28 09:14:27 --> Loader Class Initialized
INFO - 2018-09-28 09:14:27 --> Helper loaded: url_helper
INFO - 2018-09-28 09:14:27 --> Helper loaded: form_helper
INFO - 2018-09-28 09:14:27 --> Helper loaded: html_helper
INFO - 2018-09-28 09:14:27 --> Database Driver Class Initialized
INFO - 2018-09-28 09:14:27 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:14:27 --> Model "User_model" initialized
INFO - 2018-09-28 09:14:27 --> Model "Project_model" initialized
INFO - 2018-09-28 09:14:27 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:14:27 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:14:27 --> Controller Class Initialized
INFO - 2018-09-28 09:14:27 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:14:27 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 09:14:27 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:14:27 --> Final output sent to browser
DEBUG - 2018-09-28 09:14:27 --> Total execution time: 0.0480
INFO - 2018-09-28 09:14:31 --> Config Class Initialized
INFO - 2018-09-28 09:14:31 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:14:31 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:14:31 --> Utf8 Class Initialized
INFO - 2018-09-28 09:14:31 --> URI Class Initialized
INFO - 2018-09-28 09:14:31 --> Router Class Initialized
INFO - 2018-09-28 09:14:31 --> Output Class Initialized
INFO - 2018-09-28 09:14:31 --> Security Class Initialized
DEBUG - 2018-09-28 09:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:14:31 --> Input Class Initialized
INFO - 2018-09-28 09:14:31 --> Language Class Initialized
INFO - 2018-09-28 09:14:31 --> Loader Class Initialized
INFO - 2018-09-28 09:14:31 --> Helper loaded: url_helper
INFO - 2018-09-28 09:14:31 --> Helper loaded: form_helper
INFO - 2018-09-28 09:14:31 --> Helper loaded: html_helper
INFO - 2018-09-28 09:14:31 --> Database Driver Class Initialized
INFO - 2018-09-28 09:14:31 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:14:31 --> Model "User_model" initialized
INFO - 2018-09-28 09:14:31 --> Model "Project_model" initialized
INFO - 2018-09-28 09:14:31 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:14:31 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:14:31 --> Controller Class Initialized
INFO - 2018-09-28 09:14:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:14:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-28 09:14:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:14:31 --> Final output sent to browser
DEBUG - 2018-09-28 09:14:31 --> Total execution time: 0.0780
INFO - 2018-09-28 09:14:34 --> Config Class Initialized
INFO - 2018-09-28 09:14:34 --> Hooks Class Initialized
DEBUG - 2018-09-28 09:14:34 --> UTF-8 Support Enabled
INFO - 2018-09-28 09:14:34 --> Utf8 Class Initialized
INFO - 2018-09-28 09:14:34 --> URI Class Initialized
INFO - 2018-09-28 09:14:34 --> Router Class Initialized
INFO - 2018-09-28 09:14:34 --> Output Class Initialized
INFO - 2018-09-28 09:14:34 --> Security Class Initialized
DEBUG - 2018-09-28 09:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 09:14:34 --> Input Class Initialized
INFO - 2018-09-28 09:14:34 --> Language Class Initialized
INFO - 2018-09-28 09:14:34 --> Loader Class Initialized
INFO - 2018-09-28 09:14:34 --> Helper loaded: url_helper
INFO - 2018-09-28 09:14:34 --> Helper loaded: form_helper
INFO - 2018-09-28 09:14:34 --> Helper loaded: html_helper
INFO - 2018-09-28 09:14:34 --> Database Driver Class Initialized
INFO - 2018-09-28 09:14:34 --> Form Validation Class Initialized
DEBUG - 2018-09-28 09:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 09:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 09:14:34 --> Model "User_model" initialized
INFO - 2018-09-28 09:14:34 --> Model "Project_model" initialized
INFO - 2018-09-28 09:14:34 --> Model "Tasks_model" initialized
INFO - 2018-09-28 09:14:34 --> Model "Lists_model" initialized
INFO - 2018-09-28 09:14:34 --> Controller Class Initialized
INFO - 2018-09-28 09:14:34 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 09:14:34 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 09:14:34 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 09:14:34 --> Final output sent to browser
DEBUG - 2018-09-28 09:14:34 --> Total execution time: 0.0620
INFO - 2018-09-28 10:07:47 --> Config Class Initialized
INFO - 2018-09-28 10:07:47 --> Hooks Class Initialized
DEBUG - 2018-09-28 10:07:47 --> UTF-8 Support Enabled
INFO - 2018-09-28 10:07:47 --> Utf8 Class Initialized
INFO - 2018-09-28 10:07:47 --> URI Class Initialized
INFO - 2018-09-28 10:07:47 --> Router Class Initialized
INFO - 2018-09-28 10:07:47 --> Output Class Initialized
INFO - 2018-09-28 10:07:47 --> Security Class Initialized
DEBUG - 2018-09-28 10:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 10:07:47 --> Input Class Initialized
INFO - 2018-09-28 10:07:47 --> Language Class Initialized
INFO - 2018-09-28 10:07:47 --> Loader Class Initialized
INFO - 2018-09-28 10:07:47 --> Helper loaded: url_helper
INFO - 2018-09-28 10:07:47 --> Helper loaded: form_helper
INFO - 2018-09-28 10:07:47 --> Helper loaded: html_helper
INFO - 2018-09-28 10:07:47 --> Database Driver Class Initialized
INFO - 2018-09-28 10:07:47 --> Form Validation Class Initialized
DEBUG - 2018-09-28 10:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 10:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 10:07:47 --> Model "User_model" initialized
INFO - 2018-09-28 10:07:47 --> Model "Project_model" initialized
INFO - 2018-09-28 10:07:47 --> Model "Tasks_model" initialized
INFO - 2018-09-28 10:07:47 --> Model "Lists_model" initialized
INFO - 2018-09-28 10:07:47 --> Controller Class Initialized
INFO - 2018-09-28 10:07:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 10:07:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-28 10:07:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 10:07:47 --> Final output sent to browser
DEBUG - 2018-09-28 10:07:47 --> Total execution time: 0.6330
INFO - 2018-09-28 10:07:58 --> Config Class Initialized
INFO - 2018-09-28 10:07:58 --> Hooks Class Initialized
DEBUG - 2018-09-28 10:07:58 --> UTF-8 Support Enabled
INFO - 2018-09-28 10:07:58 --> Utf8 Class Initialized
INFO - 2018-09-28 10:07:58 --> URI Class Initialized
INFO - 2018-09-28 10:07:58 --> Router Class Initialized
INFO - 2018-09-28 10:07:58 --> Output Class Initialized
INFO - 2018-09-28 10:07:58 --> Security Class Initialized
DEBUG - 2018-09-28 10:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 10:07:58 --> Input Class Initialized
INFO - 2018-09-28 10:07:58 --> Language Class Initialized
INFO - 2018-09-28 10:07:58 --> Loader Class Initialized
INFO - 2018-09-28 10:07:58 --> Helper loaded: url_helper
INFO - 2018-09-28 10:07:58 --> Helper loaded: form_helper
INFO - 2018-09-28 10:07:58 --> Helper loaded: html_helper
INFO - 2018-09-28 10:07:58 --> Database Driver Class Initialized
INFO - 2018-09-28 10:07:58 --> Form Validation Class Initialized
DEBUG - 2018-09-28 10:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 10:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 10:07:58 --> Model "User_model" initialized
INFO - 2018-09-28 10:07:58 --> Model "Project_model" initialized
INFO - 2018-09-28 10:07:58 --> Model "Tasks_model" initialized
INFO - 2018-09-28 10:07:58 --> Model "Lists_model" initialized
INFO - 2018-09-28 10:07:58 --> Controller Class Initialized
INFO - 2018-09-28 10:07:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 10:07:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-09-28 10:07:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 10:07:58 --> Final output sent to browser
DEBUG - 2018-09-28 10:07:58 --> Total execution time: 0.0820
INFO - 2018-09-28 10:07:59 --> Config Class Initialized
INFO - 2018-09-28 10:07:59 --> Hooks Class Initialized
DEBUG - 2018-09-28 10:07:59 --> UTF-8 Support Enabled
INFO - 2018-09-28 10:07:59 --> Utf8 Class Initialized
INFO - 2018-09-28 10:07:59 --> URI Class Initialized
INFO - 2018-09-28 10:07:59 --> Router Class Initialized
INFO - 2018-09-28 10:07:59 --> Output Class Initialized
INFO - 2018-09-28 10:07:59 --> Security Class Initialized
DEBUG - 2018-09-28 10:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 10:07:59 --> Input Class Initialized
INFO - 2018-09-28 10:07:59 --> Language Class Initialized
INFO - 2018-09-28 10:07:59 --> Loader Class Initialized
INFO - 2018-09-28 10:07:59 --> Helper loaded: url_helper
INFO - 2018-09-28 10:07:59 --> Helper loaded: form_helper
INFO - 2018-09-28 10:07:59 --> Helper loaded: html_helper
INFO - 2018-09-28 10:07:59 --> Database Driver Class Initialized
INFO - 2018-09-28 10:07:59 --> Form Validation Class Initialized
DEBUG - 2018-09-28 10:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 10:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 10:07:59 --> Model "User_model" initialized
INFO - 2018-09-28 10:07:59 --> Model "Project_model" initialized
INFO - 2018-09-28 10:07:59 --> Model "Tasks_model" initialized
INFO - 2018-09-28 10:07:59 --> Model "Lists_model" initialized
INFO - 2018-09-28 10:07:59 --> Controller Class Initialized
INFO - 2018-09-28 10:07:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 10:07:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-28 10:07:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 10:07:59 --> Final output sent to browser
DEBUG - 2018-09-28 10:07:59 --> Total execution time: 0.0840
INFO - 2018-09-28 10:48:58 --> Config Class Initialized
INFO - 2018-09-28 10:48:58 --> Hooks Class Initialized
DEBUG - 2018-09-28 10:48:58 --> UTF-8 Support Enabled
INFO - 2018-09-28 10:48:58 --> Utf8 Class Initialized
INFO - 2018-09-28 10:48:58 --> URI Class Initialized
INFO - 2018-09-28 10:48:58 --> Router Class Initialized
INFO - 2018-09-28 10:48:58 --> Output Class Initialized
INFO - 2018-09-28 10:48:58 --> Security Class Initialized
DEBUG - 2018-09-28 10:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 10:48:58 --> Input Class Initialized
INFO - 2018-09-28 10:48:58 --> Language Class Initialized
INFO - 2018-09-28 10:48:58 --> Loader Class Initialized
INFO - 2018-09-28 10:48:58 --> Helper loaded: url_helper
INFO - 2018-09-28 10:48:58 --> Helper loaded: form_helper
INFO - 2018-09-28 10:48:58 --> Helper loaded: html_helper
INFO - 2018-09-28 10:48:58 --> Database Driver Class Initialized
INFO - 2018-09-28 10:48:58 --> Form Validation Class Initialized
DEBUG - 2018-09-28 10:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 10:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 10:48:58 --> Model "User_model" initialized
INFO - 2018-09-28 10:48:58 --> Model "Project_model" initialized
INFO - 2018-09-28 10:48:58 --> Model "Tasks_model" initialized
INFO - 2018-09-28 10:48:58 --> Model "Lists_model" initialized
INFO - 2018-09-28 10:48:58 --> Controller Class Initialized
INFO - 2018-09-28 10:48:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 10:48:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-28 10:48:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 10:48:58 --> Final output sent to browser
DEBUG - 2018-09-28 10:48:58 --> Total execution time: 0.1870
INFO - 2018-09-28 10:51:01 --> Config Class Initialized
INFO - 2018-09-28 10:51:01 --> Hooks Class Initialized
DEBUG - 2018-09-28 10:51:01 --> UTF-8 Support Enabled
INFO - 2018-09-28 10:51:01 --> Utf8 Class Initialized
INFO - 2018-09-28 10:51:01 --> URI Class Initialized
INFO - 2018-09-28 10:51:01 --> Router Class Initialized
INFO - 2018-09-28 10:51:01 --> Output Class Initialized
INFO - 2018-09-28 10:51:01 --> Security Class Initialized
DEBUG - 2018-09-28 10:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 10:51:01 --> Input Class Initialized
INFO - 2018-09-28 10:51:01 --> Language Class Initialized
ERROR - 2018-09-28 10:51:01 --> 404 Page Not Found: /index
INFO - 2018-09-28 14:47:05 --> Config Class Initialized
INFO - 2018-09-28 14:47:06 --> Hooks Class Initialized
DEBUG - 2018-09-28 14:47:06 --> UTF-8 Support Enabled
INFO - 2018-09-28 14:47:06 --> Utf8 Class Initialized
INFO - 2018-09-28 14:47:06 --> URI Class Initialized
INFO - 2018-09-28 14:47:06 --> Router Class Initialized
INFO - 2018-09-28 14:47:06 --> Output Class Initialized
INFO - 2018-09-28 14:47:06 --> Security Class Initialized
DEBUG - 2018-09-28 14:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 14:47:06 --> Input Class Initialized
INFO - 2018-09-28 14:47:06 --> Language Class Initialized
INFO - 2018-09-28 14:47:06 --> Loader Class Initialized
INFO - 2018-09-28 14:47:06 --> Helper loaded: url_helper
INFO - 2018-09-28 14:47:06 --> Helper loaded: form_helper
INFO - 2018-09-28 14:47:06 --> Helper loaded: html_helper
INFO - 2018-09-28 14:47:06 --> Database Driver Class Initialized
INFO - 2018-09-28 14:47:06 --> Form Validation Class Initialized
DEBUG - 2018-09-28 14:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 14:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 14:47:06 --> Model "User_model" initialized
INFO - 2018-09-28 14:47:06 --> Model "Project_model" initialized
INFO - 2018-09-28 14:47:06 --> Model "Tasks_model" initialized
INFO - 2018-09-28 14:47:06 --> Model "Lists_model" initialized
INFO - 2018-09-28 14:47:06 --> Controller Class Initialized
INFO - 2018-09-28 14:47:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 14:47:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-28 14:47:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 14:47:06 --> Final output sent to browser
DEBUG - 2018-09-28 14:47:06 --> Total execution time: 0.5760
INFO - 2018-09-28 15:40:29 --> Config Class Initialized
INFO - 2018-09-28 15:40:29 --> Hooks Class Initialized
DEBUG - 2018-09-28 15:40:31 --> UTF-8 Support Enabled
INFO - 2018-09-28 15:40:31 --> Utf8 Class Initialized
INFO - 2018-09-28 15:40:31 --> URI Class Initialized
INFO - 2018-09-28 15:40:31 --> Router Class Initialized
INFO - 2018-09-28 15:40:31 --> Output Class Initialized
INFO - 2018-09-28 15:40:31 --> Security Class Initialized
DEBUG - 2018-09-28 15:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 15:40:31 --> Input Class Initialized
INFO - 2018-09-28 15:40:31 --> Language Class Initialized
INFO - 2018-09-28 15:40:31 --> Loader Class Initialized
INFO - 2018-09-28 15:40:31 --> Helper loaded: url_helper
INFO - 2018-09-28 15:40:31 --> Helper loaded: form_helper
INFO - 2018-09-28 15:40:31 --> Helper loaded: html_helper
INFO - 2018-09-28 15:40:31 --> Database Driver Class Initialized
INFO - 2018-09-28 15:40:31 --> Form Validation Class Initialized
DEBUG - 2018-09-28 15:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 15:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 15:40:31 --> Model "User_model" initialized
INFO - 2018-09-28 15:40:31 --> Model "Project_model" initialized
INFO - 2018-09-28 15:40:31 --> Model "Tasks_model" initialized
INFO - 2018-09-28 15:40:31 --> Model "Lists_model" initialized
INFO - 2018-09-28 15:40:31 --> Controller Class Initialized
INFO - 2018-09-28 15:40:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 15:40:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-28 15:40:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 15:40:31 --> Final output sent to browser
DEBUG - 2018-09-28 15:40:31 --> Total execution time: 1.3241
INFO - 2018-09-28 15:40:40 --> Config Class Initialized
INFO - 2018-09-28 15:40:40 --> Hooks Class Initialized
DEBUG - 2018-09-28 15:40:40 --> UTF-8 Support Enabled
INFO - 2018-09-28 15:40:40 --> Utf8 Class Initialized
INFO - 2018-09-28 15:40:40 --> URI Class Initialized
INFO - 2018-09-28 15:40:40 --> Router Class Initialized
INFO - 2018-09-28 15:40:40 --> Output Class Initialized
INFO - 2018-09-28 15:40:40 --> Security Class Initialized
DEBUG - 2018-09-28 15:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 15:40:40 --> Input Class Initialized
INFO - 2018-09-28 15:40:40 --> Language Class Initialized
ERROR - 2018-09-28 15:40:40 --> 404 Page Not Found: /index
INFO - 2018-09-28 15:41:08 --> Config Class Initialized
INFO - 2018-09-28 15:41:08 --> Hooks Class Initialized
DEBUG - 2018-09-28 15:41:08 --> UTF-8 Support Enabled
INFO - 2018-09-28 15:41:08 --> Utf8 Class Initialized
INFO - 2018-09-28 15:41:08 --> URI Class Initialized
INFO - 2018-09-28 15:41:08 --> Router Class Initialized
INFO - 2018-09-28 15:41:08 --> Output Class Initialized
INFO - 2018-09-28 15:41:08 --> Security Class Initialized
DEBUG - 2018-09-28 15:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-28 15:41:08 --> Input Class Initialized
INFO - 2018-09-28 15:41:08 --> Language Class Initialized
INFO - 2018-09-28 15:41:08 --> Loader Class Initialized
INFO - 2018-09-28 15:41:08 --> Helper loaded: url_helper
INFO - 2018-09-28 15:41:08 --> Helper loaded: form_helper
INFO - 2018-09-28 15:41:08 --> Helper loaded: html_helper
INFO - 2018-09-28 15:41:08 --> Database Driver Class Initialized
INFO - 2018-09-28 15:41:08 --> Form Validation Class Initialized
DEBUG - 2018-09-28 15:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-28 15:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-28 15:41:08 --> Model "User_model" initialized
INFO - 2018-09-28 15:41:08 --> Model "Project_model" initialized
INFO - 2018-09-28 15:41:08 --> Model "Tasks_model" initialized
INFO - 2018-09-28 15:41:08 --> Model "Lists_model" initialized
INFO - 2018-09-28 15:41:08 --> Controller Class Initialized
INFO - 2018-09-28 15:41:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-28 15:41:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-28 15:41:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-28 15:41:08 --> Final output sent to browser
DEBUG - 2018-09-28 15:41:08 --> Total execution time: 0.0510
