<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-26 10:55:30 --> Config Class Initialized
INFO - 2018-10-26 10:55:30 --> Hooks Class Initialized
DEBUG - 2018-10-26 10:55:30 --> UTF-8 Support Enabled
INFO - 2018-10-26 10:55:30 --> Utf8 Class Initialized
INFO - 2018-10-26 10:55:30 --> URI Class Initialized
INFO - 2018-10-26 10:55:30 --> Router Class Initialized
INFO - 2018-10-26 10:55:30 --> Output Class Initialized
INFO - 2018-10-26 10:55:30 --> Security Class Initialized
DEBUG - 2018-10-26 10:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 10:55:30 --> Input Class Initialized
INFO - 2018-10-26 10:55:30 --> Language Class Initialized
INFO - 2018-10-26 10:55:30 --> Loader Class Initialized
INFO - 2018-10-26 10:55:30 --> Helper loaded: url_helper
INFO - 2018-10-26 10:55:30 --> Helper loaded: form_helper
INFO - 2018-10-26 10:55:30 --> Helper loaded: html_helper
INFO - 2018-10-26 10:55:30 --> Database Driver Class Initialized
INFO - 2018-10-26 10:55:30 --> Form Validation Class Initialized
DEBUG - 2018-10-26 10:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 10:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 10:55:30 --> Model "User_model" initialized
INFO - 2018-10-26 10:55:30 --> Model "Project_model" initialized
INFO - 2018-10-26 10:55:30 --> Model "Tasks_model" initialized
INFO - 2018-10-26 10:55:30 --> Model "Lists_model" initialized
INFO - 2018-10-26 10:55:30 --> Controller Class Initialized
INFO - 2018-10-26 10:55:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 10:55:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 10:55:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 10:55:30 --> Final output sent to browser
DEBUG - 2018-10-26 10:55:30 --> Total execution time: 0.2110
INFO - 2018-10-26 10:55:33 --> Config Class Initialized
INFO - 2018-10-26 10:55:33 --> Hooks Class Initialized
DEBUG - 2018-10-26 10:55:33 --> UTF-8 Support Enabled
INFO - 2018-10-26 10:55:33 --> Utf8 Class Initialized
INFO - 2018-10-26 10:55:33 --> URI Class Initialized
INFO - 2018-10-26 10:55:33 --> Router Class Initialized
INFO - 2018-10-26 10:55:33 --> Output Class Initialized
INFO - 2018-10-26 10:55:33 --> Security Class Initialized
DEBUG - 2018-10-26 10:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 10:55:33 --> Input Class Initialized
INFO - 2018-10-26 10:55:33 --> Language Class Initialized
INFO - 2018-10-26 10:55:33 --> Loader Class Initialized
INFO - 2018-10-26 10:55:33 --> Helper loaded: url_helper
INFO - 2018-10-26 10:55:33 --> Helper loaded: form_helper
INFO - 2018-10-26 10:55:33 --> Helper loaded: html_helper
INFO - 2018-10-26 10:55:33 --> Database Driver Class Initialized
INFO - 2018-10-26 10:55:33 --> Form Validation Class Initialized
DEBUG - 2018-10-26 10:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 10:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 10:55:33 --> Model "User_model" initialized
INFO - 2018-10-26 10:55:33 --> Model "Project_model" initialized
INFO - 2018-10-26 10:55:33 --> Model "Tasks_model" initialized
INFO - 2018-10-26 10:55:33 --> Model "Lists_model" initialized
INFO - 2018-10-26 10:55:33 --> Controller Class Initialized
INFO - 2018-10-26 10:55:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 10:55:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 10:55:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 10:55:33 --> Final output sent to browser
DEBUG - 2018-10-26 10:55:33 --> Total execution time: 0.0760
INFO - 2018-10-26 10:55:34 --> Config Class Initialized
INFO - 2018-10-26 10:55:34 --> Hooks Class Initialized
DEBUG - 2018-10-26 10:55:34 --> UTF-8 Support Enabled
INFO - 2018-10-26 10:55:34 --> Utf8 Class Initialized
INFO - 2018-10-26 10:55:34 --> URI Class Initialized
INFO - 2018-10-26 10:55:34 --> Router Class Initialized
INFO - 2018-10-26 10:55:34 --> Output Class Initialized
INFO - 2018-10-26 10:55:34 --> Security Class Initialized
DEBUG - 2018-10-26 10:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 10:55:34 --> Input Class Initialized
INFO - 2018-10-26 10:55:34 --> Language Class Initialized
INFO - 2018-10-26 10:55:34 --> Loader Class Initialized
INFO - 2018-10-26 10:55:34 --> Helper loaded: url_helper
INFO - 2018-10-26 10:55:34 --> Helper loaded: form_helper
INFO - 2018-10-26 10:55:34 --> Helper loaded: html_helper
INFO - 2018-10-26 10:55:34 --> Database Driver Class Initialized
INFO - 2018-10-26 10:55:34 --> Form Validation Class Initialized
DEBUG - 2018-10-26 10:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 10:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 10:55:34 --> Model "User_model" initialized
INFO - 2018-10-26 10:55:34 --> Model "Project_model" initialized
INFO - 2018-10-26 10:55:34 --> Model "Tasks_model" initialized
INFO - 2018-10-26 10:55:34 --> Model "Lists_model" initialized
INFO - 2018-10-26 10:55:34 --> Controller Class Initialized
INFO - 2018-10-26 10:55:34 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 10:55:34 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 10:55:34 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 10:55:34 --> Final output sent to browser
DEBUG - 2018-10-26 10:55:34 --> Total execution time: 0.0560
INFO - 2018-10-26 10:55:56 --> Config Class Initialized
INFO - 2018-10-26 10:55:56 --> Hooks Class Initialized
DEBUG - 2018-10-26 10:55:56 --> UTF-8 Support Enabled
INFO - 2018-10-26 10:55:56 --> Utf8 Class Initialized
INFO - 2018-10-26 10:55:56 --> URI Class Initialized
INFO - 2018-10-26 10:55:56 --> Router Class Initialized
INFO - 2018-10-26 10:55:56 --> Output Class Initialized
INFO - 2018-10-26 10:55:56 --> Security Class Initialized
DEBUG - 2018-10-26 10:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 10:55:56 --> Input Class Initialized
INFO - 2018-10-26 10:55:56 --> Language Class Initialized
ERROR - 2018-10-26 10:55:56 --> 404 Page Not Found: %20-%20Copy/project_controllers
INFO - 2018-10-26 10:57:24 --> Config Class Initialized
INFO - 2018-10-26 10:57:24 --> Hooks Class Initialized
DEBUG - 2018-10-26 10:57:24 --> UTF-8 Support Enabled
INFO - 2018-10-26 10:57:24 --> Utf8 Class Initialized
INFO - 2018-10-26 10:57:24 --> URI Class Initialized
INFO - 2018-10-26 10:57:24 --> Router Class Initialized
INFO - 2018-10-26 10:57:24 --> Output Class Initialized
INFO - 2018-10-26 10:57:24 --> Security Class Initialized
DEBUG - 2018-10-26 10:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 10:57:24 --> Input Class Initialized
INFO - 2018-10-26 10:57:24 --> Language Class Initialized
ERROR - 2018-10-26 10:57:24 --> 404 Page Not Found: User_test/controllers
INFO - 2018-10-26 11:02:34 --> Config Class Initialized
INFO - 2018-10-26 11:02:34 --> Hooks Class Initialized
DEBUG - 2018-10-26 11:02:34 --> UTF-8 Support Enabled
INFO - 2018-10-26 11:02:34 --> Utf8 Class Initialized
INFO - 2018-10-26 11:02:34 --> URI Class Initialized
INFO - 2018-10-26 11:02:34 --> Router Class Initialized
INFO - 2018-10-26 11:02:34 --> Output Class Initialized
INFO - 2018-10-26 11:02:34 --> Security Class Initialized
DEBUG - 2018-10-26 11:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 11:02:34 --> Input Class Initialized
INFO - 2018-10-26 11:02:34 --> Language Class Initialized
ERROR - 2018-10-26 11:02:34 --> 404 Page Not Found: User_test/controllers
INFO - 2018-10-26 11:02:48 --> Config Class Initialized
INFO - 2018-10-26 11:02:48 --> Hooks Class Initialized
DEBUG - 2018-10-26 11:02:48 --> UTF-8 Support Enabled
INFO - 2018-10-26 11:02:48 --> Utf8 Class Initialized
INFO - 2018-10-26 11:02:48 --> URI Class Initialized
INFO - 2018-10-26 11:02:48 --> Router Class Initialized
INFO - 2018-10-26 11:02:48 --> Output Class Initialized
INFO - 2018-10-26 11:02:48 --> Security Class Initialized
DEBUG - 2018-10-26 11:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 11:02:48 --> Input Class Initialized
INFO - 2018-10-26 11:02:48 --> Language Class Initialized
ERROR - 2018-10-26 11:02:48 --> 404 Page Not Found: User_test/controllers
INFO - 2018-10-26 11:04:23 --> Config Class Initialized
INFO - 2018-10-26 11:04:23 --> Hooks Class Initialized
DEBUG - 2018-10-26 11:04:23 --> UTF-8 Support Enabled
INFO - 2018-10-26 11:04:23 --> Utf8 Class Initialized
INFO - 2018-10-26 11:04:23 --> URI Class Initialized
INFO - 2018-10-26 11:04:23 --> Router Class Initialized
INFO - 2018-10-26 11:04:23 --> Output Class Initialized
INFO - 2018-10-26 11:04:23 --> Security Class Initialized
DEBUG - 2018-10-26 11:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 11:04:23 --> Input Class Initialized
INFO - 2018-10-26 11:04:23 --> Language Class Initialized
ERROR - 2018-10-26 11:04:23 --> 404 Page Not Found: User_test/controllers
INFO - 2018-10-26 11:04:55 --> Config Class Initialized
INFO - 2018-10-26 11:04:55 --> Hooks Class Initialized
DEBUG - 2018-10-26 11:04:55 --> UTF-8 Support Enabled
INFO - 2018-10-26 11:04:55 --> Utf8 Class Initialized
INFO - 2018-10-26 11:04:55 --> URI Class Initialized
INFO - 2018-10-26 11:04:55 --> Router Class Initialized
INFO - 2018-10-26 11:04:55 --> Output Class Initialized
INFO - 2018-10-26 11:04:55 --> Security Class Initialized
DEBUG - 2018-10-26 11:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 11:04:55 --> Input Class Initialized
INFO - 2018-10-26 11:04:55 --> Language Class Initialized
ERROR - 2018-10-26 11:04:55 --> 404 Page Not Found: User_test/controllers
INFO - 2018-10-26 11:04:56 --> Config Class Initialized
INFO - 2018-10-26 11:04:56 --> Hooks Class Initialized
DEBUG - 2018-10-26 11:04:56 --> UTF-8 Support Enabled
INFO - 2018-10-26 11:04:56 --> Utf8 Class Initialized
INFO - 2018-10-26 11:04:56 --> URI Class Initialized
INFO - 2018-10-26 11:04:56 --> Router Class Initialized
INFO - 2018-10-26 11:04:56 --> Output Class Initialized
INFO - 2018-10-26 11:04:56 --> Security Class Initialized
DEBUG - 2018-10-26 11:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 11:04:56 --> Input Class Initialized
INFO - 2018-10-26 11:04:56 --> Language Class Initialized
ERROR - 2018-10-26 11:04:56 --> 404 Page Not Found: User_test/controllers
INFO - 2018-10-26 11:04:57 --> Config Class Initialized
INFO - 2018-10-26 11:04:57 --> Hooks Class Initialized
DEBUG - 2018-10-26 11:04:57 --> UTF-8 Support Enabled
INFO - 2018-10-26 11:04:57 --> Utf8 Class Initialized
INFO - 2018-10-26 11:04:57 --> URI Class Initialized
INFO - 2018-10-26 11:04:57 --> Router Class Initialized
INFO - 2018-10-26 11:04:57 --> Output Class Initialized
INFO - 2018-10-26 11:04:57 --> Security Class Initialized
DEBUG - 2018-10-26 11:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 11:04:57 --> Input Class Initialized
INFO - 2018-10-26 11:04:57 --> Language Class Initialized
ERROR - 2018-10-26 11:04:57 --> 404 Page Not Found: User_test/controllers
INFO - 2018-10-26 11:04:57 --> Config Class Initialized
INFO - 2018-10-26 11:04:57 --> Hooks Class Initialized
DEBUG - 2018-10-26 11:04:57 --> UTF-8 Support Enabled
INFO - 2018-10-26 11:04:57 --> Utf8 Class Initialized
INFO - 2018-10-26 11:04:57 --> URI Class Initialized
INFO - 2018-10-26 11:04:57 --> Router Class Initialized
INFO - 2018-10-26 11:04:57 --> Output Class Initialized
INFO - 2018-10-26 11:04:57 --> Security Class Initialized
DEBUG - 2018-10-26 11:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 11:04:57 --> Input Class Initialized
INFO - 2018-10-26 11:04:57 --> Language Class Initialized
ERROR - 2018-10-26 11:04:57 --> 404 Page Not Found: User_test/controllers
INFO - 2018-10-26 11:04:57 --> Config Class Initialized
INFO - 2018-10-26 11:04:57 --> Hooks Class Initialized
DEBUG - 2018-10-26 11:04:57 --> UTF-8 Support Enabled
INFO - 2018-10-26 11:04:57 --> Utf8 Class Initialized
INFO - 2018-10-26 11:04:57 --> URI Class Initialized
INFO - 2018-10-26 11:04:57 --> Router Class Initialized
INFO - 2018-10-26 11:04:57 --> Output Class Initialized
INFO - 2018-10-26 11:04:57 --> Security Class Initialized
DEBUG - 2018-10-26 11:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 11:04:57 --> Input Class Initialized
INFO - 2018-10-26 11:04:57 --> Language Class Initialized
ERROR - 2018-10-26 11:04:57 --> 404 Page Not Found: User_test/controllers
INFO - 2018-10-26 11:04:57 --> Config Class Initialized
INFO - 2018-10-26 11:04:57 --> Hooks Class Initialized
DEBUG - 2018-10-26 11:04:57 --> UTF-8 Support Enabled
INFO - 2018-10-26 11:04:57 --> Utf8 Class Initialized
INFO - 2018-10-26 11:04:57 --> URI Class Initialized
INFO - 2018-10-26 11:04:57 --> Router Class Initialized
INFO - 2018-10-26 11:04:57 --> Output Class Initialized
INFO - 2018-10-26 11:04:57 --> Security Class Initialized
DEBUG - 2018-10-26 11:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 11:04:57 --> Input Class Initialized
INFO - 2018-10-26 11:04:57 --> Language Class Initialized
ERROR - 2018-10-26 11:04:57 --> 404 Page Not Found: User_test/controllers
INFO - 2018-10-26 11:04:58 --> Config Class Initialized
INFO - 2018-10-26 11:04:58 --> Hooks Class Initialized
DEBUG - 2018-10-26 11:04:58 --> UTF-8 Support Enabled
INFO - 2018-10-26 11:04:58 --> Utf8 Class Initialized
INFO - 2018-10-26 11:04:58 --> URI Class Initialized
INFO - 2018-10-26 11:04:58 --> Router Class Initialized
INFO - 2018-10-26 11:04:58 --> Output Class Initialized
INFO - 2018-10-26 11:04:58 --> Security Class Initialized
DEBUG - 2018-10-26 11:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 11:04:58 --> Input Class Initialized
INFO - 2018-10-26 11:04:58 --> Language Class Initialized
ERROR - 2018-10-26 11:04:58 --> 404 Page Not Found: User_test/controllers
INFO - 2018-10-26 11:04:58 --> Config Class Initialized
INFO - 2018-10-26 11:04:58 --> Hooks Class Initialized
DEBUG - 2018-10-26 11:04:58 --> UTF-8 Support Enabled
INFO - 2018-10-26 11:04:58 --> Utf8 Class Initialized
INFO - 2018-10-26 11:04:58 --> URI Class Initialized
INFO - 2018-10-26 11:04:58 --> Router Class Initialized
INFO - 2018-10-26 11:04:58 --> Output Class Initialized
INFO - 2018-10-26 11:04:58 --> Security Class Initialized
DEBUG - 2018-10-26 11:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 11:04:58 --> Input Class Initialized
INFO - 2018-10-26 11:04:58 --> Language Class Initialized
ERROR - 2018-10-26 11:04:58 --> 404 Page Not Found: User_test/controllers
INFO - 2018-10-26 13:49:33 --> Config Class Initialized
INFO - 2018-10-26 13:49:33 --> Hooks Class Initialized
DEBUG - 2018-10-26 13:49:33 --> UTF-8 Support Enabled
INFO - 2018-10-26 13:49:33 --> Utf8 Class Initialized
INFO - 2018-10-26 13:49:33 --> URI Class Initialized
INFO - 2018-10-26 13:49:33 --> Router Class Initialized
INFO - 2018-10-26 13:49:33 --> Output Class Initialized
INFO - 2018-10-26 13:49:33 --> Security Class Initialized
DEBUG - 2018-10-26 13:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 13:49:33 --> Input Class Initialized
INFO - 2018-10-26 13:49:33 --> Language Class Initialized
INFO - 2018-10-26 13:49:33 --> Loader Class Initialized
INFO - 2018-10-26 13:49:33 --> Helper loaded: url_helper
INFO - 2018-10-26 13:49:33 --> Helper loaded: form_helper
INFO - 2018-10-26 13:49:33 --> Helper loaded: html_helper
INFO - 2018-10-26 13:49:33 --> Database Driver Class Initialized
INFO - 2018-10-26 13:49:33 --> Form Validation Class Initialized
DEBUG - 2018-10-26 13:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 13:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 13:49:33 --> Model "User_model" initialized
INFO - 2018-10-26 13:49:33 --> Model "Project_model" initialized
INFO - 2018-10-26 13:49:33 --> Model "Tasks_model" initialized
INFO - 2018-10-26 13:49:33 --> Model "Lists_model" initialized
INFO - 2018-10-26 13:49:33 --> Controller Class Initialized
INFO - 2018-10-26 13:49:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 13:49:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 13:49:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 13:49:33 --> Final output sent to browser
DEBUG - 2018-10-26 13:49:33 --> Total execution time: 0.0590
INFO - 2018-10-26 13:49:35 --> Config Class Initialized
INFO - 2018-10-26 13:49:35 --> Hooks Class Initialized
DEBUG - 2018-10-26 13:49:35 --> UTF-8 Support Enabled
INFO - 2018-10-26 13:49:35 --> Utf8 Class Initialized
INFO - 2018-10-26 13:49:36 --> URI Class Initialized
INFO - 2018-10-26 13:49:36 --> Router Class Initialized
INFO - 2018-10-26 13:49:36 --> Output Class Initialized
INFO - 2018-10-26 13:49:36 --> Security Class Initialized
DEBUG - 2018-10-26 13:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 13:49:36 --> Input Class Initialized
INFO - 2018-10-26 13:49:36 --> Language Class Initialized
INFO - 2018-10-26 13:49:36 --> Loader Class Initialized
INFO - 2018-10-26 13:49:36 --> Helper loaded: url_helper
INFO - 2018-10-26 13:49:36 --> Helper loaded: form_helper
INFO - 2018-10-26 13:49:36 --> Helper loaded: html_helper
INFO - 2018-10-26 13:49:36 --> Database Driver Class Initialized
INFO - 2018-10-26 13:49:36 --> Form Validation Class Initialized
DEBUG - 2018-10-26 13:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 13:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 13:49:36 --> Model "User_model" initialized
INFO - 2018-10-26 13:49:36 --> Model "Project_model" initialized
INFO - 2018-10-26 13:49:36 --> Model "Tasks_model" initialized
INFO - 2018-10-26 13:49:36 --> Model "Lists_model" initialized
INFO - 2018-10-26 13:49:36 --> Controller Class Initialized
INFO - 2018-10-26 13:49:36 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 13:49:36 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 13:49:36 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 13:49:36 --> Final output sent to browser
DEBUG - 2018-10-26 13:49:36 --> Total execution time: 0.0610
INFO - 2018-10-26 13:49:36 --> Config Class Initialized
INFO - 2018-10-26 13:49:36 --> Hooks Class Initialized
DEBUG - 2018-10-26 13:49:36 --> UTF-8 Support Enabled
INFO - 2018-10-26 13:49:36 --> Utf8 Class Initialized
INFO - 2018-10-26 13:49:36 --> URI Class Initialized
INFO - 2018-10-26 13:49:36 --> Router Class Initialized
INFO - 2018-10-26 13:49:36 --> Output Class Initialized
INFO - 2018-10-26 13:49:36 --> Security Class Initialized
DEBUG - 2018-10-26 13:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 13:49:36 --> Input Class Initialized
INFO - 2018-10-26 13:49:36 --> Language Class Initialized
INFO - 2018-10-26 13:49:36 --> Loader Class Initialized
INFO - 2018-10-26 13:49:36 --> Helper loaded: url_helper
INFO - 2018-10-26 13:49:36 --> Helper loaded: form_helper
INFO - 2018-10-26 13:49:36 --> Helper loaded: html_helper
INFO - 2018-10-26 13:49:36 --> Database Driver Class Initialized
INFO - 2018-10-26 13:49:36 --> Form Validation Class Initialized
DEBUG - 2018-10-26 13:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 13:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 13:49:36 --> Model "User_model" initialized
INFO - 2018-10-26 13:49:36 --> Model "Project_model" initialized
INFO - 2018-10-26 13:49:36 --> Model "Tasks_model" initialized
INFO - 2018-10-26 13:49:36 --> Model "Lists_model" initialized
INFO - 2018-10-26 13:49:36 --> Controller Class Initialized
INFO - 2018-10-26 13:49:36 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 13:49:36 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 13:49:36 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 13:49:36 --> Final output sent to browser
DEBUG - 2018-10-26 13:49:36 --> Total execution time: 0.0550
INFO - 2018-10-26 13:51:15 --> Config Class Initialized
INFO - 2018-10-26 13:51:15 --> Hooks Class Initialized
DEBUG - 2018-10-26 13:51:15 --> UTF-8 Support Enabled
INFO - 2018-10-26 13:51:15 --> Utf8 Class Initialized
INFO - 2018-10-26 13:51:15 --> URI Class Initialized
INFO - 2018-10-26 13:51:15 --> Router Class Initialized
INFO - 2018-10-26 13:51:15 --> Output Class Initialized
INFO - 2018-10-26 13:51:15 --> Security Class Initialized
DEBUG - 2018-10-26 13:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 13:51:15 --> Input Class Initialized
INFO - 2018-10-26 13:51:15 --> Language Class Initialized
INFO - 2018-10-26 13:51:15 --> Loader Class Initialized
INFO - 2018-10-26 13:51:15 --> Helper loaded: url_helper
INFO - 2018-10-26 13:51:15 --> Helper loaded: form_helper
INFO - 2018-10-26 13:51:15 --> Helper loaded: html_helper
INFO - 2018-10-26 13:51:15 --> Database Driver Class Initialized
INFO - 2018-10-26 13:51:15 --> Form Validation Class Initialized
DEBUG - 2018-10-26 13:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 13:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 13:51:15 --> Model "User_model" initialized
INFO - 2018-10-26 13:51:15 --> Model "Project_model" initialized
INFO - 2018-10-26 13:51:15 --> Model "Tasks_model" initialized
INFO - 2018-10-26 13:51:15 --> Model "Lists_model" initialized
INFO - 2018-10-26 13:51:15 --> Controller Class Initialized
INFO - 2018-10-26 13:51:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 13:51:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 13:51:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 13:51:15 --> Final output sent to browser
DEBUG - 2018-10-26 13:51:15 --> Total execution time: 0.0680
INFO - 2018-10-26 13:51:34 --> Config Class Initialized
INFO - 2018-10-26 13:51:34 --> Hooks Class Initialized
DEBUG - 2018-10-26 13:51:34 --> UTF-8 Support Enabled
INFO - 2018-10-26 13:51:34 --> Utf8 Class Initialized
INFO - 2018-10-26 13:51:34 --> URI Class Initialized
INFO - 2018-10-26 13:51:34 --> Router Class Initialized
INFO - 2018-10-26 13:51:34 --> Output Class Initialized
INFO - 2018-10-26 13:51:34 --> Security Class Initialized
DEBUG - 2018-10-26 13:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 13:51:34 --> Input Class Initialized
INFO - 2018-10-26 13:51:34 --> Language Class Initialized
INFO - 2018-10-26 13:51:34 --> Loader Class Initialized
INFO - 2018-10-26 13:51:34 --> Helper loaded: url_helper
INFO - 2018-10-26 13:51:34 --> Helper loaded: form_helper
INFO - 2018-10-26 13:51:34 --> Helper loaded: html_helper
INFO - 2018-10-26 13:51:34 --> Database Driver Class Initialized
INFO - 2018-10-26 13:51:34 --> Form Validation Class Initialized
DEBUG - 2018-10-26 13:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 13:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 13:51:34 --> Model "User_model" initialized
INFO - 2018-10-26 13:51:34 --> Model "Project_model" initialized
INFO - 2018-10-26 13:51:34 --> Model "Tasks_model" initialized
INFO - 2018-10-26 13:51:34 --> Model "Lists_model" initialized
INFO - 2018-10-26 13:51:34 --> Controller Class Initialized
INFO - 2018-10-26 13:51:34 --> Final output sent to browser
DEBUG - 2018-10-26 13:51:34 --> Total execution time: 0.0540
INFO - 2018-10-26 13:51:40 --> Config Class Initialized
INFO - 2018-10-26 13:51:40 --> Hooks Class Initialized
DEBUG - 2018-10-26 13:51:40 --> UTF-8 Support Enabled
INFO - 2018-10-26 13:51:40 --> Utf8 Class Initialized
INFO - 2018-10-26 13:51:40 --> URI Class Initialized
INFO - 2018-10-26 13:51:40 --> Router Class Initialized
INFO - 2018-10-26 13:51:40 --> Output Class Initialized
INFO - 2018-10-26 13:51:40 --> Security Class Initialized
DEBUG - 2018-10-26 13:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 13:51:40 --> Input Class Initialized
INFO - 2018-10-26 13:51:40 --> Language Class Initialized
INFO - 2018-10-26 13:51:40 --> Loader Class Initialized
INFO - 2018-10-26 13:51:40 --> Helper loaded: url_helper
INFO - 2018-10-26 13:51:40 --> Helper loaded: form_helper
INFO - 2018-10-26 13:51:40 --> Helper loaded: html_helper
INFO - 2018-10-26 13:51:40 --> Database Driver Class Initialized
INFO - 2018-10-26 13:51:40 --> Form Validation Class Initialized
DEBUG - 2018-10-26 13:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 13:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 13:51:40 --> Model "User_model" initialized
INFO - 2018-10-26 13:51:40 --> Model "Project_model" initialized
INFO - 2018-10-26 13:51:40 --> Model "Tasks_model" initialized
INFO - 2018-10-26 13:51:40 --> Model "Lists_model" initialized
INFO - 2018-10-26 13:51:40 --> Controller Class Initialized
INFO - 2018-10-26 13:51:40 --> Final output sent to browser
DEBUG - 2018-10-26 13:51:40 --> Total execution time: 0.0430
INFO - 2018-10-26 13:51:43 --> Config Class Initialized
INFO - 2018-10-26 13:51:43 --> Hooks Class Initialized
DEBUG - 2018-10-26 13:51:43 --> UTF-8 Support Enabled
INFO - 2018-10-26 13:51:43 --> Utf8 Class Initialized
INFO - 2018-10-26 13:51:43 --> URI Class Initialized
INFO - 2018-10-26 13:51:43 --> Router Class Initialized
INFO - 2018-10-26 13:51:43 --> Output Class Initialized
INFO - 2018-10-26 13:51:43 --> Security Class Initialized
DEBUG - 2018-10-26 13:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 13:51:43 --> Input Class Initialized
INFO - 2018-10-26 13:51:43 --> Language Class Initialized
INFO - 2018-10-26 13:51:43 --> Loader Class Initialized
INFO - 2018-10-26 13:51:43 --> Helper loaded: url_helper
INFO - 2018-10-26 13:51:43 --> Helper loaded: form_helper
INFO - 2018-10-26 13:51:43 --> Helper loaded: html_helper
INFO - 2018-10-26 13:51:43 --> Database Driver Class Initialized
INFO - 2018-10-26 13:51:43 --> Form Validation Class Initialized
DEBUG - 2018-10-26 13:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 13:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 13:51:43 --> Model "User_model" initialized
INFO - 2018-10-26 13:51:43 --> Model "Project_model" initialized
INFO - 2018-10-26 13:51:43 --> Model "Tasks_model" initialized
INFO - 2018-10-26 13:51:43 --> Model "Lists_model" initialized
INFO - 2018-10-26 13:51:43 --> Controller Class Initialized
INFO - 2018-10-26 13:51:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 13:51:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 13:51:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 13:51:43 --> Final output sent to browser
DEBUG - 2018-10-26 13:51:43 --> Total execution time: 0.0370
INFO - 2018-10-26 13:52:04 --> Config Class Initialized
INFO - 2018-10-26 13:52:04 --> Hooks Class Initialized
DEBUG - 2018-10-26 13:52:04 --> UTF-8 Support Enabled
INFO - 2018-10-26 13:52:04 --> Utf8 Class Initialized
INFO - 2018-10-26 13:52:04 --> URI Class Initialized
INFO - 2018-10-26 13:52:04 --> Router Class Initialized
INFO - 2018-10-26 13:52:04 --> Output Class Initialized
INFO - 2018-10-26 13:52:04 --> Security Class Initialized
DEBUG - 2018-10-26 13:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 13:52:04 --> Input Class Initialized
INFO - 2018-10-26 13:52:04 --> Language Class Initialized
INFO - 2018-10-26 13:52:04 --> Loader Class Initialized
INFO - 2018-10-26 13:52:04 --> Helper loaded: url_helper
INFO - 2018-10-26 13:52:04 --> Helper loaded: form_helper
INFO - 2018-10-26 13:52:04 --> Helper loaded: html_helper
INFO - 2018-10-26 13:52:04 --> Database Driver Class Initialized
INFO - 2018-10-26 13:52:04 --> Form Validation Class Initialized
DEBUG - 2018-10-26 13:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 13:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 13:52:04 --> Model "User_model" initialized
INFO - 2018-10-26 13:52:04 --> Model "Project_model" initialized
INFO - 2018-10-26 13:52:04 --> Model "Tasks_model" initialized
INFO - 2018-10-26 13:52:04 --> Model "Lists_model" initialized
INFO - 2018-10-26 13:52:04 --> Controller Class Initialized
INFO - 2018-10-26 13:52:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 13:52:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 13:52:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 13:52:04 --> Final output sent to browser
DEBUG - 2018-10-26 13:52:04 --> Total execution time: 0.0850
INFO - 2018-10-26 13:52:08 --> Config Class Initialized
INFO - 2018-10-26 13:52:08 --> Hooks Class Initialized
DEBUG - 2018-10-26 13:52:08 --> UTF-8 Support Enabled
INFO - 2018-10-26 13:52:08 --> Utf8 Class Initialized
INFO - 2018-10-26 13:52:08 --> URI Class Initialized
INFO - 2018-10-26 13:52:08 --> Router Class Initialized
INFO - 2018-10-26 13:52:08 --> Output Class Initialized
INFO - 2018-10-26 13:52:08 --> Security Class Initialized
DEBUG - 2018-10-26 13:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 13:52:08 --> Input Class Initialized
INFO - 2018-10-26 13:52:08 --> Language Class Initialized
INFO - 2018-10-26 13:52:08 --> Loader Class Initialized
INFO - 2018-10-26 13:52:08 --> Helper loaded: url_helper
INFO - 2018-10-26 13:52:08 --> Helper loaded: form_helper
INFO - 2018-10-26 13:52:08 --> Helper loaded: html_helper
INFO - 2018-10-26 13:52:08 --> Database Driver Class Initialized
INFO - 2018-10-26 13:52:08 --> Form Validation Class Initialized
DEBUG - 2018-10-26 13:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 13:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 13:52:08 --> Model "User_model" initialized
INFO - 2018-10-26 13:52:08 --> Model "Project_model" initialized
INFO - 2018-10-26 13:52:08 --> Model "Tasks_model" initialized
INFO - 2018-10-26 13:52:08 --> Model "Lists_model" initialized
INFO - 2018-10-26 13:52:08 --> Controller Class Initialized
INFO - 2018-10-26 13:52:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 13:52:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 13:52:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 13:52:08 --> Final output sent to browser
DEBUG - 2018-10-26 13:52:08 --> Total execution time: 0.0610
INFO - 2018-10-26 13:52:17 --> Config Class Initialized
INFO - 2018-10-26 13:52:17 --> Hooks Class Initialized
DEBUG - 2018-10-26 13:52:17 --> UTF-8 Support Enabled
INFO - 2018-10-26 13:52:17 --> Utf8 Class Initialized
INFO - 2018-10-26 13:52:17 --> URI Class Initialized
INFO - 2018-10-26 13:52:17 --> Router Class Initialized
INFO - 2018-10-26 13:52:17 --> Output Class Initialized
INFO - 2018-10-26 13:52:17 --> Security Class Initialized
DEBUG - 2018-10-26 13:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 13:52:17 --> Input Class Initialized
INFO - 2018-10-26 13:52:17 --> Language Class Initialized
INFO - 2018-10-26 13:52:17 --> Loader Class Initialized
INFO - 2018-10-26 13:52:17 --> Helper loaded: url_helper
INFO - 2018-10-26 13:52:17 --> Helper loaded: form_helper
INFO - 2018-10-26 13:52:17 --> Helper loaded: html_helper
INFO - 2018-10-26 13:52:17 --> Database Driver Class Initialized
INFO - 2018-10-26 13:52:17 --> Form Validation Class Initialized
DEBUG - 2018-10-26 13:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 13:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 13:52:17 --> Model "User_model" initialized
INFO - 2018-10-26 13:52:17 --> Model "Project_model" initialized
INFO - 2018-10-26 13:52:17 --> Model "Tasks_model" initialized
INFO - 2018-10-26 13:52:17 --> Model "Lists_model" initialized
INFO - 2018-10-26 13:52:17 --> Controller Class Initialized
INFO - 2018-10-26 13:52:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 13:52:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 13:52:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 13:52:17 --> Final output sent to browser
DEBUG - 2018-10-26 13:52:17 --> Total execution time: 0.0560
INFO - 2018-10-26 13:52:17 --> Config Class Initialized
INFO - 2018-10-26 13:52:17 --> Hooks Class Initialized
DEBUG - 2018-10-26 13:52:17 --> UTF-8 Support Enabled
INFO - 2018-10-26 13:52:17 --> Utf8 Class Initialized
INFO - 2018-10-26 13:52:17 --> URI Class Initialized
INFO - 2018-10-26 13:52:17 --> Router Class Initialized
INFO - 2018-10-26 13:52:17 --> Output Class Initialized
INFO - 2018-10-26 13:52:17 --> Security Class Initialized
DEBUG - 2018-10-26 13:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 13:52:17 --> Input Class Initialized
INFO - 2018-10-26 13:52:17 --> Language Class Initialized
INFO - 2018-10-26 13:52:17 --> Loader Class Initialized
INFO - 2018-10-26 13:52:17 --> Helper loaded: url_helper
INFO - 2018-10-26 13:52:17 --> Helper loaded: form_helper
INFO - 2018-10-26 13:52:17 --> Helper loaded: html_helper
INFO - 2018-10-26 13:52:17 --> Database Driver Class Initialized
INFO - 2018-10-26 13:52:17 --> Form Validation Class Initialized
DEBUG - 2018-10-26 13:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 13:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 13:52:17 --> Model "User_model" initialized
INFO - 2018-10-26 13:52:17 --> Model "Project_model" initialized
INFO - 2018-10-26 13:52:17 --> Model "Tasks_model" initialized
INFO - 2018-10-26 13:52:17 --> Model "Lists_model" initialized
INFO - 2018-10-26 13:52:17 --> Controller Class Initialized
INFO - 2018-10-26 13:52:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 13:52:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 13:52:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 13:52:17 --> Final output sent to browser
DEBUG - 2018-10-26 13:52:17 --> Total execution time: 0.0620
INFO - 2018-10-26 13:52:18 --> Config Class Initialized
INFO - 2018-10-26 13:52:18 --> Hooks Class Initialized
DEBUG - 2018-10-26 13:52:18 --> UTF-8 Support Enabled
INFO - 2018-10-26 13:52:18 --> Utf8 Class Initialized
INFO - 2018-10-26 13:52:18 --> URI Class Initialized
INFO - 2018-10-26 13:52:18 --> Router Class Initialized
INFO - 2018-10-26 13:52:18 --> Output Class Initialized
INFO - 2018-10-26 13:52:18 --> Security Class Initialized
DEBUG - 2018-10-26 13:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 13:52:18 --> Input Class Initialized
INFO - 2018-10-26 13:52:18 --> Language Class Initialized
INFO - 2018-10-26 13:52:18 --> Loader Class Initialized
INFO - 2018-10-26 13:52:18 --> Helper loaded: url_helper
INFO - 2018-10-26 13:52:18 --> Helper loaded: form_helper
INFO - 2018-10-26 13:52:18 --> Helper loaded: html_helper
INFO - 2018-10-26 13:52:18 --> Database Driver Class Initialized
INFO - 2018-10-26 13:52:18 --> Form Validation Class Initialized
DEBUG - 2018-10-26 13:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 13:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 13:52:18 --> Model "User_model" initialized
INFO - 2018-10-26 13:52:18 --> Model "Project_model" initialized
INFO - 2018-10-26 13:52:18 --> Model "Tasks_model" initialized
INFO - 2018-10-26 13:52:18 --> Model "Lists_model" initialized
INFO - 2018-10-26 13:52:18 --> Controller Class Initialized
INFO - 2018-10-26 13:52:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 13:52:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 13:52:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 13:52:18 --> Final output sent to browser
DEBUG - 2018-10-26 13:52:18 --> Total execution time: 0.0480
INFO - 2018-10-26 13:52:39 --> Config Class Initialized
INFO - 2018-10-26 13:52:39 --> Hooks Class Initialized
DEBUG - 2018-10-26 13:52:39 --> UTF-8 Support Enabled
INFO - 2018-10-26 13:52:39 --> Utf8 Class Initialized
INFO - 2018-10-26 13:52:39 --> URI Class Initialized
INFO - 2018-10-26 13:52:39 --> Router Class Initialized
INFO - 2018-10-26 13:52:39 --> Output Class Initialized
INFO - 2018-10-26 13:52:39 --> Security Class Initialized
DEBUG - 2018-10-26 13:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 13:52:39 --> Input Class Initialized
INFO - 2018-10-26 13:52:39 --> Language Class Initialized
INFO - 2018-10-26 13:52:39 --> Loader Class Initialized
INFO - 2018-10-26 13:52:39 --> Helper loaded: url_helper
INFO - 2018-10-26 13:52:39 --> Helper loaded: form_helper
INFO - 2018-10-26 13:52:39 --> Helper loaded: html_helper
INFO - 2018-10-26 13:52:39 --> Database Driver Class Initialized
INFO - 2018-10-26 13:52:39 --> Form Validation Class Initialized
DEBUG - 2018-10-26 13:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 13:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 13:52:39 --> Model "User_model" initialized
INFO - 2018-10-26 13:52:39 --> Model "Project_model" initialized
INFO - 2018-10-26 13:52:39 --> Model "Tasks_model" initialized
INFO - 2018-10-26 13:52:39 --> Model "Lists_model" initialized
INFO - 2018-10-26 13:52:39 --> Controller Class Initialized
INFO - 2018-10-26 13:52:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 13:52:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 13:52:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 13:52:39 --> Final output sent to browser
DEBUG - 2018-10-26 13:52:39 --> Total execution time: 0.0580
INFO - 2018-10-26 13:52:40 --> Config Class Initialized
INFO - 2018-10-26 13:52:40 --> Hooks Class Initialized
DEBUG - 2018-10-26 13:52:40 --> UTF-8 Support Enabled
INFO - 2018-10-26 13:52:40 --> Utf8 Class Initialized
INFO - 2018-10-26 13:52:40 --> URI Class Initialized
INFO - 2018-10-26 13:52:40 --> Router Class Initialized
INFO - 2018-10-26 13:52:40 --> Output Class Initialized
INFO - 2018-10-26 13:52:40 --> Security Class Initialized
DEBUG - 2018-10-26 13:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 13:52:40 --> Input Class Initialized
INFO - 2018-10-26 13:52:40 --> Language Class Initialized
INFO - 2018-10-26 13:52:40 --> Loader Class Initialized
INFO - 2018-10-26 13:52:40 --> Helper loaded: url_helper
INFO - 2018-10-26 13:52:40 --> Helper loaded: form_helper
INFO - 2018-10-26 13:52:40 --> Helper loaded: html_helper
INFO - 2018-10-26 13:52:40 --> Database Driver Class Initialized
INFO - 2018-10-26 13:52:40 --> Form Validation Class Initialized
DEBUG - 2018-10-26 13:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 13:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 13:52:40 --> Model "User_model" initialized
INFO - 2018-10-26 13:52:40 --> Model "Project_model" initialized
INFO - 2018-10-26 13:52:40 --> Model "Tasks_model" initialized
INFO - 2018-10-26 13:52:40 --> Model "Lists_model" initialized
INFO - 2018-10-26 13:52:40 --> Controller Class Initialized
INFO - 2018-10-26 13:52:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 13:52:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 13:52:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 13:52:40 --> Final output sent to browser
DEBUG - 2018-10-26 13:52:40 --> Total execution time: 0.0580
INFO - 2018-10-26 13:52:41 --> Config Class Initialized
INFO - 2018-10-26 13:52:41 --> Hooks Class Initialized
DEBUG - 2018-10-26 13:52:41 --> UTF-8 Support Enabled
INFO - 2018-10-26 13:52:41 --> Utf8 Class Initialized
INFO - 2018-10-26 13:52:41 --> URI Class Initialized
INFO - 2018-10-26 13:52:41 --> Router Class Initialized
INFO - 2018-10-26 13:52:41 --> Output Class Initialized
INFO - 2018-10-26 13:52:41 --> Security Class Initialized
DEBUG - 2018-10-26 13:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 13:52:41 --> Input Class Initialized
INFO - 2018-10-26 13:52:41 --> Language Class Initialized
INFO - 2018-10-26 13:52:41 --> Loader Class Initialized
INFO - 2018-10-26 13:52:41 --> Helper loaded: url_helper
INFO - 2018-10-26 13:52:41 --> Helper loaded: form_helper
INFO - 2018-10-26 13:52:41 --> Helper loaded: html_helper
INFO - 2018-10-26 13:52:41 --> Database Driver Class Initialized
INFO - 2018-10-26 13:52:41 --> Form Validation Class Initialized
DEBUG - 2018-10-26 13:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 13:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 13:52:41 --> Model "User_model" initialized
INFO - 2018-10-26 13:52:41 --> Model "Project_model" initialized
INFO - 2018-10-26 13:52:41 --> Model "Tasks_model" initialized
INFO - 2018-10-26 13:52:41 --> Model "Lists_model" initialized
INFO - 2018-10-26 13:52:41 --> Controller Class Initialized
INFO - 2018-10-26 13:52:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 13:52:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 13:52:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 13:52:41 --> Final output sent to browser
DEBUG - 2018-10-26 13:52:41 --> Total execution time: 0.0460
INFO - 2018-10-26 13:52:41 --> Config Class Initialized
INFO - 2018-10-26 13:52:41 --> Hooks Class Initialized
DEBUG - 2018-10-26 13:52:41 --> UTF-8 Support Enabled
INFO - 2018-10-26 13:52:41 --> Utf8 Class Initialized
INFO - 2018-10-26 13:52:41 --> URI Class Initialized
INFO - 2018-10-26 13:52:41 --> Router Class Initialized
INFO - 2018-10-26 13:52:41 --> Output Class Initialized
INFO - 2018-10-26 13:52:41 --> Security Class Initialized
DEBUG - 2018-10-26 13:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 13:52:41 --> Input Class Initialized
INFO - 2018-10-26 13:52:41 --> Language Class Initialized
INFO - 2018-10-26 13:52:41 --> Loader Class Initialized
INFO - 2018-10-26 13:52:41 --> Helper loaded: url_helper
INFO - 2018-10-26 13:52:41 --> Helper loaded: form_helper
INFO - 2018-10-26 13:52:41 --> Helper loaded: html_helper
INFO - 2018-10-26 13:52:41 --> Database Driver Class Initialized
INFO - 2018-10-26 13:52:41 --> Form Validation Class Initialized
DEBUG - 2018-10-26 13:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 13:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 13:52:41 --> Model "User_model" initialized
INFO - 2018-10-26 13:52:41 --> Model "Project_model" initialized
INFO - 2018-10-26 13:52:41 --> Model "Tasks_model" initialized
INFO - 2018-10-26 13:52:41 --> Model "Lists_model" initialized
INFO - 2018-10-26 13:52:41 --> Controller Class Initialized
INFO - 2018-10-26 13:52:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 13:52:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 13:52:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 13:52:41 --> Final output sent to browser
DEBUG - 2018-10-26 13:52:41 --> Total execution time: 0.0540
INFO - 2018-10-26 13:52:43 --> Config Class Initialized
INFO - 2018-10-26 13:52:43 --> Hooks Class Initialized
DEBUG - 2018-10-26 13:52:43 --> UTF-8 Support Enabled
INFO - 2018-10-26 13:52:43 --> Utf8 Class Initialized
INFO - 2018-10-26 13:52:43 --> URI Class Initialized
INFO - 2018-10-26 13:52:43 --> Router Class Initialized
INFO - 2018-10-26 13:52:43 --> Output Class Initialized
INFO - 2018-10-26 13:52:43 --> Security Class Initialized
DEBUG - 2018-10-26 13:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 13:52:43 --> Input Class Initialized
INFO - 2018-10-26 13:52:43 --> Language Class Initialized
INFO - 2018-10-26 13:52:43 --> Loader Class Initialized
INFO - 2018-10-26 13:52:43 --> Helper loaded: url_helper
INFO - 2018-10-26 13:52:43 --> Helper loaded: form_helper
INFO - 2018-10-26 13:52:43 --> Helper loaded: html_helper
INFO - 2018-10-26 13:52:43 --> Database Driver Class Initialized
INFO - 2018-10-26 13:52:43 --> Form Validation Class Initialized
DEBUG - 2018-10-26 13:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 13:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 13:52:43 --> Model "User_model" initialized
INFO - 2018-10-26 13:52:43 --> Model "Project_model" initialized
INFO - 2018-10-26 13:52:43 --> Model "Tasks_model" initialized
INFO - 2018-10-26 13:52:43 --> Model "Lists_model" initialized
INFO - 2018-10-26 13:52:43 --> Controller Class Initialized
INFO - 2018-10-26 13:52:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 13:52:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 13:52:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 13:52:43 --> Final output sent to browser
DEBUG - 2018-10-26 13:52:43 --> Total execution time: 0.0550
INFO - 2018-10-26 13:53:23 --> Config Class Initialized
INFO - 2018-10-26 13:53:23 --> Hooks Class Initialized
DEBUG - 2018-10-26 13:53:23 --> UTF-8 Support Enabled
INFO - 2018-10-26 13:53:23 --> Utf8 Class Initialized
INFO - 2018-10-26 13:53:23 --> URI Class Initialized
INFO - 2018-10-26 13:53:23 --> Router Class Initialized
INFO - 2018-10-26 13:53:23 --> Output Class Initialized
INFO - 2018-10-26 13:53:23 --> Security Class Initialized
DEBUG - 2018-10-26 13:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 13:53:23 --> Input Class Initialized
INFO - 2018-10-26 13:53:23 --> Language Class Initialized
INFO - 2018-10-26 13:53:23 --> Loader Class Initialized
INFO - 2018-10-26 13:53:23 --> Helper loaded: url_helper
INFO - 2018-10-26 13:53:23 --> Helper loaded: form_helper
INFO - 2018-10-26 13:53:23 --> Helper loaded: html_helper
INFO - 2018-10-26 13:53:23 --> Database Driver Class Initialized
INFO - 2018-10-26 13:53:23 --> Form Validation Class Initialized
DEBUG - 2018-10-26 13:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 13:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 13:53:23 --> Model "User_model" initialized
INFO - 2018-10-26 13:53:23 --> Model "Project_model" initialized
INFO - 2018-10-26 13:53:23 --> Model "Tasks_model" initialized
INFO - 2018-10-26 13:53:23 --> Model "Lists_model" initialized
INFO - 2018-10-26 13:53:23 --> Controller Class Initialized
INFO - 2018-10-26 13:53:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 13:53:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 13:53:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 13:53:23 --> Final output sent to browser
DEBUG - 2018-10-26 13:53:23 --> Total execution time: 0.0620
INFO - 2018-10-26 13:53:24 --> Config Class Initialized
INFO - 2018-10-26 13:53:24 --> Hooks Class Initialized
DEBUG - 2018-10-26 13:53:24 --> UTF-8 Support Enabled
INFO - 2018-10-26 13:53:24 --> Utf8 Class Initialized
INFO - 2018-10-26 13:53:24 --> URI Class Initialized
INFO - 2018-10-26 13:53:24 --> Router Class Initialized
INFO - 2018-10-26 13:53:24 --> Output Class Initialized
INFO - 2018-10-26 13:53:24 --> Security Class Initialized
DEBUG - 2018-10-26 13:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 13:53:24 --> Input Class Initialized
INFO - 2018-10-26 13:53:24 --> Language Class Initialized
INFO - 2018-10-26 13:53:24 --> Loader Class Initialized
INFO - 2018-10-26 13:53:24 --> Helper loaded: url_helper
INFO - 2018-10-26 13:53:24 --> Helper loaded: form_helper
INFO - 2018-10-26 13:53:24 --> Helper loaded: html_helper
INFO - 2018-10-26 13:53:24 --> Database Driver Class Initialized
INFO - 2018-10-26 13:53:24 --> Form Validation Class Initialized
DEBUG - 2018-10-26 13:53:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 13:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 13:53:24 --> Model "User_model" initialized
INFO - 2018-10-26 13:53:24 --> Model "Project_model" initialized
INFO - 2018-10-26 13:53:24 --> Model "Tasks_model" initialized
INFO - 2018-10-26 13:53:24 --> Model "Lists_model" initialized
INFO - 2018-10-26 13:53:24 --> Controller Class Initialized
INFO - 2018-10-26 13:53:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 13:53:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 13:53:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 13:53:24 --> Final output sent to browser
DEBUG - 2018-10-26 13:53:24 --> Total execution time: 0.0460
INFO - 2018-10-26 13:53:51 --> Config Class Initialized
INFO - 2018-10-26 13:53:51 --> Hooks Class Initialized
DEBUG - 2018-10-26 13:53:51 --> UTF-8 Support Enabled
INFO - 2018-10-26 13:53:51 --> Utf8 Class Initialized
INFO - 2018-10-26 13:53:51 --> URI Class Initialized
INFO - 2018-10-26 13:53:51 --> Router Class Initialized
INFO - 2018-10-26 13:53:51 --> Output Class Initialized
INFO - 2018-10-26 13:53:51 --> Security Class Initialized
DEBUG - 2018-10-26 13:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 13:53:51 --> Input Class Initialized
INFO - 2018-10-26 13:53:51 --> Language Class Initialized
INFO - 2018-10-26 13:53:51 --> Loader Class Initialized
INFO - 2018-10-26 13:53:51 --> Helper loaded: url_helper
INFO - 2018-10-26 13:53:51 --> Helper loaded: form_helper
INFO - 2018-10-26 13:53:51 --> Helper loaded: html_helper
INFO - 2018-10-26 13:53:51 --> Database Driver Class Initialized
INFO - 2018-10-26 13:53:51 --> Form Validation Class Initialized
DEBUG - 2018-10-26 13:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 13:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 13:53:51 --> Model "User_model" initialized
INFO - 2018-10-26 13:53:51 --> Model "Project_model" initialized
INFO - 2018-10-26 13:53:51 --> Model "Tasks_model" initialized
INFO - 2018-10-26 13:53:51 --> Model "Lists_model" initialized
INFO - 2018-10-26 13:53:51 --> Controller Class Initialized
INFO - 2018-10-26 13:53:51 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 13:53:51 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 13:53:51 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 13:53:51 --> Final output sent to browser
DEBUG - 2018-10-26 13:53:51 --> Total execution time: 0.0630
INFO - 2018-10-26 13:53:53 --> Config Class Initialized
INFO - 2018-10-26 13:53:53 --> Hooks Class Initialized
DEBUG - 2018-10-26 13:53:53 --> UTF-8 Support Enabled
INFO - 2018-10-26 13:53:53 --> Utf8 Class Initialized
INFO - 2018-10-26 13:53:53 --> URI Class Initialized
INFO - 2018-10-26 13:53:53 --> Router Class Initialized
INFO - 2018-10-26 13:53:53 --> Output Class Initialized
INFO - 2018-10-26 13:53:53 --> Security Class Initialized
DEBUG - 2018-10-26 13:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 13:53:53 --> Input Class Initialized
INFO - 2018-10-26 13:53:53 --> Language Class Initialized
INFO - 2018-10-26 13:53:53 --> Loader Class Initialized
INFO - 2018-10-26 13:53:53 --> Helper loaded: url_helper
INFO - 2018-10-26 13:53:53 --> Helper loaded: form_helper
INFO - 2018-10-26 13:53:53 --> Helper loaded: html_helper
INFO - 2018-10-26 13:53:53 --> Database Driver Class Initialized
INFO - 2018-10-26 13:53:53 --> Form Validation Class Initialized
DEBUG - 2018-10-26 13:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 13:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 13:53:53 --> Model "User_model" initialized
INFO - 2018-10-26 13:53:53 --> Model "Project_model" initialized
INFO - 2018-10-26 13:53:53 --> Model "Tasks_model" initialized
INFO - 2018-10-26 13:53:53 --> Model "Lists_model" initialized
INFO - 2018-10-26 13:53:53 --> Controller Class Initialized
INFO - 2018-10-26 13:53:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 13:53:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 13:53:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 13:53:53 --> Final output sent to browser
DEBUG - 2018-10-26 13:53:53 --> Total execution time: 0.0590
INFO - 2018-10-26 13:53:54 --> Config Class Initialized
INFO - 2018-10-26 13:53:54 --> Hooks Class Initialized
DEBUG - 2018-10-26 13:53:54 --> UTF-8 Support Enabled
INFO - 2018-10-26 13:53:54 --> Utf8 Class Initialized
INFO - 2018-10-26 13:53:54 --> URI Class Initialized
INFO - 2018-10-26 13:53:54 --> Router Class Initialized
INFO - 2018-10-26 13:53:54 --> Output Class Initialized
INFO - 2018-10-26 13:53:54 --> Security Class Initialized
DEBUG - 2018-10-26 13:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 13:53:54 --> Input Class Initialized
INFO - 2018-10-26 13:53:54 --> Language Class Initialized
INFO - 2018-10-26 13:53:54 --> Loader Class Initialized
INFO - 2018-10-26 13:53:54 --> Helper loaded: url_helper
INFO - 2018-10-26 13:53:54 --> Helper loaded: form_helper
INFO - 2018-10-26 13:53:54 --> Helper loaded: html_helper
INFO - 2018-10-26 13:53:54 --> Database Driver Class Initialized
INFO - 2018-10-26 13:53:54 --> Form Validation Class Initialized
DEBUG - 2018-10-26 13:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 13:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 13:53:54 --> Model "User_model" initialized
INFO - 2018-10-26 13:53:54 --> Model "Project_model" initialized
INFO - 2018-10-26 13:53:54 --> Model "Tasks_model" initialized
INFO - 2018-10-26 13:53:54 --> Model "Lists_model" initialized
INFO - 2018-10-26 13:53:54 --> Controller Class Initialized
INFO - 2018-10-26 13:53:54 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 13:53:54 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 13:53:54 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 13:53:54 --> Final output sent to browser
DEBUG - 2018-10-26 13:53:54 --> Total execution time: 0.0590
INFO - 2018-10-26 13:53:57 --> Config Class Initialized
INFO - 2018-10-26 13:53:57 --> Hooks Class Initialized
DEBUG - 2018-10-26 13:53:57 --> UTF-8 Support Enabled
INFO - 2018-10-26 13:53:57 --> Utf8 Class Initialized
INFO - 2018-10-26 13:53:57 --> URI Class Initialized
INFO - 2018-10-26 13:53:57 --> Router Class Initialized
INFO - 2018-10-26 13:53:57 --> Output Class Initialized
INFO - 2018-10-26 13:53:57 --> Security Class Initialized
DEBUG - 2018-10-26 13:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 13:53:57 --> Input Class Initialized
INFO - 2018-10-26 13:53:57 --> Language Class Initialized
INFO - 2018-10-26 13:53:57 --> Loader Class Initialized
INFO - 2018-10-26 13:53:57 --> Helper loaded: url_helper
INFO - 2018-10-26 13:53:57 --> Helper loaded: form_helper
INFO - 2018-10-26 13:53:57 --> Helper loaded: html_helper
INFO - 2018-10-26 13:53:57 --> Database Driver Class Initialized
INFO - 2018-10-26 13:53:57 --> Form Validation Class Initialized
DEBUG - 2018-10-26 13:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 13:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 13:53:57 --> Model "User_model" initialized
INFO - 2018-10-26 13:53:57 --> Model "Project_model" initialized
INFO - 2018-10-26 13:53:57 --> Model "Tasks_model" initialized
INFO - 2018-10-26 13:53:57 --> Model "Lists_model" initialized
INFO - 2018-10-26 13:53:57 --> Controller Class Initialized
INFO - 2018-10-26 13:53:57 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 13:53:57 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 13:53:57 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 13:53:57 --> Final output sent to browser
DEBUG - 2018-10-26 13:53:57 --> Total execution time: 0.0700
INFO - 2018-10-26 13:54:24 --> Config Class Initialized
INFO - 2018-10-26 13:54:24 --> Hooks Class Initialized
DEBUG - 2018-10-26 13:54:24 --> UTF-8 Support Enabled
INFO - 2018-10-26 13:54:24 --> Utf8 Class Initialized
INFO - 2018-10-26 13:54:24 --> URI Class Initialized
INFO - 2018-10-26 13:54:24 --> Router Class Initialized
INFO - 2018-10-26 13:54:24 --> Output Class Initialized
INFO - 2018-10-26 13:54:24 --> Security Class Initialized
DEBUG - 2018-10-26 13:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 13:54:24 --> Input Class Initialized
INFO - 2018-10-26 13:54:24 --> Language Class Initialized
INFO - 2018-10-26 13:54:24 --> Loader Class Initialized
INFO - 2018-10-26 13:54:24 --> Helper loaded: url_helper
INFO - 2018-10-26 13:54:24 --> Helper loaded: form_helper
INFO - 2018-10-26 13:54:24 --> Helper loaded: html_helper
INFO - 2018-10-26 13:54:24 --> Database Driver Class Initialized
INFO - 2018-10-26 13:54:24 --> Form Validation Class Initialized
DEBUG - 2018-10-26 13:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 13:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 13:54:24 --> Model "User_model" initialized
INFO - 2018-10-26 13:54:24 --> Model "Project_model" initialized
INFO - 2018-10-26 13:54:24 --> Model "Tasks_model" initialized
INFO - 2018-10-26 13:54:24 --> Model "Lists_model" initialized
INFO - 2018-10-26 13:54:24 --> Controller Class Initialized
INFO - 2018-10-26 13:54:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 13:54:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 13:54:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 13:54:24 --> Final output sent to browser
DEBUG - 2018-10-26 13:54:24 --> Total execution time: 0.0650
INFO - 2018-10-26 14:42:01 --> Config Class Initialized
INFO - 2018-10-26 14:42:01 --> Hooks Class Initialized
DEBUG - 2018-10-26 14:42:01 --> UTF-8 Support Enabled
INFO - 2018-10-26 14:42:01 --> Utf8 Class Initialized
INFO - 2018-10-26 14:42:01 --> URI Class Initialized
INFO - 2018-10-26 14:42:01 --> Router Class Initialized
INFO - 2018-10-26 14:42:01 --> Output Class Initialized
INFO - 2018-10-26 14:42:01 --> Security Class Initialized
DEBUG - 2018-10-26 14:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 14:42:01 --> Input Class Initialized
INFO - 2018-10-26 14:42:01 --> Language Class Initialized
INFO - 2018-10-26 14:42:01 --> Loader Class Initialized
INFO - 2018-10-26 14:42:01 --> Helper loaded: url_helper
INFO - 2018-10-26 14:42:01 --> Helper loaded: form_helper
INFO - 2018-10-26 14:42:01 --> Helper loaded: html_helper
INFO - 2018-10-26 14:42:01 --> Database Driver Class Initialized
INFO - 2018-10-26 14:42:01 --> Form Validation Class Initialized
DEBUG - 2018-10-26 14:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 14:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 14:42:01 --> Model "User_model" initialized
INFO - 2018-10-26 14:42:01 --> Model "Project_model" initialized
INFO - 2018-10-26 14:42:01 --> Model "Tasks_model" initialized
INFO - 2018-10-26 14:42:01 --> Model "Lists_model" initialized
INFO - 2018-10-26 14:42:01 --> Controller Class Initialized
INFO - 2018-10-26 14:42:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 14:42:01 --> Config Class Initialized
INFO - 2018-10-26 14:42:01 --> Hooks Class Initialized
DEBUG - 2018-10-26 14:42:01 --> UTF-8 Support Enabled
INFO - 2018-10-26 14:42:01 --> Utf8 Class Initialized
INFO - 2018-10-26 14:42:01 --> URI Class Initialized
INFO - 2018-10-26 14:42:01 --> Router Class Initialized
INFO - 2018-10-26 14:42:01 --> Output Class Initialized
INFO - 2018-10-26 14:42:01 --> Security Class Initialized
DEBUG - 2018-10-26 14:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 14:42:01 --> Input Class Initialized
INFO - 2018-10-26 14:42:01 --> Language Class Initialized
INFO - 2018-10-26 14:42:01 --> Loader Class Initialized
INFO - 2018-10-26 14:42:01 --> Helper loaded: url_helper
INFO - 2018-10-26 14:42:01 --> Helper loaded: form_helper
INFO - 2018-10-26 14:42:01 --> Helper loaded: html_helper
INFO - 2018-10-26 14:42:01 --> Database Driver Class Initialized
INFO - 2018-10-26 14:42:01 --> Form Validation Class Initialized
DEBUG - 2018-10-26 14:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 14:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 14:42:01 --> Model "User_model" initialized
INFO - 2018-10-26 14:42:01 --> Model "Project_model" initialized
INFO - 2018-10-26 14:42:01 --> Model "Tasks_model" initialized
INFO - 2018-10-26 14:42:01 --> Model "Lists_model" initialized
INFO - 2018-10-26 14:42:01 --> Controller Class Initialized
INFO - 2018-10-26 14:42:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 14:42:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 14:42:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 14:42:01 --> Final output sent to browser
DEBUG - 2018-10-26 14:42:01 --> Total execution time: 0.0760
INFO - 2018-10-26 14:42:30 --> Config Class Initialized
INFO - 2018-10-26 14:42:30 --> Hooks Class Initialized
DEBUG - 2018-10-26 14:42:30 --> UTF-8 Support Enabled
INFO - 2018-10-26 14:42:30 --> Utf8 Class Initialized
INFO - 2018-10-26 14:42:30 --> URI Class Initialized
INFO - 2018-10-26 14:42:30 --> Router Class Initialized
INFO - 2018-10-26 14:42:30 --> Output Class Initialized
INFO - 2018-10-26 14:42:30 --> Security Class Initialized
DEBUG - 2018-10-26 14:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 14:42:30 --> Input Class Initialized
INFO - 2018-10-26 14:42:30 --> Language Class Initialized
INFO - 2018-10-26 14:42:30 --> Loader Class Initialized
INFO - 2018-10-26 14:42:30 --> Helper loaded: url_helper
INFO - 2018-10-26 14:42:30 --> Helper loaded: form_helper
INFO - 2018-10-26 14:42:30 --> Helper loaded: html_helper
INFO - 2018-10-26 14:42:30 --> Database Driver Class Initialized
INFO - 2018-10-26 14:42:30 --> Form Validation Class Initialized
DEBUG - 2018-10-26 14:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 14:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 14:42:30 --> Model "User_model" initialized
INFO - 2018-10-26 14:42:30 --> Model "Project_model" initialized
INFO - 2018-10-26 14:42:30 --> Model "Tasks_model" initialized
INFO - 2018-10-26 14:42:30 --> Model "Lists_model" initialized
INFO - 2018-10-26 14:42:30 --> Controller Class Initialized
INFO - 2018-10-26 14:42:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 14:42:30 --> Config Class Initialized
INFO - 2018-10-26 14:42:30 --> Hooks Class Initialized
DEBUG - 2018-10-26 14:42:30 --> UTF-8 Support Enabled
INFO - 2018-10-26 14:42:30 --> Utf8 Class Initialized
INFO - 2018-10-26 14:42:30 --> URI Class Initialized
INFO - 2018-10-26 14:42:30 --> Router Class Initialized
INFO - 2018-10-26 14:42:30 --> Output Class Initialized
INFO - 2018-10-26 14:42:30 --> Security Class Initialized
DEBUG - 2018-10-26 14:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 14:42:30 --> Input Class Initialized
INFO - 2018-10-26 14:42:30 --> Language Class Initialized
INFO - 2018-10-26 14:42:30 --> Loader Class Initialized
INFO - 2018-10-26 14:42:30 --> Helper loaded: url_helper
INFO - 2018-10-26 14:42:30 --> Helper loaded: form_helper
INFO - 2018-10-26 14:42:30 --> Helper loaded: html_helper
INFO - 2018-10-26 14:42:30 --> Database Driver Class Initialized
INFO - 2018-10-26 14:42:30 --> Form Validation Class Initialized
DEBUG - 2018-10-26 14:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 14:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 14:42:30 --> Model "User_model" initialized
INFO - 2018-10-26 14:42:30 --> Model "Project_model" initialized
INFO - 2018-10-26 14:42:30 --> Model "Tasks_model" initialized
INFO - 2018-10-26 14:42:30 --> Model "Lists_model" initialized
INFO - 2018-10-26 14:42:30 --> Controller Class Initialized
INFO - 2018-10-26 14:42:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 14:42:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 14:42:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 14:42:30 --> Final output sent to browser
DEBUG - 2018-10-26 14:42:30 --> Total execution time: 0.0330
INFO - 2018-10-26 14:42:42 --> Config Class Initialized
INFO - 2018-10-26 14:42:42 --> Hooks Class Initialized
DEBUG - 2018-10-26 14:42:42 --> UTF-8 Support Enabled
INFO - 2018-10-26 14:42:42 --> Utf8 Class Initialized
INFO - 2018-10-26 14:42:42 --> URI Class Initialized
INFO - 2018-10-26 14:42:42 --> Router Class Initialized
INFO - 2018-10-26 14:42:42 --> Output Class Initialized
INFO - 2018-10-26 14:42:42 --> Security Class Initialized
DEBUG - 2018-10-26 14:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 14:42:42 --> Input Class Initialized
INFO - 2018-10-26 14:42:42 --> Language Class Initialized
INFO - 2018-10-26 14:42:42 --> Loader Class Initialized
INFO - 2018-10-26 14:42:42 --> Helper loaded: url_helper
INFO - 2018-10-26 14:42:42 --> Helper loaded: form_helper
INFO - 2018-10-26 14:42:42 --> Helper loaded: html_helper
INFO - 2018-10-26 14:42:42 --> Database Driver Class Initialized
INFO - 2018-10-26 14:42:42 --> Form Validation Class Initialized
DEBUG - 2018-10-26 14:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 14:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 14:42:42 --> Model "User_model" initialized
INFO - 2018-10-26 14:42:42 --> Model "Project_model" initialized
INFO - 2018-10-26 14:42:42 --> Model "Tasks_model" initialized
INFO - 2018-10-26 14:42:42 --> Model "Lists_model" initialized
INFO - 2018-10-26 14:42:42 --> Controller Class Initialized
INFO - 2018-10-26 14:42:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 14:42:42 --> Config Class Initialized
INFO - 2018-10-26 14:42:42 --> Hooks Class Initialized
DEBUG - 2018-10-26 14:42:42 --> UTF-8 Support Enabled
INFO - 2018-10-26 14:42:42 --> Utf8 Class Initialized
INFO - 2018-10-26 14:42:42 --> URI Class Initialized
INFO - 2018-10-26 14:42:42 --> Router Class Initialized
INFO - 2018-10-26 14:42:42 --> Output Class Initialized
INFO - 2018-10-26 14:42:42 --> Security Class Initialized
DEBUG - 2018-10-26 14:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 14:42:42 --> Input Class Initialized
INFO - 2018-10-26 14:42:42 --> Language Class Initialized
INFO - 2018-10-26 14:42:42 --> Loader Class Initialized
INFO - 2018-10-26 14:42:42 --> Helper loaded: url_helper
INFO - 2018-10-26 14:42:42 --> Helper loaded: form_helper
INFO - 2018-10-26 14:42:42 --> Helper loaded: html_helper
INFO - 2018-10-26 14:42:42 --> Database Driver Class Initialized
INFO - 2018-10-26 14:42:42 --> Form Validation Class Initialized
DEBUG - 2018-10-26 14:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 14:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 14:42:42 --> Model "User_model" initialized
INFO - 2018-10-26 14:42:42 --> Model "Project_model" initialized
INFO - 2018-10-26 14:42:42 --> Model "Tasks_model" initialized
INFO - 2018-10-26 14:42:42 --> Model "Lists_model" initialized
INFO - 2018-10-26 14:42:42 --> Controller Class Initialized
INFO - 2018-10-26 14:42:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 14:42:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 14:42:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 14:42:42 --> Final output sent to browser
DEBUG - 2018-10-26 14:42:42 --> Total execution time: 0.0430
INFO - 2018-10-26 14:42:45 --> Config Class Initialized
INFO - 2018-10-26 14:42:45 --> Hooks Class Initialized
DEBUG - 2018-10-26 14:42:45 --> UTF-8 Support Enabled
INFO - 2018-10-26 14:42:45 --> Utf8 Class Initialized
INFO - 2018-10-26 14:42:45 --> URI Class Initialized
INFO - 2018-10-26 14:42:45 --> Router Class Initialized
INFO - 2018-10-26 14:42:45 --> Output Class Initialized
INFO - 2018-10-26 14:42:45 --> Security Class Initialized
DEBUG - 2018-10-26 14:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 14:42:45 --> Input Class Initialized
INFO - 2018-10-26 14:42:45 --> Language Class Initialized
INFO - 2018-10-26 14:42:45 --> Loader Class Initialized
INFO - 2018-10-26 14:42:45 --> Helper loaded: url_helper
INFO - 2018-10-26 14:42:45 --> Helper loaded: form_helper
INFO - 2018-10-26 14:42:45 --> Helper loaded: html_helper
INFO - 2018-10-26 14:42:45 --> Database Driver Class Initialized
INFO - 2018-10-26 14:42:45 --> Form Validation Class Initialized
DEBUG - 2018-10-26 14:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 14:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 14:42:45 --> Model "User_model" initialized
INFO - 2018-10-26 14:42:45 --> Model "Project_model" initialized
INFO - 2018-10-26 14:42:45 --> Model "Tasks_model" initialized
INFO - 2018-10-26 14:42:45 --> Model "Lists_model" initialized
INFO - 2018-10-26 14:42:45 --> Controller Class Initialized
INFO - 2018-10-26 14:42:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 14:42:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 14:42:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 14:42:45 --> Final output sent to browser
DEBUG - 2018-10-26 14:42:45 --> Total execution time: 0.0550
INFO - 2018-10-26 14:42:46 --> Config Class Initialized
INFO - 2018-10-26 14:42:46 --> Hooks Class Initialized
DEBUG - 2018-10-26 14:42:46 --> UTF-8 Support Enabled
INFO - 2018-10-26 14:42:46 --> Utf8 Class Initialized
INFO - 2018-10-26 14:42:46 --> URI Class Initialized
INFO - 2018-10-26 14:42:46 --> Router Class Initialized
INFO - 2018-10-26 14:42:46 --> Output Class Initialized
INFO - 2018-10-26 14:42:46 --> Security Class Initialized
DEBUG - 2018-10-26 14:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 14:42:46 --> Input Class Initialized
INFO - 2018-10-26 14:42:46 --> Language Class Initialized
INFO - 2018-10-26 14:42:46 --> Loader Class Initialized
INFO - 2018-10-26 14:42:46 --> Helper loaded: url_helper
INFO - 2018-10-26 14:42:46 --> Helper loaded: form_helper
INFO - 2018-10-26 14:42:46 --> Helper loaded: html_helper
INFO - 2018-10-26 14:42:46 --> Database Driver Class Initialized
INFO - 2018-10-26 14:42:46 --> Form Validation Class Initialized
DEBUG - 2018-10-26 14:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 14:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 14:42:46 --> Model "User_model" initialized
INFO - 2018-10-26 14:42:46 --> Model "Project_model" initialized
INFO - 2018-10-26 14:42:46 --> Model "Tasks_model" initialized
INFO - 2018-10-26 14:42:46 --> Model "Lists_model" initialized
INFO - 2018-10-26 14:42:46 --> Controller Class Initialized
INFO - 2018-10-26 14:42:46 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 14:42:46 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 14:42:46 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 14:42:46 --> Final output sent to browser
DEBUG - 2018-10-26 14:42:46 --> Total execution time: 0.0620
INFO - 2018-10-26 14:52:02 --> Config Class Initialized
INFO - 2018-10-26 14:52:02 --> Hooks Class Initialized
DEBUG - 2018-10-26 14:52:02 --> UTF-8 Support Enabled
INFO - 2018-10-26 14:52:02 --> Utf8 Class Initialized
INFO - 2018-10-26 14:52:02 --> URI Class Initialized
INFO - 2018-10-26 14:52:02 --> Router Class Initialized
INFO - 2018-10-26 14:52:02 --> Output Class Initialized
INFO - 2018-10-26 14:52:02 --> Security Class Initialized
DEBUG - 2018-10-26 14:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 14:52:02 --> Input Class Initialized
INFO - 2018-10-26 14:52:02 --> Language Class Initialized
INFO - 2018-10-26 14:52:02 --> Loader Class Initialized
INFO - 2018-10-26 14:52:02 --> Helper loaded: url_helper
INFO - 2018-10-26 14:52:02 --> Helper loaded: form_helper
INFO - 2018-10-26 14:52:02 --> Helper loaded: html_helper
INFO - 2018-10-26 14:52:02 --> Database Driver Class Initialized
INFO - 2018-10-26 14:52:02 --> Form Validation Class Initialized
DEBUG - 2018-10-26 14:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 14:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 14:52:02 --> Model "User_model" initialized
INFO - 2018-10-26 14:52:02 --> Model "Project_model" initialized
INFO - 2018-10-26 14:52:02 --> Model "Tasks_model" initialized
INFO - 2018-10-26 14:52:02 --> Model "Lists_model" initialized
INFO - 2018-10-26 14:52:02 --> Controller Class Initialized
INFO - 2018-10-26 14:52:02 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 14:52:02 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 14:52:02 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 14:52:02 --> Final output sent to browser
DEBUG - 2018-10-26 14:52:02 --> Total execution time: 0.0520
INFO - 2018-10-26 14:52:06 --> Config Class Initialized
INFO - 2018-10-26 14:52:06 --> Hooks Class Initialized
DEBUG - 2018-10-26 14:52:06 --> UTF-8 Support Enabled
INFO - 2018-10-26 14:52:06 --> Utf8 Class Initialized
INFO - 2018-10-26 14:52:06 --> URI Class Initialized
INFO - 2018-10-26 14:52:06 --> Router Class Initialized
INFO - 2018-10-26 14:52:06 --> Output Class Initialized
INFO - 2018-10-26 14:52:06 --> Security Class Initialized
DEBUG - 2018-10-26 14:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 14:52:06 --> Input Class Initialized
INFO - 2018-10-26 14:52:06 --> Language Class Initialized
INFO - 2018-10-26 14:52:06 --> Loader Class Initialized
INFO - 2018-10-26 14:52:06 --> Helper loaded: url_helper
INFO - 2018-10-26 14:52:06 --> Helper loaded: form_helper
INFO - 2018-10-26 14:52:06 --> Helper loaded: html_helper
INFO - 2018-10-26 14:52:06 --> Database Driver Class Initialized
INFO - 2018-10-26 14:52:06 --> Form Validation Class Initialized
DEBUG - 2018-10-26 14:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 14:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 14:52:06 --> Model "User_model" initialized
INFO - 2018-10-26 14:52:06 --> Model "Project_model" initialized
INFO - 2018-10-26 14:52:06 --> Model "Tasks_model" initialized
INFO - 2018-10-26 14:52:06 --> Model "Lists_model" initialized
INFO - 2018-10-26 14:52:06 --> Controller Class Initialized
INFO - 2018-10-26 14:52:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 14:52:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 14:52:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 14:52:06 --> Final output sent to browser
DEBUG - 2018-10-26 14:52:06 --> Total execution time: 0.0590
INFO - 2018-10-26 14:52:53 --> Config Class Initialized
INFO - 2018-10-26 14:52:53 --> Hooks Class Initialized
DEBUG - 2018-10-26 14:52:53 --> UTF-8 Support Enabled
INFO - 2018-10-26 14:52:53 --> Utf8 Class Initialized
INFO - 2018-10-26 14:52:53 --> URI Class Initialized
INFO - 2018-10-26 14:52:53 --> Router Class Initialized
INFO - 2018-10-26 14:52:53 --> Output Class Initialized
INFO - 2018-10-26 14:52:53 --> Security Class Initialized
DEBUG - 2018-10-26 14:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 14:52:53 --> Input Class Initialized
INFO - 2018-10-26 14:52:53 --> Language Class Initialized
INFO - 2018-10-26 14:52:53 --> Loader Class Initialized
INFO - 2018-10-26 14:52:53 --> Helper loaded: url_helper
INFO - 2018-10-26 14:52:53 --> Helper loaded: form_helper
INFO - 2018-10-26 14:52:53 --> Helper loaded: html_helper
INFO - 2018-10-26 14:52:53 --> Database Driver Class Initialized
INFO - 2018-10-26 14:52:53 --> Form Validation Class Initialized
DEBUG - 2018-10-26 14:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 14:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 14:52:53 --> Model "User_model" initialized
INFO - 2018-10-26 14:52:53 --> Model "Project_model" initialized
INFO - 2018-10-26 14:52:53 --> Model "Tasks_model" initialized
INFO - 2018-10-26 14:52:53 --> Model "Lists_model" initialized
INFO - 2018-10-26 14:52:53 --> Controller Class Initialized
INFO - 2018-10-26 14:52:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 14:52:53 --> Config Class Initialized
INFO - 2018-10-26 14:52:53 --> Hooks Class Initialized
DEBUG - 2018-10-26 14:52:53 --> UTF-8 Support Enabled
INFO - 2018-10-26 14:52:53 --> Utf8 Class Initialized
INFO - 2018-10-26 14:52:53 --> URI Class Initialized
INFO - 2018-10-26 14:52:53 --> Router Class Initialized
INFO - 2018-10-26 14:52:53 --> Output Class Initialized
INFO - 2018-10-26 14:52:53 --> Security Class Initialized
DEBUG - 2018-10-26 14:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 14:52:53 --> Input Class Initialized
INFO - 2018-10-26 14:52:53 --> Language Class Initialized
INFO - 2018-10-26 14:52:53 --> Loader Class Initialized
INFO - 2018-10-26 14:52:53 --> Helper loaded: url_helper
INFO - 2018-10-26 14:52:53 --> Helper loaded: form_helper
INFO - 2018-10-26 14:52:53 --> Helper loaded: html_helper
INFO - 2018-10-26 14:52:53 --> Database Driver Class Initialized
INFO - 2018-10-26 14:52:54 --> Form Validation Class Initialized
DEBUG - 2018-10-26 14:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 14:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 14:52:54 --> Model "User_model" initialized
INFO - 2018-10-26 14:52:54 --> Model "Project_model" initialized
INFO - 2018-10-26 14:52:54 --> Model "Tasks_model" initialized
INFO - 2018-10-26 14:52:54 --> Model "Lists_model" initialized
INFO - 2018-10-26 14:52:54 --> Controller Class Initialized
INFO - 2018-10-26 14:52:54 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 14:52:54 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 14:52:54 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 14:52:54 --> Final output sent to browser
DEBUG - 2018-10-26 14:52:54 --> Total execution time: 0.0420
INFO - 2018-10-26 14:53:07 --> Config Class Initialized
INFO - 2018-10-26 14:53:07 --> Hooks Class Initialized
DEBUG - 2018-10-26 14:53:07 --> UTF-8 Support Enabled
INFO - 2018-10-26 14:53:07 --> Utf8 Class Initialized
INFO - 2018-10-26 14:53:07 --> URI Class Initialized
INFO - 2018-10-26 14:53:07 --> Router Class Initialized
INFO - 2018-10-26 14:53:07 --> Output Class Initialized
INFO - 2018-10-26 14:53:07 --> Security Class Initialized
DEBUG - 2018-10-26 14:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 14:53:07 --> Input Class Initialized
INFO - 2018-10-26 14:53:07 --> Language Class Initialized
INFO - 2018-10-26 14:53:07 --> Loader Class Initialized
INFO - 2018-10-26 14:53:07 --> Helper loaded: url_helper
INFO - 2018-10-26 14:53:07 --> Helper loaded: form_helper
INFO - 2018-10-26 14:53:07 --> Helper loaded: html_helper
INFO - 2018-10-26 14:53:07 --> Database Driver Class Initialized
INFO - 2018-10-26 14:53:07 --> Form Validation Class Initialized
DEBUG - 2018-10-26 14:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 14:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 14:53:07 --> Model "User_model" initialized
INFO - 2018-10-26 14:53:07 --> Model "Project_model" initialized
INFO - 2018-10-26 14:53:07 --> Model "Tasks_model" initialized
INFO - 2018-10-26 14:53:07 --> Model "Lists_model" initialized
INFO - 2018-10-26 14:53:07 --> Controller Class Initialized
INFO - 2018-10-26 14:53:07 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 14:53:07 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 14:53:07 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 14:53:07 --> Final output sent to browser
DEBUG - 2018-10-26 14:53:07 --> Total execution time: 0.0390
INFO - 2018-10-26 14:53:09 --> Config Class Initialized
INFO - 2018-10-26 14:53:09 --> Hooks Class Initialized
DEBUG - 2018-10-26 14:53:09 --> UTF-8 Support Enabled
INFO - 2018-10-26 14:53:09 --> Utf8 Class Initialized
INFO - 2018-10-26 14:53:09 --> URI Class Initialized
INFO - 2018-10-26 14:53:09 --> Router Class Initialized
INFO - 2018-10-26 14:53:09 --> Output Class Initialized
INFO - 2018-10-26 14:53:09 --> Security Class Initialized
DEBUG - 2018-10-26 14:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 14:53:09 --> Input Class Initialized
INFO - 2018-10-26 14:53:09 --> Language Class Initialized
INFO - 2018-10-26 14:53:09 --> Loader Class Initialized
INFO - 2018-10-26 14:53:09 --> Helper loaded: url_helper
INFO - 2018-10-26 14:53:09 --> Helper loaded: form_helper
INFO - 2018-10-26 14:53:09 --> Helper loaded: html_helper
INFO - 2018-10-26 14:53:09 --> Database Driver Class Initialized
INFO - 2018-10-26 14:53:09 --> Form Validation Class Initialized
DEBUG - 2018-10-26 14:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 14:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 14:53:09 --> Model "User_model" initialized
INFO - 2018-10-26 14:53:09 --> Model "Project_model" initialized
INFO - 2018-10-26 14:53:09 --> Model "Tasks_model" initialized
INFO - 2018-10-26 14:53:09 --> Model "Lists_model" initialized
INFO - 2018-10-26 14:53:09 --> Controller Class Initialized
INFO - 2018-10-26 14:53:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 14:53:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 14:53:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 14:53:09 --> Final output sent to browser
DEBUG - 2018-10-26 14:53:09 --> Total execution time: 0.0410
INFO - 2018-10-26 14:53:11 --> Config Class Initialized
INFO - 2018-10-26 14:53:11 --> Hooks Class Initialized
DEBUG - 2018-10-26 14:53:11 --> UTF-8 Support Enabled
INFO - 2018-10-26 14:53:11 --> Utf8 Class Initialized
INFO - 2018-10-26 14:53:11 --> URI Class Initialized
INFO - 2018-10-26 14:53:11 --> Router Class Initialized
INFO - 2018-10-26 14:53:11 --> Output Class Initialized
INFO - 2018-10-26 14:53:11 --> Security Class Initialized
DEBUG - 2018-10-26 14:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 14:53:11 --> Input Class Initialized
INFO - 2018-10-26 14:53:11 --> Language Class Initialized
INFO - 2018-10-26 14:53:11 --> Loader Class Initialized
INFO - 2018-10-26 14:53:11 --> Helper loaded: url_helper
INFO - 2018-10-26 14:53:11 --> Helper loaded: form_helper
INFO - 2018-10-26 14:53:11 --> Helper loaded: html_helper
INFO - 2018-10-26 14:53:11 --> Database Driver Class Initialized
INFO - 2018-10-26 14:53:11 --> Form Validation Class Initialized
DEBUG - 2018-10-26 14:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 14:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 14:53:11 --> Model "User_model" initialized
INFO - 2018-10-26 14:53:11 --> Model "Project_model" initialized
INFO - 2018-10-26 14:53:11 --> Model "Tasks_model" initialized
INFO - 2018-10-26 14:53:11 --> Model "Lists_model" initialized
INFO - 2018-10-26 14:53:11 --> Controller Class Initialized
INFO - 2018-10-26 14:53:11 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 14:53:11 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 14:53:11 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 14:53:11 --> Final output sent to browser
DEBUG - 2018-10-26 14:53:11 --> Total execution time: 0.0650
INFO - 2018-10-26 14:53:12 --> Config Class Initialized
INFO - 2018-10-26 14:53:12 --> Hooks Class Initialized
DEBUG - 2018-10-26 14:53:12 --> UTF-8 Support Enabled
INFO - 2018-10-26 14:53:12 --> Utf8 Class Initialized
INFO - 2018-10-26 14:53:12 --> URI Class Initialized
INFO - 2018-10-26 14:53:12 --> Router Class Initialized
INFO - 2018-10-26 14:53:12 --> Output Class Initialized
INFO - 2018-10-26 14:53:12 --> Security Class Initialized
DEBUG - 2018-10-26 14:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 14:53:12 --> Input Class Initialized
INFO - 2018-10-26 14:53:12 --> Language Class Initialized
INFO - 2018-10-26 14:53:12 --> Loader Class Initialized
INFO - 2018-10-26 14:53:12 --> Helper loaded: url_helper
INFO - 2018-10-26 14:53:12 --> Helper loaded: form_helper
INFO - 2018-10-26 14:53:12 --> Helper loaded: html_helper
INFO - 2018-10-26 14:53:12 --> Database Driver Class Initialized
INFO - 2018-10-26 14:53:12 --> Form Validation Class Initialized
DEBUG - 2018-10-26 14:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 14:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 14:53:12 --> Model "User_model" initialized
INFO - 2018-10-26 14:53:12 --> Model "Project_model" initialized
INFO - 2018-10-26 14:53:12 --> Model "Tasks_model" initialized
INFO - 2018-10-26 14:53:12 --> Model "Lists_model" initialized
INFO - 2018-10-26 14:53:12 --> Controller Class Initialized
INFO - 2018-10-26 14:53:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 14:53:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 14:53:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 14:53:12 --> Final output sent to browser
DEBUG - 2018-10-26 14:53:12 --> Total execution time: 0.0570
INFO - 2018-10-26 14:54:41 --> Config Class Initialized
INFO - 2018-10-26 14:54:41 --> Hooks Class Initialized
DEBUG - 2018-10-26 14:54:41 --> UTF-8 Support Enabled
INFO - 2018-10-26 14:54:41 --> Utf8 Class Initialized
INFO - 2018-10-26 14:54:41 --> URI Class Initialized
INFO - 2018-10-26 14:54:41 --> Router Class Initialized
INFO - 2018-10-26 14:54:41 --> Output Class Initialized
INFO - 2018-10-26 14:54:41 --> Security Class Initialized
DEBUG - 2018-10-26 14:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 14:54:41 --> Input Class Initialized
INFO - 2018-10-26 14:54:41 --> Language Class Initialized
INFO - 2018-10-26 14:54:41 --> Loader Class Initialized
INFO - 2018-10-26 14:54:41 --> Helper loaded: url_helper
INFO - 2018-10-26 14:54:41 --> Helper loaded: form_helper
INFO - 2018-10-26 14:54:41 --> Helper loaded: html_helper
INFO - 2018-10-26 14:54:41 --> Database Driver Class Initialized
INFO - 2018-10-26 14:54:41 --> Form Validation Class Initialized
DEBUG - 2018-10-26 14:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 14:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 14:54:41 --> Model "User_model" initialized
INFO - 2018-10-26 14:54:41 --> Model "Project_model" initialized
INFO - 2018-10-26 14:54:41 --> Model "Tasks_model" initialized
INFO - 2018-10-26 14:54:41 --> Model "Lists_model" initialized
INFO - 2018-10-26 14:54:41 --> Controller Class Initialized
INFO - 2018-10-26 14:54:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 14:54:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 14:54:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 14:54:41 --> Final output sent to browser
DEBUG - 2018-10-26 14:54:41 --> Total execution time: 0.0560
INFO - 2018-10-26 14:54:42 --> Config Class Initialized
INFO - 2018-10-26 14:54:42 --> Hooks Class Initialized
DEBUG - 2018-10-26 14:54:42 --> UTF-8 Support Enabled
INFO - 2018-10-26 14:54:42 --> Utf8 Class Initialized
INFO - 2018-10-26 14:54:42 --> URI Class Initialized
INFO - 2018-10-26 14:54:42 --> Router Class Initialized
INFO - 2018-10-26 14:54:42 --> Output Class Initialized
INFO - 2018-10-26 14:54:42 --> Security Class Initialized
DEBUG - 2018-10-26 14:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 14:54:42 --> Input Class Initialized
INFO - 2018-10-26 14:54:42 --> Language Class Initialized
INFO - 2018-10-26 14:54:42 --> Loader Class Initialized
INFO - 2018-10-26 14:54:42 --> Helper loaded: url_helper
INFO - 2018-10-26 14:54:42 --> Helper loaded: form_helper
INFO - 2018-10-26 14:54:42 --> Helper loaded: html_helper
INFO - 2018-10-26 14:54:42 --> Database Driver Class Initialized
INFO - 2018-10-26 14:54:42 --> Form Validation Class Initialized
DEBUG - 2018-10-26 14:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 14:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 14:54:42 --> Model "User_model" initialized
INFO - 2018-10-26 14:54:42 --> Model "Project_model" initialized
INFO - 2018-10-26 14:54:42 --> Model "Tasks_model" initialized
INFO - 2018-10-26 14:54:42 --> Model "Lists_model" initialized
INFO - 2018-10-26 14:54:42 --> Controller Class Initialized
INFO - 2018-10-26 14:54:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 14:54:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 14:54:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 14:54:42 --> Final output sent to browser
DEBUG - 2018-10-26 14:54:42 --> Total execution time: 0.0840
INFO - 2018-10-26 14:55:45 --> Config Class Initialized
INFO - 2018-10-26 14:55:45 --> Hooks Class Initialized
DEBUG - 2018-10-26 14:55:45 --> UTF-8 Support Enabled
INFO - 2018-10-26 14:55:45 --> Utf8 Class Initialized
INFO - 2018-10-26 14:55:45 --> URI Class Initialized
INFO - 2018-10-26 14:55:45 --> Router Class Initialized
INFO - 2018-10-26 14:55:45 --> Output Class Initialized
INFO - 2018-10-26 14:55:45 --> Security Class Initialized
DEBUG - 2018-10-26 14:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 14:55:45 --> Input Class Initialized
INFO - 2018-10-26 14:55:45 --> Language Class Initialized
INFO - 2018-10-26 14:55:45 --> Loader Class Initialized
INFO - 2018-10-26 14:55:45 --> Helper loaded: url_helper
INFO - 2018-10-26 14:55:45 --> Helper loaded: form_helper
INFO - 2018-10-26 14:55:45 --> Helper loaded: html_helper
INFO - 2018-10-26 14:55:45 --> Database Driver Class Initialized
INFO - 2018-10-26 14:55:45 --> Form Validation Class Initialized
DEBUG - 2018-10-26 14:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 14:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 14:55:45 --> Model "User_model" initialized
INFO - 2018-10-26 14:55:45 --> Model "Project_model" initialized
INFO - 2018-10-26 14:55:45 --> Model "Tasks_model" initialized
INFO - 2018-10-26 14:55:45 --> Model "Lists_model" initialized
INFO - 2018-10-26 14:55:45 --> Controller Class Initialized
INFO - 2018-10-26 14:55:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 14:55:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 14:55:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 14:55:45 --> Final output sent to browser
DEBUG - 2018-10-26 14:55:45 --> Total execution time: 0.0490
INFO - 2018-10-26 14:57:04 --> Config Class Initialized
INFO - 2018-10-26 14:57:04 --> Hooks Class Initialized
DEBUG - 2018-10-26 14:57:04 --> UTF-8 Support Enabled
INFO - 2018-10-26 14:57:04 --> Utf8 Class Initialized
INFO - 2018-10-26 14:57:04 --> URI Class Initialized
INFO - 2018-10-26 14:57:04 --> Router Class Initialized
INFO - 2018-10-26 14:57:04 --> Output Class Initialized
INFO - 2018-10-26 14:57:04 --> Security Class Initialized
DEBUG - 2018-10-26 14:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 14:57:04 --> Input Class Initialized
INFO - 2018-10-26 14:57:04 --> Language Class Initialized
INFO - 2018-10-26 14:57:04 --> Loader Class Initialized
INFO - 2018-10-26 14:57:04 --> Helper loaded: url_helper
INFO - 2018-10-26 14:57:04 --> Helper loaded: form_helper
INFO - 2018-10-26 14:57:04 --> Helper loaded: html_helper
INFO - 2018-10-26 14:57:04 --> Database Driver Class Initialized
INFO - 2018-10-26 14:57:04 --> Form Validation Class Initialized
DEBUG - 2018-10-26 14:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 14:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 14:57:04 --> Model "User_model" initialized
INFO - 2018-10-26 14:57:04 --> Model "Project_model" initialized
INFO - 2018-10-26 14:57:04 --> Model "Tasks_model" initialized
INFO - 2018-10-26 14:57:04 --> Model "Lists_model" initialized
INFO - 2018-10-26 14:57:04 --> Controller Class Initialized
INFO - 2018-10-26 14:57:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 14:57:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 14:57:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 14:57:04 --> Final output sent to browser
DEBUG - 2018-10-26 14:57:04 --> Total execution time: 0.0690
INFO - 2018-10-26 14:57:05 --> Config Class Initialized
INFO - 2018-10-26 14:57:05 --> Hooks Class Initialized
DEBUG - 2018-10-26 14:57:05 --> UTF-8 Support Enabled
INFO - 2018-10-26 14:57:05 --> Utf8 Class Initialized
INFO - 2018-10-26 14:57:05 --> URI Class Initialized
INFO - 2018-10-26 14:57:05 --> Router Class Initialized
INFO - 2018-10-26 14:57:05 --> Output Class Initialized
INFO - 2018-10-26 14:57:05 --> Security Class Initialized
DEBUG - 2018-10-26 14:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 14:57:05 --> Input Class Initialized
INFO - 2018-10-26 14:57:05 --> Language Class Initialized
INFO - 2018-10-26 14:57:05 --> Loader Class Initialized
INFO - 2018-10-26 14:57:05 --> Helper loaded: url_helper
INFO - 2018-10-26 14:57:05 --> Helper loaded: form_helper
INFO - 2018-10-26 14:57:05 --> Helper loaded: html_helper
INFO - 2018-10-26 14:57:05 --> Database Driver Class Initialized
INFO - 2018-10-26 14:57:05 --> Form Validation Class Initialized
DEBUG - 2018-10-26 14:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 14:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 14:57:05 --> Model "User_model" initialized
INFO - 2018-10-26 14:57:05 --> Model "Project_model" initialized
INFO - 2018-10-26 14:57:05 --> Model "Tasks_model" initialized
INFO - 2018-10-26 14:57:05 --> Model "Lists_model" initialized
INFO - 2018-10-26 14:57:05 --> Controller Class Initialized
INFO - 2018-10-26 14:57:05 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 14:57:05 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 14:57:05 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 14:57:05 --> Final output sent to browser
DEBUG - 2018-10-26 14:57:05 --> Total execution time: 0.0610
INFO - 2018-10-26 14:57:06 --> Config Class Initialized
INFO - 2018-10-26 14:57:06 --> Hooks Class Initialized
DEBUG - 2018-10-26 14:57:06 --> UTF-8 Support Enabled
INFO - 2018-10-26 14:57:06 --> Utf8 Class Initialized
INFO - 2018-10-26 14:57:06 --> URI Class Initialized
INFO - 2018-10-26 14:57:06 --> Router Class Initialized
INFO - 2018-10-26 14:57:06 --> Output Class Initialized
INFO - 2018-10-26 14:57:06 --> Security Class Initialized
DEBUG - 2018-10-26 14:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 14:57:06 --> Input Class Initialized
INFO - 2018-10-26 14:57:06 --> Language Class Initialized
INFO - 2018-10-26 14:57:06 --> Loader Class Initialized
INFO - 2018-10-26 14:57:06 --> Helper loaded: url_helper
INFO - 2018-10-26 14:57:06 --> Helper loaded: form_helper
INFO - 2018-10-26 14:57:06 --> Helper loaded: html_helper
INFO - 2018-10-26 14:57:06 --> Database Driver Class Initialized
INFO - 2018-10-26 14:57:06 --> Form Validation Class Initialized
DEBUG - 2018-10-26 14:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 14:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 14:57:06 --> Model "User_model" initialized
INFO - 2018-10-26 14:57:06 --> Model "Project_model" initialized
INFO - 2018-10-26 14:57:06 --> Model "Tasks_model" initialized
INFO - 2018-10-26 14:57:06 --> Model "Lists_model" initialized
INFO - 2018-10-26 14:57:06 --> Controller Class Initialized
INFO - 2018-10-26 14:57:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 14:57:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 14:57:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 14:57:06 --> Final output sent to browser
DEBUG - 2018-10-26 14:57:06 --> Total execution time: 0.0610
INFO - 2018-10-26 14:57:07 --> Config Class Initialized
INFO - 2018-10-26 14:57:07 --> Hooks Class Initialized
DEBUG - 2018-10-26 14:57:07 --> UTF-8 Support Enabled
INFO - 2018-10-26 14:57:07 --> Utf8 Class Initialized
INFO - 2018-10-26 14:57:07 --> URI Class Initialized
INFO - 2018-10-26 14:57:07 --> Router Class Initialized
INFO - 2018-10-26 14:57:07 --> Output Class Initialized
INFO - 2018-10-26 14:57:07 --> Security Class Initialized
DEBUG - 2018-10-26 14:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 14:57:07 --> Input Class Initialized
INFO - 2018-10-26 14:57:07 --> Language Class Initialized
INFO - 2018-10-26 14:57:07 --> Loader Class Initialized
INFO - 2018-10-26 14:57:07 --> Helper loaded: url_helper
INFO - 2018-10-26 14:57:07 --> Helper loaded: form_helper
INFO - 2018-10-26 14:57:07 --> Helper loaded: html_helper
INFO - 2018-10-26 14:57:07 --> Database Driver Class Initialized
INFO - 2018-10-26 14:57:07 --> Form Validation Class Initialized
DEBUG - 2018-10-26 14:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 14:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 14:57:07 --> Model "User_model" initialized
INFO - 2018-10-26 14:57:07 --> Model "Project_model" initialized
INFO - 2018-10-26 14:57:07 --> Model "Tasks_model" initialized
INFO - 2018-10-26 14:57:07 --> Model "Lists_model" initialized
INFO - 2018-10-26 14:57:07 --> Controller Class Initialized
INFO - 2018-10-26 14:57:07 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 14:57:07 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 14:57:07 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 14:57:07 --> Final output sent to browser
DEBUG - 2018-10-26 14:57:07 --> Total execution time: 0.0580
INFO - 2018-10-26 14:57:08 --> Config Class Initialized
INFO - 2018-10-26 14:57:08 --> Hooks Class Initialized
DEBUG - 2018-10-26 14:57:08 --> UTF-8 Support Enabled
INFO - 2018-10-26 14:57:08 --> Utf8 Class Initialized
INFO - 2018-10-26 14:57:08 --> URI Class Initialized
INFO - 2018-10-26 14:57:08 --> Router Class Initialized
INFO - 2018-10-26 14:57:08 --> Output Class Initialized
INFO - 2018-10-26 14:57:08 --> Security Class Initialized
DEBUG - 2018-10-26 14:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 14:57:08 --> Input Class Initialized
INFO - 2018-10-26 14:57:08 --> Language Class Initialized
INFO - 2018-10-26 14:57:08 --> Loader Class Initialized
INFO - 2018-10-26 14:57:08 --> Helper loaded: url_helper
INFO - 2018-10-26 14:57:08 --> Helper loaded: form_helper
INFO - 2018-10-26 14:57:08 --> Helper loaded: html_helper
INFO - 2018-10-26 14:57:08 --> Database Driver Class Initialized
INFO - 2018-10-26 14:57:08 --> Form Validation Class Initialized
DEBUG - 2018-10-26 14:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 14:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 14:57:08 --> Model "User_model" initialized
INFO - 2018-10-26 14:57:08 --> Model "Project_model" initialized
INFO - 2018-10-26 14:57:08 --> Model "Tasks_model" initialized
INFO - 2018-10-26 14:57:08 --> Model "Lists_model" initialized
INFO - 2018-10-26 14:57:08 --> Controller Class Initialized
INFO - 2018-10-26 14:57:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 14:57:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 14:57:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 14:57:08 --> Final output sent to browser
DEBUG - 2018-10-26 14:57:08 --> Total execution time: 0.0600
INFO - 2018-10-26 14:57:09 --> Config Class Initialized
INFO - 2018-10-26 14:57:09 --> Hooks Class Initialized
DEBUG - 2018-10-26 14:57:09 --> UTF-8 Support Enabled
INFO - 2018-10-26 14:57:09 --> Utf8 Class Initialized
INFO - 2018-10-26 14:57:09 --> URI Class Initialized
INFO - 2018-10-26 14:57:09 --> Router Class Initialized
INFO - 2018-10-26 14:57:09 --> Output Class Initialized
INFO - 2018-10-26 14:57:09 --> Security Class Initialized
DEBUG - 2018-10-26 14:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 14:57:09 --> Input Class Initialized
INFO - 2018-10-26 14:57:09 --> Language Class Initialized
INFO - 2018-10-26 14:57:09 --> Loader Class Initialized
INFO - 2018-10-26 14:57:09 --> Helper loaded: url_helper
INFO - 2018-10-26 14:57:09 --> Helper loaded: form_helper
INFO - 2018-10-26 14:57:09 --> Helper loaded: html_helper
INFO - 2018-10-26 14:57:09 --> Database Driver Class Initialized
INFO - 2018-10-26 14:57:09 --> Form Validation Class Initialized
DEBUG - 2018-10-26 14:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 14:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 14:57:09 --> Model "User_model" initialized
INFO - 2018-10-26 14:57:09 --> Model "Project_model" initialized
INFO - 2018-10-26 14:57:09 --> Model "Tasks_model" initialized
INFO - 2018-10-26 14:57:09 --> Model "Lists_model" initialized
INFO - 2018-10-26 14:57:09 --> Controller Class Initialized
INFO - 2018-10-26 14:57:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 14:57:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 14:57:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 14:57:09 --> Final output sent to browser
DEBUG - 2018-10-26 14:57:09 --> Total execution time: 0.0540
INFO - 2018-10-26 14:57:27 --> Config Class Initialized
INFO - 2018-10-26 14:57:27 --> Hooks Class Initialized
DEBUG - 2018-10-26 14:57:27 --> UTF-8 Support Enabled
INFO - 2018-10-26 14:57:27 --> Utf8 Class Initialized
INFO - 2018-10-26 14:57:27 --> URI Class Initialized
INFO - 2018-10-26 14:57:27 --> Router Class Initialized
INFO - 2018-10-26 14:57:27 --> Output Class Initialized
INFO - 2018-10-26 14:57:27 --> Security Class Initialized
DEBUG - 2018-10-26 14:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 14:57:27 --> Input Class Initialized
INFO - 2018-10-26 14:57:27 --> Language Class Initialized
INFO - 2018-10-26 14:57:27 --> Loader Class Initialized
INFO - 2018-10-26 14:57:27 --> Helper loaded: url_helper
INFO - 2018-10-26 14:57:27 --> Helper loaded: form_helper
INFO - 2018-10-26 14:57:27 --> Helper loaded: html_helper
INFO - 2018-10-26 14:57:27 --> Database Driver Class Initialized
INFO - 2018-10-26 14:57:27 --> Form Validation Class Initialized
DEBUG - 2018-10-26 14:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 14:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 14:57:27 --> Model "User_model" initialized
INFO - 2018-10-26 14:57:27 --> Model "Project_model" initialized
INFO - 2018-10-26 14:57:27 --> Model "Tasks_model" initialized
INFO - 2018-10-26 14:57:27 --> Model "Lists_model" initialized
INFO - 2018-10-26 14:57:27 --> Controller Class Initialized
INFO - 2018-10-26 14:57:27 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 14:57:27 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 14:57:27 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 14:57:27 --> Final output sent to browser
DEBUG - 2018-10-26 14:57:27 --> Total execution time: 0.0500
INFO - 2018-10-26 14:57:28 --> Config Class Initialized
INFO - 2018-10-26 14:57:28 --> Hooks Class Initialized
DEBUG - 2018-10-26 14:57:28 --> UTF-8 Support Enabled
INFO - 2018-10-26 14:57:28 --> Utf8 Class Initialized
INFO - 2018-10-26 14:57:28 --> URI Class Initialized
INFO - 2018-10-26 14:57:28 --> Router Class Initialized
INFO - 2018-10-26 14:57:28 --> Output Class Initialized
INFO - 2018-10-26 14:57:28 --> Security Class Initialized
DEBUG - 2018-10-26 14:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 14:57:28 --> Input Class Initialized
INFO - 2018-10-26 14:57:28 --> Language Class Initialized
INFO - 2018-10-26 14:57:28 --> Loader Class Initialized
INFO - 2018-10-26 14:57:28 --> Helper loaded: url_helper
INFO - 2018-10-26 14:57:28 --> Helper loaded: form_helper
INFO - 2018-10-26 14:57:28 --> Helper loaded: html_helper
INFO - 2018-10-26 14:57:28 --> Database Driver Class Initialized
INFO - 2018-10-26 14:57:28 --> Form Validation Class Initialized
DEBUG - 2018-10-26 14:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 14:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 14:57:28 --> Model "User_model" initialized
INFO - 2018-10-26 14:57:28 --> Model "Project_model" initialized
INFO - 2018-10-26 14:57:28 --> Model "Tasks_model" initialized
INFO - 2018-10-26 14:57:28 --> Model "Lists_model" initialized
INFO - 2018-10-26 14:57:28 --> Controller Class Initialized
INFO - 2018-10-26 14:57:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 14:57:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 14:57:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 14:57:28 --> Final output sent to browser
DEBUG - 2018-10-26 14:57:28 --> Total execution time: 0.0480
INFO - 2018-10-26 14:57:29 --> Config Class Initialized
INFO - 2018-10-26 14:57:29 --> Hooks Class Initialized
DEBUG - 2018-10-26 14:57:29 --> UTF-8 Support Enabled
INFO - 2018-10-26 14:57:29 --> Utf8 Class Initialized
INFO - 2018-10-26 14:57:29 --> URI Class Initialized
INFO - 2018-10-26 14:57:29 --> Router Class Initialized
INFO - 2018-10-26 14:57:29 --> Output Class Initialized
INFO - 2018-10-26 14:57:29 --> Security Class Initialized
DEBUG - 2018-10-26 14:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 14:57:29 --> Input Class Initialized
INFO - 2018-10-26 14:57:29 --> Language Class Initialized
INFO - 2018-10-26 14:57:29 --> Loader Class Initialized
INFO - 2018-10-26 14:57:29 --> Helper loaded: url_helper
INFO - 2018-10-26 14:57:29 --> Helper loaded: form_helper
INFO - 2018-10-26 14:57:29 --> Helper loaded: html_helper
INFO - 2018-10-26 14:57:29 --> Database Driver Class Initialized
INFO - 2018-10-26 14:57:29 --> Form Validation Class Initialized
DEBUG - 2018-10-26 14:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 14:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 14:57:29 --> Model "User_model" initialized
INFO - 2018-10-26 14:57:29 --> Model "Project_model" initialized
INFO - 2018-10-26 14:57:29 --> Model "Tasks_model" initialized
INFO - 2018-10-26 14:57:29 --> Model "Lists_model" initialized
INFO - 2018-10-26 14:57:29 --> Controller Class Initialized
INFO - 2018-10-26 14:57:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 14:57:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 14:57:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 14:57:29 --> Final output sent to browser
DEBUG - 2018-10-26 14:57:29 --> Total execution time: 0.0700
INFO - 2018-10-26 14:59:49 --> Config Class Initialized
INFO - 2018-10-26 14:59:49 --> Hooks Class Initialized
DEBUG - 2018-10-26 14:59:49 --> UTF-8 Support Enabled
INFO - 2018-10-26 14:59:49 --> Utf8 Class Initialized
INFO - 2018-10-26 14:59:49 --> URI Class Initialized
INFO - 2018-10-26 14:59:49 --> Router Class Initialized
INFO - 2018-10-26 14:59:49 --> Output Class Initialized
INFO - 2018-10-26 14:59:49 --> Security Class Initialized
DEBUG - 2018-10-26 14:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 14:59:49 --> Input Class Initialized
INFO - 2018-10-26 14:59:49 --> Language Class Initialized
INFO - 2018-10-26 14:59:49 --> Loader Class Initialized
INFO - 2018-10-26 14:59:49 --> Helper loaded: url_helper
INFO - 2018-10-26 14:59:49 --> Helper loaded: form_helper
INFO - 2018-10-26 14:59:49 --> Helper loaded: html_helper
INFO - 2018-10-26 14:59:49 --> Database Driver Class Initialized
INFO - 2018-10-26 14:59:49 --> Form Validation Class Initialized
DEBUG - 2018-10-26 14:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 14:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 14:59:49 --> Model "User_model" initialized
INFO - 2018-10-26 14:59:49 --> Model "Project_model" initialized
INFO - 2018-10-26 14:59:49 --> Model "Tasks_model" initialized
INFO - 2018-10-26 14:59:49 --> Model "Lists_model" initialized
INFO - 2018-10-26 14:59:49 --> Controller Class Initialized
INFO - 2018-10-26 14:59:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 14:59:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 14:59:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 14:59:49 --> Final output sent to browser
DEBUG - 2018-10-26 14:59:49 --> Total execution time: 0.0630
INFO - 2018-10-26 14:59:56 --> Config Class Initialized
INFO - 2018-10-26 14:59:56 --> Hooks Class Initialized
DEBUG - 2018-10-26 14:59:56 --> UTF-8 Support Enabled
INFO - 2018-10-26 14:59:56 --> Utf8 Class Initialized
INFO - 2018-10-26 14:59:56 --> URI Class Initialized
INFO - 2018-10-26 14:59:56 --> Router Class Initialized
INFO - 2018-10-26 14:59:56 --> Output Class Initialized
INFO - 2018-10-26 14:59:56 --> Security Class Initialized
DEBUG - 2018-10-26 14:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 14:59:56 --> Input Class Initialized
INFO - 2018-10-26 14:59:56 --> Language Class Initialized
INFO - 2018-10-26 14:59:56 --> Loader Class Initialized
INFO - 2018-10-26 14:59:56 --> Helper loaded: url_helper
INFO - 2018-10-26 14:59:56 --> Helper loaded: form_helper
INFO - 2018-10-26 14:59:56 --> Helper loaded: html_helper
INFO - 2018-10-26 14:59:56 --> Database Driver Class Initialized
INFO - 2018-10-26 14:59:56 --> Form Validation Class Initialized
DEBUG - 2018-10-26 14:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 14:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 14:59:56 --> Model "User_model" initialized
INFO - 2018-10-26 14:59:56 --> Model "Project_model" initialized
INFO - 2018-10-26 14:59:56 --> Model "Tasks_model" initialized
INFO - 2018-10-26 14:59:56 --> Model "Lists_model" initialized
INFO - 2018-10-26 14:59:56 --> Controller Class Initialized
INFO - 2018-10-26 14:59:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 14:59:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 14:59:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 14:59:56 --> Final output sent to browser
DEBUG - 2018-10-26 14:59:56 --> Total execution time: 0.0360
INFO - 2018-10-26 14:59:59 --> Config Class Initialized
INFO - 2018-10-26 14:59:59 --> Hooks Class Initialized
DEBUG - 2018-10-26 14:59:59 --> UTF-8 Support Enabled
INFO - 2018-10-26 14:59:59 --> Utf8 Class Initialized
INFO - 2018-10-26 14:59:59 --> URI Class Initialized
INFO - 2018-10-26 14:59:59 --> Router Class Initialized
INFO - 2018-10-26 14:59:59 --> Output Class Initialized
INFO - 2018-10-26 14:59:59 --> Security Class Initialized
DEBUG - 2018-10-26 14:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 14:59:59 --> Input Class Initialized
INFO - 2018-10-26 14:59:59 --> Language Class Initialized
INFO - 2018-10-26 14:59:59 --> Loader Class Initialized
INFO - 2018-10-26 14:59:59 --> Helper loaded: url_helper
INFO - 2018-10-26 14:59:59 --> Helper loaded: form_helper
INFO - 2018-10-26 14:59:59 --> Helper loaded: html_helper
INFO - 2018-10-26 14:59:59 --> Database Driver Class Initialized
INFO - 2018-10-26 14:59:59 --> Form Validation Class Initialized
DEBUG - 2018-10-26 14:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 14:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 14:59:59 --> Model "User_model" initialized
INFO - 2018-10-26 14:59:59 --> Model "Project_model" initialized
INFO - 2018-10-26 14:59:59 --> Model "Tasks_model" initialized
INFO - 2018-10-26 14:59:59 --> Model "Lists_model" initialized
INFO - 2018-10-26 14:59:59 --> Controller Class Initialized
INFO - 2018-10-26 14:59:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 14:59:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 14:59:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 14:59:59 --> Final output sent to browser
DEBUG - 2018-10-26 14:59:59 --> Total execution time: 0.0390
INFO - 2018-10-26 15:00:00 --> Config Class Initialized
INFO - 2018-10-26 15:00:00 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:00:00 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:00:00 --> Utf8 Class Initialized
INFO - 2018-10-26 15:00:00 --> URI Class Initialized
INFO - 2018-10-26 15:00:00 --> Router Class Initialized
INFO - 2018-10-26 15:00:00 --> Output Class Initialized
INFO - 2018-10-26 15:00:00 --> Security Class Initialized
DEBUG - 2018-10-26 15:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:00:00 --> Input Class Initialized
INFO - 2018-10-26 15:00:00 --> Language Class Initialized
INFO - 2018-10-26 15:00:00 --> Loader Class Initialized
INFO - 2018-10-26 15:00:00 --> Helper loaded: url_helper
INFO - 2018-10-26 15:00:00 --> Helper loaded: form_helper
INFO - 2018-10-26 15:00:00 --> Helper loaded: html_helper
INFO - 2018-10-26 15:00:00 --> Database Driver Class Initialized
INFO - 2018-10-26 15:00:00 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:00:00 --> Model "User_model" initialized
INFO - 2018-10-26 15:00:00 --> Model "Project_model" initialized
INFO - 2018-10-26 15:00:00 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:00:00 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:00:00 --> Controller Class Initialized
INFO - 2018-10-26 15:00:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:00:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:00:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:00:00 --> Final output sent to browser
DEBUG - 2018-10-26 15:00:00 --> Total execution time: 0.0520
INFO - 2018-10-26 15:00:15 --> Config Class Initialized
INFO - 2018-10-26 15:00:15 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:00:15 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:00:15 --> Utf8 Class Initialized
INFO - 2018-10-26 15:00:15 --> URI Class Initialized
INFO - 2018-10-26 15:00:15 --> Router Class Initialized
INFO - 2018-10-26 15:00:15 --> Output Class Initialized
INFO - 2018-10-26 15:00:15 --> Security Class Initialized
DEBUG - 2018-10-26 15:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:00:15 --> Input Class Initialized
INFO - 2018-10-26 15:00:15 --> Language Class Initialized
INFO - 2018-10-26 15:00:15 --> Loader Class Initialized
INFO - 2018-10-26 15:00:15 --> Helper loaded: url_helper
INFO - 2018-10-26 15:00:15 --> Helper loaded: form_helper
INFO - 2018-10-26 15:00:15 --> Helper loaded: html_helper
INFO - 2018-10-26 15:00:15 --> Database Driver Class Initialized
INFO - 2018-10-26 15:00:15 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:00:15 --> Model "User_model" initialized
INFO - 2018-10-26 15:00:15 --> Model "Project_model" initialized
INFO - 2018-10-26 15:00:15 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:00:15 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:00:15 --> Controller Class Initialized
INFO - 2018-10-26 15:00:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:00:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:00:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:00:15 --> Final output sent to browser
DEBUG - 2018-10-26 15:00:15 --> Total execution time: 0.0470
INFO - 2018-10-26 15:01:10 --> Config Class Initialized
INFO - 2018-10-26 15:01:10 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:01:10 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:01:10 --> Utf8 Class Initialized
INFO - 2018-10-26 15:01:10 --> URI Class Initialized
INFO - 2018-10-26 15:01:10 --> Router Class Initialized
INFO - 2018-10-26 15:01:10 --> Output Class Initialized
INFO - 2018-10-26 15:01:10 --> Security Class Initialized
DEBUG - 2018-10-26 15:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:01:10 --> Input Class Initialized
INFO - 2018-10-26 15:01:10 --> Language Class Initialized
INFO - 2018-10-26 15:01:10 --> Loader Class Initialized
INFO - 2018-10-26 15:01:10 --> Helper loaded: url_helper
INFO - 2018-10-26 15:01:10 --> Helper loaded: form_helper
INFO - 2018-10-26 15:01:10 --> Helper loaded: html_helper
INFO - 2018-10-26 15:01:10 --> Database Driver Class Initialized
INFO - 2018-10-26 15:01:10 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:01:10 --> Model "User_model" initialized
INFO - 2018-10-26 15:01:10 --> Model "Project_model" initialized
INFO - 2018-10-26 15:01:10 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:01:10 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:01:10 --> Controller Class Initialized
INFO - 2018-10-26 15:01:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:01:11 --> Config Class Initialized
INFO - 2018-10-26 15:01:11 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:01:11 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:01:11 --> Utf8 Class Initialized
INFO - 2018-10-26 15:01:11 --> URI Class Initialized
INFO - 2018-10-26 15:01:11 --> Router Class Initialized
INFO - 2018-10-26 15:01:11 --> Output Class Initialized
INFO - 2018-10-26 15:01:11 --> Security Class Initialized
DEBUG - 2018-10-26 15:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:01:11 --> Input Class Initialized
INFO - 2018-10-26 15:01:11 --> Language Class Initialized
INFO - 2018-10-26 15:01:11 --> Loader Class Initialized
INFO - 2018-10-26 15:01:11 --> Helper loaded: url_helper
INFO - 2018-10-26 15:01:11 --> Helper loaded: form_helper
INFO - 2018-10-26 15:01:11 --> Helper loaded: html_helper
INFO - 2018-10-26 15:01:11 --> Database Driver Class Initialized
INFO - 2018-10-26 15:01:11 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:01:11 --> Model "User_model" initialized
INFO - 2018-10-26 15:01:11 --> Model "Project_model" initialized
INFO - 2018-10-26 15:01:11 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:01:11 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:01:11 --> Controller Class Initialized
INFO - 2018-10-26 15:01:11 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:01:11 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:01:11 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:01:11 --> Final output sent to browser
DEBUG - 2018-10-26 15:01:11 --> Total execution time: 0.0480
INFO - 2018-10-26 15:01:50 --> Config Class Initialized
INFO - 2018-10-26 15:01:50 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:01:50 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:01:50 --> Utf8 Class Initialized
INFO - 2018-10-26 15:01:50 --> URI Class Initialized
INFO - 2018-10-26 15:01:50 --> Router Class Initialized
INFO - 2018-10-26 15:01:50 --> Output Class Initialized
INFO - 2018-10-26 15:01:50 --> Security Class Initialized
DEBUG - 2018-10-26 15:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:01:50 --> Input Class Initialized
INFO - 2018-10-26 15:01:50 --> Language Class Initialized
INFO - 2018-10-26 15:01:50 --> Loader Class Initialized
INFO - 2018-10-26 15:01:50 --> Helper loaded: url_helper
INFO - 2018-10-26 15:01:50 --> Helper loaded: form_helper
INFO - 2018-10-26 15:01:50 --> Helper loaded: html_helper
INFO - 2018-10-26 15:01:50 --> Database Driver Class Initialized
INFO - 2018-10-26 15:01:50 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:01:50 --> Model "User_model" initialized
INFO - 2018-10-26 15:01:50 --> Model "Project_model" initialized
INFO - 2018-10-26 15:01:50 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:01:50 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:01:50 --> Controller Class Initialized
INFO - 2018-10-26 15:01:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:01:50 --> Config Class Initialized
INFO - 2018-10-26 15:01:50 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:01:50 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:01:50 --> Utf8 Class Initialized
INFO - 2018-10-26 15:01:50 --> URI Class Initialized
INFO - 2018-10-26 15:01:50 --> Router Class Initialized
INFO - 2018-10-26 15:01:50 --> Output Class Initialized
INFO - 2018-10-26 15:01:50 --> Security Class Initialized
DEBUG - 2018-10-26 15:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:01:50 --> Input Class Initialized
INFO - 2018-10-26 15:01:50 --> Language Class Initialized
INFO - 2018-10-26 15:01:50 --> Loader Class Initialized
INFO - 2018-10-26 15:01:50 --> Helper loaded: url_helper
INFO - 2018-10-26 15:01:50 --> Helper loaded: form_helper
INFO - 2018-10-26 15:01:50 --> Helper loaded: html_helper
INFO - 2018-10-26 15:01:50 --> Database Driver Class Initialized
INFO - 2018-10-26 15:01:50 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:01:50 --> Model "User_model" initialized
INFO - 2018-10-26 15:01:50 --> Model "Project_model" initialized
INFO - 2018-10-26 15:01:50 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:01:50 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:01:50 --> Controller Class Initialized
INFO - 2018-10-26 15:01:50 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:01:50 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:01:50 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:01:50 --> Final output sent to browser
DEBUG - 2018-10-26 15:01:50 --> Total execution time: 0.0460
INFO - 2018-10-26 15:01:52 --> Config Class Initialized
INFO - 2018-10-26 15:01:52 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:01:52 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:01:52 --> Utf8 Class Initialized
INFO - 2018-10-26 15:01:52 --> URI Class Initialized
INFO - 2018-10-26 15:01:52 --> Router Class Initialized
INFO - 2018-10-26 15:01:52 --> Output Class Initialized
INFO - 2018-10-26 15:01:52 --> Security Class Initialized
DEBUG - 2018-10-26 15:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:01:52 --> Input Class Initialized
INFO - 2018-10-26 15:01:52 --> Language Class Initialized
INFO - 2018-10-26 15:01:52 --> Loader Class Initialized
INFO - 2018-10-26 15:01:52 --> Helper loaded: url_helper
INFO - 2018-10-26 15:01:52 --> Helper loaded: form_helper
INFO - 2018-10-26 15:01:52 --> Helper loaded: html_helper
INFO - 2018-10-26 15:01:52 --> Database Driver Class Initialized
INFO - 2018-10-26 15:01:52 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:01:52 --> Model "User_model" initialized
INFO - 2018-10-26 15:01:52 --> Model "Project_model" initialized
INFO - 2018-10-26 15:01:52 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:01:52 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:01:52 --> Controller Class Initialized
INFO - 2018-10-26 15:01:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:01:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:01:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:01:52 --> Final output sent to browser
DEBUG - 2018-10-26 15:01:52 --> Total execution time: 0.0640
INFO - 2018-10-26 15:02:11 --> Config Class Initialized
INFO - 2018-10-26 15:02:11 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:02:11 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:02:11 --> Utf8 Class Initialized
INFO - 2018-10-26 15:02:11 --> URI Class Initialized
INFO - 2018-10-26 15:02:11 --> Router Class Initialized
INFO - 2018-10-26 15:02:11 --> Output Class Initialized
INFO - 2018-10-26 15:02:11 --> Security Class Initialized
DEBUG - 2018-10-26 15:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:02:11 --> Input Class Initialized
INFO - 2018-10-26 15:02:11 --> Language Class Initialized
INFO - 2018-10-26 15:02:11 --> Loader Class Initialized
INFO - 2018-10-26 15:02:11 --> Helper loaded: url_helper
INFO - 2018-10-26 15:02:11 --> Helper loaded: form_helper
INFO - 2018-10-26 15:02:11 --> Helper loaded: html_helper
INFO - 2018-10-26 15:02:11 --> Database Driver Class Initialized
INFO - 2018-10-26 15:02:11 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:02:11 --> Model "User_model" initialized
INFO - 2018-10-26 15:02:11 --> Model "Project_model" initialized
INFO - 2018-10-26 15:02:11 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:02:11 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:02:11 --> Controller Class Initialized
INFO - 2018-10-26 15:02:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:02:12 --> Config Class Initialized
INFO - 2018-10-26 15:02:12 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:02:12 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:02:12 --> Utf8 Class Initialized
INFO - 2018-10-26 15:02:12 --> URI Class Initialized
INFO - 2018-10-26 15:02:12 --> Router Class Initialized
INFO - 2018-10-26 15:02:12 --> Output Class Initialized
INFO - 2018-10-26 15:02:12 --> Security Class Initialized
DEBUG - 2018-10-26 15:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:02:12 --> Input Class Initialized
INFO - 2018-10-26 15:02:12 --> Language Class Initialized
INFO - 2018-10-26 15:02:12 --> Loader Class Initialized
INFO - 2018-10-26 15:02:12 --> Helper loaded: url_helper
INFO - 2018-10-26 15:02:12 --> Helper loaded: form_helper
INFO - 2018-10-26 15:02:12 --> Helper loaded: html_helper
INFO - 2018-10-26 15:02:12 --> Database Driver Class Initialized
INFO - 2018-10-26 15:02:12 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:02:12 --> Model "User_model" initialized
INFO - 2018-10-26 15:02:12 --> Model "Project_model" initialized
INFO - 2018-10-26 15:02:12 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:02:12 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:02:12 --> Controller Class Initialized
INFO - 2018-10-26 15:02:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:02:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:02:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:02:12 --> Final output sent to browser
DEBUG - 2018-10-26 15:02:12 --> Total execution time: 0.0440
INFO - 2018-10-26 15:02:26 --> Config Class Initialized
INFO - 2018-10-26 15:02:26 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:02:26 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:02:26 --> Utf8 Class Initialized
INFO - 2018-10-26 15:02:26 --> URI Class Initialized
INFO - 2018-10-26 15:02:26 --> Router Class Initialized
INFO - 2018-10-26 15:02:26 --> Output Class Initialized
INFO - 2018-10-26 15:02:26 --> Security Class Initialized
DEBUG - 2018-10-26 15:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:02:26 --> Input Class Initialized
INFO - 2018-10-26 15:02:26 --> Language Class Initialized
INFO - 2018-10-26 15:02:26 --> Loader Class Initialized
INFO - 2018-10-26 15:02:26 --> Helper loaded: url_helper
INFO - 2018-10-26 15:02:26 --> Helper loaded: form_helper
INFO - 2018-10-26 15:02:26 --> Helper loaded: html_helper
INFO - 2018-10-26 15:02:26 --> Database Driver Class Initialized
INFO - 2018-10-26 15:02:26 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:02:26 --> Model "User_model" initialized
INFO - 2018-10-26 15:02:26 --> Model "Project_model" initialized
INFO - 2018-10-26 15:02:26 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:02:26 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:02:26 --> Controller Class Initialized
INFO - 2018-10-26 15:02:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:02:27 --> Config Class Initialized
INFO - 2018-10-26 15:02:27 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:02:27 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:02:27 --> Utf8 Class Initialized
INFO - 2018-10-26 15:02:27 --> URI Class Initialized
INFO - 2018-10-26 15:02:27 --> Router Class Initialized
INFO - 2018-10-26 15:02:27 --> Output Class Initialized
INFO - 2018-10-26 15:02:27 --> Security Class Initialized
DEBUG - 2018-10-26 15:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:02:27 --> Input Class Initialized
INFO - 2018-10-26 15:02:27 --> Language Class Initialized
INFO - 2018-10-26 15:02:27 --> Loader Class Initialized
INFO - 2018-10-26 15:02:27 --> Helper loaded: url_helper
INFO - 2018-10-26 15:02:27 --> Helper loaded: form_helper
INFO - 2018-10-26 15:02:27 --> Helper loaded: html_helper
INFO - 2018-10-26 15:02:27 --> Database Driver Class Initialized
INFO - 2018-10-26 15:02:27 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:02:27 --> Model "User_model" initialized
INFO - 2018-10-26 15:02:27 --> Model "Project_model" initialized
INFO - 2018-10-26 15:02:27 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:02:27 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:02:27 --> Controller Class Initialized
ERROR - 2018-10-26 15:02:27 --> Query error: Table 'users.projects' doesn't exist - Invalid query: SELECT *
FROM `projects`
JOIN `tasks` ON `projects`.`id` = `tasks`.`project_id`
WHERE `project_user_id` IS NULL
INFO - 2018-10-26 15:02:27 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-26 15:02:55 --> Config Class Initialized
INFO - 2018-10-26 15:02:55 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:02:55 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:02:55 --> Utf8 Class Initialized
INFO - 2018-10-26 15:02:55 --> URI Class Initialized
INFO - 2018-10-26 15:02:55 --> Router Class Initialized
INFO - 2018-10-26 15:02:55 --> Output Class Initialized
INFO - 2018-10-26 15:02:55 --> Security Class Initialized
DEBUG - 2018-10-26 15:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:02:55 --> Input Class Initialized
INFO - 2018-10-26 15:02:55 --> Language Class Initialized
INFO - 2018-10-26 15:02:55 --> Loader Class Initialized
INFO - 2018-10-26 15:02:55 --> Helper loaded: url_helper
INFO - 2018-10-26 15:02:55 --> Helper loaded: form_helper
INFO - 2018-10-26 15:02:55 --> Helper loaded: html_helper
INFO - 2018-10-26 15:02:55 --> Database Driver Class Initialized
INFO - 2018-10-26 15:02:55 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:02:55 --> Model "User_model" initialized
INFO - 2018-10-26 15:02:55 --> Model "Project_model" initialized
INFO - 2018-10-26 15:02:55 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:02:55 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:02:55 --> Controller Class Initialized
ERROR - 2018-10-26 15:02:55 --> Query error: Table 'users.projects' doesn't exist - Invalid query: SELECT *
FROM `projects`
JOIN `tasks` ON `projects`.`id` = `tasks`.`project_id`
WHERE `project_user_id` IS NULL
INFO - 2018-10-26 15:02:55 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-26 15:02:57 --> Config Class Initialized
INFO - 2018-10-26 15:02:57 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:02:57 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:02:57 --> Utf8 Class Initialized
INFO - 2018-10-26 15:02:57 --> URI Class Initialized
INFO - 2018-10-26 15:02:58 --> Router Class Initialized
INFO - 2018-10-26 15:02:58 --> Output Class Initialized
INFO - 2018-10-26 15:02:58 --> Security Class Initialized
DEBUG - 2018-10-26 15:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:02:58 --> Input Class Initialized
INFO - 2018-10-26 15:02:58 --> Language Class Initialized
INFO - 2018-10-26 15:02:58 --> Loader Class Initialized
INFO - 2018-10-26 15:02:58 --> Helper loaded: url_helper
INFO - 2018-10-26 15:02:58 --> Helper loaded: form_helper
INFO - 2018-10-26 15:02:58 --> Helper loaded: html_helper
INFO - 2018-10-26 15:02:58 --> Database Driver Class Initialized
INFO - 2018-10-26 15:02:58 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:02:58 --> Model "User_model" initialized
INFO - 2018-10-26 15:02:58 --> Model "Project_model" initialized
INFO - 2018-10-26 15:02:58 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:02:58 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:02:58 --> Controller Class Initialized
ERROR - 2018-10-26 15:02:58 --> Query error: Table 'users.projects' doesn't exist - Invalid query: SELECT *
FROM `projects`
JOIN `tasks` ON `projects`.`id` = `tasks`.`project_id`
WHERE `project_user_id` IS NULL
INFO - 2018-10-26 15:02:58 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-26 15:03:03 --> Config Class Initialized
INFO - 2018-10-26 15:03:03 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:03:03 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:03:03 --> Utf8 Class Initialized
INFO - 2018-10-26 15:03:03 --> URI Class Initialized
INFO - 2018-10-26 15:03:03 --> Router Class Initialized
INFO - 2018-10-26 15:03:03 --> Output Class Initialized
INFO - 2018-10-26 15:03:03 --> Security Class Initialized
DEBUG - 2018-10-26 15:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:03:03 --> Input Class Initialized
INFO - 2018-10-26 15:03:03 --> Language Class Initialized
ERROR - 2018-10-26 15:03:03 --> 404 Page Not Found: project_controllers/Home_view/index
INFO - 2018-10-26 15:03:08 --> Config Class Initialized
INFO - 2018-10-26 15:03:08 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:03:08 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:03:08 --> Utf8 Class Initialized
INFO - 2018-10-26 15:03:08 --> URI Class Initialized
INFO - 2018-10-26 15:03:08 --> Router Class Initialized
INFO - 2018-10-26 15:03:08 --> Output Class Initialized
INFO - 2018-10-26 15:03:08 --> Security Class Initialized
DEBUG - 2018-10-26 15:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:03:08 --> Input Class Initialized
INFO - 2018-10-26 15:03:08 --> Language Class Initialized
INFO - 2018-10-26 15:03:08 --> Loader Class Initialized
INFO - 2018-10-26 15:03:08 --> Helper loaded: url_helper
INFO - 2018-10-26 15:03:08 --> Helper loaded: form_helper
INFO - 2018-10-26 15:03:08 --> Helper loaded: html_helper
INFO - 2018-10-26 15:03:08 --> Database Driver Class Initialized
INFO - 2018-10-26 15:03:08 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:03:08 --> Model "User_model" initialized
INFO - 2018-10-26 15:03:08 --> Model "Project_model" initialized
INFO - 2018-10-26 15:03:08 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:03:08 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:03:08 --> Controller Class Initialized
ERROR - 2018-10-26 15:03:08 --> Query error: Table 'users.projects' doesn't exist - Invalid query: SELECT *
FROM `projects`
JOIN `tasks` ON `projects`.`id` = `tasks`.`project_id`
WHERE `project_user_id` IS NULL
INFO - 2018-10-26 15:03:08 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-26 15:03:18 --> Config Class Initialized
INFO - 2018-10-26 15:03:18 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:03:18 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:03:18 --> Utf8 Class Initialized
INFO - 2018-10-26 15:03:18 --> URI Class Initialized
INFO - 2018-10-26 15:03:18 --> Router Class Initialized
INFO - 2018-10-26 15:03:18 --> Output Class Initialized
INFO - 2018-10-26 15:03:18 --> Security Class Initialized
DEBUG - 2018-10-26 15:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:03:18 --> Input Class Initialized
INFO - 2018-10-26 15:03:18 --> Language Class Initialized
ERROR - 2018-10-26 15:03:18 --> 404 Page Not Found: Controllers/project_controllers
INFO - 2018-10-26 15:03:20 --> Config Class Initialized
INFO - 2018-10-26 15:03:20 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:03:20 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:03:20 --> Utf8 Class Initialized
INFO - 2018-10-26 15:03:20 --> URI Class Initialized
INFO - 2018-10-26 15:03:20 --> Router Class Initialized
INFO - 2018-10-26 15:03:20 --> Output Class Initialized
INFO - 2018-10-26 15:03:20 --> Security Class Initialized
DEBUG - 2018-10-26 15:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:03:20 --> Input Class Initialized
INFO - 2018-10-26 15:03:20 --> Language Class Initialized
INFO - 2018-10-26 15:03:20 --> Loader Class Initialized
INFO - 2018-10-26 15:03:20 --> Helper loaded: url_helper
INFO - 2018-10-26 15:03:20 --> Helper loaded: form_helper
INFO - 2018-10-26 15:03:20 --> Helper loaded: html_helper
INFO - 2018-10-26 15:03:20 --> Database Driver Class Initialized
INFO - 2018-10-26 15:03:20 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:03:20 --> Model "User_model" initialized
INFO - 2018-10-26 15:03:20 --> Model "Project_model" initialized
INFO - 2018-10-26 15:03:20 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:03:20 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:03:20 --> Controller Class Initialized
ERROR - 2018-10-26 15:03:20 --> Query error: Table 'users.projects' doesn't exist - Invalid query: SELECT *
FROM `projects`
JOIN `tasks` ON `projects`.`id` = `tasks`.`project_id`
WHERE `project_user_id` IS NULL
INFO - 2018-10-26 15:03:20 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-26 15:03:21 --> Config Class Initialized
INFO - 2018-10-26 15:03:21 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:03:21 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:03:21 --> Utf8 Class Initialized
INFO - 2018-10-26 15:03:21 --> URI Class Initialized
INFO - 2018-10-26 15:03:21 --> Router Class Initialized
INFO - 2018-10-26 15:03:21 --> Output Class Initialized
INFO - 2018-10-26 15:03:21 --> Security Class Initialized
DEBUG - 2018-10-26 15:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:03:21 --> Input Class Initialized
INFO - 2018-10-26 15:03:21 --> Language Class Initialized
INFO - 2018-10-26 15:03:21 --> Loader Class Initialized
INFO - 2018-10-26 15:03:21 --> Helper loaded: url_helper
INFO - 2018-10-26 15:03:21 --> Helper loaded: form_helper
INFO - 2018-10-26 15:03:21 --> Helper loaded: html_helper
INFO - 2018-10-26 15:03:21 --> Database Driver Class Initialized
INFO - 2018-10-26 15:03:21 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:03:21 --> Model "User_model" initialized
INFO - 2018-10-26 15:03:21 --> Model "Project_model" initialized
INFO - 2018-10-26 15:03:21 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:03:21 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:03:21 --> Controller Class Initialized
ERROR - 2018-10-26 15:03:21 --> Query error: Table 'users.projects' doesn't exist - Invalid query: SELECT *
FROM `projects`
JOIN `tasks` ON `projects`.`id` = `tasks`.`project_id`
WHERE `project_user_id` IS NULL
INFO - 2018-10-26 15:03:21 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-26 15:03:21 --> Config Class Initialized
INFO - 2018-10-26 15:03:21 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:03:21 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:03:21 --> Utf8 Class Initialized
INFO - 2018-10-26 15:03:21 --> URI Class Initialized
INFO - 2018-10-26 15:03:21 --> Router Class Initialized
INFO - 2018-10-26 15:03:21 --> Output Class Initialized
INFO - 2018-10-26 15:03:21 --> Security Class Initialized
DEBUG - 2018-10-26 15:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:03:21 --> Input Class Initialized
INFO - 2018-10-26 15:03:21 --> Language Class Initialized
INFO - 2018-10-26 15:03:21 --> Loader Class Initialized
INFO - 2018-10-26 15:03:21 --> Helper loaded: url_helper
INFO - 2018-10-26 15:03:21 --> Helper loaded: form_helper
INFO - 2018-10-26 15:03:21 --> Helper loaded: html_helper
INFO - 2018-10-26 15:03:21 --> Database Driver Class Initialized
INFO - 2018-10-26 15:03:21 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:03:21 --> Model "User_model" initialized
INFO - 2018-10-26 15:03:21 --> Model "Project_model" initialized
INFO - 2018-10-26 15:03:21 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:03:21 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:03:21 --> Controller Class Initialized
INFO - 2018-10-26 15:03:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:03:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:03:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:03:21 --> Final output sent to browser
DEBUG - 2018-10-26 15:03:21 --> Total execution time: 0.0550
INFO - 2018-10-26 15:03:21 --> Config Class Initialized
INFO - 2018-10-26 15:03:21 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:03:21 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:03:21 --> Utf8 Class Initialized
INFO - 2018-10-26 15:03:21 --> URI Class Initialized
INFO - 2018-10-26 15:03:21 --> Router Class Initialized
INFO - 2018-10-26 15:03:21 --> Output Class Initialized
INFO - 2018-10-26 15:03:21 --> Security Class Initialized
DEBUG - 2018-10-26 15:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:03:21 --> Input Class Initialized
INFO - 2018-10-26 15:03:21 --> Language Class Initialized
INFO - 2018-10-26 15:03:21 --> Loader Class Initialized
INFO - 2018-10-26 15:03:21 --> Helper loaded: url_helper
INFO - 2018-10-26 15:03:21 --> Helper loaded: form_helper
INFO - 2018-10-26 15:03:21 --> Helper loaded: html_helper
INFO - 2018-10-26 15:03:21 --> Database Driver Class Initialized
INFO - 2018-10-26 15:03:21 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:03:21 --> Model "User_model" initialized
INFO - 2018-10-26 15:03:21 --> Model "Project_model" initialized
INFO - 2018-10-26 15:03:21 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:03:21 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:03:21 --> Controller Class Initialized
ERROR - 2018-10-26 15:03:21 --> Query error: Table 'users.projects' doesn't exist - Invalid query: SELECT *
FROM `projects`
JOIN `tasks` ON `projects`.`id` = `tasks`.`project_id`
WHERE `project_user_id` IS NULL
INFO - 2018-10-26 15:03:21 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-26 15:03:22 --> Config Class Initialized
INFO - 2018-10-26 15:03:22 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:03:22 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:03:22 --> Utf8 Class Initialized
INFO - 2018-10-26 15:03:22 --> URI Class Initialized
INFO - 2018-10-26 15:03:22 --> Router Class Initialized
INFO - 2018-10-26 15:03:22 --> Output Class Initialized
INFO - 2018-10-26 15:03:22 --> Security Class Initialized
DEBUG - 2018-10-26 15:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:03:22 --> Input Class Initialized
INFO - 2018-10-26 15:03:22 --> Language Class Initialized
INFO - 2018-10-26 15:03:22 --> Loader Class Initialized
INFO - 2018-10-26 15:03:22 --> Helper loaded: url_helper
INFO - 2018-10-26 15:03:22 --> Helper loaded: form_helper
INFO - 2018-10-26 15:03:22 --> Helper loaded: html_helper
INFO - 2018-10-26 15:03:22 --> Database Driver Class Initialized
INFO - 2018-10-26 15:03:22 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:03:22 --> Model "User_model" initialized
INFO - 2018-10-26 15:03:22 --> Model "Project_model" initialized
INFO - 2018-10-26 15:03:22 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:03:22 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:03:22 --> Controller Class Initialized
INFO - 2018-10-26 15:03:22 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:03:22 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:03:22 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:03:22 --> Final output sent to browser
DEBUG - 2018-10-26 15:03:22 --> Total execution time: 0.0630
INFO - 2018-10-26 15:03:24 --> Config Class Initialized
INFO - 2018-10-26 15:03:24 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:03:24 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:03:24 --> Utf8 Class Initialized
INFO - 2018-10-26 15:03:24 --> URI Class Initialized
INFO - 2018-10-26 15:03:24 --> Router Class Initialized
INFO - 2018-10-26 15:03:24 --> Output Class Initialized
INFO - 2018-10-26 15:03:24 --> Security Class Initialized
DEBUG - 2018-10-26 15:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:03:24 --> Input Class Initialized
INFO - 2018-10-26 15:03:24 --> Language Class Initialized
INFO - 2018-10-26 15:03:24 --> Loader Class Initialized
INFO - 2018-10-26 15:03:24 --> Helper loaded: url_helper
INFO - 2018-10-26 15:03:24 --> Helper loaded: form_helper
INFO - 2018-10-26 15:03:24 --> Helper loaded: html_helper
INFO - 2018-10-26 15:03:24 --> Database Driver Class Initialized
INFO - 2018-10-26 15:03:24 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:03:24 --> Model "User_model" initialized
INFO - 2018-10-26 15:03:24 --> Model "Project_model" initialized
INFO - 2018-10-26 15:03:24 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:03:24 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:03:24 --> Controller Class Initialized
ERROR - 2018-10-26 15:03:24 --> Query error: Table 'users.projects' doesn't exist - Invalid query: SELECT *
FROM `projects`
JOIN `tasks` ON `projects`.`id` = `tasks`.`project_id`
WHERE `project_user_id` IS NULL
INFO - 2018-10-26 15:03:24 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-26 15:03:26 --> Config Class Initialized
INFO - 2018-10-26 15:03:26 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:03:26 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:03:26 --> Utf8 Class Initialized
INFO - 2018-10-26 15:03:26 --> URI Class Initialized
INFO - 2018-10-26 15:03:26 --> Router Class Initialized
INFO - 2018-10-26 15:03:26 --> Output Class Initialized
INFO - 2018-10-26 15:03:26 --> Security Class Initialized
DEBUG - 2018-10-26 15:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:03:26 --> Input Class Initialized
INFO - 2018-10-26 15:03:26 --> Language Class Initialized
INFO - 2018-10-26 15:03:26 --> Loader Class Initialized
INFO - 2018-10-26 15:03:26 --> Helper loaded: url_helper
INFO - 2018-10-26 15:03:26 --> Helper loaded: form_helper
INFO - 2018-10-26 15:03:26 --> Helper loaded: html_helper
INFO - 2018-10-26 15:03:26 --> Database Driver Class Initialized
INFO - 2018-10-26 15:03:26 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:03:26 --> Model "User_model" initialized
INFO - 2018-10-26 15:03:26 --> Model "Project_model" initialized
INFO - 2018-10-26 15:03:26 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:03:26 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:03:26 --> Controller Class Initialized
INFO - 2018-10-26 15:03:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:03:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:03:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:03:26 --> Final output sent to browser
DEBUG - 2018-10-26 15:03:26 --> Total execution time: 0.0730
INFO - 2018-10-26 15:03:29 --> Config Class Initialized
INFO - 2018-10-26 15:03:29 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:03:29 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:03:29 --> Utf8 Class Initialized
INFO - 2018-10-26 15:03:29 --> URI Class Initialized
INFO - 2018-10-26 15:03:29 --> Router Class Initialized
INFO - 2018-10-26 15:03:29 --> Output Class Initialized
INFO - 2018-10-26 15:03:29 --> Security Class Initialized
DEBUG - 2018-10-26 15:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:03:29 --> Input Class Initialized
INFO - 2018-10-26 15:03:29 --> Language Class Initialized
INFO - 2018-10-26 15:03:29 --> Loader Class Initialized
INFO - 2018-10-26 15:03:29 --> Helper loaded: url_helper
INFO - 2018-10-26 15:03:29 --> Helper loaded: form_helper
INFO - 2018-10-26 15:03:29 --> Helper loaded: html_helper
INFO - 2018-10-26 15:03:29 --> Database Driver Class Initialized
INFO - 2018-10-26 15:03:29 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:03:29 --> Model "User_model" initialized
INFO - 2018-10-26 15:03:29 --> Model "Project_model" initialized
INFO - 2018-10-26 15:03:29 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:03:29 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:03:29 --> Controller Class Initialized
ERROR - 2018-10-26 15:03:29 --> Query error: Table 'users.projects' doesn't exist - Invalid query: SELECT *
FROM `projects`
JOIN `tasks` ON `projects`.`id` = `tasks`.`project_id`
WHERE `project_user_id` IS NULL
INFO - 2018-10-26 15:03:29 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-26 15:03:33 --> Config Class Initialized
INFO - 2018-10-26 15:03:33 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:03:33 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:03:33 --> Utf8 Class Initialized
INFO - 2018-10-26 15:03:33 --> URI Class Initialized
INFO - 2018-10-26 15:03:33 --> Router Class Initialized
INFO - 2018-10-26 15:03:33 --> Output Class Initialized
INFO - 2018-10-26 15:03:33 --> Security Class Initialized
DEBUG - 2018-10-26 15:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:03:33 --> Input Class Initialized
INFO - 2018-10-26 15:03:33 --> Language Class Initialized
INFO - 2018-10-26 15:03:33 --> Loader Class Initialized
INFO - 2018-10-26 15:03:33 --> Helper loaded: url_helper
INFO - 2018-10-26 15:03:33 --> Helper loaded: form_helper
INFO - 2018-10-26 15:03:33 --> Helper loaded: html_helper
INFO - 2018-10-26 15:03:33 --> Database Driver Class Initialized
INFO - 2018-10-26 15:03:33 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:03:33 --> Model "User_model" initialized
INFO - 2018-10-26 15:03:33 --> Model "Project_model" initialized
INFO - 2018-10-26 15:03:33 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:03:33 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:03:33 --> Controller Class Initialized
INFO - 2018-10-26 15:03:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:03:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:03:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:03:33 --> Final output sent to browser
DEBUG - 2018-10-26 15:03:33 --> Total execution time: 0.0590
INFO - 2018-10-26 15:03:36 --> Config Class Initialized
INFO - 2018-10-26 15:03:36 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:03:36 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:03:36 --> Utf8 Class Initialized
INFO - 2018-10-26 15:03:36 --> URI Class Initialized
INFO - 2018-10-26 15:03:36 --> Router Class Initialized
INFO - 2018-10-26 15:03:36 --> Output Class Initialized
INFO - 2018-10-26 15:03:36 --> Security Class Initialized
DEBUG - 2018-10-26 15:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:03:36 --> Input Class Initialized
INFO - 2018-10-26 15:03:36 --> Language Class Initialized
INFO - 2018-10-26 15:03:36 --> Loader Class Initialized
INFO - 2018-10-26 15:03:36 --> Helper loaded: url_helper
INFO - 2018-10-26 15:03:36 --> Helper loaded: form_helper
INFO - 2018-10-26 15:03:36 --> Helper loaded: html_helper
INFO - 2018-10-26 15:03:36 --> Database Driver Class Initialized
INFO - 2018-10-26 15:03:37 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:03:37 --> Model "User_model" initialized
INFO - 2018-10-26 15:03:37 --> Model "Project_model" initialized
INFO - 2018-10-26 15:03:37 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:03:37 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:03:37 --> Controller Class Initialized
INFO - 2018-10-26 15:03:37 --> Config Class Initialized
INFO - 2018-10-26 15:03:37 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:03:37 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:03:37 --> Utf8 Class Initialized
INFO - 2018-10-26 15:03:37 --> URI Class Initialized
INFO - 2018-10-26 15:03:37 --> Router Class Initialized
INFO - 2018-10-26 15:03:37 --> Output Class Initialized
INFO - 2018-10-26 15:03:37 --> Security Class Initialized
DEBUG - 2018-10-26 15:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:03:37 --> Input Class Initialized
INFO - 2018-10-26 15:03:37 --> Language Class Initialized
INFO - 2018-10-26 15:03:37 --> Loader Class Initialized
INFO - 2018-10-26 15:03:37 --> Helper loaded: url_helper
INFO - 2018-10-26 15:03:37 --> Helper loaded: form_helper
INFO - 2018-10-26 15:03:37 --> Helper loaded: html_helper
INFO - 2018-10-26 15:03:37 --> Database Driver Class Initialized
INFO - 2018-10-26 15:03:37 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:03:37 --> Model "User_model" initialized
INFO - 2018-10-26 15:03:37 --> Model "Project_model" initialized
INFO - 2018-10-26 15:03:37 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:03:37 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:03:37 --> Controller Class Initialized
INFO - 2018-10-26 15:03:37 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:03:37 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:03:37 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:03:37 --> Final output sent to browser
DEBUG - 2018-10-26 15:03:37 --> Total execution time: 0.0370
INFO - 2018-10-26 15:03:41 --> Config Class Initialized
INFO - 2018-10-26 15:03:41 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:03:41 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:03:41 --> Utf8 Class Initialized
INFO - 2018-10-26 15:03:41 --> URI Class Initialized
INFO - 2018-10-26 15:03:41 --> Router Class Initialized
INFO - 2018-10-26 15:03:41 --> Output Class Initialized
INFO - 2018-10-26 15:03:41 --> Security Class Initialized
DEBUG - 2018-10-26 15:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:03:41 --> Input Class Initialized
INFO - 2018-10-26 15:03:41 --> Language Class Initialized
INFO - 2018-10-26 15:03:41 --> Loader Class Initialized
INFO - 2018-10-26 15:03:41 --> Helper loaded: url_helper
INFO - 2018-10-26 15:03:41 --> Helper loaded: form_helper
INFO - 2018-10-26 15:03:41 --> Helper loaded: html_helper
INFO - 2018-10-26 15:03:41 --> Database Driver Class Initialized
INFO - 2018-10-26 15:03:41 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:03:41 --> Model "User_model" initialized
INFO - 2018-10-26 15:03:41 --> Model "Project_model" initialized
INFO - 2018-10-26 15:03:41 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:03:41 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:03:41 --> Controller Class Initialized
INFO - 2018-10-26 15:03:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:03:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:03:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:03:41 --> Final output sent to browser
DEBUG - 2018-10-26 15:03:41 --> Total execution time: 0.0550
INFO - 2018-10-26 15:03:42 --> Config Class Initialized
INFO - 2018-10-26 15:03:42 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:03:42 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:03:42 --> Utf8 Class Initialized
INFO - 2018-10-26 15:03:42 --> URI Class Initialized
INFO - 2018-10-26 15:03:42 --> Router Class Initialized
INFO - 2018-10-26 15:03:42 --> Output Class Initialized
INFO - 2018-10-26 15:03:42 --> Security Class Initialized
DEBUG - 2018-10-26 15:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:03:42 --> Input Class Initialized
INFO - 2018-10-26 15:03:42 --> Language Class Initialized
INFO - 2018-10-26 15:03:42 --> Loader Class Initialized
INFO - 2018-10-26 15:03:42 --> Helper loaded: url_helper
INFO - 2018-10-26 15:03:42 --> Helper loaded: form_helper
INFO - 2018-10-26 15:03:42 --> Helper loaded: html_helper
INFO - 2018-10-26 15:03:42 --> Database Driver Class Initialized
INFO - 2018-10-26 15:03:42 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:03:42 --> Model "User_model" initialized
INFO - 2018-10-26 15:03:42 --> Model "Project_model" initialized
INFO - 2018-10-26 15:03:42 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:03:42 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:03:42 --> Controller Class Initialized
INFO - 2018-10-26 15:03:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:03:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:03:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:03:42 --> Final output sent to browser
DEBUG - 2018-10-26 15:03:42 --> Total execution time: 0.0620
INFO - 2018-10-26 15:03:58 --> Config Class Initialized
INFO - 2018-10-26 15:03:58 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:03:58 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:03:58 --> Utf8 Class Initialized
INFO - 2018-10-26 15:03:58 --> URI Class Initialized
INFO - 2018-10-26 15:03:58 --> Router Class Initialized
INFO - 2018-10-26 15:03:58 --> Output Class Initialized
INFO - 2018-10-26 15:03:58 --> Security Class Initialized
DEBUG - 2018-10-26 15:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:03:58 --> Input Class Initialized
INFO - 2018-10-26 15:03:58 --> Language Class Initialized
INFO - 2018-10-26 15:03:58 --> Loader Class Initialized
INFO - 2018-10-26 15:03:58 --> Helper loaded: url_helper
INFO - 2018-10-26 15:03:58 --> Helper loaded: form_helper
INFO - 2018-10-26 15:03:58 --> Helper loaded: html_helper
INFO - 2018-10-26 15:03:58 --> Database Driver Class Initialized
INFO - 2018-10-26 15:03:58 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:03:58 --> Model "User_model" initialized
INFO - 2018-10-26 15:03:58 --> Model "Project_model" initialized
INFO - 2018-10-26 15:03:58 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:03:58 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:03:58 --> Controller Class Initialized
INFO - 2018-10-26 15:03:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:03:58 --> Config Class Initialized
INFO - 2018-10-26 15:03:58 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:03:58 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:03:58 --> Utf8 Class Initialized
INFO - 2018-10-26 15:03:58 --> URI Class Initialized
INFO - 2018-10-26 15:03:58 --> Router Class Initialized
INFO - 2018-10-26 15:03:58 --> Output Class Initialized
INFO - 2018-10-26 15:03:58 --> Security Class Initialized
DEBUG - 2018-10-26 15:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:03:58 --> Input Class Initialized
INFO - 2018-10-26 15:03:58 --> Language Class Initialized
INFO - 2018-10-26 15:03:58 --> Loader Class Initialized
INFO - 2018-10-26 15:03:58 --> Helper loaded: url_helper
INFO - 2018-10-26 15:03:58 --> Helper loaded: form_helper
INFO - 2018-10-26 15:03:58 --> Helper loaded: html_helper
INFO - 2018-10-26 15:03:58 --> Database Driver Class Initialized
INFO - 2018-10-26 15:03:58 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:03:58 --> Model "User_model" initialized
INFO - 2018-10-26 15:03:58 --> Model "Project_model" initialized
INFO - 2018-10-26 15:03:58 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:03:58 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:03:58 --> Controller Class Initialized
ERROR - 2018-10-26 15:03:58 --> Query error: Table 'users.projects' doesn't exist - Invalid query: SELECT *
FROM `projects`
JOIN `tasks` ON `projects`.`id` = `tasks`.`project_id`
WHERE `project_user_id` IS NULL
INFO - 2018-10-26 15:03:58 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-26 15:04:00 --> Config Class Initialized
INFO - 2018-10-26 15:04:00 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:04:00 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:04:00 --> Utf8 Class Initialized
INFO - 2018-10-26 15:04:00 --> URI Class Initialized
INFO - 2018-10-26 15:04:00 --> Router Class Initialized
INFO - 2018-10-26 15:04:00 --> Output Class Initialized
INFO - 2018-10-26 15:04:00 --> Security Class Initialized
DEBUG - 2018-10-26 15:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:04:00 --> Input Class Initialized
INFO - 2018-10-26 15:04:00 --> Language Class Initialized
INFO - 2018-10-26 15:04:00 --> Loader Class Initialized
INFO - 2018-10-26 15:04:00 --> Helper loaded: url_helper
INFO - 2018-10-26 15:04:00 --> Helper loaded: form_helper
INFO - 2018-10-26 15:04:00 --> Helper loaded: html_helper
INFO - 2018-10-26 15:04:00 --> Database Driver Class Initialized
INFO - 2018-10-26 15:04:00 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:04:00 --> Model "User_model" initialized
INFO - 2018-10-26 15:04:00 --> Model "Project_model" initialized
INFO - 2018-10-26 15:04:00 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:04:00 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:04:00 --> Controller Class Initialized
ERROR - 2018-10-26 15:04:00 --> Query error: Table 'users.projects' doesn't exist - Invalid query: SELECT *
FROM `projects`
JOIN `tasks` ON `projects`.`id` = `tasks`.`project_id`
WHERE `project_user_id` IS NULL
INFO - 2018-10-26 15:04:00 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-26 15:04:01 --> Config Class Initialized
INFO - 2018-10-26 15:04:01 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:04:01 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:04:01 --> Utf8 Class Initialized
INFO - 2018-10-26 15:04:01 --> URI Class Initialized
INFO - 2018-10-26 15:04:01 --> Router Class Initialized
INFO - 2018-10-26 15:04:01 --> Output Class Initialized
INFO - 2018-10-26 15:04:01 --> Security Class Initialized
DEBUG - 2018-10-26 15:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:04:01 --> Input Class Initialized
INFO - 2018-10-26 15:04:01 --> Language Class Initialized
INFO - 2018-10-26 15:04:01 --> Loader Class Initialized
INFO - 2018-10-26 15:04:01 --> Helper loaded: url_helper
INFO - 2018-10-26 15:04:01 --> Helper loaded: form_helper
INFO - 2018-10-26 15:04:01 --> Helper loaded: html_helper
INFO - 2018-10-26 15:04:01 --> Database Driver Class Initialized
INFO - 2018-10-26 15:04:01 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:04:01 --> Model "User_model" initialized
INFO - 2018-10-26 15:04:01 --> Model "Project_model" initialized
INFO - 2018-10-26 15:04:01 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:04:01 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:04:01 --> Controller Class Initialized
INFO - 2018-10-26 15:04:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:04:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:04:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:04:01 --> Final output sent to browser
DEBUG - 2018-10-26 15:04:01 --> Total execution time: 0.0550
INFO - 2018-10-26 15:04:06 --> Config Class Initialized
INFO - 2018-10-26 15:04:06 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:04:06 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:04:06 --> Utf8 Class Initialized
INFO - 2018-10-26 15:04:06 --> URI Class Initialized
INFO - 2018-10-26 15:04:06 --> Router Class Initialized
INFO - 2018-10-26 15:04:06 --> Output Class Initialized
INFO - 2018-10-26 15:04:06 --> Security Class Initialized
DEBUG - 2018-10-26 15:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:04:06 --> Input Class Initialized
INFO - 2018-10-26 15:04:06 --> Language Class Initialized
ERROR - 2018-10-26 15:04:06 --> 404 Page Not Found: project_controllers/Projects/index
INFO - 2018-10-26 15:04:08 --> Config Class Initialized
INFO - 2018-10-26 15:04:08 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:04:08 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:04:08 --> Utf8 Class Initialized
INFO - 2018-10-26 15:04:08 --> URI Class Initialized
INFO - 2018-10-26 15:04:08 --> Router Class Initialized
INFO - 2018-10-26 15:04:08 --> Output Class Initialized
INFO - 2018-10-26 15:04:08 --> Security Class Initialized
DEBUG - 2018-10-26 15:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:04:08 --> Input Class Initialized
INFO - 2018-10-26 15:04:08 --> Language Class Initialized
ERROR - 2018-10-26 15:04:08 --> 404 Page Not Found: project_controllers/Tasks/index
INFO - 2018-10-26 15:04:10 --> Config Class Initialized
INFO - 2018-10-26 15:04:10 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:04:10 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:04:10 --> Utf8 Class Initialized
INFO - 2018-10-26 15:04:10 --> URI Class Initialized
INFO - 2018-10-26 15:04:10 --> Router Class Initialized
INFO - 2018-10-26 15:04:10 --> Output Class Initialized
INFO - 2018-10-26 15:04:10 --> Security Class Initialized
DEBUG - 2018-10-26 15:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:04:10 --> Input Class Initialized
INFO - 2018-10-26 15:04:10 --> Language Class Initialized
ERROR - 2018-10-26 15:04:10 --> 404 Page Not Found: project_controllers/Lists/index
INFO - 2018-10-26 15:04:13 --> Config Class Initialized
INFO - 2018-10-26 15:04:13 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:04:13 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:04:13 --> Utf8 Class Initialized
INFO - 2018-10-26 15:04:13 --> URI Class Initialized
INFO - 2018-10-26 15:04:13 --> Router Class Initialized
INFO - 2018-10-26 15:04:13 --> Output Class Initialized
INFO - 2018-10-26 15:04:13 --> Security Class Initialized
DEBUG - 2018-10-26 15:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:04:13 --> Input Class Initialized
INFO - 2018-10-26 15:04:13 --> Language Class Initialized
INFO - 2018-10-26 15:04:13 --> Loader Class Initialized
INFO - 2018-10-26 15:04:13 --> Helper loaded: url_helper
INFO - 2018-10-26 15:04:13 --> Helper loaded: form_helper
INFO - 2018-10-26 15:04:13 --> Helper loaded: html_helper
INFO - 2018-10-26 15:04:13 --> Database Driver Class Initialized
INFO - 2018-10-26 15:04:13 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:04:13 --> Model "User_model" initialized
INFO - 2018-10-26 15:04:13 --> Model "Project_model" initialized
INFO - 2018-10-26 15:04:13 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:04:13 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:04:13 --> Controller Class Initialized
ERROR - 2018-10-26 15:04:13 --> Query error: Table 'users.projects' doesn't exist - Invalid query: SELECT *
FROM `projects`
JOIN `tasks` ON `projects`.`id` = `tasks`.`project_id`
WHERE `project_user_id` IS NULL
INFO - 2018-10-26 15:04:13 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-26 15:04:18 --> Config Class Initialized
INFO - 2018-10-26 15:04:18 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:04:19 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:04:19 --> Utf8 Class Initialized
INFO - 2018-10-26 15:04:19 --> URI Class Initialized
INFO - 2018-10-26 15:04:19 --> Router Class Initialized
INFO - 2018-10-26 15:04:19 --> Output Class Initialized
INFO - 2018-10-26 15:04:19 --> Security Class Initialized
DEBUG - 2018-10-26 15:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:04:19 --> Input Class Initialized
INFO - 2018-10-26 15:04:19 --> Language Class Initialized
INFO - 2018-10-26 15:04:19 --> Loader Class Initialized
INFO - 2018-10-26 15:04:19 --> Helper loaded: url_helper
INFO - 2018-10-26 15:04:19 --> Helper loaded: form_helper
INFO - 2018-10-26 15:04:19 --> Helper loaded: html_helper
INFO - 2018-10-26 15:04:19 --> Database Driver Class Initialized
INFO - 2018-10-26 15:04:19 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:04:19 --> Model "User_model" initialized
INFO - 2018-10-26 15:04:19 --> Model "Project_model" initialized
INFO - 2018-10-26 15:04:19 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:04:19 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:04:19 --> Controller Class Initialized
ERROR - 2018-10-26 15:04:19 --> Query error: Table 'users.projects' doesn't exist - Invalid query: SELECT *
FROM `projects`
JOIN `tasks` ON `projects`.`id` = `tasks`.`project_id`
WHERE `project_user_id` IS NULL
INFO - 2018-10-26 15:04:19 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-26 15:04:47 --> Config Class Initialized
INFO - 2018-10-26 15:04:47 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:04:47 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:04:47 --> Utf8 Class Initialized
INFO - 2018-10-26 15:04:47 --> URI Class Initialized
INFO - 2018-10-26 15:04:47 --> Router Class Initialized
INFO - 2018-10-26 15:04:47 --> Output Class Initialized
INFO - 2018-10-26 15:04:47 --> Security Class Initialized
DEBUG - 2018-10-26 15:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:04:47 --> Input Class Initialized
INFO - 2018-10-26 15:04:47 --> Language Class Initialized
INFO - 2018-10-26 15:04:47 --> Loader Class Initialized
INFO - 2018-10-26 15:04:47 --> Helper loaded: url_helper
INFO - 2018-10-26 15:04:47 --> Helper loaded: form_helper
INFO - 2018-10-26 15:04:47 --> Helper loaded: html_helper
INFO - 2018-10-26 15:04:47 --> Database Driver Class Initialized
INFO - 2018-10-26 15:04:47 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:04:47 --> Model "User_model" initialized
INFO - 2018-10-26 15:04:47 --> Model "Project_model" initialized
INFO - 2018-10-26 15:04:47 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:04:47 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:04:47 --> Controller Class Initialized
ERROR - 2018-10-26 15:04:47 --> Query error: Table 'users.projects' doesn't exist - Invalid query: SELECT *
FROM `projects`
JOIN `tasks` ON `projects`.`id` = `tasks`.`project_id`
WHERE `project_user_id` IS NULL
INFO - 2018-10-26 15:04:47 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-26 15:04:49 --> Config Class Initialized
INFO - 2018-10-26 15:04:49 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:04:49 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:04:49 --> Utf8 Class Initialized
INFO - 2018-10-26 15:04:49 --> URI Class Initialized
INFO - 2018-10-26 15:04:49 --> Router Class Initialized
INFO - 2018-10-26 15:04:49 --> Output Class Initialized
INFO - 2018-10-26 15:04:49 --> Security Class Initialized
DEBUG - 2018-10-26 15:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:04:49 --> Input Class Initialized
INFO - 2018-10-26 15:04:49 --> Language Class Initialized
INFO - 2018-10-26 15:04:49 --> Loader Class Initialized
INFO - 2018-10-26 15:04:49 --> Helper loaded: url_helper
INFO - 2018-10-26 15:04:49 --> Helper loaded: form_helper
INFO - 2018-10-26 15:04:49 --> Helper loaded: html_helper
INFO - 2018-10-26 15:04:49 --> Database Driver Class Initialized
INFO - 2018-10-26 15:04:49 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:04:49 --> Model "User_model" initialized
INFO - 2018-10-26 15:04:49 --> Model "Project_model" initialized
INFO - 2018-10-26 15:04:49 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:04:49 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:04:49 --> Controller Class Initialized
INFO - 2018-10-26 15:04:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:04:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:04:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:04:49 --> Final output sent to browser
DEBUG - 2018-10-26 15:04:49 --> Total execution time: 0.0640
INFO - 2018-10-26 15:04:51 --> Config Class Initialized
INFO - 2018-10-26 15:04:51 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:04:51 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:04:51 --> Utf8 Class Initialized
INFO - 2018-10-26 15:04:51 --> URI Class Initialized
INFO - 2018-10-26 15:04:51 --> Router Class Initialized
INFO - 2018-10-26 15:04:51 --> Output Class Initialized
INFO - 2018-10-26 15:04:51 --> Security Class Initialized
DEBUG - 2018-10-26 15:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:04:51 --> Input Class Initialized
INFO - 2018-10-26 15:04:51 --> Language Class Initialized
INFO - 2018-10-26 15:04:51 --> Loader Class Initialized
INFO - 2018-10-26 15:04:51 --> Helper loaded: url_helper
INFO - 2018-10-26 15:04:51 --> Helper loaded: form_helper
INFO - 2018-10-26 15:04:51 --> Helper loaded: html_helper
INFO - 2018-10-26 15:04:51 --> Database Driver Class Initialized
INFO - 2018-10-26 15:04:51 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:04:51 --> Model "User_model" initialized
INFO - 2018-10-26 15:04:51 --> Model "Project_model" initialized
INFO - 2018-10-26 15:04:51 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:04:51 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:04:51 --> Controller Class Initialized
ERROR - 2018-10-26 15:04:51 --> Query error: Table 'users.projects' doesn't exist - Invalid query: SELECT *
FROM `projects`
JOIN `tasks` ON `projects`.`id` = `tasks`.`project_id`
WHERE `project_user_id` IS NULL
INFO - 2018-10-26 15:04:51 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-26 15:04:52 --> Config Class Initialized
INFO - 2018-10-26 15:04:52 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:04:52 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:04:52 --> Utf8 Class Initialized
INFO - 2018-10-26 15:04:52 --> URI Class Initialized
INFO - 2018-10-26 15:04:52 --> Router Class Initialized
INFO - 2018-10-26 15:04:52 --> Output Class Initialized
INFO - 2018-10-26 15:04:52 --> Security Class Initialized
DEBUG - 2018-10-26 15:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:04:52 --> Input Class Initialized
INFO - 2018-10-26 15:04:52 --> Language Class Initialized
INFO - 2018-10-26 15:04:52 --> Loader Class Initialized
INFO - 2018-10-26 15:04:52 --> Helper loaded: url_helper
INFO - 2018-10-26 15:04:52 --> Helper loaded: form_helper
INFO - 2018-10-26 15:04:52 --> Helper loaded: html_helper
INFO - 2018-10-26 15:04:52 --> Database Driver Class Initialized
INFO - 2018-10-26 15:04:52 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:04:52 --> Model "User_model" initialized
INFO - 2018-10-26 15:04:52 --> Model "Project_model" initialized
INFO - 2018-10-26 15:04:52 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:04:52 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:04:52 --> Controller Class Initialized
INFO - 2018-10-26 15:04:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:04:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:04:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:04:52 --> Final output sent to browser
DEBUG - 2018-10-26 15:04:52 --> Total execution time: 0.0680
INFO - 2018-10-26 15:06:21 --> Config Class Initialized
INFO - 2018-10-26 15:06:21 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:06:21 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:06:21 --> Utf8 Class Initialized
INFO - 2018-10-26 15:06:21 --> URI Class Initialized
INFO - 2018-10-26 15:06:21 --> Router Class Initialized
INFO - 2018-10-26 15:06:21 --> Output Class Initialized
INFO - 2018-10-26 15:06:21 --> Security Class Initialized
DEBUG - 2018-10-26 15:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:06:21 --> Input Class Initialized
INFO - 2018-10-26 15:06:21 --> Language Class Initialized
INFO - 2018-10-26 15:06:21 --> Loader Class Initialized
INFO - 2018-10-26 15:06:21 --> Helper loaded: url_helper
INFO - 2018-10-26 15:06:21 --> Helper loaded: form_helper
INFO - 2018-10-26 15:06:21 --> Helper loaded: html_helper
INFO - 2018-10-26 15:06:21 --> Database Driver Class Initialized
INFO - 2018-10-26 15:06:21 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:06:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:06:21 --> Model "User_model" initialized
INFO - 2018-10-26 15:06:21 --> Model "Project_model" initialized
INFO - 2018-10-26 15:06:21 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:06:21 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:06:21 --> Controller Class Initialized
INFO - 2018-10-26 15:06:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:06:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:06:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:06:21 --> Final output sent to browser
DEBUG - 2018-10-26 15:06:21 --> Total execution time: 0.0740
INFO - 2018-10-26 15:06:23 --> Config Class Initialized
INFO - 2018-10-26 15:06:23 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:06:23 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:06:23 --> Utf8 Class Initialized
INFO - 2018-10-26 15:06:23 --> URI Class Initialized
INFO - 2018-10-26 15:06:23 --> Router Class Initialized
INFO - 2018-10-26 15:06:23 --> Output Class Initialized
INFO - 2018-10-26 15:06:23 --> Security Class Initialized
DEBUG - 2018-10-26 15:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:06:23 --> Input Class Initialized
INFO - 2018-10-26 15:06:23 --> Language Class Initialized
INFO - 2018-10-26 15:06:23 --> Loader Class Initialized
INFO - 2018-10-26 15:06:23 --> Helper loaded: url_helper
INFO - 2018-10-26 15:06:23 --> Helper loaded: form_helper
INFO - 2018-10-26 15:06:23 --> Helper loaded: html_helper
INFO - 2018-10-26 15:06:23 --> Database Driver Class Initialized
INFO - 2018-10-26 15:06:23 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:06:23 --> Model "User_model" initialized
INFO - 2018-10-26 15:06:23 --> Model "Project_model" initialized
INFO - 2018-10-26 15:06:23 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:06:23 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:06:23 --> Controller Class Initialized
ERROR - 2018-10-26 15:06:23 --> Query error: Table 'users.projects' doesn't exist - Invalid query: SELECT *
FROM `projects`
JOIN `tasks` ON `projects`.`id` = `tasks`.`project_id`
WHERE `project_user_id` IS NULL
INFO - 2018-10-26 15:06:23 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-26 15:06:24 --> Config Class Initialized
INFO - 2018-10-26 15:06:24 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:06:24 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:06:24 --> Utf8 Class Initialized
INFO - 2018-10-26 15:06:24 --> URI Class Initialized
INFO - 2018-10-26 15:06:24 --> Router Class Initialized
INFO - 2018-10-26 15:06:24 --> Output Class Initialized
INFO - 2018-10-26 15:06:24 --> Security Class Initialized
DEBUG - 2018-10-26 15:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:06:24 --> Input Class Initialized
INFO - 2018-10-26 15:06:24 --> Language Class Initialized
INFO - 2018-10-26 15:06:24 --> Loader Class Initialized
INFO - 2018-10-26 15:06:24 --> Helper loaded: url_helper
INFO - 2018-10-26 15:06:24 --> Helper loaded: form_helper
INFO - 2018-10-26 15:06:24 --> Helper loaded: html_helper
INFO - 2018-10-26 15:06:24 --> Database Driver Class Initialized
INFO - 2018-10-26 15:06:24 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:06:24 --> Model "User_model" initialized
INFO - 2018-10-26 15:06:24 --> Model "Project_model" initialized
INFO - 2018-10-26 15:06:24 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:06:24 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:06:24 --> Controller Class Initialized
INFO - 2018-10-26 15:06:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:06:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:06:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:06:24 --> Final output sent to browser
DEBUG - 2018-10-26 15:06:24 --> Total execution time: 0.0710
INFO - 2018-10-26 15:06:28 --> Config Class Initialized
INFO - 2018-10-26 15:06:28 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:06:28 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:06:28 --> Utf8 Class Initialized
INFO - 2018-10-26 15:06:28 --> URI Class Initialized
INFO - 2018-10-26 15:06:28 --> Router Class Initialized
INFO - 2018-10-26 15:06:28 --> Output Class Initialized
INFO - 2018-10-26 15:06:28 --> Security Class Initialized
DEBUG - 2018-10-26 15:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:06:28 --> Input Class Initialized
INFO - 2018-10-26 15:06:28 --> Language Class Initialized
INFO - 2018-10-26 15:06:28 --> Loader Class Initialized
INFO - 2018-10-26 15:06:28 --> Helper loaded: url_helper
INFO - 2018-10-26 15:06:28 --> Helper loaded: form_helper
INFO - 2018-10-26 15:06:28 --> Helper loaded: html_helper
INFO - 2018-10-26 15:06:28 --> Database Driver Class Initialized
INFO - 2018-10-26 15:06:28 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:06:28 --> Model "User_model" initialized
INFO - 2018-10-26 15:06:28 --> Model "Project_model" initialized
INFO - 2018-10-26 15:06:28 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:06:28 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:06:28 --> Controller Class Initialized
INFO - 2018-10-26 15:06:28 --> Config Class Initialized
INFO - 2018-10-26 15:06:28 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:06:28 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:06:28 --> Utf8 Class Initialized
INFO - 2018-10-26 15:06:28 --> URI Class Initialized
INFO - 2018-10-26 15:06:28 --> Router Class Initialized
INFO - 2018-10-26 15:06:28 --> Output Class Initialized
INFO - 2018-10-26 15:06:28 --> Security Class Initialized
DEBUG - 2018-10-26 15:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:06:28 --> Input Class Initialized
INFO - 2018-10-26 15:06:28 --> Language Class Initialized
INFO - 2018-10-26 15:06:28 --> Loader Class Initialized
INFO - 2018-10-26 15:06:28 --> Helper loaded: url_helper
INFO - 2018-10-26 15:06:28 --> Helper loaded: form_helper
INFO - 2018-10-26 15:06:28 --> Helper loaded: html_helper
INFO - 2018-10-26 15:06:28 --> Database Driver Class Initialized
INFO - 2018-10-26 15:06:28 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:06:28 --> Model "User_model" initialized
INFO - 2018-10-26 15:06:28 --> Model "Project_model" initialized
INFO - 2018-10-26 15:06:28 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:06:28 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:06:28 --> Controller Class Initialized
INFO - 2018-10-26 15:06:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:06:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:06:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:06:28 --> Final output sent to browser
DEBUG - 2018-10-26 15:06:28 --> Total execution time: 0.0330
INFO - 2018-10-26 15:06:29 --> Config Class Initialized
INFO - 2018-10-26 15:06:29 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:06:29 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:06:29 --> Utf8 Class Initialized
INFO - 2018-10-26 15:06:29 --> URI Class Initialized
INFO - 2018-10-26 15:06:29 --> Router Class Initialized
INFO - 2018-10-26 15:06:29 --> Output Class Initialized
INFO - 2018-10-26 15:06:29 --> Security Class Initialized
DEBUG - 2018-10-26 15:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:06:29 --> Input Class Initialized
INFO - 2018-10-26 15:06:29 --> Language Class Initialized
INFO - 2018-10-26 15:06:29 --> Loader Class Initialized
INFO - 2018-10-26 15:06:29 --> Helper loaded: url_helper
INFO - 2018-10-26 15:06:29 --> Helper loaded: form_helper
INFO - 2018-10-26 15:06:29 --> Helper loaded: html_helper
INFO - 2018-10-26 15:06:29 --> Database Driver Class Initialized
INFO - 2018-10-26 15:06:29 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:06:29 --> Model "User_model" initialized
INFO - 2018-10-26 15:06:29 --> Model "Project_model" initialized
INFO - 2018-10-26 15:06:29 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:06:29 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:06:29 --> Controller Class Initialized
INFO - 2018-10-26 15:06:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:06:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:06:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:06:29 --> Final output sent to browser
DEBUG - 2018-10-26 15:06:29 --> Total execution time: 0.0460
INFO - 2018-10-26 15:06:30 --> Config Class Initialized
INFO - 2018-10-26 15:06:30 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:06:30 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:06:30 --> Utf8 Class Initialized
INFO - 2018-10-26 15:06:30 --> URI Class Initialized
INFO - 2018-10-26 15:06:30 --> Router Class Initialized
INFO - 2018-10-26 15:06:30 --> Output Class Initialized
INFO - 2018-10-26 15:06:30 --> Security Class Initialized
DEBUG - 2018-10-26 15:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:06:30 --> Input Class Initialized
INFO - 2018-10-26 15:06:30 --> Language Class Initialized
INFO - 2018-10-26 15:06:30 --> Loader Class Initialized
INFO - 2018-10-26 15:06:30 --> Helper loaded: url_helper
INFO - 2018-10-26 15:06:30 --> Helper loaded: form_helper
INFO - 2018-10-26 15:06:30 --> Helper loaded: html_helper
INFO - 2018-10-26 15:06:30 --> Database Driver Class Initialized
INFO - 2018-10-26 15:06:30 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:06:30 --> Model "User_model" initialized
INFO - 2018-10-26 15:06:30 --> Model "Project_model" initialized
INFO - 2018-10-26 15:06:30 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:06:30 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:06:30 --> Controller Class Initialized
INFO - 2018-10-26 15:06:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:06:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:06:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:06:30 --> Final output sent to browser
DEBUG - 2018-10-26 15:06:30 --> Total execution time: 0.0650
INFO - 2018-10-26 15:06:39 --> Config Class Initialized
INFO - 2018-10-26 15:06:39 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:06:39 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:06:39 --> Utf8 Class Initialized
INFO - 2018-10-26 15:06:39 --> URI Class Initialized
INFO - 2018-10-26 15:06:39 --> Router Class Initialized
INFO - 2018-10-26 15:06:39 --> Output Class Initialized
INFO - 2018-10-26 15:06:39 --> Security Class Initialized
DEBUG - 2018-10-26 15:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:06:39 --> Input Class Initialized
INFO - 2018-10-26 15:06:39 --> Language Class Initialized
INFO - 2018-10-26 15:06:39 --> Loader Class Initialized
INFO - 2018-10-26 15:06:39 --> Helper loaded: url_helper
INFO - 2018-10-26 15:06:39 --> Helper loaded: form_helper
INFO - 2018-10-26 15:06:39 --> Helper loaded: html_helper
INFO - 2018-10-26 15:06:39 --> Database Driver Class Initialized
INFO - 2018-10-26 15:06:39 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:06:39 --> Model "User_model" initialized
INFO - 2018-10-26 15:06:39 --> Model "Project_model" initialized
INFO - 2018-10-26 15:06:39 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:06:39 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:06:39 --> Controller Class Initialized
INFO - 2018-10-26 15:06:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:06:39 --> Config Class Initialized
INFO - 2018-10-26 15:06:39 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:06:39 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:06:39 --> Utf8 Class Initialized
INFO - 2018-10-26 15:06:39 --> URI Class Initialized
INFO - 2018-10-26 15:06:39 --> Router Class Initialized
INFO - 2018-10-26 15:06:39 --> Output Class Initialized
INFO - 2018-10-26 15:06:39 --> Security Class Initialized
DEBUG - 2018-10-26 15:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:06:39 --> Input Class Initialized
INFO - 2018-10-26 15:06:39 --> Language Class Initialized
INFO - 2018-10-26 15:06:39 --> Loader Class Initialized
INFO - 2018-10-26 15:06:39 --> Helper loaded: url_helper
INFO - 2018-10-26 15:06:39 --> Helper loaded: form_helper
INFO - 2018-10-26 15:06:39 --> Helper loaded: html_helper
INFO - 2018-10-26 15:06:39 --> Database Driver Class Initialized
INFO - 2018-10-26 15:06:39 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:06:39 --> Model "User_model" initialized
INFO - 2018-10-26 15:06:39 --> Model "Project_model" initialized
INFO - 2018-10-26 15:06:39 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:06:39 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:06:39 --> Controller Class Initialized
INFO - 2018-10-26 15:06:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:06:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:06:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:06:39 --> Final output sent to browser
DEBUG - 2018-10-26 15:06:39 --> Total execution time: 0.0420
INFO - 2018-10-26 15:06:47 --> Config Class Initialized
INFO - 2018-10-26 15:06:47 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:06:47 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:06:47 --> Utf8 Class Initialized
INFO - 2018-10-26 15:06:47 --> URI Class Initialized
INFO - 2018-10-26 15:06:47 --> Router Class Initialized
INFO - 2018-10-26 15:06:47 --> Output Class Initialized
INFO - 2018-10-26 15:06:47 --> Security Class Initialized
DEBUG - 2018-10-26 15:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:06:47 --> Input Class Initialized
INFO - 2018-10-26 15:06:47 --> Language Class Initialized
INFO - 2018-10-26 15:06:47 --> Loader Class Initialized
INFO - 2018-10-26 15:06:47 --> Helper loaded: url_helper
INFO - 2018-10-26 15:06:47 --> Helper loaded: form_helper
INFO - 2018-10-26 15:06:47 --> Helper loaded: html_helper
INFO - 2018-10-26 15:06:47 --> Database Driver Class Initialized
INFO - 2018-10-26 15:06:47 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:06:47 --> Model "User_model" initialized
INFO - 2018-10-26 15:06:47 --> Model "Project_model" initialized
INFO - 2018-10-26 15:06:47 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:06:47 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:06:47 --> Controller Class Initialized
INFO - 2018-10-26 15:06:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:06:48 --> Config Class Initialized
INFO - 2018-10-26 15:06:48 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:06:48 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:06:48 --> Utf8 Class Initialized
INFO - 2018-10-26 15:06:48 --> URI Class Initialized
INFO - 2018-10-26 15:06:48 --> Router Class Initialized
INFO - 2018-10-26 15:06:48 --> Output Class Initialized
INFO - 2018-10-26 15:06:48 --> Security Class Initialized
DEBUG - 2018-10-26 15:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:06:48 --> Input Class Initialized
INFO - 2018-10-26 15:06:48 --> Language Class Initialized
INFO - 2018-10-26 15:06:48 --> Loader Class Initialized
INFO - 2018-10-26 15:06:48 --> Helper loaded: url_helper
INFO - 2018-10-26 15:06:48 --> Helper loaded: form_helper
INFO - 2018-10-26 15:06:48 --> Helper loaded: html_helper
INFO - 2018-10-26 15:06:48 --> Database Driver Class Initialized
INFO - 2018-10-26 15:06:48 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:06:48 --> Model "User_model" initialized
INFO - 2018-10-26 15:06:48 --> Model "Project_model" initialized
INFO - 2018-10-26 15:06:48 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:06:48 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:06:48 --> Controller Class Initialized
ERROR - 2018-10-26 15:06:48 --> Query error: Table 'users.projects' doesn't exist - Invalid query: SELECT *
FROM `projects`
JOIN `tasks` ON `projects`.`id` = `tasks`.`project_id`
WHERE `project_user_id` IS NULL
INFO - 2018-10-26 15:06:48 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-26 15:06:51 --> Config Class Initialized
INFO - 2018-10-26 15:06:51 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:06:51 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:06:51 --> Utf8 Class Initialized
INFO - 2018-10-26 15:06:51 --> URI Class Initialized
INFO - 2018-10-26 15:06:51 --> Router Class Initialized
INFO - 2018-10-26 15:06:51 --> Output Class Initialized
INFO - 2018-10-26 15:06:51 --> Security Class Initialized
DEBUG - 2018-10-26 15:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:06:51 --> Input Class Initialized
INFO - 2018-10-26 15:06:51 --> Language Class Initialized
INFO - 2018-10-26 15:06:51 --> Loader Class Initialized
INFO - 2018-10-26 15:06:51 --> Helper loaded: url_helper
INFO - 2018-10-26 15:06:51 --> Helper loaded: form_helper
INFO - 2018-10-26 15:06:51 --> Helper loaded: html_helper
INFO - 2018-10-26 15:06:51 --> Database Driver Class Initialized
INFO - 2018-10-26 15:06:51 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:06:51 --> Model "User_model" initialized
INFO - 2018-10-26 15:06:51 --> Model "Project_model" initialized
INFO - 2018-10-26 15:06:51 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:06:51 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:06:51 --> Controller Class Initialized
ERROR - 2018-10-26 15:06:51 --> Query error: Table 'users.projects' doesn't exist - Invalid query: SELECT *
FROM `projects`
JOIN `tasks` ON `projects`.`id` = `tasks`.`project_id`
WHERE `project_user_id` IS NULL
INFO - 2018-10-26 15:06:51 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-26 15:06:52 --> Config Class Initialized
INFO - 2018-10-26 15:06:52 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:06:52 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:06:52 --> Utf8 Class Initialized
INFO - 2018-10-26 15:06:52 --> URI Class Initialized
INFO - 2018-10-26 15:06:52 --> Router Class Initialized
INFO - 2018-10-26 15:06:52 --> Output Class Initialized
INFO - 2018-10-26 15:06:52 --> Security Class Initialized
DEBUG - 2018-10-26 15:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:06:52 --> Input Class Initialized
INFO - 2018-10-26 15:06:52 --> Language Class Initialized
INFO - 2018-10-26 15:06:52 --> Loader Class Initialized
INFO - 2018-10-26 15:06:52 --> Helper loaded: url_helper
INFO - 2018-10-26 15:06:52 --> Helper loaded: form_helper
INFO - 2018-10-26 15:06:52 --> Helper loaded: html_helper
INFO - 2018-10-26 15:06:52 --> Database Driver Class Initialized
INFO - 2018-10-26 15:06:52 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:06:52 --> Model "User_model" initialized
INFO - 2018-10-26 15:06:52 --> Model "Project_model" initialized
INFO - 2018-10-26 15:06:52 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:06:52 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:06:52 --> Controller Class Initialized
ERROR - 2018-10-26 15:06:52 --> Query error: Table 'users.projects' doesn't exist - Invalid query: SELECT *
FROM `projects`
JOIN `tasks` ON `projects`.`id` = `tasks`.`project_id`
WHERE `project_user_id` IS NULL
INFO - 2018-10-26 15:06:52 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-26 15:06:53 --> Config Class Initialized
INFO - 2018-10-26 15:06:53 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:06:53 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:06:53 --> Utf8 Class Initialized
INFO - 2018-10-26 15:06:53 --> URI Class Initialized
INFO - 2018-10-26 15:06:53 --> Router Class Initialized
INFO - 2018-10-26 15:06:53 --> Output Class Initialized
INFO - 2018-10-26 15:06:53 --> Security Class Initialized
DEBUG - 2018-10-26 15:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:06:53 --> Input Class Initialized
INFO - 2018-10-26 15:06:53 --> Language Class Initialized
INFO - 2018-10-26 15:06:53 --> Loader Class Initialized
INFO - 2018-10-26 15:06:53 --> Helper loaded: url_helper
INFO - 2018-10-26 15:06:53 --> Helper loaded: form_helper
INFO - 2018-10-26 15:06:53 --> Helper loaded: html_helper
INFO - 2018-10-26 15:06:53 --> Database Driver Class Initialized
INFO - 2018-10-26 15:06:53 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:06:53 --> Model "User_model" initialized
INFO - 2018-10-26 15:06:53 --> Model "Project_model" initialized
INFO - 2018-10-26 15:06:53 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:06:53 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:06:53 --> Controller Class Initialized
INFO - 2018-10-26 15:06:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:06:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:06:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:06:53 --> Final output sent to browser
DEBUG - 2018-10-26 15:06:53 --> Total execution time: 0.0540
INFO - 2018-10-26 15:06:55 --> Config Class Initialized
INFO - 2018-10-26 15:06:55 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:06:55 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:06:55 --> Utf8 Class Initialized
INFO - 2018-10-26 15:06:55 --> URI Class Initialized
INFO - 2018-10-26 15:06:55 --> Router Class Initialized
INFO - 2018-10-26 15:06:55 --> Output Class Initialized
INFO - 2018-10-26 15:06:55 --> Security Class Initialized
DEBUG - 2018-10-26 15:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:06:55 --> Input Class Initialized
INFO - 2018-10-26 15:06:55 --> Language Class Initialized
INFO - 2018-10-26 15:06:55 --> Loader Class Initialized
INFO - 2018-10-26 15:06:55 --> Helper loaded: url_helper
INFO - 2018-10-26 15:06:55 --> Helper loaded: form_helper
INFO - 2018-10-26 15:06:55 --> Helper loaded: html_helper
INFO - 2018-10-26 15:06:55 --> Database Driver Class Initialized
INFO - 2018-10-26 15:06:55 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:06:55 --> Model "User_model" initialized
INFO - 2018-10-26 15:06:55 --> Model "Project_model" initialized
INFO - 2018-10-26 15:06:55 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:06:55 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:06:55 --> Controller Class Initialized
ERROR - 2018-10-26 15:06:55 --> Query error: Table 'users.projects' doesn't exist - Invalid query: SELECT *
FROM `projects`
JOIN `tasks` ON `projects`.`id` = `tasks`.`project_id`
WHERE `project_user_id` IS NULL
INFO - 2018-10-26 15:06:55 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-26 15:06:58 --> Config Class Initialized
INFO - 2018-10-26 15:06:58 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:06:58 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:06:58 --> Utf8 Class Initialized
INFO - 2018-10-26 15:06:58 --> URI Class Initialized
INFO - 2018-10-26 15:06:58 --> Router Class Initialized
INFO - 2018-10-26 15:06:58 --> Output Class Initialized
INFO - 2018-10-26 15:06:58 --> Security Class Initialized
DEBUG - 2018-10-26 15:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:06:58 --> Input Class Initialized
INFO - 2018-10-26 15:06:58 --> Language Class Initialized
INFO - 2018-10-26 15:06:58 --> Loader Class Initialized
INFO - 2018-10-26 15:06:58 --> Helper loaded: url_helper
INFO - 2018-10-26 15:06:58 --> Helper loaded: form_helper
INFO - 2018-10-26 15:06:58 --> Helper loaded: html_helper
INFO - 2018-10-26 15:06:58 --> Database Driver Class Initialized
INFO - 2018-10-26 15:06:58 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:06:58 --> Model "User_model" initialized
INFO - 2018-10-26 15:06:58 --> Model "Project_model" initialized
INFO - 2018-10-26 15:06:58 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:06:58 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:06:58 --> Controller Class Initialized
INFO - 2018-10-26 15:06:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:06:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:06:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:06:58 --> Final output sent to browser
DEBUG - 2018-10-26 15:06:58 --> Total execution time: 0.0370
INFO - 2018-10-26 15:06:59 --> Config Class Initialized
INFO - 2018-10-26 15:06:59 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:06:59 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:06:59 --> Utf8 Class Initialized
INFO - 2018-10-26 15:06:59 --> URI Class Initialized
INFO - 2018-10-26 15:06:59 --> Router Class Initialized
INFO - 2018-10-26 15:06:59 --> Output Class Initialized
INFO - 2018-10-26 15:06:59 --> Security Class Initialized
DEBUG - 2018-10-26 15:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:06:59 --> Input Class Initialized
INFO - 2018-10-26 15:06:59 --> Language Class Initialized
INFO - 2018-10-26 15:06:59 --> Loader Class Initialized
INFO - 2018-10-26 15:06:59 --> Helper loaded: url_helper
INFO - 2018-10-26 15:06:59 --> Helper loaded: form_helper
INFO - 2018-10-26 15:06:59 --> Helper loaded: html_helper
INFO - 2018-10-26 15:06:59 --> Database Driver Class Initialized
INFO - 2018-10-26 15:06:59 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:06:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:06:59 --> Model "User_model" initialized
INFO - 2018-10-26 15:06:59 --> Model "Project_model" initialized
INFO - 2018-10-26 15:06:59 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:06:59 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:06:59 --> Controller Class Initialized
INFO - 2018-10-26 15:06:59 --> Config Class Initialized
INFO - 2018-10-26 15:06:59 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:06:59 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:06:59 --> Utf8 Class Initialized
INFO - 2018-10-26 15:06:59 --> URI Class Initialized
INFO - 2018-10-26 15:06:59 --> Router Class Initialized
INFO - 2018-10-26 15:06:59 --> Output Class Initialized
INFO - 2018-10-26 15:06:59 --> Security Class Initialized
DEBUG - 2018-10-26 15:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:06:59 --> Input Class Initialized
INFO - 2018-10-26 15:06:59 --> Language Class Initialized
INFO - 2018-10-26 15:06:59 --> Loader Class Initialized
INFO - 2018-10-26 15:06:59 --> Helper loaded: url_helper
INFO - 2018-10-26 15:06:59 --> Helper loaded: form_helper
INFO - 2018-10-26 15:06:59 --> Helper loaded: html_helper
INFO - 2018-10-26 15:06:59 --> Database Driver Class Initialized
INFO - 2018-10-26 15:06:59 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:06:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:06:59 --> Model "User_model" initialized
INFO - 2018-10-26 15:06:59 --> Model "Project_model" initialized
INFO - 2018-10-26 15:06:59 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:06:59 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:06:59 --> Controller Class Initialized
INFO - 2018-10-26 15:06:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:06:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:06:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:06:59 --> Final output sent to browser
DEBUG - 2018-10-26 15:06:59 --> Total execution time: 0.0330
INFO - 2018-10-26 15:07:08 --> Config Class Initialized
INFO - 2018-10-26 15:07:08 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:07:08 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:07:08 --> Utf8 Class Initialized
INFO - 2018-10-26 15:07:08 --> URI Class Initialized
INFO - 2018-10-26 15:07:08 --> Router Class Initialized
INFO - 2018-10-26 15:07:08 --> Output Class Initialized
INFO - 2018-10-26 15:07:08 --> Security Class Initialized
DEBUG - 2018-10-26 15:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:07:08 --> Input Class Initialized
INFO - 2018-10-26 15:07:08 --> Language Class Initialized
INFO - 2018-10-26 15:07:08 --> Loader Class Initialized
INFO - 2018-10-26 15:07:08 --> Helper loaded: url_helper
INFO - 2018-10-26 15:07:08 --> Helper loaded: form_helper
INFO - 2018-10-26 15:07:08 --> Helper loaded: html_helper
INFO - 2018-10-26 15:07:08 --> Database Driver Class Initialized
INFO - 2018-10-26 15:07:08 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:07:08 --> Model "User_model" initialized
INFO - 2018-10-26 15:07:08 --> Model "Project_model" initialized
INFO - 2018-10-26 15:07:08 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:07:08 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:07:08 --> Controller Class Initialized
INFO - 2018-10-26 15:07:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:07:09 --> Config Class Initialized
INFO - 2018-10-26 15:07:09 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:07:09 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:07:09 --> Utf8 Class Initialized
INFO - 2018-10-26 15:07:09 --> URI Class Initialized
INFO - 2018-10-26 15:07:09 --> Router Class Initialized
INFO - 2018-10-26 15:07:09 --> Output Class Initialized
INFO - 2018-10-26 15:07:09 --> Security Class Initialized
DEBUG - 2018-10-26 15:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:07:09 --> Input Class Initialized
INFO - 2018-10-26 15:07:09 --> Language Class Initialized
INFO - 2018-10-26 15:07:09 --> Loader Class Initialized
INFO - 2018-10-26 15:07:09 --> Helper loaded: url_helper
INFO - 2018-10-26 15:07:09 --> Helper loaded: form_helper
INFO - 2018-10-26 15:07:09 --> Helper loaded: html_helper
INFO - 2018-10-26 15:07:09 --> Database Driver Class Initialized
INFO - 2018-10-26 15:07:09 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:07:09 --> Model "User_model" initialized
INFO - 2018-10-26 15:07:09 --> Model "Project_model" initialized
INFO - 2018-10-26 15:07:09 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:07:09 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:07:09 --> Controller Class Initialized
ERROR - 2018-10-26 15:07:09 --> Query error: Table 'users.projects' doesn't exist - Invalid query: SELECT *
FROM `projects`
JOIN `tasks` ON `projects`.`id` = `tasks`.`project_id`
WHERE `project_user_id` IS NULL
INFO - 2018-10-26 15:07:09 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-26 15:07:12 --> Config Class Initialized
INFO - 2018-10-26 15:07:12 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:07:12 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:07:12 --> Utf8 Class Initialized
INFO - 2018-10-26 15:07:12 --> URI Class Initialized
INFO - 2018-10-26 15:07:12 --> Router Class Initialized
INFO - 2018-10-26 15:07:12 --> Output Class Initialized
INFO - 2018-10-26 15:07:12 --> Security Class Initialized
DEBUG - 2018-10-26 15:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:07:12 --> Input Class Initialized
INFO - 2018-10-26 15:07:12 --> Language Class Initialized
INFO - 2018-10-26 15:07:12 --> Loader Class Initialized
INFO - 2018-10-26 15:07:12 --> Helper loaded: url_helper
INFO - 2018-10-26 15:07:12 --> Helper loaded: form_helper
INFO - 2018-10-26 15:07:12 --> Helper loaded: html_helper
INFO - 2018-10-26 15:07:12 --> Database Driver Class Initialized
INFO - 2018-10-26 15:07:12 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:07:12 --> Model "User_model" initialized
INFO - 2018-10-26 15:07:12 --> Model "Project_model" initialized
INFO - 2018-10-26 15:07:12 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:07:12 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:07:12 --> Controller Class Initialized
ERROR - 2018-10-26 15:07:12 --> Query error: Table 'users.projects' doesn't exist - Invalid query: SELECT *
FROM `projects`
JOIN `tasks` ON `projects`.`id` = `tasks`.`project_id`
WHERE `project_user_id` IS NULL
INFO - 2018-10-26 15:07:12 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-26 15:07:14 --> Config Class Initialized
INFO - 2018-10-26 15:07:14 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:07:14 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:07:14 --> Utf8 Class Initialized
INFO - 2018-10-26 15:07:14 --> URI Class Initialized
INFO - 2018-10-26 15:07:14 --> Router Class Initialized
INFO - 2018-10-26 15:07:14 --> Output Class Initialized
INFO - 2018-10-26 15:07:14 --> Security Class Initialized
DEBUG - 2018-10-26 15:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:07:14 --> Input Class Initialized
INFO - 2018-10-26 15:07:14 --> Language Class Initialized
INFO - 2018-10-26 15:07:14 --> Loader Class Initialized
INFO - 2018-10-26 15:07:14 --> Helper loaded: url_helper
INFO - 2018-10-26 15:07:14 --> Helper loaded: form_helper
INFO - 2018-10-26 15:07:14 --> Helper loaded: html_helper
INFO - 2018-10-26 15:07:14 --> Database Driver Class Initialized
INFO - 2018-10-26 15:07:14 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:07:14 --> Model "User_model" initialized
INFO - 2018-10-26 15:07:14 --> Model "Project_model" initialized
INFO - 2018-10-26 15:07:14 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:07:14 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:07:14 --> Controller Class Initialized
INFO - 2018-10-26 15:07:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:07:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:07:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:07:14 --> Final output sent to browser
DEBUG - 2018-10-26 15:07:14 --> Total execution time: 0.0510
INFO - 2018-10-26 15:08:22 --> Config Class Initialized
INFO - 2018-10-26 15:08:22 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:08:22 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:08:22 --> Utf8 Class Initialized
INFO - 2018-10-26 15:08:22 --> URI Class Initialized
INFO - 2018-10-26 15:08:22 --> Router Class Initialized
INFO - 2018-10-26 15:08:22 --> Output Class Initialized
INFO - 2018-10-26 15:08:22 --> Security Class Initialized
DEBUG - 2018-10-26 15:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:08:22 --> Input Class Initialized
INFO - 2018-10-26 15:08:22 --> Language Class Initialized
INFO - 2018-10-26 15:08:22 --> Loader Class Initialized
INFO - 2018-10-26 15:08:22 --> Helper loaded: url_helper
INFO - 2018-10-26 15:08:22 --> Helper loaded: form_helper
INFO - 2018-10-26 15:08:22 --> Helper loaded: html_helper
INFO - 2018-10-26 15:08:22 --> Database Driver Class Initialized
INFO - 2018-10-26 15:08:22 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:08:22 --> Model "User_model" initialized
INFO - 2018-10-26 15:08:22 --> Model "Project_model" initialized
INFO - 2018-10-26 15:08:22 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:08:22 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:08:22 --> Controller Class Initialized
INFO - 2018-10-26 15:08:22 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:08:22 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:08:22 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:08:22 --> Final output sent to browser
DEBUG - 2018-10-26 15:08:22 --> Total execution time: 0.0530
INFO - 2018-10-26 15:12:22 --> Config Class Initialized
INFO - 2018-10-26 15:12:22 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:12:22 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:12:22 --> Utf8 Class Initialized
INFO - 2018-10-26 15:12:22 --> URI Class Initialized
INFO - 2018-10-26 15:12:22 --> Router Class Initialized
INFO - 2018-10-26 15:12:22 --> Output Class Initialized
INFO - 2018-10-26 15:12:22 --> Security Class Initialized
DEBUG - 2018-10-26 15:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:12:22 --> Input Class Initialized
INFO - 2018-10-26 15:12:22 --> Language Class Initialized
INFO - 2018-10-26 15:12:22 --> Loader Class Initialized
INFO - 2018-10-26 15:12:22 --> Helper loaded: url_helper
INFO - 2018-10-26 15:12:22 --> Helper loaded: form_helper
INFO - 2018-10-26 15:12:22 --> Helper loaded: html_helper
INFO - 2018-10-26 15:12:22 --> Database Driver Class Initialized
INFO - 2018-10-26 15:12:22 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:12:22 --> Model "User_model" initialized
INFO - 2018-10-26 15:12:22 --> Model "Project_model" initialized
INFO - 2018-10-26 15:12:22 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:12:22 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:12:22 --> Controller Class Initialized
INFO - 2018-10-26 15:12:22 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:12:22 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:12:22 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:12:22 --> Final output sent to browser
DEBUG - 2018-10-26 15:12:22 --> Total execution time: 0.0530
INFO - 2018-10-26 15:12:26 --> Config Class Initialized
INFO - 2018-10-26 15:12:26 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:12:26 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:12:26 --> Utf8 Class Initialized
INFO - 2018-10-26 15:12:26 --> URI Class Initialized
INFO - 2018-10-26 15:12:26 --> Router Class Initialized
INFO - 2018-10-26 15:12:26 --> Output Class Initialized
INFO - 2018-10-26 15:12:26 --> Security Class Initialized
DEBUG - 2018-10-26 15:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:12:26 --> Input Class Initialized
INFO - 2018-10-26 15:12:26 --> Language Class Initialized
INFO - 2018-10-26 15:12:26 --> Loader Class Initialized
INFO - 2018-10-26 15:12:26 --> Helper loaded: url_helper
INFO - 2018-10-26 15:12:26 --> Helper loaded: form_helper
INFO - 2018-10-26 15:12:26 --> Helper loaded: html_helper
INFO - 2018-10-26 15:12:26 --> Database Driver Class Initialized
INFO - 2018-10-26 15:12:26 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:12:26 --> Model "User_model" initialized
INFO - 2018-10-26 15:12:26 --> Model "Project_model" initialized
INFO - 2018-10-26 15:12:26 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:12:26 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:12:26 --> Controller Class Initialized
INFO - 2018-10-26 15:12:26 --> Config Class Initialized
INFO - 2018-10-26 15:12:26 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:12:26 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:12:26 --> Utf8 Class Initialized
INFO - 2018-10-26 15:12:26 --> URI Class Initialized
INFO - 2018-10-26 15:12:26 --> Router Class Initialized
INFO - 2018-10-26 15:12:26 --> Output Class Initialized
INFO - 2018-10-26 15:12:26 --> Security Class Initialized
DEBUG - 2018-10-26 15:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:12:26 --> Input Class Initialized
INFO - 2018-10-26 15:12:26 --> Language Class Initialized
INFO - 2018-10-26 15:12:26 --> Loader Class Initialized
INFO - 2018-10-26 15:12:26 --> Helper loaded: url_helper
INFO - 2018-10-26 15:12:26 --> Helper loaded: form_helper
INFO - 2018-10-26 15:12:26 --> Helper loaded: html_helper
INFO - 2018-10-26 15:12:26 --> Database Driver Class Initialized
INFO - 2018-10-26 15:12:26 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:12:26 --> Model "User_model" initialized
INFO - 2018-10-26 15:12:26 --> Model "Project_model" initialized
INFO - 2018-10-26 15:12:26 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:12:26 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:12:26 --> Controller Class Initialized
INFO - 2018-10-26 15:12:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:12:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:12:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:12:26 --> Final output sent to browser
DEBUG - 2018-10-26 15:12:26 --> Total execution time: 0.0440
INFO - 2018-10-26 15:12:29 --> Config Class Initialized
INFO - 2018-10-26 15:12:29 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:12:29 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:12:29 --> Utf8 Class Initialized
INFO - 2018-10-26 15:12:29 --> URI Class Initialized
INFO - 2018-10-26 15:12:29 --> Router Class Initialized
INFO - 2018-10-26 15:12:29 --> Output Class Initialized
INFO - 2018-10-26 15:12:29 --> Security Class Initialized
DEBUG - 2018-10-26 15:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:12:29 --> Input Class Initialized
INFO - 2018-10-26 15:12:29 --> Language Class Initialized
INFO - 2018-10-26 15:12:29 --> Loader Class Initialized
INFO - 2018-10-26 15:12:29 --> Helper loaded: url_helper
INFO - 2018-10-26 15:12:29 --> Helper loaded: form_helper
INFO - 2018-10-26 15:12:29 --> Helper loaded: html_helper
INFO - 2018-10-26 15:12:29 --> Database Driver Class Initialized
INFO - 2018-10-26 15:12:29 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:12:29 --> Model "User_model" initialized
INFO - 2018-10-26 15:12:29 --> Model "Project_model" initialized
INFO - 2018-10-26 15:12:29 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:12:29 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:12:29 --> Controller Class Initialized
INFO - 2018-10-26 15:12:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:12:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:12:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:12:29 --> Final output sent to browser
DEBUG - 2018-10-26 15:12:29 --> Total execution time: 0.0400
INFO - 2018-10-26 15:12:30 --> Config Class Initialized
INFO - 2018-10-26 15:12:30 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:12:30 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:12:30 --> Utf8 Class Initialized
INFO - 2018-10-26 15:12:30 --> URI Class Initialized
INFO - 2018-10-26 15:12:30 --> Router Class Initialized
INFO - 2018-10-26 15:12:30 --> Output Class Initialized
INFO - 2018-10-26 15:12:30 --> Security Class Initialized
DEBUG - 2018-10-26 15:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:12:30 --> Input Class Initialized
INFO - 2018-10-26 15:12:30 --> Language Class Initialized
INFO - 2018-10-26 15:12:30 --> Loader Class Initialized
INFO - 2018-10-26 15:12:30 --> Helper loaded: url_helper
INFO - 2018-10-26 15:12:30 --> Helper loaded: form_helper
INFO - 2018-10-26 15:12:30 --> Helper loaded: html_helper
INFO - 2018-10-26 15:12:30 --> Database Driver Class Initialized
INFO - 2018-10-26 15:12:30 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:12:30 --> Model "User_model" initialized
INFO - 2018-10-26 15:12:30 --> Model "Project_model" initialized
INFO - 2018-10-26 15:12:30 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:12:30 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:12:30 --> Controller Class Initialized
INFO - 2018-10-26 15:12:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:12:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:12:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:12:30 --> Final output sent to browser
DEBUG - 2018-10-26 15:12:30 --> Total execution time: 0.0510
INFO - 2018-10-26 15:12:38 --> Config Class Initialized
INFO - 2018-10-26 15:12:38 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:12:38 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:12:38 --> Utf8 Class Initialized
INFO - 2018-10-26 15:12:38 --> URI Class Initialized
INFO - 2018-10-26 15:12:38 --> Router Class Initialized
INFO - 2018-10-26 15:12:38 --> Output Class Initialized
INFO - 2018-10-26 15:12:38 --> Security Class Initialized
DEBUG - 2018-10-26 15:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:12:38 --> Input Class Initialized
INFO - 2018-10-26 15:12:38 --> Language Class Initialized
INFO - 2018-10-26 15:12:38 --> Loader Class Initialized
INFO - 2018-10-26 15:12:38 --> Helper loaded: url_helper
INFO - 2018-10-26 15:12:38 --> Helper loaded: form_helper
INFO - 2018-10-26 15:12:38 --> Helper loaded: html_helper
INFO - 2018-10-26 15:12:38 --> Database Driver Class Initialized
INFO - 2018-10-26 15:12:38 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:12:38 --> Model "User_model" initialized
INFO - 2018-10-26 15:12:38 --> Model "Project_model" initialized
INFO - 2018-10-26 15:12:38 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:12:38 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:12:38 --> Controller Class Initialized
INFO - 2018-10-26 15:12:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:12:38 --> Config Class Initialized
INFO - 2018-10-26 15:12:38 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:12:38 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:12:38 --> Utf8 Class Initialized
INFO - 2018-10-26 15:12:38 --> URI Class Initialized
INFO - 2018-10-26 15:12:38 --> Router Class Initialized
INFO - 2018-10-26 15:12:38 --> Output Class Initialized
INFO - 2018-10-26 15:12:38 --> Security Class Initialized
DEBUG - 2018-10-26 15:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:12:38 --> Input Class Initialized
INFO - 2018-10-26 15:12:38 --> Language Class Initialized
INFO - 2018-10-26 15:12:38 --> Loader Class Initialized
INFO - 2018-10-26 15:12:38 --> Helper loaded: url_helper
INFO - 2018-10-26 15:12:38 --> Helper loaded: form_helper
INFO - 2018-10-26 15:12:38 --> Helper loaded: html_helper
INFO - 2018-10-26 15:12:38 --> Database Driver Class Initialized
INFO - 2018-10-26 15:12:38 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:12:38 --> Model "User_model" initialized
INFO - 2018-10-26 15:12:38 --> Model "Project_model" initialized
INFO - 2018-10-26 15:12:38 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:12:38 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:12:38 --> Controller Class Initialized
ERROR - 2018-10-26 15:12:38 --> Query error: Table 'users.projects' doesn't exist - Invalid query: SELECT *
FROM `projects`
JOIN `tasks` ON `projects`.`id` = `tasks`.`project_id`
WHERE `project_user_id` IS NULL
INFO - 2018-10-26 15:12:38 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-26 15:12:40 --> Config Class Initialized
INFO - 2018-10-26 15:12:40 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:12:40 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:12:40 --> Utf8 Class Initialized
INFO - 2018-10-26 15:12:40 --> URI Class Initialized
INFO - 2018-10-26 15:12:40 --> Router Class Initialized
INFO - 2018-10-26 15:12:40 --> Output Class Initialized
INFO - 2018-10-26 15:12:40 --> Security Class Initialized
DEBUG - 2018-10-26 15:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:12:40 --> Input Class Initialized
INFO - 2018-10-26 15:12:40 --> Language Class Initialized
INFO - 2018-10-26 15:12:40 --> Loader Class Initialized
INFO - 2018-10-26 15:12:40 --> Helper loaded: url_helper
INFO - 2018-10-26 15:12:40 --> Helper loaded: form_helper
INFO - 2018-10-26 15:12:40 --> Helper loaded: html_helper
INFO - 2018-10-26 15:12:40 --> Database Driver Class Initialized
INFO - 2018-10-26 15:12:40 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:12:40 --> Model "User_model" initialized
INFO - 2018-10-26 15:12:40 --> Model "Project_model" initialized
INFO - 2018-10-26 15:12:40 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:12:40 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:12:40 --> Controller Class Initialized
ERROR - 2018-10-26 15:12:40 --> Query error: Table 'users.projects' doesn't exist - Invalid query: SELECT *
FROM `projects`
JOIN `tasks` ON `projects`.`id` = `tasks`.`project_id`
WHERE `project_user_id` IS NULL
INFO - 2018-10-26 15:12:40 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-26 15:12:41 --> Config Class Initialized
INFO - 2018-10-26 15:12:41 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:12:41 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:12:41 --> Utf8 Class Initialized
INFO - 2018-10-26 15:12:41 --> URI Class Initialized
INFO - 2018-10-26 15:12:41 --> Router Class Initialized
INFO - 2018-10-26 15:12:41 --> Output Class Initialized
INFO - 2018-10-26 15:12:41 --> Security Class Initialized
DEBUG - 2018-10-26 15:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:12:41 --> Input Class Initialized
INFO - 2018-10-26 15:12:41 --> Language Class Initialized
INFO - 2018-10-26 15:12:41 --> Loader Class Initialized
INFO - 2018-10-26 15:12:41 --> Helper loaded: url_helper
INFO - 2018-10-26 15:12:41 --> Helper loaded: form_helper
INFO - 2018-10-26 15:12:41 --> Helper loaded: html_helper
INFO - 2018-10-26 15:12:41 --> Database Driver Class Initialized
INFO - 2018-10-26 15:12:41 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:12:41 --> Model "User_model" initialized
INFO - 2018-10-26 15:12:41 --> Model "Project_model" initialized
INFO - 2018-10-26 15:12:41 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:12:41 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:12:41 --> Controller Class Initialized
INFO - 2018-10-26 15:12:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:12:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:12:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:12:41 --> Final output sent to browser
DEBUG - 2018-10-26 15:12:41 --> Total execution time: 0.0460
INFO - 2018-10-26 15:13:13 --> Config Class Initialized
INFO - 2018-10-26 15:13:13 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:13:13 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:13:13 --> Utf8 Class Initialized
INFO - 2018-10-26 15:13:13 --> URI Class Initialized
INFO - 2018-10-26 15:13:13 --> Router Class Initialized
INFO - 2018-10-26 15:13:13 --> Output Class Initialized
INFO - 2018-10-26 15:13:13 --> Security Class Initialized
DEBUG - 2018-10-26 15:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:13:13 --> Input Class Initialized
INFO - 2018-10-26 15:13:13 --> Language Class Initialized
INFO - 2018-10-26 15:13:13 --> Loader Class Initialized
INFO - 2018-10-26 15:13:13 --> Helper loaded: url_helper
INFO - 2018-10-26 15:13:13 --> Helper loaded: form_helper
INFO - 2018-10-26 15:13:13 --> Helper loaded: html_helper
INFO - 2018-10-26 15:13:13 --> Database Driver Class Initialized
INFO - 2018-10-26 15:13:13 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:13:13 --> Model "User_model" initialized
INFO - 2018-10-26 15:13:13 --> Model "Project_model" initialized
INFO - 2018-10-26 15:13:13 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:13:13 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:13:13 --> Controller Class Initialized
ERROR - 2018-10-26 15:13:13 --> Query error: Table 'users.projects' doesn't exist - Invalid query: SELECT *
FROM `projects`
JOIN `tasks` ON `projects`.`id` = `tasks`.`project_id`
WHERE `project_user_id` IS NULL
INFO - 2018-10-26 15:13:13 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-26 15:13:14 --> Config Class Initialized
INFO - 2018-10-26 15:13:14 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:13:14 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:13:14 --> Utf8 Class Initialized
INFO - 2018-10-26 15:13:14 --> URI Class Initialized
INFO - 2018-10-26 15:13:14 --> Router Class Initialized
INFO - 2018-10-26 15:13:14 --> Output Class Initialized
INFO - 2018-10-26 15:13:14 --> Security Class Initialized
DEBUG - 2018-10-26 15:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:13:14 --> Input Class Initialized
INFO - 2018-10-26 15:13:14 --> Language Class Initialized
INFO - 2018-10-26 15:13:14 --> Loader Class Initialized
INFO - 2018-10-26 15:13:14 --> Helper loaded: url_helper
INFO - 2018-10-26 15:13:14 --> Helper loaded: form_helper
INFO - 2018-10-26 15:13:14 --> Helper loaded: html_helper
INFO - 2018-10-26 15:13:14 --> Database Driver Class Initialized
INFO - 2018-10-26 15:13:14 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:13:14 --> Model "User_model" initialized
INFO - 2018-10-26 15:13:14 --> Model "Project_model" initialized
INFO - 2018-10-26 15:13:14 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:13:14 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:13:14 --> Controller Class Initialized
INFO - 2018-10-26 15:13:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:13:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:13:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:13:14 --> Final output sent to browser
DEBUG - 2018-10-26 15:13:14 --> Total execution time: 0.0620
INFO - 2018-10-26 15:13:34 --> Config Class Initialized
INFO - 2018-10-26 15:13:34 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:13:34 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:13:34 --> Utf8 Class Initialized
INFO - 2018-10-26 15:13:34 --> URI Class Initialized
INFO - 2018-10-26 15:13:34 --> Router Class Initialized
INFO - 2018-10-26 15:13:34 --> Output Class Initialized
INFO - 2018-10-26 15:13:34 --> Security Class Initialized
DEBUG - 2018-10-26 15:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:13:34 --> Input Class Initialized
INFO - 2018-10-26 15:13:34 --> Language Class Initialized
INFO - 2018-10-26 15:13:34 --> Loader Class Initialized
INFO - 2018-10-26 15:13:34 --> Helper loaded: url_helper
INFO - 2018-10-26 15:13:34 --> Helper loaded: form_helper
INFO - 2018-10-26 15:13:34 --> Helper loaded: html_helper
INFO - 2018-10-26 15:13:34 --> Database Driver Class Initialized
INFO - 2018-10-26 15:13:35 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:13:35 --> Model "User_model" initialized
INFO - 2018-10-26 15:13:35 --> Model "Project_model" initialized
INFO - 2018-10-26 15:13:35 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:13:35 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:13:35 --> Controller Class Initialized
ERROR - 2018-10-26 15:13:35 --> Query error: Table 'users.projects' doesn't exist - Invalid query: SELECT *
FROM `projects`
JOIN `tasks` ON `projects`.`id` = `tasks`.`project_id`
WHERE `project_user_id` IS NULL
INFO - 2018-10-26 15:13:35 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-26 15:13:35 --> Config Class Initialized
INFO - 2018-10-26 15:13:35 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:13:35 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:13:35 --> Utf8 Class Initialized
INFO - 2018-10-26 15:13:35 --> URI Class Initialized
INFO - 2018-10-26 15:13:35 --> Router Class Initialized
INFO - 2018-10-26 15:13:35 --> Output Class Initialized
INFO - 2018-10-26 15:13:35 --> Security Class Initialized
DEBUG - 2018-10-26 15:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:13:35 --> Input Class Initialized
INFO - 2018-10-26 15:13:35 --> Language Class Initialized
INFO - 2018-10-26 15:13:35 --> Loader Class Initialized
INFO - 2018-10-26 15:13:35 --> Helper loaded: url_helper
INFO - 2018-10-26 15:13:35 --> Helper loaded: form_helper
INFO - 2018-10-26 15:13:35 --> Helper loaded: html_helper
INFO - 2018-10-26 15:13:35 --> Database Driver Class Initialized
INFO - 2018-10-26 15:13:35 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:13:35 --> Model "User_model" initialized
INFO - 2018-10-26 15:13:35 --> Model "Project_model" initialized
INFO - 2018-10-26 15:13:35 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:13:35 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:13:35 --> Controller Class Initialized
INFO - 2018-10-26 15:13:35 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:13:35 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:13:35 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:13:35 --> Final output sent to browser
DEBUG - 2018-10-26 15:13:35 --> Total execution time: 0.0520
INFO - 2018-10-26 15:13:42 --> Config Class Initialized
INFO - 2018-10-26 15:13:42 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:13:42 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:13:42 --> Utf8 Class Initialized
INFO - 2018-10-26 15:13:42 --> URI Class Initialized
INFO - 2018-10-26 15:13:42 --> Router Class Initialized
INFO - 2018-10-26 15:13:42 --> Output Class Initialized
INFO - 2018-10-26 15:13:42 --> Security Class Initialized
DEBUG - 2018-10-26 15:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:13:42 --> Input Class Initialized
INFO - 2018-10-26 15:13:42 --> Language Class Initialized
INFO - 2018-10-26 15:13:42 --> Loader Class Initialized
INFO - 2018-10-26 15:13:42 --> Helper loaded: url_helper
INFO - 2018-10-26 15:13:42 --> Helper loaded: form_helper
INFO - 2018-10-26 15:13:42 --> Helper loaded: html_helper
INFO - 2018-10-26 15:13:42 --> Database Driver Class Initialized
INFO - 2018-10-26 15:13:42 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:13:42 --> Model "User_model" initialized
INFO - 2018-10-26 15:13:42 --> Model "Project_model" initialized
INFO - 2018-10-26 15:13:42 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:13:42 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:13:42 --> Controller Class Initialized
ERROR - 2018-10-26 15:13:42 --> Query error: Table 'users.projects' doesn't exist - Invalid query: SELECT *
FROM `projects`
JOIN `tasks` ON `projects`.`id` = `tasks`.`project_id`
WHERE `project_user_id` IS NULL
INFO - 2018-10-26 15:13:42 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-26 15:13:44 --> Config Class Initialized
INFO - 2018-10-26 15:13:44 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:13:44 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:13:44 --> Utf8 Class Initialized
INFO - 2018-10-26 15:13:44 --> URI Class Initialized
INFO - 2018-10-26 15:13:44 --> Router Class Initialized
INFO - 2018-10-26 15:13:44 --> Output Class Initialized
INFO - 2018-10-26 15:13:44 --> Security Class Initialized
DEBUG - 2018-10-26 15:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:13:44 --> Input Class Initialized
INFO - 2018-10-26 15:13:44 --> Language Class Initialized
INFO - 2018-10-26 15:13:44 --> Loader Class Initialized
INFO - 2018-10-26 15:13:44 --> Helper loaded: url_helper
INFO - 2018-10-26 15:13:44 --> Helper loaded: form_helper
INFO - 2018-10-26 15:13:44 --> Helper loaded: html_helper
INFO - 2018-10-26 15:13:44 --> Database Driver Class Initialized
INFO - 2018-10-26 15:13:44 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:13:44 --> Model "User_model" initialized
INFO - 2018-10-26 15:13:44 --> Model "Project_model" initialized
INFO - 2018-10-26 15:13:44 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:13:44 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:13:44 --> Controller Class Initialized
INFO - 2018-10-26 15:13:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:13:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:13:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:13:44 --> Final output sent to browser
DEBUG - 2018-10-26 15:13:44 --> Total execution time: 0.0430
INFO - 2018-10-26 15:13:45 --> Config Class Initialized
INFO - 2018-10-26 15:13:45 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:13:45 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:13:45 --> Utf8 Class Initialized
INFO - 2018-10-26 15:13:45 --> URI Class Initialized
INFO - 2018-10-26 15:13:45 --> Router Class Initialized
INFO - 2018-10-26 15:13:45 --> Output Class Initialized
INFO - 2018-10-26 15:13:45 --> Security Class Initialized
DEBUG - 2018-10-26 15:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:13:45 --> Input Class Initialized
INFO - 2018-10-26 15:13:45 --> Language Class Initialized
INFO - 2018-10-26 15:13:45 --> Loader Class Initialized
INFO - 2018-10-26 15:13:45 --> Helper loaded: url_helper
INFO - 2018-10-26 15:13:45 --> Helper loaded: form_helper
INFO - 2018-10-26 15:13:45 --> Helper loaded: html_helper
INFO - 2018-10-26 15:13:45 --> Database Driver Class Initialized
INFO - 2018-10-26 15:13:45 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:13:45 --> Model "User_model" initialized
INFO - 2018-10-26 15:13:45 --> Model "Project_model" initialized
INFO - 2018-10-26 15:13:45 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:13:45 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:13:45 --> Controller Class Initialized
ERROR - 2018-10-26 15:13:45 --> Query error: Table 'users.projects' doesn't exist - Invalid query: SELECT *
FROM `projects`
JOIN `tasks` ON `projects`.`id` = `tasks`.`project_id`
WHERE `project_user_id` IS NULL
INFO - 2018-10-26 15:13:45 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-26 15:13:47 --> Config Class Initialized
INFO - 2018-10-26 15:13:47 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:13:47 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:13:47 --> Utf8 Class Initialized
INFO - 2018-10-26 15:13:47 --> URI Class Initialized
INFO - 2018-10-26 15:13:47 --> Router Class Initialized
INFO - 2018-10-26 15:13:47 --> Output Class Initialized
INFO - 2018-10-26 15:13:47 --> Security Class Initialized
DEBUG - 2018-10-26 15:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:13:47 --> Input Class Initialized
INFO - 2018-10-26 15:13:47 --> Language Class Initialized
INFO - 2018-10-26 15:13:47 --> Loader Class Initialized
INFO - 2018-10-26 15:13:47 --> Helper loaded: url_helper
INFO - 2018-10-26 15:13:47 --> Helper loaded: form_helper
INFO - 2018-10-26 15:13:47 --> Helper loaded: html_helper
INFO - 2018-10-26 15:13:47 --> Database Driver Class Initialized
INFO - 2018-10-26 15:13:47 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:13:47 --> Model "User_model" initialized
INFO - 2018-10-26 15:13:47 --> Model "Project_model" initialized
INFO - 2018-10-26 15:13:47 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:13:47 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:13:47 --> Controller Class Initialized
INFO - 2018-10-26 15:13:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:13:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:13:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:13:47 --> Final output sent to browser
DEBUG - 2018-10-26 15:13:47 --> Total execution time: 0.0390
INFO - 2018-10-26 15:13:47 --> Config Class Initialized
INFO - 2018-10-26 15:13:47 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:13:47 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:13:47 --> Utf8 Class Initialized
INFO - 2018-10-26 15:13:47 --> URI Class Initialized
INFO - 2018-10-26 15:13:47 --> Router Class Initialized
INFO - 2018-10-26 15:13:47 --> Output Class Initialized
INFO - 2018-10-26 15:13:47 --> Security Class Initialized
DEBUG - 2018-10-26 15:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:13:47 --> Input Class Initialized
INFO - 2018-10-26 15:13:47 --> Language Class Initialized
INFO - 2018-10-26 15:13:47 --> Loader Class Initialized
INFO - 2018-10-26 15:13:47 --> Helper loaded: url_helper
INFO - 2018-10-26 15:13:47 --> Helper loaded: form_helper
INFO - 2018-10-26 15:13:47 --> Helper loaded: html_helper
INFO - 2018-10-26 15:13:47 --> Database Driver Class Initialized
INFO - 2018-10-26 15:13:47 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:13:47 --> Model "User_model" initialized
INFO - 2018-10-26 15:13:47 --> Model "Project_model" initialized
INFO - 2018-10-26 15:13:47 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:13:47 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:13:47 --> Controller Class Initialized
ERROR - 2018-10-26 15:13:47 --> Query error: Table 'users.projects' doesn't exist - Invalid query: SELECT *
FROM `projects`
JOIN `tasks` ON `projects`.`id` = `tasks`.`project_id`
WHERE `project_user_id` IS NULL
INFO - 2018-10-26 15:13:47 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-26 15:13:48 --> Config Class Initialized
INFO - 2018-10-26 15:13:48 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:13:48 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:13:48 --> Utf8 Class Initialized
INFO - 2018-10-26 15:13:48 --> URI Class Initialized
INFO - 2018-10-26 15:13:48 --> Router Class Initialized
INFO - 2018-10-26 15:13:48 --> Output Class Initialized
INFO - 2018-10-26 15:13:48 --> Security Class Initialized
DEBUG - 2018-10-26 15:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:13:48 --> Input Class Initialized
INFO - 2018-10-26 15:13:48 --> Language Class Initialized
INFO - 2018-10-26 15:13:48 --> Loader Class Initialized
INFO - 2018-10-26 15:13:48 --> Helper loaded: url_helper
INFO - 2018-10-26 15:13:48 --> Helper loaded: form_helper
INFO - 2018-10-26 15:13:48 --> Helper loaded: html_helper
INFO - 2018-10-26 15:13:48 --> Database Driver Class Initialized
INFO - 2018-10-26 15:13:48 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:13:48 --> Model "User_model" initialized
INFO - 2018-10-26 15:13:48 --> Model "Project_model" initialized
INFO - 2018-10-26 15:13:48 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:13:48 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:13:48 --> Controller Class Initialized
INFO - 2018-10-26 15:13:48 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:13:48 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:13:48 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:13:48 --> Final output sent to browser
DEBUG - 2018-10-26 15:13:48 --> Total execution time: 0.0470
INFO - 2018-10-26 15:15:23 --> Config Class Initialized
INFO - 2018-10-26 15:15:23 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:15:23 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:15:23 --> Utf8 Class Initialized
INFO - 2018-10-26 15:15:23 --> URI Class Initialized
INFO - 2018-10-26 15:15:23 --> Router Class Initialized
INFO - 2018-10-26 15:15:23 --> Output Class Initialized
INFO - 2018-10-26 15:15:23 --> Security Class Initialized
DEBUG - 2018-10-26 15:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:15:23 --> Input Class Initialized
INFO - 2018-10-26 15:15:23 --> Language Class Initialized
INFO - 2018-10-26 15:15:23 --> Loader Class Initialized
INFO - 2018-10-26 15:15:23 --> Helper loaded: url_helper
INFO - 2018-10-26 15:15:23 --> Helper loaded: form_helper
INFO - 2018-10-26 15:15:23 --> Helper loaded: html_helper
INFO - 2018-10-26 15:15:23 --> Database Driver Class Initialized
INFO - 2018-10-26 15:15:23 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:15:23 --> Model "User_model" initialized
INFO - 2018-10-26 15:15:23 --> Model "Project_model" initialized
INFO - 2018-10-26 15:15:23 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:15:23 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:15:23 --> Controller Class Initialized
INFO - 2018-10-26 15:15:23 --> Config Class Initialized
INFO - 2018-10-26 15:15:23 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:15:23 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:15:23 --> Utf8 Class Initialized
INFO - 2018-10-26 15:15:23 --> URI Class Initialized
INFO - 2018-10-26 15:15:23 --> Router Class Initialized
INFO - 2018-10-26 15:15:23 --> Output Class Initialized
INFO - 2018-10-26 15:15:23 --> Security Class Initialized
DEBUG - 2018-10-26 15:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:15:23 --> Input Class Initialized
INFO - 2018-10-26 15:15:23 --> Language Class Initialized
INFO - 2018-10-26 15:15:23 --> Loader Class Initialized
INFO - 2018-10-26 15:15:23 --> Helper loaded: url_helper
INFO - 2018-10-26 15:15:23 --> Helper loaded: form_helper
INFO - 2018-10-26 15:15:23 --> Helper loaded: html_helper
INFO - 2018-10-26 15:15:23 --> Database Driver Class Initialized
INFO - 2018-10-26 15:15:23 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:15:23 --> Model "User_model" initialized
INFO - 2018-10-26 15:15:23 --> Model "Project_model" initialized
INFO - 2018-10-26 15:15:23 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:15:23 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:15:23 --> Controller Class Initialized
INFO - 2018-10-26 15:15:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:15:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:15:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:15:23 --> Final output sent to browser
DEBUG - 2018-10-26 15:15:23 --> Total execution time: 0.0420
INFO - 2018-10-26 15:15:27 --> Config Class Initialized
INFO - 2018-10-26 15:15:27 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:15:27 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:15:27 --> Utf8 Class Initialized
INFO - 2018-10-26 15:15:27 --> URI Class Initialized
INFO - 2018-10-26 15:15:27 --> Router Class Initialized
INFO - 2018-10-26 15:15:27 --> Output Class Initialized
INFO - 2018-10-26 15:15:27 --> Security Class Initialized
DEBUG - 2018-10-26 15:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:15:27 --> Input Class Initialized
INFO - 2018-10-26 15:15:27 --> Language Class Initialized
INFO - 2018-10-26 15:15:27 --> Loader Class Initialized
INFO - 2018-10-26 15:15:27 --> Helper loaded: url_helper
INFO - 2018-10-26 15:15:27 --> Helper loaded: form_helper
INFO - 2018-10-26 15:15:27 --> Helper loaded: html_helper
INFO - 2018-10-26 15:15:27 --> Database Driver Class Initialized
INFO - 2018-10-26 15:15:27 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:15:27 --> Model "User_model" initialized
INFO - 2018-10-26 15:15:27 --> Model "Project_model" initialized
INFO - 2018-10-26 15:15:27 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:15:27 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:15:27 --> Controller Class Initialized
INFO - 2018-10-26 15:15:27 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:15:27 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:15:27 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:15:27 --> Final output sent to browser
DEBUG - 2018-10-26 15:15:27 --> Total execution time: 0.0690
INFO - 2018-10-26 15:15:28 --> Config Class Initialized
INFO - 2018-10-26 15:15:28 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:15:28 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:15:28 --> Utf8 Class Initialized
INFO - 2018-10-26 15:15:28 --> URI Class Initialized
INFO - 2018-10-26 15:15:28 --> Router Class Initialized
INFO - 2018-10-26 15:15:28 --> Output Class Initialized
INFO - 2018-10-26 15:15:28 --> Security Class Initialized
DEBUG - 2018-10-26 15:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:15:28 --> Input Class Initialized
INFO - 2018-10-26 15:15:28 --> Language Class Initialized
INFO - 2018-10-26 15:15:28 --> Loader Class Initialized
INFO - 2018-10-26 15:15:28 --> Helper loaded: url_helper
INFO - 2018-10-26 15:15:28 --> Helper loaded: form_helper
INFO - 2018-10-26 15:15:28 --> Helper loaded: html_helper
INFO - 2018-10-26 15:15:28 --> Database Driver Class Initialized
INFO - 2018-10-26 15:15:28 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:15:28 --> Model "User_model" initialized
INFO - 2018-10-26 15:15:28 --> Model "Project_model" initialized
INFO - 2018-10-26 15:15:28 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:15:28 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:15:28 --> Controller Class Initialized
INFO - 2018-10-26 15:15:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:15:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:15:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:15:28 --> Final output sent to browser
DEBUG - 2018-10-26 15:15:28 --> Total execution time: 0.0360
INFO - 2018-10-26 15:15:29 --> Config Class Initialized
INFO - 2018-10-26 15:15:29 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:15:29 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:15:29 --> Utf8 Class Initialized
INFO - 2018-10-26 15:15:29 --> URI Class Initialized
INFO - 2018-10-26 15:15:29 --> Router Class Initialized
INFO - 2018-10-26 15:15:29 --> Output Class Initialized
INFO - 2018-10-26 15:15:29 --> Security Class Initialized
DEBUG - 2018-10-26 15:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:15:29 --> Input Class Initialized
INFO - 2018-10-26 15:15:29 --> Language Class Initialized
INFO - 2018-10-26 15:15:29 --> Loader Class Initialized
INFO - 2018-10-26 15:15:29 --> Helper loaded: url_helper
INFO - 2018-10-26 15:15:29 --> Helper loaded: form_helper
INFO - 2018-10-26 15:15:29 --> Helper loaded: html_helper
INFO - 2018-10-26 15:15:29 --> Database Driver Class Initialized
INFO - 2018-10-26 15:15:29 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:15:29 --> Model "User_model" initialized
INFO - 2018-10-26 15:15:29 --> Model "Project_model" initialized
INFO - 2018-10-26 15:15:29 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:15:29 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:15:29 --> Controller Class Initialized
INFO - 2018-10-26 15:15:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:15:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:15:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:15:29 --> Final output sent to browser
DEBUG - 2018-10-26 15:15:29 --> Total execution time: 0.0360
INFO - 2018-10-26 15:15:59 --> Config Class Initialized
INFO - 2018-10-26 15:15:59 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:15:59 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:15:59 --> Utf8 Class Initialized
INFO - 2018-10-26 15:15:59 --> URI Class Initialized
INFO - 2018-10-26 15:15:59 --> Router Class Initialized
INFO - 2018-10-26 15:15:59 --> Output Class Initialized
INFO - 2018-10-26 15:15:59 --> Security Class Initialized
DEBUG - 2018-10-26 15:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:15:59 --> Input Class Initialized
INFO - 2018-10-26 15:15:59 --> Language Class Initialized
INFO - 2018-10-26 15:15:59 --> Loader Class Initialized
INFO - 2018-10-26 15:15:59 --> Helper loaded: url_helper
INFO - 2018-10-26 15:15:59 --> Helper loaded: form_helper
INFO - 2018-10-26 15:15:59 --> Helper loaded: html_helper
INFO - 2018-10-26 15:15:59 --> Database Driver Class Initialized
INFO - 2018-10-26 15:15:59 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:15:59 --> Model "User_model" initialized
INFO - 2018-10-26 15:15:59 --> Model "Project_model" initialized
INFO - 2018-10-26 15:15:59 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:15:59 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:15:59 --> Controller Class Initialized
INFO - 2018-10-26 15:15:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:15:59 --> Config Class Initialized
INFO - 2018-10-26 15:15:59 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:15:59 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:15:59 --> Utf8 Class Initialized
INFO - 2018-10-26 15:15:59 --> URI Class Initialized
INFO - 2018-10-26 15:15:59 --> Router Class Initialized
INFO - 2018-10-26 15:15:59 --> Output Class Initialized
INFO - 2018-10-26 15:15:59 --> Security Class Initialized
DEBUG - 2018-10-26 15:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:15:59 --> Input Class Initialized
INFO - 2018-10-26 15:15:59 --> Language Class Initialized
INFO - 2018-10-26 15:15:59 --> Loader Class Initialized
INFO - 2018-10-26 15:15:59 --> Helper loaded: url_helper
INFO - 2018-10-26 15:15:59 --> Helper loaded: form_helper
INFO - 2018-10-26 15:15:59 --> Helper loaded: html_helper
INFO - 2018-10-26 15:15:59 --> Database Driver Class Initialized
INFO - 2018-10-26 15:15:59 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:15:59 --> Model "User_model" initialized
INFO - 2018-10-26 15:15:59 --> Model "Project_model" initialized
INFO - 2018-10-26 15:15:59 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:15:59 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:15:59 --> Controller Class Initialized
ERROR - 2018-10-26 15:15:59 --> Query error: Table 'users.projects' doesn't exist - Invalid query: SELECT *
FROM `projects`
JOIN `tasks` ON `projects`.`id` = `tasks`.`project_id`
WHERE `project_user_id` IS NULL
INFO - 2018-10-26 15:15:59 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-26 15:16:07 --> Config Class Initialized
INFO - 2018-10-26 15:16:07 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:16:07 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:16:07 --> Utf8 Class Initialized
INFO - 2018-10-26 15:16:07 --> URI Class Initialized
INFO - 2018-10-26 15:16:07 --> Router Class Initialized
INFO - 2018-10-26 15:16:07 --> Output Class Initialized
INFO - 2018-10-26 15:16:07 --> Security Class Initialized
DEBUG - 2018-10-26 15:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:16:07 --> Input Class Initialized
INFO - 2018-10-26 15:16:07 --> Language Class Initialized
INFO - 2018-10-26 15:16:07 --> Loader Class Initialized
INFO - 2018-10-26 15:16:07 --> Helper loaded: url_helper
INFO - 2018-10-26 15:16:07 --> Helper loaded: form_helper
INFO - 2018-10-26 15:16:07 --> Helper loaded: html_helper
INFO - 2018-10-26 15:16:07 --> Database Driver Class Initialized
INFO - 2018-10-26 15:16:07 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:16:07 --> Model "User_model" initialized
INFO - 2018-10-26 15:16:07 --> Model "Project_model" initialized
INFO - 2018-10-26 15:16:07 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:16:07 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:16:07 --> Controller Class Initialized
ERROR - 2018-10-26 15:16:07 --> Query error: Table 'users.projects' doesn't exist - Invalid query: SELECT *
FROM `projects`
JOIN `tasks` ON `projects`.`id` = `tasks`.`project_id`
WHERE `project_user_id` IS NULL
INFO - 2018-10-26 15:16:07 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-26 15:16:08 --> Config Class Initialized
INFO - 2018-10-26 15:16:08 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:16:08 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:16:08 --> Utf8 Class Initialized
INFO - 2018-10-26 15:16:08 --> URI Class Initialized
INFO - 2018-10-26 15:16:08 --> Router Class Initialized
INFO - 2018-10-26 15:16:08 --> Output Class Initialized
INFO - 2018-10-26 15:16:08 --> Security Class Initialized
DEBUG - 2018-10-26 15:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:16:08 --> Input Class Initialized
INFO - 2018-10-26 15:16:08 --> Language Class Initialized
INFO - 2018-10-26 15:16:08 --> Loader Class Initialized
INFO - 2018-10-26 15:16:08 --> Helper loaded: url_helper
INFO - 2018-10-26 15:16:08 --> Helper loaded: form_helper
INFO - 2018-10-26 15:16:08 --> Helper loaded: html_helper
INFO - 2018-10-26 15:16:08 --> Database Driver Class Initialized
INFO - 2018-10-26 15:16:08 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:16:08 --> Model "User_model" initialized
INFO - 2018-10-26 15:16:08 --> Model "Project_model" initialized
INFO - 2018-10-26 15:16:08 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:16:08 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:16:08 --> Controller Class Initialized
INFO - 2018-10-26 15:16:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:16:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:16:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:16:08 --> Final output sent to browser
DEBUG - 2018-10-26 15:16:08 --> Total execution time: 0.0380
INFO - 2018-10-26 15:16:16 --> Config Class Initialized
INFO - 2018-10-26 15:16:16 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:16:16 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:16:16 --> Utf8 Class Initialized
INFO - 2018-10-26 15:16:16 --> URI Class Initialized
INFO - 2018-10-26 15:16:16 --> Router Class Initialized
INFO - 2018-10-26 15:16:16 --> Output Class Initialized
INFO - 2018-10-26 15:16:16 --> Security Class Initialized
DEBUG - 2018-10-26 15:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:16:16 --> Input Class Initialized
INFO - 2018-10-26 15:16:16 --> Language Class Initialized
INFO - 2018-10-26 15:16:16 --> Loader Class Initialized
INFO - 2018-10-26 15:16:16 --> Helper loaded: url_helper
INFO - 2018-10-26 15:16:16 --> Helper loaded: form_helper
INFO - 2018-10-26 15:16:16 --> Helper loaded: html_helper
INFO - 2018-10-26 15:16:16 --> Database Driver Class Initialized
INFO - 2018-10-26 15:16:16 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:16:16 --> Model "User_model" initialized
INFO - 2018-10-26 15:16:16 --> Model "Project_model" initialized
INFO - 2018-10-26 15:16:16 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:16:16 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:16:16 --> Controller Class Initialized
INFO - 2018-10-26 15:16:16 --> Config Class Initialized
INFO - 2018-10-26 15:16:16 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:16:16 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:16:16 --> Utf8 Class Initialized
INFO - 2018-10-26 15:16:16 --> URI Class Initialized
INFO - 2018-10-26 15:16:16 --> Router Class Initialized
INFO - 2018-10-26 15:16:16 --> Output Class Initialized
INFO - 2018-10-26 15:16:16 --> Security Class Initialized
DEBUG - 2018-10-26 15:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:16:16 --> Input Class Initialized
INFO - 2018-10-26 15:16:16 --> Language Class Initialized
INFO - 2018-10-26 15:16:16 --> Loader Class Initialized
INFO - 2018-10-26 15:16:16 --> Helper loaded: url_helper
INFO - 2018-10-26 15:16:16 --> Helper loaded: form_helper
INFO - 2018-10-26 15:16:16 --> Helper loaded: html_helper
INFO - 2018-10-26 15:16:16 --> Database Driver Class Initialized
INFO - 2018-10-26 15:16:16 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:16:16 --> Model "User_model" initialized
INFO - 2018-10-26 15:16:16 --> Model "Project_model" initialized
INFO - 2018-10-26 15:16:16 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:16:16 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:16:16 --> Controller Class Initialized
INFO - 2018-10-26 15:16:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:16:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:16:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:16:16 --> Final output sent to browser
DEBUG - 2018-10-26 15:16:16 --> Total execution time: 0.0360
INFO - 2018-10-26 15:16:25 --> Config Class Initialized
INFO - 2018-10-26 15:16:25 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:16:25 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:16:25 --> Utf8 Class Initialized
INFO - 2018-10-26 15:16:25 --> URI Class Initialized
INFO - 2018-10-26 15:16:25 --> Router Class Initialized
INFO - 2018-10-26 15:16:25 --> Output Class Initialized
INFO - 2018-10-26 15:16:25 --> Security Class Initialized
DEBUG - 2018-10-26 15:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:16:25 --> Input Class Initialized
INFO - 2018-10-26 15:16:25 --> Language Class Initialized
INFO - 2018-10-26 15:16:25 --> Loader Class Initialized
INFO - 2018-10-26 15:16:25 --> Helper loaded: url_helper
INFO - 2018-10-26 15:16:25 --> Helper loaded: form_helper
INFO - 2018-10-26 15:16:25 --> Helper loaded: html_helper
INFO - 2018-10-26 15:16:25 --> Database Driver Class Initialized
INFO - 2018-10-26 15:16:25 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:16:25 --> Model "User_model" initialized
INFO - 2018-10-26 15:16:25 --> Model "Project_model" initialized
INFO - 2018-10-26 15:16:25 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:16:25 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:16:25 --> Controller Class Initialized
INFO - 2018-10-26 15:16:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:16:26 --> Config Class Initialized
INFO - 2018-10-26 15:16:26 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:16:26 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:16:26 --> Utf8 Class Initialized
INFO - 2018-10-26 15:16:26 --> URI Class Initialized
INFO - 2018-10-26 15:16:26 --> Router Class Initialized
INFO - 2018-10-26 15:16:26 --> Output Class Initialized
INFO - 2018-10-26 15:16:26 --> Security Class Initialized
DEBUG - 2018-10-26 15:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:16:26 --> Input Class Initialized
INFO - 2018-10-26 15:16:26 --> Language Class Initialized
INFO - 2018-10-26 15:16:26 --> Loader Class Initialized
INFO - 2018-10-26 15:16:26 --> Helper loaded: url_helper
INFO - 2018-10-26 15:16:26 --> Helper loaded: form_helper
INFO - 2018-10-26 15:16:26 --> Helper loaded: html_helper
INFO - 2018-10-26 15:16:26 --> Database Driver Class Initialized
INFO - 2018-10-26 15:16:26 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:16:26 --> Model "User_model" initialized
INFO - 2018-10-26 15:16:26 --> Model "Project_model" initialized
INFO - 2018-10-26 15:16:26 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:16:26 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:16:26 --> Controller Class Initialized
ERROR - 2018-10-26 15:16:26 --> Query error: Table 'users.projects' doesn't exist - Invalid query: SELECT *
FROM `projects`
JOIN `tasks` ON `projects`.`id` = `tasks`.`project_id`
WHERE `project_user_id` IS NULL
INFO - 2018-10-26 15:16:26 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-26 15:16:33 --> Config Class Initialized
INFO - 2018-10-26 15:16:33 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:16:33 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:16:33 --> Utf8 Class Initialized
INFO - 2018-10-26 15:16:33 --> URI Class Initialized
INFO - 2018-10-26 15:16:33 --> Router Class Initialized
INFO - 2018-10-26 15:16:33 --> Output Class Initialized
INFO - 2018-10-26 15:16:33 --> Security Class Initialized
DEBUG - 2018-10-26 15:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:16:33 --> Input Class Initialized
INFO - 2018-10-26 15:16:33 --> Language Class Initialized
INFO - 2018-10-26 15:16:33 --> Loader Class Initialized
INFO - 2018-10-26 15:16:33 --> Helper loaded: url_helper
INFO - 2018-10-26 15:16:33 --> Helper loaded: form_helper
INFO - 2018-10-26 15:16:33 --> Helper loaded: html_helper
INFO - 2018-10-26 15:16:33 --> Database Driver Class Initialized
INFO - 2018-10-26 15:16:33 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:16:33 --> Model "User_model" initialized
INFO - 2018-10-26 15:16:33 --> Model "Project_model" initialized
INFO - 2018-10-26 15:16:33 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:16:33 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:16:33 --> Controller Class Initialized
ERROR - 2018-10-26 15:16:33 --> Query error: Table 'users.projects' doesn't exist - Invalid query: SELECT *
FROM `projects`
JOIN `tasks` ON `projects`.`id` = `tasks`.`project_id`
WHERE `project_user_id` IS NULL
INFO - 2018-10-26 15:16:33 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-26 15:16:33 --> Config Class Initialized
INFO - 2018-10-26 15:16:33 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:16:33 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:16:33 --> Utf8 Class Initialized
INFO - 2018-10-26 15:16:33 --> URI Class Initialized
INFO - 2018-10-26 15:16:33 --> Router Class Initialized
INFO - 2018-10-26 15:16:33 --> Output Class Initialized
INFO - 2018-10-26 15:16:33 --> Security Class Initialized
DEBUG - 2018-10-26 15:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:16:33 --> Input Class Initialized
INFO - 2018-10-26 15:16:33 --> Language Class Initialized
INFO - 2018-10-26 15:16:33 --> Loader Class Initialized
INFO - 2018-10-26 15:16:33 --> Helper loaded: url_helper
INFO - 2018-10-26 15:16:33 --> Helper loaded: form_helper
INFO - 2018-10-26 15:16:33 --> Helper loaded: html_helper
INFO - 2018-10-26 15:16:33 --> Database Driver Class Initialized
INFO - 2018-10-26 15:16:33 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:16:33 --> Model "User_model" initialized
INFO - 2018-10-26 15:16:33 --> Model "Project_model" initialized
INFO - 2018-10-26 15:16:33 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:16:33 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:16:33 --> Controller Class Initialized
INFO - 2018-10-26 15:16:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:16:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:16:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:16:33 --> Final output sent to browser
DEBUG - 2018-10-26 15:16:33 --> Total execution time: 0.0470
INFO - 2018-10-26 15:16:35 --> Config Class Initialized
INFO - 2018-10-26 15:16:35 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:16:35 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:16:35 --> Utf8 Class Initialized
INFO - 2018-10-26 15:16:35 --> URI Class Initialized
INFO - 2018-10-26 15:16:35 --> Router Class Initialized
INFO - 2018-10-26 15:16:35 --> Output Class Initialized
INFO - 2018-10-26 15:16:35 --> Security Class Initialized
DEBUG - 2018-10-26 15:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:16:35 --> Input Class Initialized
INFO - 2018-10-26 15:16:35 --> Language Class Initialized
INFO - 2018-10-26 15:16:35 --> Loader Class Initialized
INFO - 2018-10-26 15:16:35 --> Helper loaded: url_helper
INFO - 2018-10-26 15:16:35 --> Helper loaded: form_helper
INFO - 2018-10-26 15:16:35 --> Helper loaded: html_helper
INFO - 2018-10-26 15:16:35 --> Database Driver Class Initialized
INFO - 2018-10-26 15:16:35 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:16:35 --> Model "User_model" initialized
INFO - 2018-10-26 15:16:35 --> Model "Project_model" initialized
INFO - 2018-10-26 15:16:35 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:16:35 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:16:35 --> Controller Class Initialized
INFO - 2018-10-26 15:16:35 --> Config Class Initialized
INFO - 2018-10-26 15:16:35 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:16:35 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:16:35 --> Utf8 Class Initialized
INFO - 2018-10-26 15:16:35 --> URI Class Initialized
INFO - 2018-10-26 15:16:35 --> Router Class Initialized
INFO - 2018-10-26 15:16:35 --> Output Class Initialized
INFO - 2018-10-26 15:16:35 --> Security Class Initialized
DEBUG - 2018-10-26 15:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:16:35 --> Input Class Initialized
INFO - 2018-10-26 15:16:35 --> Language Class Initialized
INFO - 2018-10-26 15:16:35 --> Loader Class Initialized
INFO - 2018-10-26 15:16:35 --> Helper loaded: url_helper
INFO - 2018-10-26 15:16:35 --> Helper loaded: form_helper
INFO - 2018-10-26 15:16:35 --> Helper loaded: html_helper
INFO - 2018-10-26 15:16:35 --> Database Driver Class Initialized
INFO - 2018-10-26 15:16:35 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:16:35 --> Model "User_model" initialized
INFO - 2018-10-26 15:16:35 --> Model "Project_model" initialized
INFO - 2018-10-26 15:16:35 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:16:35 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:16:35 --> Controller Class Initialized
INFO - 2018-10-26 15:16:35 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:16:35 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:16:35 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:16:35 --> Final output sent to browser
DEBUG - 2018-10-26 15:16:35 --> Total execution time: 0.0430
INFO - 2018-10-26 15:17:38 --> Config Class Initialized
INFO - 2018-10-26 15:17:38 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:17:38 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:17:38 --> Utf8 Class Initialized
INFO - 2018-10-26 15:17:38 --> URI Class Initialized
INFO - 2018-10-26 15:17:38 --> Router Class Initialized
INFO - 2018-10-26 15:17:38 --> Output Class Initialized
INFO - 2018-10-26 15:17:38 --> Security Class Initialized
DEBUG - 2018-10-26 15:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:17:38 --> Input Class Initialized
INFO - 2018-10-26 15:17:38 --> Language Class Initialized
INFO - 2018-10-26 15:17:38 --> Loader Class Initialized
INFO - 2018-10-26 15:17:38 --> Helper loaded: url_helper
INFO - 2018-10-26 15:17:38 --> Helper loaded: form_helper
INFO - 2018-10-26 15:17:38 --> Helper loaded: html_helper
INFO - 2018-10-26 15:17:38 --> Database Driver Class Initialized
INFO - 2018-10-26 15:17:38 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:17:38 --> Model "User_model" initialized
INFO - 2018-10-26 15:17:38 --> Model "Project_model" initialized
INFO - 2018-10-26 15:17:38 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:17:38 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:17:38 --> Controller Class Initialized
INFO - 2018-10-26 15:17:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:17:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:17:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:17:38 --> Final output sent to browser
DEBUG - 2018-10-26 15:17:38 --> Total execution time: 0.0710
INFO - 2018-10-26 15:17:39 --> Config Class Initialized
INFO - 2018-10-26 15:17:39 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:17:39 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:17:39 --> Utf8 Class Initialized
INFO - 2018-10-26 15:17:39 --> URI Class Initialized
INFO - 2018-10-26 15:17:39 --> Router Class Initialized
INFO - 2018-10-26 15:17:39 --> Output Class Initialized
INFO - 2018-10-26 15:17:39 --> Security Class Initialized
DEBUG - 2018-10-26 15:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:17:39 --> Input Class Initialized
INFO - 2018-10-26 15:17:39 --> Language Class Initialized
INFO - 2018-10-26 15:17:39 --> Loader Class Initialized
INFO - 2018-10-26 15:17:39 --> Helper loaded: url_helper
INFO - 2018-10-26 15:17:39 --> Helper loaded: form_helper
INFO - 2018-10-26 15:17:39 --> Helper loaded: html_helper
INFO - 2018-10-26 15:17:39 --> Database Driver Class Initialized
INFO - 2018-10-26 15:17:39 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:17:39 --> Model "User_model" initialized
INFO - 2018-10-26 15:17:39 --> Model "Project_model" initialized
INFO - 2018-10-26 15:17:39 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:17:39 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:17:39 --> Controller Class Initialized
INFO - 2018-10-26 15:17:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:17:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:17:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:17:39 --> Final output sent to browser
DEBUG - 2018-10-26 15:17:39 --> Total execution time: 0.0620
INFO - 2018-10-26 15:19:54 --> Config Class Initialized
INFO - 2018-10-26 15:19:54 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:19:54 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:19:54 --> Utf8 Class Initialized
INFO - 2018-10-26 15:19:54 --> URI Class Initialized
INFO - 2018-10-26 15:19:54 --> Router Class Initialized
INFO - 2018-10-26 15:19:54 --> Output Class Initialized
INFO - 2018-10-26 15:19:54 --> Security Class Initialized
DEBUG - 2018-10-26 15:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:19:54 --> Input Class Initialized
INFO - 2018-10-26 15:19:54 --> Language Class Initialized
INFO - 2018-10-26 15:19:54 --> Loader Class Initialized
INFO - 2018-10-26 15:19:54 --> Helper loaded: url_helper
INFO - 2018-10-26 15:19:54 --> Helper loaded: form_helper
INFO - 2018-10-26 15:19:54 --> Helper loaded: html_helper
INFO - 2018-10-26 15:19:54 --> Database Driver Class Initialized
INFO - 2018-10-26 15:19:54 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:19:54 --> Model "User_model" initialized
INFO - 2018-10-26 15:19:54 --> Model "Project_model" initialized
INFO - 2018-10-26 15:19:54 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:19:54 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:19:54 --> Controller Class Initialized
INFO - 2018-10-26 15:19:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:19:54 --> Config Class Initialized
INFO - 2018-10-26 15:19:54 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:19:54 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:19:54 --> Utf8 Class Initialized
INFO - 2018-10-26 15:19:54 --> URI Class Initialized
INFO - 2018-10-26 15:19:54 --> Router Class Initialized
INFO - 2018-10-26 15:19:54 --> Output Class Initialized
INFO - 2018-10-26 15:19:54 --> Security Class Initialized
DEBUG - 2018-10-26 15:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:19:54 --> Input Class Initialized
INFO - 2018-10-26 15:19:54 --> Language Class Initialized
INFO - 2018-10-26 15:19:54 --> Loader Class Initialized
INFO - 2018-10-26 15:19:54 --> Helper loaded: url_helper
INFO - 2018-10-26 15:19:54 --> Helper loaded: form_helper
INFO - 2018-10-26 15:19:54 --> Helper loaded: html_helper
INFO - 2018-10-26 15:19:54 --> Database Driver Class Initialized
INFO - 2018-10-26 15:19:54 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:19:54 --> Model "User_model" initialized
INFO - 2018-10-26 15:19:54 --> Model "Project_model" initialized
INFO - 2018-10-26 15:19:54 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:19:54 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:19:54 --> Controller Class Initialized
INFO - 2018-10-26 15:19:54 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:19:54 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:19:54 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:19:54 --> Final output sent to browser
DEBUG - 2018-10-26 15:19:54 --> Total execution time: 0.0420
INFO - 2018-10-26 15:20:03 --> Config Class Initialized
INFO - 2018-10-26 15:20:03 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:20:03 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:20:03 --> Utf8 Class Initialized
INFO - 2018-10-26 15:20:03 --> URI Class Initialized
INFO - 2018-10-26 15:20:03 --> Router Class Initialized
INFO - 2018-10-26 15:20:03 --> Output Class Initialized
INFO - 2018-10-26 15:20:03 --> Security Class Initialized
DEBUG - 2018-10-26 15:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:20:03 --> Input Class Initialized
INFO - 2018-10-26 15:20:03 --> Language Class Initialized
INFO - 2018-10-26 15:20:03 --> Loader Class Initialized
INFO - 2018-10-26 15:20:03 --> Helper loaded: url_helper
INFO - 2018-10-26 15:20:03 --> Helper loaded: form_helper
INFO - 2018-10-26 15:20:03 --> Helper loaded: html_helper
INFO - 2018-10-26 15:20:03 --> Database Driver Class Initialized
INFO - 2018-10-26 15:20:03 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:20:03 --> Model "User_model" initialized
INFO - 2018-10-26 15:20:03 --> Model "Project_model" initialized
INFO - 2018-10-26 15:20:03 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:20:03 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:20:03 --> Controller Class Initialized
INFO - 2018-10-26 15:20:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:20:03 --> Config Class Initialized
INFO - 2018-10-26 15:20:03 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:20:03 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:20:03 --> Utf8 Class Initialized
INFO - 2018-10-26 15:20:03 --> URI Class Initialized
INFO - 2018-10-26 15:20:03 --> Router Class Initialized
INFO - 2018-10-26 15:20:03 --> Output Class Initialized
INFO - 2018-10-26 15:20:03 --> Security Class Initialized
DEBUG - 2018-10-26 15:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:20:03 --> Input Class Initialized
INFO - 2018-10-26 15:20:03 --> Language Class Initialized
INFO - 2018-10-26 15:20:03 --> Loader Class Initialized
INFO - 2018-10-26 15:20:03 --> Helper loaded: url_helper
INFO - 2018-10-26 15:20:03 --> Helper loaded: form_helper
INFO - 2018-10-26 15:20:03 --> Helper loaded: html_helper
INFO - 2018-10-26 15:20:03 --> Database Driver Class Initialized
INFO - 2018-10-26 15:20:03 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:20:03 --> Model "User_model" initialized
INFO - 2018-10-26 15:20:03 --> Model "Project_model" initialized
INFO - 2018-10-26 15:20:03 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:20:03 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:20:03 --> Controller Class Initialized
INFO - 2018-10-26 15:20:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:20:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:20:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:20:03 --> Final output sent to browser
DEBUG - 2018-10-26 15:20:03 --> Total execution time: 0.0330
INFO - 2018-10-26 15:20:14 --> Config Class Initialized
INFO - 2018-10-26 15:20:14 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:20:14 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:20:14 --> Utf8 Class Initialized
INFO - 2018-10-26 15:20:14 --> URI Class Initialized
INFO - 2018-10-26 15:20:14 --> Router Class Initialized
INFO - 2018-10-26 15:20:14 --> Output Class Initialized
INFO - 2018-10-26 15:20:14 --> Security Class Initialized
DEBUG - 2018-10-26 15:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:20:14 --> Input Class Initialized
INFO - 2018-10-26 15:20:14 --> Language Class Initialized
INFO - 2018-10-26 15:20:14 --> Loader Class Initialized
INFO - 2018-10-26 15:20:14 --> Helper loaded: url_helper
INFO - 2018-10-26 15:20:14 --> Helper loaded: form_helper
INFO - 2018-10-26 15:20:14 --> Helper loaded: html_helper
INFO - 2018-10-26 15:20:14 --> Database Driver Class Initialized
INFO - 2018-10-26 15:20:14 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:20:14 --> Model "User_model" initialized
INFO - 2018-10-26 15:20:14 --> Model "Project_model" initialized
INFO - 2018-10-26 15:20:14 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:20:14 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:20:14 --> Controller Class Initialized
INFO - 2018-10-26 15:20:14 --> Config Class Initialized
INFO - 2018-10-26 15:20:14 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:20:14 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:20:14 --> Utf8 Class Initialized
INFO - 2018-10-26 15:20:14 --> URI Class Initialized
INFO - 2018-10-26 15:20:14 --> Router Class Initialized
INFO - 2018-10-26 15:20:14 --> Output Class Initialized
INFO - 2018-10-26 15:20:14 --> Security Class Initialized
DEBUG - 2018-10-26 15:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:20:14 --> Input Class Initialized
INFO - 2018-10-26 15:20:14 --> Language Class Initialized
INFO - 2018-10-26 15:20:14 --> Loader Class Initialized
INFO - 2018-10-26 15:20:14 --> Helper loaded: url_helper
INFO - 2018-10-26 15:20:14 --> Helper loaded: form_helper
INFO - 2018-10-26 15:20:14 --> Helper loaded: html_helper
INFO - 2018-10-26 15:20:14 --> Database Driver Class Initialized
INFO - 2018-10-26 15:20:14 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:20:14 --> Model "User_model" initialized
INFO - 2018-10-26 15:20:14 --> Model "Project_model" initialized
INFO - 2018-10-26 15:20:14 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:20:14 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:20:14 --> Controller Class Initialized
INFO - 2018-10-26 15:20:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:20:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:20:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:20:14 --> Final output sent to browser
DEBUG - 2018-10-26 15:20:14 --> Total execution time: 0.0380
INFO - 2018-10-26 15:20:16 --> Config Class Initialized
INFO - 2018-10-26 15:20:16 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:20:16 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:20:16 --> Utf8 Class Initialized
INFO - 2018-10-26 15:20:16 --> URI Class Initialized
INFO - 2018-10-26 15:20:16 --> Router Class Initialized
INFO - 2018-10-26 15:20:16 --> Output Class Initialized
INFO - 2018-10-26 15:20:16 --> Security Class Initialized
DEBUG - 2018-10-26 15:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:20:16 --> Input Class Initialized
INFO - 2018-10-26 15:20:16 --> Language Class Initialized
INFO - 2018-10-26 15:20:16 --> Loader Class Initialized
INFO - 2018-10-26 15:20:16 --> Helper loaded: url_helper
INFO - 2018-10-26 15:20:16 --> Helper loaded: form_helper
INFO - 2018-10-26 15:20:16 --> Helper loaded: html_helper
INFO - 2018-10-26 15:20:16 --> Database Driver Class Initialized
INFO - 2018-10-26 15:20:16 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:20:16 --> Model "User_model" initialized
INFO - 2018-10-26 15:20:16 --> Model "Project_model" initialized
INFO - 2018-10-26 15:20:16 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:20:16 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:20:16 --> Controller Class Initialized
INFO - 2018-10-26 15:20:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:20:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:20:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:20:16 --> Final output sent to browser
DEBUG - 2018-10-26 15:20:16 --> Total execution time: 0.0560
INFO - 2018-10-26 15:20:17 --> Config Class Initialized
INFO - 2018-10-26 15:20:17 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:20:17 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:20:17 --> Utf8 Class Initialized
INFO - 2018-10-26 15:20:17 --> URI Class Initialized
INFO - 2018-10-26 15:20:17 --> Router Class Initialized
INFO - 2018-10-26 15:20:17 --> Output Class Initialized
INFO - 2018-10-26 15:20:17 --> Security Class Initialized
DEBUG - 2018-10-26 15:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:20:17 --> Input Class Initialized
INFO - 2018-10-26 15:20:17 --> Language Class Initialized
INFO - 2018-10-26 15:20:17 --> Loader Class Initialized
INFO - 2018-10-26 15:20:17 --> Helper loaded: url_helper
INFO - 2018-10-26 15:20:17 --> Helper loaded: form_helper
INFO - 2018-10-26 15:20:17 --> Helper loaded: html_helper
INFO - 2018-10-26 15:20:17 --> Database Driver Class Initialized
INFO - 2018-10-26 15:20:17 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:20:17 --> Model "User_model" initialized
INFO - 2018-10-26 15:20:17 --> Model "Project_model" initialized
INFO - 2018-10-26 15:20:17 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:20:17 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:20:17 --> Controller Class Initialized
INFO - 2018-10-26 15:20:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:20:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:20:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:20:17 --> Final output sent to browser
DEBUG - 2018-10-26 15:20:17 --> Total execution time: 0.0600
INFO - 2018-10-26 15:20:23 --> Config Class Initialized
INFO - 2018-10-26 15:20:23 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:20:23 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:20:23 --> Utf8 Class Initialized
INFO - 2018-10-26 15:20:23 --> URI Class Initialized
INFO - 2018-10-26 15:20:23 --> Router Class Initialized
INFO - 2018-10-26 15:20:23 --> Output Class Initialized
INFO - 2018-10-26 15:20:23 --> Security Class Initialized
DEBUG - 2018-10-26 15:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:20:23 --> Input Class Initialized
INFO - 2018-10-26 15:20:23 --> Language Class Initialized
INFO - 2018-10-26 15:20:23 --> Loader Class Initialized
INFO - 2018-10-26 15:20:23 --> Helper loaded: url_helper
INFO - 2018-10-26 15:20:23 --> Helper loaded: form_helper
INFO - 2018-10-26 15:20:23 --> Helper loaded: html_helper
INFO - 2018-10-26 15:20:23 --> Database Driver Class Initialized
INFO - 2018-10-26 15:20:23 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:20:23 --> Model "User_model" initialized
INFO - 2018-10-26 15:20:23 --> Model "Project_model" initialized
INFO - 2018-10-26 15:20:23 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:20:23 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:20:23 --> Controller Class Initialized
INFO - 2018-10-26 15:20:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:20:24 --> Config Class Initialized
INFO - 2018-10-26 15:20:24 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:20:24 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:20:24 --> Utf8 Class Initialized
INFO - 2018-10-26 15:20:24 --> URI Class Initialized
INFO - 2018-10-26 15:20:24 --> Router Class Initialized
INFO - 2018-10-26 15:20:24 --> Output Class Initialized
INFO - 2018-10-26 15:20:24 --> Security Class Initialized
DEBUG - 2018-10-26 15:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:20:24 --> Input Class Initialized
INFO - 2018-10-26 15:20:24 --> Language Class Initialized
INFO - 2018-10-26 15:20:24 --> Loader Class Initialized
INFO - 2018-10-26 15:20:24 --> Helper loaded: url_helper
INFO - 2018-10-26 15:20:24 --> Helper loaded: form_helper
INFO - 2018-10-26 15:20:24 --> Helper loaded: html_helper
INFO - 2018-10-26 15:20:24 --> Database Driver Class Initialized
INFO - 2018-10-26 15:20:24 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:20:24 --> Model "User_model" initialized
INFO - 2018-10-26 15:20:24 --> Model "Project_model" initialized
INFO - 2018-10-26 15:20:24 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:20:24 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:20:24 --> Controller Class Initialized
INFO - 2018-10-26 15:20:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:20:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:20:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:20:24 --> Final output sent to browser
DEBUG - 2018-10-26 15:20:24 --> Total execution time: 0.0380
INFO - 2018-10-26 15:20:56 --> Config Class Initialized
INFO - 2018-10-26 15:20:56 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:20:56 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:20:56 --> Utf8 Class Initialized
INFO - 2018-10-26 15:20:56 --> URI Class Initialized
INFO - 2018-10-26 15:20:56 --> Router Class Initialized
INFO - 2018-10-26 15:20:56 --> Output Class Initialized
INFO - 2018-10-26 15:20:56 --> Security Class Initialized
DEBUG - 2018-10-26 15:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:20:56 --> Input Class Initialized
INFO - 2018-10-26 15:20:56 --> Language Class Initialized
INFO - 2018-10-26 15:20:56 --> Loader Class Initialized
INFO - 2018-10-26 15:20:56 --> Helper loaded: url_helper
INFO - 2018-10-26 15:20:56 --> Helper loaded: form_helper
INFO - 2018-10-26 15:20:56 --> Helper loaded: html_helper
INFO - 2018-10-26 15:20:56 --> Database Driver Class Initialized
INFO - 2018-10-26 15:20:56 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:20:56 --> Model "User_model" initialized
INFO - 2018-10-26 15:20:56 --> Model "Project_model" initialized
INFO - 2018-10-26 15:20:56 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:20:56 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:20:56 --> Controller Class Initialized
INFO - 2018-10-26 15:20:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:20:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:20:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:20:56 --> Final output sent to browser
DEBUG - 2018-10-26 15:20:56 --> Total execution time: 0.0480
INFO - 2018-10-26 15:22:22 --> Config Class Initialized
INFO - 2018-10-26 15:22:22 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:22:22 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:22:22 --> Utf8 Class Initialized
INFO - 2018-10-26 15:22:22 --> URI Class Initialized
INFO - 2018-10-26 15:22:22 --> Router Class Initialized
INFO - 2018-10-26 15:22:22 --> Output Class Initialized
INFO - 2018-10-26 15:22:22 --> Security Class Initialized
DEBUG - 2018-10-26 15:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:22:22 --> Input Class Initialized
INFO - 2018-10-26 15:22:22 --> Language Class Initialized
INFO - 2018-10-26 15:22:22 --> Loader Class Initialized
INFO - 2018-10-26 15:22:22 --> Helper loaded: url_helper
INFO - 2018-10-26 15:22:22 --> Helper loaded: form_helper
INFO - 2018-10-26 15:22:22 --> Helper loaded: html_helper
INFO - 2018-10-26 15:22:22 --> Database Driver Class Initialized
INFO - 2018-10-26 15:22:22 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:22:22 --> Model "User_model" initialized
ERROR - 2018-10-26 15:22:22 --> Severity: error --> Exception: Unable to locate the model you have specified: Project_model D:\xampp\htdocs\code_igniter\system\core\Loader.php 348
INFO - 2018-10-26 15:22:52 --> Config Class Initialized
INFO - 2018-10-26 15:22:52 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:22:52 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:22:52 --> Utf8 Class Initialized
INFO - 2018-10-26 15:22:52 --> URI Class Initialized
INFO - 2018-10-26 15:22:52 --> Router Class Initialized
INFO - 2018-10-26 15:22:52 --> Output Class Initialized
INFO - 2018-10-26 15:22:52 --> Security Class Initialized
DEBUG - 2018-10-26 15:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:22:52 --> Input Class Initialized
INFO - 2018-10-26 15:22:52 --> Language Class Initialized
INFO - 2018-10-26 15:22:52 --> Loader Class Initialized
INFO - 2018-10-26 15:22:52 --> Helper loaded: url_helper
INFO - 2018-10-26 15:22:52 --> Helper loaded: form_helper
INFO - 2018-10-26 15:22:52 --> Helper loaded: html_helper
INFO - 2018-10-26 15:22:52 --> Database Driver Class Initialized
INFO - 2018-10-26 15:22:52 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:22:52 --> Model "User_model" initialized
ERROR - 2018-10-26 15:22:52 --> Severity: error --> Exception: Unable to locate the model you have specified: Project_model D:\xampp\htdocs\code_igniter\system\core\Loader.php 348
INFO - 2018-10-26 15:22:55 --> Config Class Initialized
INFO - 2018-10-26 15:22:55 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:22:55 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:22:55 --> Utf8 Class Initialized
INFO - 2018-10-26 15:22:55 --> URI Class Initialized
INFO - 2018-10-26 15:22:55 --> Router Class Initialized
INFO - 2018-10-26 15:22:55 --> Output Class Initialized
INFO - 2018-10-26 15:22:55 --> Security Class Initialized
DEBUG - 2018-10-26 15:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:22:55 --> Input Class Initialized
INFO - 2018-10-26 15:22:55 --> Language Class Initialized
INFO - 2018-10-26 15:22:55 --> Loader Class Initialized
INFO - 2018-10-26 15:22:55 --> Helper loaded: url_helper
INFO - 2018-10-26 15:22:55 --> Helper loaded: form_helper
INFO - 2018-10-26 15:22:55 --> Helper loaded: html_helper
INFO - 2018-10-26 15:22:55 --> Database Driver Class Initialized
INFO - 2018-10-26 15:22:55 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:22:55 --> Model "User_model" initialized
ERROR - 2018-10-26 15:22:55 --> Severity: error --> Exception: Unable to locate the model you have specified: Project_model D:\xampp\htdocs\code_igniter\system\core\Loader.php 348
INFO - 2018-10-26 15:22:56 --> Config Class Initialized
INFO - 2018-10-26 15:22:56 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:22:56 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:22:56 --> Utf8 Class Initialized
INFO - 2018-10-26 15:22:56 --> URI Class Initialized
INFO - 2018-10-26 15:22:56 --> Router Class Initialized
INFO - 2018-10-26 15:22:56 --> Output Class Initialized
INFO - 2018-10-26 15:22:56 --> Security Class Initialized
DEBUG - 2018-10-26 15:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:22:56 --> Input Class Initialized
INFO - 2018-10-26 15:22:56 --> Language Class Initialized
INFO - 2018-10-26 15:22:56 --> Loader Class Initialized
INFO - 2018-10-26 15:22:56 --> Helper loaded: url_helper
INFO - 2018-10-26 15:22:56 --> Helper loaded: form_helper
INFO - 2018-10-26 15:22:56 --> Helper loaded: html_helper
INFO - 2018-10-26 15:22:56 --> Database Driver Class Initialized
INFO - 2018-10-26 15:22:56 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:22:56 --> Model "User_model" initialized
ERROR - 2018-10-26 15:22:56 --> Severity: error --> Exception: Unable to locate the model you have specified: Project_model D:\xampp\htdocs\code_igniter\system\core\Loader.php 348
INFO - 2018-10-26 15:23:34 --> Config Class Initialized
INFO - 2018-10-26 15:23:34 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:23:34 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:23:34 --> Utf8 Class Initialized
INFO - 2018-10-26 15:23:34 --> URI Class Initialized
INFO - 2018-10-26 15:23:34 --> Router Class Initialized
INFO - 2018-10-26 15:23:34 --> Output Class Initialized
INFO - 2018-10-26 15:23:34 --> Security Class Initialized
DEBUG - 2018-10-26 15:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:23:34 --> Input Class Initialized
INFO - 2018-10-26 15:23:34 --> Language Class Initialized
INFO - 2018-10-26 15:23:34 --> Loader Class Initialized
INFO - 2018-10-26 15:23:34 --> Helper loaded: url_helper
INFO - 2018-10-26 15:23:34 --> Helper loaded: form_helper
INFO - 2018-10-26 15:23:34 --> Helper loaded: html_helper
INFO - 2018-10-26 15:23:34 --> Database Driver Class Initialized
INFO - 2018-10-26 15:23:34 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:23:34 --> Model "User_model" initialized
INFO - 2018-10-26 15:23:34 --> Model "Project_model" initialized
ERROR - 2018-10-26 15:23:34 --> Severity: error --> Exception: Unable to locate the model you have specified: Tasks_model D:\xampp\htdocs\code_igniter\system\core\Loader.php 348
INFO - 2018-10-26 15:23:36 --> Config Class Initialized
INFO - 2018-10-26 15:23:36 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:23:36 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:23:36 --> Utf8 Class Initialized
INFO - 2018-10-26 15:23:36 --> URI Class Initialized
INFO - 2018-10-26 15:23:36 --> Router Class Initialized
INFO - 2018-10-26 15:23:36 --> Output Class Initialized
INFO - 2018-10-26 15:23:36 --> Security Class Initialized
DEBUG - 2018-10-26 15:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:23:36 --> Input Class Initialized
INFO - 2018-10-26 15:23:36 --> Language Class Initialized
INFO - 2018-10-26 15:23:36 --> Loader Class Initialized
INFO - 2018-10-26 15:23:36 --> Helper loaded: url_helper
INFO - 2018-10-26 15:23:36 --> Helper loaded: form_helper
INFO - 2018-10-26 15:23:36 --> Helper loaded: html_helper
INFO - 2018-10-26 15:23:36 --> Database Driver Class Initialized
INFO - 2018-10-26 15:23:36 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:23:36 --> Model "User_model" initialized
INFO - 2018-10-26 15:23:36 --> Model "Project_model" initialized
ERROR - 2018-10-26 15:23:36 --> Severity: error --> Exception: Unable to locate the model you have specified: Tasks_model D:\xampp\htdocs\code_igniter\system\core\Loader.php 348
INFO - 2018-10-26 15:23:37 --> Config Class Initialized
INFO - 2018-10-26 15:23:37 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:23:37 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:23:37 --> Utf8 Class Initialized
INFO - 2018-10-26 15:23:37 --> URI Class Initialized
INFO - 2018-10-26 15:23:37 --> Router Class Initialized
INFO - 2018-10-26 15:23:37 --> Output Class Initialized
INFO - 2018-10-26 15:23:37 --> Security Class Initialized
DEBUG - 2018-10-26 15:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:23:37 --> Input Class Initialized
INFO - 2018-10-26 15:23:37 --> Language Class Initialized
INFO - 2018-10-26 15:23:37 --> Loader Class Initialized
INFO - 2018-10-26 15:23:37 --> Helper loaded: url_helper
INFO - 2018-10-26 15:23:37 --> Helper loaded: form_helper
INFO - 2018-10-26 15:23:37 --> Helper loaded: html_helper
INFO - 2018-10-26 15:23:37 --> Database Driver Class Initialized
INFO - 2018-10-26 15:23:37 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:23:37 --> Model "User_model" initialized
INFO - 2018-10-26 15:23:37 --> Model "Project_model" initialized
ERROR - 2018-10-26 15:23:37 --> Severity: error --> Exception: Unable to locate the model you have specified: Tasks_model D:\xampp\htdocs\code_igniter\system\core\Loader.php 348
INFO - 2018-10-26 15:23:38 --> Config Class Initialized
INFO - 2018-10-26 15:23:38 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:23:38 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:23:38 --> Utf8 Class Initialized
INFO - 2018-10-26 15:23:38 --> URI Class Initialized
INFO - 2018-10-26 15:23:38 --> Router Class Initialized
INFO - 2018-10-26 15:23:38 --> Output Class Initialized
INFO - 2018-10-26 15:23:38 --> Security Class Initialized
DEBUG - 2018-10-26 15:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:23:38 --> Input Class Initialized
INFO - 2018-10-26 15:23:38 --> Language Class Initialized
INFO - 2018-10-26 15:23:38 --> Loader Class Initialized
INFO - 2018-10-26 15:23:38 --> Helper loaded: url_helper
INFO - 2018-10-26 15:23:38 --> Helper loaded: form_helper
INFO - 2018-10-26 15:23:38 --> Helper loaded: html_helper
INFO - 2018-10-26 15:23:38 --> Database Driver Class Initialized
INFO - 2018-10-26 15:23:38 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:23:38 --> Model "User_model" initialized
INFO - 2018-10-26 15:23:38 --> Model "Project_model" initialized
ERROR - 2018-10-26 15:23:38 --> Severity: error --> Exception: Unable to locate the model you have specified: Tasks_model D:\xampp\htdocs\code_igniter\system\core\Loader.php 348
INFO - 2018-10-26 15:23:38 --> Config Class Initialized
INFO - 2018-10-26 15:23:38 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:23:38 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:23:38 --> Utf8 Class Initialized
INFO - 2018-10-26 15:23:38 --> URI Class Initialized
INFO - 2018-10-26 15:23:38 --> Router Class Initialized
INFO - 2018-10-26 15:23:38 --> Output Class Initialized
INFO - 2018-10-26 15:23:38 --> Security Class Initialized
DEBUG - 2018-10-26 15:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:23:38 --> Input Class Initialized
INFO - 2018-10-26 15:23:38 --> Language Class Initialized
INFO - 2018-10-26 15:23:39 --> Loader Class Initialized
INFO - 2018-10-26 15:23:39 --> Helper loaded: url_helper
INFO - 2018-10-26 15:23:39 --> Helper loaded: form_helper
INFO - 2018-10-26 15:23:39 --> Helper loaded: html_helper
INFO - 2018-10-26 15:23:39 --> Database Driver Class Initialized
INFO - 2018-10-26 15:23:39 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:23:39 --> Model "User_model" initialized
INFO - 2018-10-26 15:23:39 --> Model "Project_model" initialized
ERROR - 2018-10-26 15:23:39 --> Severity: error --> Exception: Unable to locate the model you have specified: Tasks_model D:\xampp\htdocs\code_igniter\system\core\Loader.php 348
INFO - 2018-10-26 15:23:39 --> Config Class Initialized
INFO - 2018-10-26 15:23:39 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:23:39 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:23:39 --> Utf8 Class Initialized
INFO - 2018-10-26 15:23:39 --> URI Class Initialized
INFO - 2018-10-26 15:23:39 --> Router Class Initialized
INFO - 2018-10-26 15:23:39 --> Output Class Initialized
INFO - 2018-10-26 15:23:39 --> Security Class Initialized
DEBUG - 2018-10-26 15:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:23:39 --> Input Class Initialized
INFO - 2018-10-26 15:23:39 --> Language Class Initialized
INFO - 2018-10-26 15:23:39 --> Loader Class Initialized
INFO - 2018-10-26 15:23:39 --> Helper loaded: url_helper
INFO - 2018-10-26 15:23:39 --> Helper loaded: form_helper
INFO - 2018-10-26 15:23:39 --> Helper loaded: html_helper
INFO - 2018-10-26 15:23:39 --> Database Driver Class Initialized
INFO - 2018-10-26 15:23:39 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:23:39 --> Model "User_model" initialized
INFO - 2018-10-26 15:23:39 --> Model "Project_model" initialized
ERROR - 2018-10-26 15:23:39 --> Severity: error --> Exception: Unable to locate the model you have specified: Tasks_model D:\xampp\htdocs\code_igniter\system\core\Loader.php 348
INFO - 2018-10-26 15:23:39 --> Config Class Initialized
INFO - 2018-10-26 15:23:39 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:23:39 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:23:39 --> Utf8 Class Initialized
INFO - 2018-10-26 15:23:39 --> URI Class Initialized
INFO - 2018-10-26 15:23:39 --> Router Class Initialized
INFO - 2018-10-26 15:23:39 --> Output Class Initialized
INFO - 2018-10-26 15:23:39 --> Security Class Initialized
DEBUG - 2018-10-26 15:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:23:39 --> Input Class Initialized
INFO - 2018-10-26 15:23:39 --> Language Class Initialized
INFO - 2018-10-26 15:23:39 --> Loader Class Initialized
INFO - 2018-10-26 15:23:39 --> Helper loaded: url_helper
INFO - 2018-10-26 15:23:39 --> Helper loaded: form_helper
INFO - 2018-10-26 15:23:39 --> Helper loaded: html_helper
INFO - 2018-10-26 15:23:39 --> Database Driver Class Initialized
INFO - 2018-10-26 15:23:39 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:23:39 --> Model "User_model" initialized
INFO - 2018-10-26 15:23:39 --> Model "Project_model" initialized
ERROR - 2018-10-26 15:23:39 --> Severity: error --> Exception: Unable to locate the model you have specified: Tasks_model D:\xampp\htdocs\code_igniter\system\core\Loader.php 348
INFO - 2018-10-26 15:23:39 --> Config Class Initialized
INFO - 2018-10-26 15:23:39 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:23:39 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:23:39 --> Utf8 Class Initialized
INFO - 2018-10-26 15:23:39 --> URI Class Initialized
INFO - 2018-10-26 15:23:39 --> Router Class Initialized
INFO - 2018-10-26 15:23:39 --> Output Class Initialized
INFO - 2018-10-26 15:23:39 --> Security Class Initialized
DEBUG - 2018-10-26 15:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:23:39 --> Input Class Initialized
INFO - 2018-10-26 15:23:39 --> Language Class Initialized
INFO - 2018-10-26 15:23:39 --> Loader Class Initialized
INFO - 2018-10-26 15:23:39 --> Helper loaded: url_helper
INFO - 2018-10-26 15:23:39 --> Helper loaded: form_helper
INFO - 2018-10-26 15:23:39 --> Helper loaded: html_helper
INFO - 2018-10-26 15:23:39 --> Database Driver Class Initialized
INFO - 2018-10-26 15:23:39 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:23:39 --> Model "User_model" initialized
INFO - 2018-10-26 15:23:39 --> Model "Project_model" initialized
ERROR - 2018-10-26 15:23:39 --> Severity: error --> Exception: Unable to locate the model you have specified: Tasks_model D:\xampp\htdocs\code_igniter\system\core\Loader.php 348
INFO - 2018-10-26 15:23:40 --> Config Class Initialized
INFO - 2018-10-26 15:23:40 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:23:40 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:23:40 --> Utf8 Class Initialized
INFO - 2018-10-26 15:23:40 --> URI Class Initialized
INFO - 2018-10-26 15:23:40 --> Router Class Initialized
INFO - 2018-10-26 15:23:40 --> Output Class Initialized
INFO - 2018-10-26 15:23:40 --> Security Class Initialized
DEBUG - 2018-10-26 15:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:23:40 --> Input Class Initialized
INFO - 2018-10-26 15:23:40 --> Language Class Initialized
INFO - 2018-10-26 15:23:40 --> Loader Class Initialized
INFO - 2018-10-26 15:23:40 --> Helper loaded: url_helper
INFO - 2018-10-26 15:23:40 --> Helper loaded: form_helper
INFO - 2018-10-26 15:23:40 --> Helper loaded: html_helper
INFO - 2018-10-26 15:23:40 --> Database Driver Class Initialized
INFO - 2018-10-26 15:23:40 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:23:40 --> Model "User_model" initialized
INFO - 2018-10-26 15:23:40 --> Model "Project_model" initialized
ERROR - 2018-10-26 15:23:40 --> Severity: error --> Exception: Unable to locate the model you have specified: Tasks_model D:\xampp\htdocs\code_igniter\system\core\Loader.php 348
INFO - 2018-10-26 15:23:40 --> Config Class Initialized
INFO - 2018-10-26 15:23:40 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:23:40 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:23:40 --> Utf8 Class Initialized
INFO - 2018-10-26 15:23:40 --> URI Class Initialized
INFO - 2018-10-26 15:23:40 --> Router Class Initialized
INFO - 2018-10-26 15:23:40 --> Output Class Initialized
INFO - 2018-10-26 15:23:40 --> Security Class Initialized
DEBUG - 2018-10-26 15:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:23:40 --> Input Class Initialized
INFO - 2018-10-26 15:23:40 --> Language Class Initialized
INFO - 2018-10-26 15:23:40 --> Loader Class Initialized
INFO - 2018-10-26 15:23:40 --> Helper loaded: url_helper
INFO - 2018-10-26 15:23:40 --> Helper loaded: form_helper
INFO - 2018-10-26 15:23:40 --> Helper loaded: html_helper
INFO - 2018-10-26 15:23:40 --> Database Driver Class Initialized
INFO - 2018-10-26 15:23:40 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:23:40 --> Model "User_model" initialized
INFO - 2018-10-26 15:23:40 --> Model "Project_model" initialized
ERROR - 2018-10-26 15:23:40 --> Severity: error --> Exception: Unable to locate the model you have specified: Tasks_model D:\xampp\htdocs\code_igniter\system\core\Loader.php 348
INFO - 2018-10-26 15:23:40 --> Config Class Initialized
INFO - 2018-10-26 15:23:40 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:23:40 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:23:40 --> Utf8 Class Initialized
INFO - 2018-10-26 15:23:40 --> URI Class Initialized
INFO - 2018-10-26 15:23:40 --> Router Class Initialized
INFO - 2018-10-26 15:23:40 --> Output Class Initialized
INFO - 2018-10-26 15:23:40 --> Security Class Initialized
DEBUG - 2018-10-26 15:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:23:40 --> Input Class Initialized
INFO - 2018-10-26 15:23:40 --> Language Class Initialized
INFO - 2018-10-26 15:23:40 --> Loader Class Initialized
INFO - 2018-10-26 15:23:40 --> Helper loaded: url_helper
INFO - 2018-10-26 15:23:40 --> Helper loaded: form_helper
INFO - 2018-10-26 15:23:40 --> Helper loaded: html_helper
INFO - 2018-10-26 15:23:40 --> Database Driver Class Initialized
INFO - 2018-10-26 15:23:40 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:23:40 --> Model "User_model" initialized
INFO - 2018-10-26 15:23:40 --> Model "Project_model" initialized
ERROR - 2018-10-26 15:23:40 --> Severity: error --> Exception: Unable to locate the model you have specified: Tasks_model D:\xampp\htdocs\code_igniter\system\core\Loader.php 348
INFO - 2018-10-26 15:24:03 --> Config Class Initialized
INFO - 2018-10-26 15:24:03 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:24:03 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:24:03 --> Utf8 Class Initialized
INFO - 2018-10-26 15:24:03 --> URI Class Initialized
INFO - 2018-10-26 15:24:03 --> Router Class Initialized
INFO - 2018-10-26 15:24:03 --> Output Class Initialized
INFO - 2018-10-26 15:24:03 --> Security Class Initialized
DEBUG - 2018-10-26 15:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:24:03 --> Input Class Initialized
INFO - 2018-10-26 15:24:03 --> Language Class Initialized
INFO - 2018-10-26 15:24:03 --> Loader Class Initialized
INFO - 2018-10-26 15:24:03 --> Helper loaded: url_helper
INFO - 2018-10-26 15:24:03 --> Helper loaded: form_helper
INFO - 2018-10-26 15:24:03 --> Helper loaded: html_helper
INFO - 2018-10-26 15:24:03 --> Database Driver Class Initialized
INFO - 2018-10-26 15:24:03 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:24:03 --> Model "User_model" initialized
INFO - 2018-10-26 15:24:03 --> Model "Project_model" initialized
INFO - 2018-10-26 15:24:03 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:24:03 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:24:03 --> Controller Class Initialized
INFO - 2018-10-26 15:24:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:24:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:24:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:24:03 --> Final output sent to browser
DEBUG - 2018-10-26 15:24:03 --> Total execution time: 0.0360
INFO - 2018-10-26 15:24:06 --> Config Class Initialized
INFO - 2018-10-26 15:24:06 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:24:06 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:24:06 --> Utf8 Class Initialized
INFO - 2018-10-26 15:24:06 --> URI Class Initialized
INFO - 2018-10-26 15:24:06 --> Router Class Initialized
INFO - 2018-10-26 15:24:06 --> Output Class Initialized
INFO - 2018-10-26 15:24:06 --> Security Class Initialized
DEBUG - 2018-10-26 15:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:24:06 --> Input Class Initialized
INFO - 2018-10-26 15:24:06 --> Language Class Initialized
INFO - 2018-10-26 15:24:06 --> Loader Class Initialized
INFO - 2018-10-26 15:24:06 --> Helper loaded: url_helper
INFO - 2018-10-26 15:24:06 --> Helper loaded: form_helper
INFO - 2018-10-26 15:24:06 --> Helper loaded: html_helper
INFO - 2018-10-26 15:24:06 --> Database Driver Class Initialized
INFO - 2018-10-26 15:24:06 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:24:06 --> Model "User_model" initialized
INFO - 2018-10-26 15:24:06 --> Model "Project_model" initialized
INFO - 2018-10-26 15:24:06 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:24:06 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:24:06 --> Controller Class Initialized
INFO - 2018-10-26 15:24:06 --> Config Class Initialized
INFO - 2018-10-26 15:24:06 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:24:06 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:24:06 --> Utf8 Class Initialized
INFO - 2018-10-26 15:24:06 --> URI Class Initialized
INFO - 2018-10-26 15:24:06 --> Router Class Initialized
INFO - 2018-10-26 15:24:06 --> Output Class Initialized
INFO - 2018-10-26 15:24:06 --> Security Class Initialized
DEBUG - 2018-10-26 15:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:24:06 --> Input Class Initialized
INFO - 2018-10-26 15:24:06 --> Language Class Initialized
INFO - 2018-10-26 15:24:06 --> Loader Class Initialized
INFO - 2018-10-26 15:24:06 --> Helper loaded: url_helper
INFO - 2018-10-26 15:24:06 --> Helper loaded: form_helper
INFO - 2018-10-26 15:24:06 --> Helper loaded: html_helper
INFO - 2018-10-26 15:24:06 --> Database Driver Class Initialized
INFO - 2018-10-26 15:24:06 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:24:06 --> Model "User_model" initialized
INFO - 2018-10-26 15:24:06 --> Model "Project_model" initialized
INFO - 2018-10-26 15:24:06 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:24:06 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:24:06 --> Controller Class Initialized
INFO - 2018-10-26 15:24:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:24:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:24:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:24:06 --> Final output sent to browser
DEBUG - 2018-10-26 15:24:06 --> Total execution time: 0.0440
INFO - 2018-10-26 15:24:08 --> Config Class Initialized
INFO - 2018-10-26 15:24:08 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:24:08 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:24:08 --> Utf8 Class Initialized
INFO - 2018-10-26 15:24:08 --> URI Class Initialized
INFO - 2018-10-26 15:24:08 --> Router Class Initialized
INFO - 2018-10-26 15:24:08 --> Output Class Initialized
INFO - 2018-10-26 15:24:08 --> Security Class Initialized
DEBUG - 2018-10-26 15:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:24:08 --> Input Class Initialized
INFO - 2018-10-26 15:24:08 --> Language Class Initialized
INFO - 2018-10-26 15:24:08 --> Loader Class Initialized
INFO - 2018-10-26 15:24:08 --> Helper loaded: url_helper
INFO - 2018-10-26 15:24:08 --> Helper loaded: form_helper
INFO - 2018-10-26 15:24:08 --> Helper loaded: html_helper
INFO - 2018-10-26 15:24:08 --> Database Driver Class Initialized
INFO - 2018-10-26 15:24:08 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:24:08 --> Model "User_model" initialized
INFO - 2018-10-26 15:24:08 --> Model "Project_model" initialized
INFO - 2018-10-26 15:24:08 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:24:08 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:24:08 --> Controller Class Initialized
INFO - 2018-10-26 15:24:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:24:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:24:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:24:08 --> Final output sent to browser
DEBUG - 2018-10-26 15:24:08 --> Total execution time: 0.0580
INFO - 2018-10-26 15:24:09 --> Config Class Initialized
INFO - 2018-10-26 15:24:09 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:24:09 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:24:09 --> Utf8 Class Initialized
INFO - 2018-10-26 15:24:09 --> URI Class Initialized
INFO - 2018-10-26 15:24:09 --> Router Class Initialized
INFO - 2018-10-26 15:24:09 --> Output Class Initialized
INFO - 2018-10-26 15:24:09 --> Security Class Initialized
DEBUG - 2018-10-26 15:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:24:09 --> Input Class Initialized
INFO - 2018-10-26 15:24:09 --> Language Class Initialized
INFO - 2018-10-26 15:24:09 --> Loader Class Initialized
INFO - 2018-10-26 15:24:09 --> Helper loaded: url_helper
INFO - 2018-10-26 15:24:09 --> Helper loaded: form_helper
INFO - 2018-10-26 15:24:09 --> Helper loaded: html_helper
INFO - 2018-10-26 15:24:09 --> Database Driver Class Initialized
INFO - 2018-10-26 15:24:09 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:24:09 --> Model "User_model" initialized
INFO - 2018-10-26 15:24:09 --> Model "Project_model" initialized
INFO - 2018-10-26 15:24:09 --> Model "Tasks_model" initialized
INFO - 2018-10-26 15:24:09 --> Model "Lists_model" initialized
INFO - 2018-10-26 15:24:09 --> Controller Class Initialized
INFO - 2018-10-26 15:24:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:24:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:24:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:24:09 --> Final output sent to browser
DEBUG - 2018-10-26 15:24:09 --> Total execution time: 0.0640
INFO - 2018-10-26 15:25:11 --> Config Class Initialized
INFO - 2018-10-26 15:25:11 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:25:11 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:25:11 --> Utf8 Class Initialized
INFO - 2018-10-26 15:25:11 --> URI Class Initialized
INFO - 2018-10-26 15:25:11 --> Router Class Initialized
INFO - 2018-10-26 15:25:11 --> Output Class Initialized
INFO - 2018-10-26 15:25:11 --> Security Class Initialized
DEBUG - 2018-10-26 15:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:25:11 --> Input Class Initialized
INFO - 2018-10-26 15:25:11 --> Language Class Initialized
INFO - 2018-10-26 15:25:11 --> Loader Class Initialized
INFO - 2018-10-26 15:25:11 --> Helper loaded: url_helper
INFO - 2018-10-26 15:25:11 --> Helper loaded: form_helper
INFO - 2018-10-26 15:25:11 --> Helper loaded: html_helper
INFO - 2018-10-26 15:25:11 --> Database Driver Class Initialized
INFO - 2018-10-26 15:25:11 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:25:11 --> Model "User_model" initialized
INFO - 2018-10-26 15:25:11 --> Controller Class Initialized
INFO - 2018-10-26 15:25:11 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:25:11 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:25:11 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:25:11 --> Final output sent to browser
DEBUG - 2018-10-26 15:25:11 --> Total execution time: 0.0550
INFO - 2018-10-26 15:25:18 --> Config Class Initialized
INFO - 2018-10-26 15:25:18 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:25:18 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:25:18 --> Utf8 Class Initialized
INFO - 2018-10-26 15:25:18 --> URI Class Initialized
INFO - 2018-10-26 15:25:18 --> Router Class Initialized
INFO - 2018-10-26 15:25:18 --> Output Class Initialized
INFO - 2018-10-26 15:25:18 --> Security Class Initialized
DEBUG - 2018-10-26 15:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:25:18 --> Input Class Initialized
INFO - 2018-10-26 15:25:18 --> Language Class Initialized
INFO - 2018-10-26 15:25:18 --> Loader Class Initialized
INFO - 2018-10-26 15:25:18 --> Helper loaded: url_helper
INFO - 2018-10-26 15:25:18 --> Helper loaded: form_helper
INFO - 2018-10-26 15:25:18 --> Helper loaded: html_helper
INFO - 2018-10-26 15:25:18 --> Database Driver Class Initialized
INFO - 2018-10-26 15:25:18 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:25:18 --> Model "User_model" initialized
INFO - 2018-10-26 15:25:18 --> Controller Class Initialized
INFO - 2018-10-26 15:25:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:25:18 --> Config Class Initialized
INFO - 2018-10-26 15:25:18 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:25:18 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:25:18 --> Utf8 Class Initialized
INFO - 2018-10-26 15:25:18 --> URI Class Initialized
INFO - 2018-10-26 15:25:18 --> Router Class Initialized
INFO - 2018-10-26 15:25:18 --> Output Class Initialized
INFO - 2018-10-26 15:25:18 --> Security Class Initialized
DEBUG - 2018-10-26 15:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:25:18 --> Input Class Initialized
INFO - 2018-10-26 15:25:18 --> Language Class Initialized
INFO - 2018-10-26 15:25:18 --> Loader Class Initialized
INFO - 2018-10-26 15:25:18 --> Helper loaded: url_helper
INFO - 2018-10-26 15:25:18 --> Helper loaded: form_helper
INFO - 2018-10-26 15:25:18 --> Helper loaded: html_helper
INFO - 2018-10-26 15:25:18 --> Database Driver Class Initialized
INFO - 2018-10-26 15:25:18 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:25:18 --> Model "User_model" initialized
INFO - 2018-10-26 15:25:18 --> Controller Class Initialized
INFO - 2018-10-26 15:25:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:25:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:25:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:25:18 --> Final output sent to browser
DEBUG - 2018-10-26 15:25:18 --> Total execution time: 0.0380
INFO - 2018-10-26 15:25:20 --> Config Class Initialized
INFO - 2018-10-26 15:25:20 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:25:20 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:25:20 --> Utf8 Class Initialized
INFO - 2018-10-26 15:25:20 --> URI Class Initialized
INFO - 2018-10-26 15:25:20 --> Router Class Initialized
INFO - 2018-10-26 15:25:20 --> Output Class Initialized
INFO - 2018-10-26 15:25:20 --> Security Class Initialized
DEBUG - 2018-10-26 15:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:25:20 --> Input Class Initialized
INFO - 2018-10-26 15:25:20 --> Language Class Initialized
INFO - 2018-10-26 15:25:20 --> Loader Class Initialized
INFO - 2018-10-26 15:25:20 --> Helper loaded: url_helper
INFO - 2018-10-26 15:25:20 --> Helper loaded: form_helper
INFO - 2018-10-26 15:25:20 --> Helper loaded: html_helper
INFO - 2018-10-26 15:25:20 --> Database Driver Class Initialized
INFO - 2018-10-26 15:25:20 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:25:20 --> Model "User_model" initialized
INFO - 2018-10-26 15:25:20 --> Controller Class Initialized
INFO - 2018-10-26 15:25:20 --> Config Class Initialized
INFO - 2018-10-26 15:25:20 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:25:20 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:25:20 --> Utf8 Class Initialized
INFO - 2018-10-26 15:25:20 --> URI Class Initialized
INFO - 2018-10-26 15:25:20 --> Router Class Initialized
INFO - 2018-10-26 15:25:20 --> Output Class Initialized
INFO - 2018-10-26 15:25:20 --> Security Class Initialized
DEBUG - 2018-10-26 15:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:25:20 --> Input Class Initialized
INFO - 2018-10-26 15:25:20 --> Language Class Initialized
INFO - 2018-10-26 15:25:20 --> Loader Class Initialized
INFO - 2018-10-26 15:25:20 --> Helper loaded: url_helper
INFO - 2018-10-26 15:25:20 --> Helper loaded: form_helper
INFO - 2018-10-26 15:25:20 --> Helper loaded: html_helper
INFO - 2018-10-26 15:25:20 --> Database Driver Class Initialized
INFO - 2018-10-26 15:25:20 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:25:20 --> Model "User_model" initialized
INFO - 2018-10-26 15:25:20 --> Controller Class Initialized
INFO - 2018-10-26 15:25:20 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:25:20 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:25:20 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:25:20 --> Final output sent to browser
DEBUG - 2018-10-26 15:25:20 --> Total execution time: 0.0310
INFO - 2018-10-26 15:26:07 --> Config Class Initialized
INFO - 2018-10-26 15:26:07 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:26:07 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:26:07 --> Utf8 Class Initialized
INFO - 2018-10-26 15:26:07 --> URI Class Initialized
INFO - 2018-10-26 15:26:07 --> Router Class Initialized
INFO - 2018-10-26 15:26:07 --> Output Class Initialized
INFO - 2018-10-26 15:26:07 --> Security Class Initialized
DEBUG - 2018-10-26 15:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:26:07 --> Input Class Initialized
INFO - 2018-10-26 15:26:07 --> Language Class Initialized
INFO - 2018-10-26 15:26:07 --> Loader Class Initialized
INFO - 2018-10-26 15:26:07 --> Helper loaded: url_helper
INFO - 2018-10-26 15:26:07 --> Helper loaded: form_helper
INFO - 2018-10-26 15:26:07 --> Helper loaded: html_helper
INFO - 2018-10-26 15:26:07 --> Database Driver Class Initialized
INFO - 2018-10-26 15:26:07 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:26:07 --> Model "User_model" initialized
INFO - 2018-10-26 15:26:07 --> Controller Class Initialized
INFO - 2018-10-26 15:26:07 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:26:07 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:26:07 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:26:07 --> Final output sent to browser
DEBUG - 2018-10-26 15:26:07 --> Total execution time: 0.0550
INFO - 2018-10-26 15:26:15 --> Config Class Initialized
INFO - 2018-10-26 15:26:15 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:26:15 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:26:15 --> Utf8 Class Initialized
INFO - 2018-10-26 15:26:15 --> URI Class Initialized
INFO - 2018-10-26 15:26:15 --> Router Class Initialized
INFO - 2018-10-26 15:26:15 --> Output Class Initialized
INFO - 2018-10-26 15:26:15 --> Security Class Initialized
DEBUG - 2018-10-26 15:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:26:15 --> Input Class Initialized
INFO - 2018-10-26 15:26:15 --> Language Class Initialized
INFO - 2018-10-26 15:26:15 --> Loader Class Initialized
INFO - 2018-10-26 15:26:15 --> Helper loaded: url_helper
INFO - 2018-10-26 15:26:15 --> Helper loaded: form_helper
INFO - 2018-10-26 15:26:15 --> Helper loaded: html_helper
INFO - 2018-10-26 15:26:15 --> Database Driver Class Initialized
INFO - 2018-10-26 15:26:15 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:26:15 --> Model "User_model" initialized
INFO - 2018-10-26 15:26:15 --> Controller Class Initialized
INFO - 2018-10-26 15:26:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:26:16 --> Config Class Initialized
INFO - 2018-10-26 15:26:16 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:26:16 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:26:16 --> Utf8 Class Initialized
INFO - 2018-10-26 15:26:16 --> URI Class Initialized
INFO - 2018-10-26 15:26:16 --> Router Class Initialized
INFO - 2018-10-26 15:26:16 --> Output Class Initialized
INFO - 2018-10-26 15:26:16 --> Security Class Initialized
DEBUG - 2018-10-26 15:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:26:16 --> Input Class Initialized
INFO - 2018-10-26 15:26:16 --> Language Class Initialized
INFO - 2018-10-26 15:26:16 --> Loader Class Initialized
INFO - 2018-10-26 15:26:16 --> Helper loaded: url_helper
INFO - 2018-10-26 15:26:16 --> Helper loaded: form_helper
INFO - 2018-10-26 15:26:16 --> Helper loaded: html_helper
INFO - 2018-10-26 15:26:16 --> Database Driver Class Initialized
INFO - 2018-10-26 15:26:16 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:26:16 --> Model "User_model" initialized
INFO - 2018-10-26 15:26:16 --> Controller Class Initialized
INFO - 2018-10-26 15:26:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:26:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:26:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:26:16 --> Final output sent to browser
DEBUG - 2018-10-26 15:26:16 --> Total execution time: 0.0420
INFO - 2018-10-26 15:26:18 --> Config Class Initialized
INFO - 2018-10-26 15:26:18 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:26:18 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:26:18 --> Utf8 Class Initialized
INFO - 2018-10-26 15:26:18 --> URI Class Initialized
INFO - 2018-10-26 15:26:18 --> Router Class Initialized
INFO - 2018-10-26 15:26:18 --> Output Class Initialized
INFO - 2018-10-26 15:26:18 --> Security Class Initialized
DEBUG - 2018-10-26 15:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:26:18 --> Input Class Initialized
INFO - 2018-10-26 15:26:18 --> Language Class Initialized
INFO - 2018-10-26 15:26:18 --> Loader Class Initialized
INFO - 2018-10-26 15:26:18 --> Helper loaded: url_helper
INFO - 2018-10-26 15:26:18 --> Helper loaded: form_helper
INFO - 2018-10-26 15:26:18 --> Helper loaded: html_helper
INFO - 2018-10-26 15:26:18 --> Database Driver Class Initialized
INFO - 2018-10-26 15:26:18 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:26:18 --> Model "User_model" initialized
INFO - 2018-10-26 15:26:18 --> Controller Class Initialized
INFO - 2018-10-26 15:26:18 --> Config Class Initialized
INFO - 2018-10-26 15:26:18 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:26:18 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:26:18 --> Utf8 Class Initialized
INFO - 2018-10-26 15:26:18 --> URI Class Initialized
INFO - 2018-10-26 15:26:18 --> Router Class Initialized
INFO - 2018-10-26 15:26:18 --> Output Class Initialized
INFO - 2018-10-26 15:26:18 --> Security Class Initialized
DEBUG - 2018-10-26 15:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:26:18 --> Input Class Initialized
INFO - 2018-10-26 15:26:18 --> Language Class Initialized
INFO - 2018-10-26 15:26:18 --> Loader Class Initialized
INFO - 2018-10-26 15:26:18 --> Helper loaded: url_helper
INFO - 2018-10-26 15:26:18 --> Helper loaded: form_helper
INFO - 2018-10-26 15:26:18 --> Helper loaded: html_helper
INFO - 2018-10-26 15:26:18 --> Database Driver Class Initialized
INFO - 2018-10-26 15:26:18 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:26:18 --> Model "User_model" initialized
INFO - 2018-10-26 15:26:18 --> Controller Class Initialized
INFO - 2018-10-26 15:26:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:26:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:26:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:26:18 --> Final output sent to browser
DEBUG - 2018-10-26 15:26:18 --> Total execution time: 0.0410
INFO - 2018-10-26 15:26:20 --> Config Class Initialized
INFO - 2018-10-26 15:26:20 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:26:20 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:26:20 --> Utf8 Class Initialized
INFO - 2018-10-26 15:26:20 --> URI Class Initialized
INFO - 2018-10-26 15:26:20 --> Router Class Initialized
INFO - 2018-10-26 15:26:20 --> Output Class Initialized
INFO - 2018-10-26 15:26:20 --> Security Class Initialized
DEBUG - 2018-10-26 15:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:26:20 --> Input Class Initialized
INFO - 2018-10-26 15:26:20 --> Language Class Initialized
INFO - 2018-10-26 15:26:20 --> Loader Class Initialized
INFO - 2018-10-26 15:26:20 --> Helper loaded: url_helper
INFO - 2018-10-26 15:26:20 --> Helper loaded: form_helper
INFO - 2018-10-26 15:26:20 --> Helper loaded: html_helper
INFO - 2018-10-26 15:26:20 --> Database Driver Class Initialized
INFO - 2018-10-26 15:26:20 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:26:20 --> Model "User_model" initialized
INFO - 2018-10-26 15:26:20 --> Controller Class Initialized
INFO - 2018-10-26 15:26:20 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:26:20 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:26:20 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:26:20 --> Final output sent to browser
DEBUG - 2018-10-26 15:26:20 --> Total execution time: 0.0660
INFO - 2018-10-26 15:26:20 --> Config Class Initialized
INFO - 2018-10-26 15:26:20 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:26:20 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:26:20 --> Utf8 Class Initialized
INFO - 2018-10-26 15:26:20 --> URI Class Initialized
INFO - 2018-10-26 15:26:20 --> Router Class Initialized
INFO - 2018-10-26 15:26:20 --> Output Class Initialized
INFO - 2018-10-26 15:26:20 --> Security Class Initialized
DEBUG - 2018-10-26 15:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:26:20 --> Input Class Initialized
INFO - 2018-10-26 15:26:20 --> Language Class Initialized
INFO - 2018-10-26 15:26:20 --> Loader Class Initialized
INFO - 2018-10-26 15:26:20 --> Helper loaded: url_helper
INFO - 2018-10-26 15:26:20 --> Helper loaded: form_helper
INFO - 2018-10-26 15:26:20 --> Helper loaded: html_helper
INFO - 2018-10-26 15:26:20 --> Database Driver Class Initialized
INFO - 2018-10-26 15:26:20 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:26:20 --> Model "User_model" initialized
INFO - 2018-10-26 15:26:20 --> Controller Class Initialized
INFO - 2018-10-26 15:26:20 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:26:20 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:26:20 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:26:20 --> Final output sent to browser
DEBUG - 2018-10-26 15:26:20 --> Total execution time: 0.0370
INFO - 2018-10-26 15:26:23 --> Config Class Initialized
INFO - 2018-10-26 15:26:23 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:26:23 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:26:23 --> Utf8 Class Initialized
INFO - 2018-10-26 15:26:23 --> URI Class Initialized
INFO - 2018-10-26 15:26:23 --> Router Class Initialized
INFO - 2018-10-26 15:26:23 --> Output Class Initialized
INFO - 2018-10-26 15:26:23 --> Security Class Initialized
DEBUG - 2018-10-26 15:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:26:23 --> Input Class Initialized
INFO - 2018-10-26 15:26:23 --> Language Class Initialized
INFO - 2018-10-26 15:26:23 --> Loader Class Initialized
INFO - 2018-10-26 15:26:23 --> Helper loaded: url_helper
INFO - 2018-10-26 15:26:23 --> Helper loaded: form_helper
INFO - 2018-10-26 15:26:23 --> Helper loaded: html_helper
INFO - 2018-10-26 15:26:23 --> Database Driver Class Initialized
INFO - 2018-10-26 15:26:23 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:26:23 --> Model "User_model" initialized
INFO - 2018-10-26 15:26:23 --> Controller Class Initialized
INFO - 2018-10-26 15:26:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:26:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:26:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:26:23 --> Final output sent to browser
DEBUG - 2018-10-26 15:26:23 --> Total execution time: 0.0410
INFO - 2018-10-26 15:26:24 --> Config Class Initialized
INFO - 2018-10-26 15:26:24 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:26:24 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:26:24 --> Utf8 Class Initialized
INFO - 2018-10-26 15:26:24 --> URI Class Initialized
INFO - 2018-10-26 15:26:24 --> Router Class Initialized
INFO - 2018-10-26 15:26:24 --> Output Class Initialized
INFO - 2018-10-26 15:26:24 --> Security Class Initialized
DEBUG - 2018-10-26 15:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:26:24 --> Input Class Initialized
INFO - 2018-10-26 15:26:24 --> Language Class Initialized
INFO - 2018-10-26 15:26:24 --> Loader Class Initialized
INFO - 2018-10-26 15:26:24 --> Helper loaded: url_helper
INFO - 2018-10-26 15:26:24 --> Helper loaded: form_helper
INFO - 2018-10-26 15:26:24 --> Helper loaded: html_helper
INFO - 2018-10-26 15:26:24 --> Database Driver Class Initialized
INFO - 2018-10-26 15:26:24 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:26:24 --> Model "User_model" initialized
INFO - 2018-10-26 15:26:24 --> Controller Class Initialized
INFO - 2018-10-26 15:26:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:26:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:26:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:26:24 --> Final output sent to browser
DEBUG - 2018-10-26 15:26:24 --> Total execution time: 0.0400
INFO - 2018-10-26 15:26:31 --> Config Class Initialized
INFO - 2018-10-26 15:26:31 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:26:31 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:26:31 --> Utf8 Class Initialized
INFO - 2018-10-26 15:26:31 --> URI Class Initialized
INFO - 2018-10-26 15:26:31 --> Router Class Initialized
INFO - 2018-10-26 15:26:31 --> Output Class Initialized
INFO - 2018-10-26 15:26:31 --> Security Class Initialized
DEBUG - 2018-10-26 15:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:26:31 --> Input Class Initialized
INFO - 2018-10-26 15:26:31 --> Language Class Initialized
INFO - 2018-10-26 15:26:31 --> Loader Class Initialized
INFO - 2018-10-26 15:26:31 --> Helper loaded: url_helper
INFO - 2018-10-26 15:26:31 --> Helper loaded: form_helper
INFO - 2018-10-26 15:26:31 --> Helper loaded: html_helper
INFO - 2018-10-26 15:26:31 --> Database Driver Class Initialized
INFO - 2018-10-26 15:26:31 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:26:31 --> Model "User_model" initialized
INFO - 2018-10-26 15:26:31 --> Controller Class Initialized
INFO - 2018-10-26 15:26:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:26:31 --> Config Class Initialized
INFO - 2018-10-26 15:26:31 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:26:31 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:26:31 --> Utf8 Class Initialized
INFO - 2018-10-26 15:26:31 --> URI Class Initialized
INFO - 2018-10-26 15:26:31 --> Router Class Initialized
INFO - 2018-10-26 15:26:31 --> Output Class Initialized
INFO - 2018-10-26 15:26:31 --> Security Class Initialized
DEBUG - 2018-10-26 15:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:26:31 --> Input Class Initialized
INFO - 2018-10-26 15:26:31 --> Language Class Initialized
INFO - 2018-10-26 15:26:31 --> Loader Class Initialized
INFO - 2018-10-26 15:26:31 --> Helper loaded: url_helper
INFO - 2018-10-26 15:26:31 --> Helper loaded: form_helper
INFO - 2018-10-26 15:26:31 --> Helper loaded: html_helper
INFO - 2018-10-26 15:26:31 --> Database Driver Class Initialized
INFO - 2018-10-26 15:26:31 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:26:31 --> Model "User_model" initialized
INFO - 2018-10-26 15:26:31 --> Controller Class Initialized
INFO - 2018-10-26 15:26:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:26:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:26:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:26:31 --> Final output sent to browser
DEBUG - 2018-10-26 15:26:31 --> Total execution time: 0.0410
INFO - 2018-10-26 15:27:37 --> Config Class Initialized
INFO - 2018-10-26 15:27:37 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:27:37 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:27:37 --> Utf8 Class Initialized
INFO - 2018-10-26 15:27:37 --> URI Class Initialized
INFO - 2018-10-26 15:27:37 --> Router Class Initialized
INFO - 2018-10-26 15:27:37 --> Output Class Initialized
INFO - 2018-10-26 15:27:37 --> Security Class Initialized
DEBUG - 2018-10-26 15:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:27:37 --> Input Class Initialized
INFO - 2018-10-26 15:27:37 --> Language Class Initialized
INFO - 2018-10-26 15:27:37 --> Loader Class Initialized
INFO - 2018-10-26 15:27:37 --> Helper loaded: url_helper
INFO - 2018-10-26 15:27:37 --> Helper loaded: form_helper
INFO - 2018-10-26 15:27:37 --> Helper loaded: html_helper
INFO - 2018-10-26 15:27:37 --> Database Driver Class Initialized
INFO - 2018-10-26 15:27:37 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:27:37 --> Model "User_model" initialized
INFO - 2018-10-26 15:27:37 --> Controller Class Initialized
INFO - 2018-10-26 15:27:37 --> Config Class Initialized
INFO - 2018-10-26 15:27:37 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:27:37 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:27:37 --> Utf8 Class Initialized
INFO - 2018-10-26 15:27:37 --> URI Class Initialized
INFO - 2018-10-26 15:27:37 --> Router Class Initialized
INFO - 2018-10-26 15:27:37 --> Output Class Initialized
INFO - 2018-10-26 15:27:37 --> Security Class Initialized
DEBUG - 2018-10-26 15:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:27:37 --> Input Class Initialized
INFO - 2018-10-26 15:27:37 --> Language Class Initialized
INFO - 2018-10-26 15:27:37 --> Loader Class Initialized
INFO - 2018-10-26 15:27:37 --> Helper loaded: url_helper
INFO - 2018-10-26 15:27:37 --> Helper loaded: form_helper
INFO - 2018-10-26 15:27:37 --> Helper loaded: html_helper
INFO - 2018-10-26 15:27:37 --> Database Driver Class Initialized
INFO - 2018-10-26 15:27:37 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:27:37 --> Model "User_model" initialized
INFO - 2018-10-26 15:27:37 --> Controller Class Initialized
INFO - 2018-10-26 15:27:37 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:27:37 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:27:37 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:27:37 --> Final output sent to browser
DEBUG - 2018-10-26 15:27:37 --> Total execution time: 0.0550
INFO - 2018-10-26 15:27:46 --> Config Class Initialized
INFO - 2018-10-26 15:27:46 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:27:46 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:27:46 --> Utf8 Class Initialized
INFO - 2018-10-26 15:27:46 --> URI Class Initialized
INFO - 2018-10-26 15:27:46 --> Router Class Initialized
INFO - 2018-10-26 15:27:46 --> Output Class Initialized
INFO - 2018-10-26 15:27:46 --> Security Class Initialized
DEBUG - 2018-10-26 15:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:27:46 --> Input Class Initialized
INFO - 2018-10-26 15:27:46 --> Language Class Initialized
INFO - 2018-10-26 15:27:46 --> Loader Class Initialized
INFO - 2018-10-26 15:27:46 --> Helper loaded: url_helper
INFO - 2018-10-26 15:27:46 --> Helper loaded: form_helper
INFO - 2018-10-26 15:27:46 --> Helper loaded: html_helper
INFO - 2018-10-26 15:27:46 --> Database Driver Class Initialized
INFO - 2018-10-26 15:27:46 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:27:46 --> Model "User_model" initialized
INFO - 2018-10-26 15:27:46 --> Controller Class Initialized
INFO - 2018-10-26 15:27:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:27:47 --> Config Class Initialized
INFO - 2018-10-26 15:27:47 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:27:47 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:27:47 --> Utf8 Class Initialized
INFO - 2018-10-26 15:27:47 --> URI Class Initialized
INFO - 2018-10-26 15:27:47 --> Router Class Initialized
INFO - 2018-10-26 15:27:47 --> Output Class Initialized
INFO - 2018-10-26 15:27:47 --> Security Class Initialized
DEBUG - 2018-10-26 15:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:27:47 --> Input Class Initialized
INFO - 2018-10-26 15:27:47 --> Language Class Initialized
INFO - 2018-10-26 15:27:47 --> Loader Class Initialized
INFO - 2018-10-26 15:27:47 --> Helper loaded: url_helper
INFO - 2018-10-26 15:27:47 --> Helper loaded: form_helper
INFO - 2018-10-26 15:27:47 --> Helper loaded: html_helper
INFO - 2018-10-26 15:27:47 --> Database Driver Class Initialized
INFO - 2018-10-26 15:27:47 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:27:47 --> Model "User_model" initialized
INFO - 2018-10-26 15:27:47 --> Controller Class Initialized
INFO - 2018-10-26 15:27:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:27:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:27:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:27:47 --> Final output sent to browser
DEBUG - 2018-10-26 15:27:47 --> Total execution time: 0.0330
INFO - 2018-10-26 15:27:48 --> Config Class Initialized
INFO - 2018-10-26 15:27:48 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:27:48 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:27:48 --> Utf8 Class Initialized
INFO - 2018-10-26 15:27:48 --> URI Class Initialized
INFO - 2018-10-26 15:27:48 --> Router Class Initialized
INFO - 2018-10-26 15:27:48 --> Output Class Initialized
INFO - 2018-10-26 15:27:48 --> Security Class Initialized
DEBUG - 2018-10-26 15:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:27:48 --> Input Class Initialized
INFO - 2018-10-26 15:27:48 --> Language Class Initialized
INFO - 2018-10-26 15:27:48 --> Loader Class Initialized
INFO - 2018-10-26 15:27:48 --> Helper loaded: url_helper
INFO - 2018-10-26 15:27:48 --> Helper loaded: form_helper
INFO - 2018-10-26 15:27:48 --> Helper loaded: html_helper
INFO - 2018-10-26 15:27:48 --> Database Driver Class Initialized
INFO - 2018-10-26 15:27:48 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:27:48 --> Model "User_model" initialized
INFO - 2018-10-26 15:27:48 --> Controller Class Initialized
INFO - 2018-10-26 15:27:48 --> Config Class Initialized
INFO - 2018-10-26 15:27:48 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:27:48 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:27:48 --> Utf8 Class Initialized
INFO - 2018-10-26 15:27:48 --> URI Class Initialized
INFO - 2018-10-26 15:27:48 --> Router Class Initialized
INFO - 2018-10-26 15:27:48 --> Output Class Initialized
INFO - 2018-10-26 15:27:48 --> Security Class Initialized
DEBUG - 2018-10-26 15:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:27:48 --> Input Class Initialized
INFO - 2018-10-26 15:27:48 --> Language Class Initialized
INFO - 2018-10-26 15:27:48 --> Loader Class Initialized
INFO - 2018-10-26 15:27:48 --> Helper loaded: url_helper
INFO - 2018-10-26 15:27:48 --> Helper loaded: form_helper
INFO - 2018-10-26 15:27:48 --> Helper loaded: html_helper
INFO - 2018-10-26 15:27:48 --> Database Driver Class Initialized
INFO - 2018-10-26 15:27:48 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:27:48 --> Model "User_model" initialized
INFO - 2018-10-26 15:27:48 --> Controller Class Initialized
INFO - 2018-10-26 15:27:48 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:27:48 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:27:48 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:27:48 --> Final output sent to browser
DEBUG - 2018-10-26 15:27:48 --> Total execution time: 0.0330
INFO - 2018-10-26 15:28:52 --> Config Class Initialized
INFO - 2018-10-26 15:28:52 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:28:52 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:28:52 --> Utf8 Class Initialized
INFO - 2018-10-26 15:28:52 --> URI Class Initialized
INFO - 2018-10-26 15:28:52 --> Router Class Initialized
INFO - 2018-10-26 15:28:52 --> Output Class Initialized
INFO - 2018-10-26 15:28:52 --> Security Class Initialized
DEBUG - 2018-10-26 15:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:28:52 --> Input Class Initialized
INFO - 2018-10-26 15:28:52 --> Language Class Initialized
INFO - 2018-10-26 15:28:52 --> Loader Class Initialized
INFO - 2018-10-26 15:28:52 --> Helper loaded: url_helper
INFO - 2018-10-26 15:28:52 --> Helper loaded: form_helper
INFO - 2018-10-26 15:28:52 --> Helper loaded: html_helper
INFO - 2018-10-26 15:28:52 --> Database Driver Class Initialized
INFO - 2018-10-26 15:28:52 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:28:52 --> Model "User_model" initialized
INFO - 2018-10-26 15:28:52 --> Controller Class Initialized
INFO - 2018-10-26 15:28:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:28:53 --> Config Class Initialized
INFO - 2018-10-26 15:28:53 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:28:53 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:28:53 --> Utf8 Class Initialized
INFO - 2018-10-26 15:28:53 --> URI Class Initialized
INFO - 2018-10-26 15:28:53 --> Router Class Initialized
INFO - 2018-10-26 15:28:53 --> Output Class Initialized
INFO - 2018-10-26 15:28:53 --> Security Class Initialized
DEBUG - 2018-10-26 15:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:28:53 --> Input Class Initialized
INFO - 2018-10-26 15:28:53 --> Language Class Initialized
INFO - 2018-10-26 15:28:53 --> Loader Class Initialized
INFO - 2018-10-26 15:28:53 --> Helper loaded: url_helper
INFO - 2018-10-26 15:28:53 --> Helper loaded: form_helper
INFO - 2018-10-26 15:28:53 --> Helper loaded: html_helper
INFO - 2018-10-26 15:28:53 --> Database Driver Class Initialized
INFO - 2018-10-26 15:28:53 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:28:53 --> Model "User_model" initialized
INFO - 2018-10-26 15:28:53 --> Controller Class Initialized
INFO - 2018-10-26 15:28:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:28:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:28:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:28:53 --> Final output sent to browser
DEBUG - 2018-10-26 15:28:53 --> Total execution time: 0.0440
INFO - 2018-10-26 15:29:06 --> Config Class Initialized
INFO - 2018-10-26 15:29:06 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:29:06 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:29:06 --> Utf8 Class Initialized
INFO - 2018-10-26 15:29:06 --> URI Class Initialized
INFO - 2018-10-26 15:29:06 --> Router Class Initialized
INFO - 2018-10-26 15:29:06 --> Output Class Initialized
INFO - 2018-10-26 15:29:06 --> Security Class Initialized
DEBUG - 2018-10-26 15:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:29:06 --> Input Class Initialized
INFO - 2018-10-26 15:29:06 --> Language Class Initialized
INFO - 2018-10-26 15:29:06 --> Loader Class Initialized
INFO - 2018-10-26 15:29:06 --> Helper loaded: url_helper
INFO - 2018-10-26 15:29:06 --> Helper loaded: form_helper
INFO - 2018-10-26 15:29:06 --> Helper loaded: html_helper
INFO - 2018-10-26 15:29:06 --> Database Driver Class Initialized
INFO - 2018-10-26 15:29:06 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:29:06 --> Model "User_model" initialized
INFO - 2018-10-26 15:29:06 --> Controller Class Initialized
INFO - 2018-10-26 15:29:06 --> Config Class Initialized
INFO - 2018-10-26 15:29:06 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:29:06 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:29:06 --> Utf8 Class Initialized
INFO - 2018-10-26 15:29:06 --> URI Class Initialized
INFO - 2018-10-26 15:29:06 --> Router Class Initialized
INFO - 2018-10-26 15:29:06 --> Output Class Initialized
INFO - 2018-10-26 15:29:06 --> Security Class Initialized
DEBUG - 2018-10-26 15:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:29:06 --> Input Class Initialized
INFO - 2018-10-26 15:29:06 --> Language Class Initialized
INFO - 2018-10-26 15:29:06 --> Loader Class Initialized
INFO - 2018-10-26 15:29:06 --> Helper loaded: url_helper
INFO - 2018-10-26 15:29:06 --> Helper loaded: form_helper
INFO - 2018-10-26 15:29:06 --> Helper loaded: html_helper
INFO - 2018-10-26 15:29:06 --> Database Driver Class Initialized
INFO - 2018-10-26 15:29:06 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:29:06 --> Model "User_model" initialized
INFO - 2018-10-26 15:29:06 --> Controller Class Initialized
INFO - 2018-10-26 15:29:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:29:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:29:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:29:06 --> Final output sent to browser
DEBUG - 2018-10-26 15:29:06 --> Total execution time: 0.0410
INFO - 2018-10-26 15:29:44 --> Config Class Initialized
INFO - 2018-10-26 15:29:44 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:29:44 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:29:44 --> Utf8 Class Initialized
INFO - 2018-10-26 15:29:44 --> URI Class Initialized
INFO - 2018-10-26 15:29:44 --> Router Class Initialized
INFO - 2018-10-26 15:29:44 --> Output Class Initialized
INFO - 2018-10-26 15:29:44 --> Security Class Initialized
DEBUG - 2018-10-26 15:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:29:44 --> Input Class Initialized
INFO - 2018-10-26 15:29:44 --> Language Class Initialized
INFO - 2018-10-26 15:29:44 --> Loader Class Initialized
INFO - 2018-10-26 15:29:44 --> Helper loaded: url_helper
INFO - 2018-10-26 15:29:44 --> Helper loaded: form_helper
INFO - 2018-10-26 15:29:44 --> Helper loaded: html_helper
INFO - 2018-10-26 15:29:44 --> Database Driver Class Initialized
INFO - 2018-10-26 15:29:44 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:29:44 --> Model "User_model" initialized
INFO - 2018-10-26 15:29:44 --> Controller Class Initialized
INFO - 2018-10-26 15:29:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:29:44 --> Config Class Initialized
INFO - 2018-10-26 15:29:44 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:29:44 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:29:44 --> Utf8 Class Initialized
INFO - 2018-10-26 15:29:44 --> URI Class Initialized
INFO - 2018-10-26 15:29:44 --> Router Class Initialized
INFO - 2018-10-26 15:29:44 --> Output Class Initialized
INFO - 2018-10-26 15:29:44 --> Security Class Initialized
DEBUG - 2018-10-26 15:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:29:44 --> Input Class Initialized
INFO - 2018-10-26 15:29:44 --> Language Class Initialized
INFO - 2018-10-26 15:29:44 --> Loader Class Initialized
INFO - 2018-10-26 15:29:44 --> Helper loaded: url_helper
INFO - 2018-10-26 15:29:44 --> Helper loaded: form_helper
INFO - 2018-10-26 15:29:44 --> Helper loaded: html_helper
INFO - 2018-10-26 15:29:44 --> Database Driver Class Initialized
INFO - 2018-10-26 15:29:44 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:29:44 --> Model "User_model" initialized
INFO - 2018-10-26 15:29:44 --> Controller Class Initialized
INFO - 2018-10-26 15:29:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:29:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:29:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:29:44 --> Final output sent to browser
DEBUG - 2018-10-26 15:29:44 --> Total execution time: 0.0410
INFO - 2018-10-26 15:29:48 --> Config Class Initialized
INFO - 2018-10-26 15:29:48 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:29:48 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:29:48 --> Utf8 Class Initialized
INFO - 2018-10-26 15:29:48 --> URI Class Initialized
INFO - 2018-10-26 15:29:48 --> Router Class Initialized
INFO - 2018-10-26 15:29:48 --> Output Class Initialized
INFO - 2018-10-26 15:29:48 --> Security Class Initialized
DEBUG - 2018-10-26 15:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:29:48 --> Input Class Initialized
INFO - 2018-10-26 15:29:48 --> Language Class Initialized
INFO - 2018-10-26 15:29:48 --> Loader Class Initialized
INFO - 2018-10-26 15:29:48 --> Helper loaded: url_helper
INFO - 2018-10-26 15:29:48 --> Helper loaded: form_helper
INFO - 2018-10-26 15:29:48 --> Helper loaded: html_helper
INFO - 2018-10-26 15:29:48 --> Database Driver Class Initialized
INFO - 2018-10-26 15:29:48 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:29:48 --> Model "User_model" initialized
INFO - 2018-10-26 15:29:48 --> Controller Class Initialized
INFO - 2018-10-26 15:29:48 --> Config Class Initialized
INFO - 2018-10-26 15:29:48 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:29:48 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:29:48 --> Utf8 Class Initialized
INFO - 2018-10-26 15:29:48 --> URI Class Initialized
INFO - 2018-10-26 15:29:48 --> Router Class Initialized
INFO - 2018-10-26 15:29:48 --> Output Class Initialized
INFO - 2018-10-26 15:29:48 --> Security Class Initialized
DEBUG - 2018-10-26 15:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:29:48 --> Input Class Initialized
INFO - 2018-10-26 15:29:48 --> Language Class Initialized
INFO - 2018-10-26 15:29:48 --> Loader Class Initialized
INFO - 2018-10-26 15:29:48 --> Helper loaded: url_helper
INFO - 2018-10-26 15:29:48 --> Helper loaded: form_helper
INFO - 2018-10-26 15:29:48 --> Helper loaded: html_helper
INFO - 2018-10-26 15:29:48 --> Database Driver Class Initialized
INFO - 2018-10-26 15:29:48 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:29:48 --> Model "User_model" initialized
INFO - 2018-10-26 15:29:48 --> Controller Class Initialized
INFO - 2018-10-26 15:29:48 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:29:48 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:29:48 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:29:48 --> Final output sent to browser
DEBUG - 2018-10-26 15:29:48 --> Total execution time: 0.0410
INFO - 2018-10-26 15:29:50 --> Config Class Initialized
INFO - 2018-10-26 15:29:50 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:29:50 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:29:50 --> Utf8 Class Initialized
INFO - 2018-10-26 15:29:50 --> URI Class Initialized
INFO - 2018-10-26 15:29:50 --> Router Class Initialized
INFO - 2018-10-26 15:29:50 --> Output Class Initialized
INFO - 2018-10-26 15:29:50 --> Security Class Initialized
DEBUG - 2018-10-26 15:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:29:50 --> Input Class Initialized
INFO - 2018-10-26 15:29:50 --> Language Class Initialized
INFO - 2018-10-26 15:29:50 --> Loader Class Initialized
INFO - 2018-10-26 15:29:50 --> Helper loaded: url_helper
INFO - 2018-10-26 15:29:50 --> Helper loaded: form_helper
INFO - 2018-10-26 15:29:50 --> Helper loaded: html_helper
INFO - 2018-10-26 15:29:50 --> Database Driver Class Initialized
INFO - 2018-10-26 15:29:50 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:29:50 --> Model "User_model" initialized
INFO - 2018-10-26 15:29:50 --> Controller Class Initialized
INFO - 2018-10-26 15:29:50 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:29:50 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:29:50 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:29:50 --> Final output sent to browser
DEBUG - 2018-10-26 15:29:50 --> Total execution time: 0.0390
INFO - 2018-10-26 15:30:00 --> Config Class Initialized
INFO - 2018-10-26 15:30:00 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:30:00 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:30:00 --> Utf8 Class Initialized
INFO - 2018-10-26 15:30:00 --> URI Class Initialized
INFO - 2018-10-26 15:30:00 --> Router Class Initialized
INFO - 2018-10-26 15:30:00 --> Output Class Initialized
INFO - 2018-10-26 15:30:00 --> Security Class Initialized
DEBUG - 2018-10-26 15:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:30:00 --> Input Class Initialized
INFO - 2018-10-26 15:30:00 --> Language Class Initialized
INFO - 2018-10-26 15:30:00 --> Loader Class Initialized
INFO - 2018-10-26 15:30:00 --> Helper loaded: url_helper
INFO - 2018-10-26 15:30:00 --> Helper loaded: form_helper
INFO - 2018-10-26 15:30:00 --> Helper loaded: html_helper
INFO - 2018-10-26 15:30:00 --> Database Driver Class Initialized
INFO - 2018-10-26 15:30:00 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:30:00 --> Model "User_model" initialized
INFO - 2018-10-26 15:30:00 --> Controller Class Initialized
INFO - 2018-10-26 15:30:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:30:01 --> Config Class Initialized
INFO - 2018-10-26 15:30:01 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:30:01 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:30:01 --> Utf8 Class Initialized
INFO - 2018-10-26 15:30:01 --> URI Class Initialized
INFO - 2018-10-26 15:30:01 --> Router Class Initialized
INFO - 2018-10-26 15:30:01 --> Output Class Initialized
INFO - 2018-10-26 15:30:01 --> Security Class Initialized
DEBUG - 2018-10-26 15:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:30:01 --> Input Class Initialized
INFO - 2018-10-26 15:30:01 --> Language Class Initialized
INFO - 2018-10-26 15:30:01 --> Loader Class Initialized
INFO - 2018-10-26 15:30:01 --> Helper loaded: url_helper
INFO - 2018-10-26 15:30:01 --> Helper loaded: form_helper
INFO - 2018-10-26 15:30:01 --> Helper loaded: html_helper
INFO - 2018-10-26 15:30:01 --> Database Driver Class Initialized
INFO - 2018-10-26 15:30:01 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:30:01 --> Model "User_model" initialized
INFO - 2018-10-26 15:30:01 --> Controller Class Initialized
INFO - 2018-10-26 15:30:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:30:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:30:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:30:01 --> Final output sent to browser
DEBUG - 2018-10-26 15:30:01 --> Total execution time: 0.0440
INFO - 2018-10-26 15:30:04 --> Config Class Initialized
INFO - 2018-10-26 15:30:04 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:30:04 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:30:04 --> Utf8 Class Initialized
INFO - 2018-10-26 15:30:04 --> URI Class Initialized
INFO - 2018-10-26 15:30:04 --> Router Class Initialized
INFO - 2018-10-26 15:30:04 --> Output Class Initialized
INFO - 2018-10-26 15:30:04 --> Security Class Initialized
DEBUG - 2018-10-26 15:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:30:04 --> Input Class Initialized
INFO - 2018-10-26 15:30:04 --> Language Class Initialized
INFO - 2018-10-26 15:30:04 --> Loader Class Initialized
INFO - 2018-10-26 15:30:04 --> Helper loaded: url_helper
INFO - 2018-10-26 15:30:04 --> Helper loaded: form_helper
INFO - 2018-10-26 15:30:04 --> Helper loaded: html_helper
INFO - 2018-10-26 15:30:04 --> Database Driver Class Initialized
INFO - 2018-10-26 15:30:04 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:30:04 --> Model "User_model" initialized
INFO - 2018-10-26 15:30:04 --> Controller Class Initialized
INFO - 2018-10-26 15:30:04 --> Config Class Initialized
INFO - 2018-10-26 15:30:04 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:30:04 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:30:04 --> Utf8 Class Initialized
INFO - 2018-10-26 15:30:04 --> URI Class Initialized
INFO - 2018-10-26 15:30:04 --> Router Class Initialized
INFO - 2018-10-26 15:30:04 --> Output Class Initialized
INFO - 2018-10-26 15:30:04 --> Security Class Initialized
DEBUG - 2018-10-26 15:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:30:04 --> Input Class Initialized
INFO - 2018-10-26 15:30:04 --> Language Class Initialized
INFO - 2018-10-26 15:30:04 --> Loader Class Initialized
INFO - 2018-10-26 15:30:04 --> Helper loaded: url_helper
INFO - 2018-10-26 15:30:04 --> Helper loaded: form_helper
INFO - 2018-10-26 15:30:04 --> Helper loaded: html_helper
INFO - 2018-10-26 15:30:04 --> Database Driver Class Initialized
INFO - 2018-10-26 15:30:04 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:30:04 --> Model "User_model" initialized
INFO - 2018-10-26 15:30:04 --> Controller Class Initialized
INFO - 2018-10-26 15:30:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:30:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:30:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:30:04 --> Final output sent to browser
DEBUG - 2018-10-26 15:30:04 --> Total execution time: 0.0430
INFO - 2018-10-26 15:31:04 --> Config Class Initialized
INFO - 2018-10-26 15:31:04 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:31:04 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:31:04 --> Utf8 Class Initialized
INFO - 2018-10-26 15:31:04 --> URI Class Initialized
INFO - 2018-10-26 15:31:04 --> Router Class Initialized
INFO - 2018-10-26 15:31:04 --> Output Class Initialized
INFO - 2018-10-26 15:31:04 --> Security Class Initialized
DEBUG - 2018-10-26 15:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:31:04 --> Input Class Initialized
INFO - 2018-10-26 15:31:04 --> Language Class Initialized
INFO - 2018-10-26 15:31:04 --> Loader Class Initialized
INFO - 2018-10-26 15:31:04 --> Helper loaded: url_helper
INFO - 2018-10-26 15:31:04 --> Helper loaded: form_helper
INFO - 2018-10-26 15:31:04 --> Helper loaded: html_helper
INFO - 2018-10-26 15:31:04 --> Database Driver Class Initialized
INFO - 2018-10-26 15:31:04 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:31:04 --> Model "User_model" initialized
INFO - 2018-10-26 15:31:04 --> Controller Class Initialized
INFO - 2018-10-26 15:31:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:31:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:31:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:31:04 --> Final output sent to browser
DEBUG - 2018-10-26 15:31:04 --> Total execution time: 0.0420
INFO - 2018-10-26 15:31:05 --> Config Class Initialized
INFO - 2018-10-26 15:31:05 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:31:05 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:31:05 --> Utf8 Class Initialized
INFO - 2018-10-26 15:31:05 --> URI Class Initialized
INFO - 2018-10-26 15:31:05 --> Router Class Initialized
INFO - 2018-10-26 15:31:05 --> Output Class Initialized
INFO - 2018-10-26 15:31:05 --> Security Class Initialized
DEBUG - 2018-10-26 15:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:31:05 --> Input Class Initialized
INFO - 2018-10-26 15:31:05 --> Language Class Initialized
INFO - 2018-10-26 15:31:05 --> Loader Class Initialized
INFO - 2018-10-26 15:31:05 --> Helper loaded: url_helper
INFO - 2018-10-26 15:31:05 --> Helper loaded: form_helper
INFO - 2018-10-26 15:31:05 --> Helper loaded: html_helper
INFO - 2018-10-26 15:31:05 --> Database Driver Class Initialized
INFO - 2018-10-26 15:31:05 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:31:05 --> Model "User_model" initialized
INFO - 2018-10-26 15:31:05 --> Controller Class Initialized
INFO - 2018-10-26 15:31:05 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:31:05 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:31:05 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:31:05 --> Final output sent to browser
DEBUG - 2018-10-26 15:31:05 --> Total execution time: 0.0630
INFO - 2018-10-26 15:31:15 --> Config Class Initialized
INFO - 2018-10-26 15:31:15 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:31:15 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:31:15 --> Utf8 Class Initialized
INFO - 2018-10-26 15:31:15 --> URI Class Initialized
INFO - 2018-10-26 15:31:15 --> Router Class Initialized
INFO - 2018-10-26 15:31:15 --> Output Class Initialized
INFO - 2018-10-26 15:31:15 --> Security Class Initialized
DEBUG - 2018-10-26 15:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:31:15 --> Input Class Initialized
INFO - 2018-10-26 15:31:15 --> Language Class Initialized
INFO - 2018-10-26 15:31:15 --> Loader Class Initialized
INFO - 2018-10-26 15:31:15 --> Helper loaded: url_helper
INFO - 2018-10-26 15:31:15 --> Helper loaded: form_helper
INFO - 2018-10-26 15:31:15 --> Helper loaded: html_helper
INFO - 2018-10-26 15:31:15 --> Database Driver Class Initialized
INFO - 2018-10-26 15:31:15 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:31:15 --> Model "User_model" initialized
INFO - 2018-10-26 15:31:15 --> Controller Class Initialized
INFO - 2018-10-26 15:31:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:31:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:31:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:31:15 --> Final output sent to browser
DEBUG - 2018-10-26 15:31:15 --> Total execution time: 0.0410
INFO - 2018-10-26 15:31:30 --> Config Class Initialized
INFO - 2018-10-26 15:31:30 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:31:30 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:31:30 --> Utf8 Class Initialized
INFO - 2018-10-26 15:31:30 --> URI Class Initialized
INFO - 2018-10-26 15:31:30 --> Router Class Initialized
INFO - 2018-10-26 15:31:30 --> Output Class Initialized
INFO - 2018-10-26 15:31:30 --> Security Class Initialized
DEBUG - 2018-10-26 15:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:31:30 --> Input Class Initialized
INFO - 2018-10-26 15:31:30 --> Language Class Initialized
INFO - 2018-10-26 15:31:30 --> Loader Class Initialized
INFO - 2018-10-26 15:31:30 --> Helper loaded: url_helper
INFO - 2018-10-26 15:31:30 --> Helper loaded: form_helper
INFO - 2018-10-26 15:31:30 --> Helper loaded: html_helper
INFO - 2018-10-26 15:31:30 --> Database Driver Class Initialized
INFO - 2018-10-26 15:31:30 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:31:30 --> Model "User_model" initialized
INFO - 2018-10-26 15:31:30 --> Controller Class Initialized
INFO - 2018-10-26 15:31:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:31:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:31:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:31:30 --> Final output sent to browser
DEBUG - 2018-10-26 15:31:30 --> Total execution time: 0.0470
INFO - 2018-10-26 15:31:44 --> Config Class Initialized
INFO - 2018-10-26 15:31:44 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:31:44 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:31:44 --> Utf8 Class Initialized
INFO - 2018-10-26 15:31:44 --> URI Class Initialized
INFO - 2018-10-26 15:31:44 --> Router Class Initialized
INFO - 2018-10-26 15:31:44 --> Output Class Initialized
INFO - 2018-10-26 15:31:44 --> Security Class Initialized
DEBUG - 2018-10-26 15:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:31:44 --> Input Class Initialized
INFO - 2018-10-26 15:31:44 --> Language Class Initialized
INFO - 2018-10-26 15:31:44 --> Loader Class Initialized
INFO - 2018-10-26 15:31:44 --> Helper loaded: url_helper
INFO - 2018-10-26 15:31:44 --> Helper loaded: form_helper
INFO - 2018-10-26 15:31:44 --> Helper loaded: html_helper
INFO - 2018-10-26 15:31:44 --> Database Driver Class Initialized
INFO - 2018-10-26 15:31:44 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:31:44 --> Model "User_model" initialized
INFO - 2018-10-26 15:31:44 --> Controller Class Initialized
INFO - 2018-10-26 15:31:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:31:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:31:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:31:44 --> Final output sent to browser
DEBUG - 2018-10-26 15:31:44 --> Total execution time: 0.0450
INFO - 2018-10-26 15:31:47 --> Config Class Initialized
INFO - 2018-10-26 15:31:47 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:31:47 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:31:47 --> Utf8 Class Initialized
INFO - 2018-10-26 15:31:47 --> URI Class Initialized
INFO - 2018-10-26 15:31:47 --> Router Class Initialized
INFO - 2018-10-26 15:31:47 --> Output Class Initialized
INFO - 2018-10-26 15:31:47 --> Security Class Initialized
DEBUG - 2018-10-26 15:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:31:47 --> Input Class Initialized
INFO - 2018-10-26 15:31:47 --> Language Class Initialized
INFO - 2018-10-26 15:31:47 --> Loader Class Initialized
INFO - 2018-10-26 15:31:47 --> Helper loaded: url_helper
INFO - 2018-10-26 15:31:47 --> Helper loaded: form_helper
INFO - 2018-10-26 15:31:47 --> Helper loaded: html_helper
INFO - 2018-10-26 15:31:47 --> Database Driver Class Initialized
INFO - 2018-10-26 15:31:47 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:31:47 --> Model "User_model" initialized
INFO - 2018-10-26 15:31:47 --> Controller Class Initialized
INFO - 2018-10-26 15:31:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:31:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:31:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:31:47 --> Final output sent to browser
DEBUG - 2018-10-26 15:31:47 --> Total execution time: 0.0510
INFO - 2018-10-26 15:31:48 --> Config Class Initialized
INFO - 2018-10-26 15:31:48 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:31:48 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:31:48 --> Utf8 Class Initialized
INFO - 2018-10-26 15:31:48 --> URI Class Initialized
INFO - 2018-10-26 15:31:48 --> Router Class Initialized
INFO - 2018-10-26 15:31:48 --> Output Class Initialized
INFO - 2018-10-26 15:31:48 --> Security Class Initialized
DEBUG - 2018-10-26 15:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:31:48 --> Input Class Initialized
INFO - 2018-10-26 15:31:48 --> Language Class Initialized
INFO - 2018-10-26 15:31:48 --> Loader Class Initialized
INFO - 2018-10-26 15:31:48 --> Helper loaded: url_helper
INFO - 2018-10-26 15:31:48 --> Helper loaded: form_helper
INFO - 2018-10-26 15:31:48 --> Helper loaded: html_helper
INFO - 2018-10-26 15:31:48 --> Database Driver Class Initialized
INFO - 2018-10-26 15:31:48 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:31:48 --> Model "User_model" initialized
INFO - 2018-10-26 15:31:48 --> Controller Class Initialized
INFO - 2018-10-26 15:31:48 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:31:48 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:31:48 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:31:48 --> Final output sent to browser
DEBUG - 2018-10-26 15:31:48 --> Total execution time: 0.0570
INFO - 2018-10-26 15:32:01 --> Config Class Initialized
INFO - 2018-10-26 15:32:01 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:32:01 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:32:01 --> Utf8 Class Initialized
INFO - 2018-10-26 15:32:01 --> URI Class Initialized
INFO - 2018-10-26 15:32:01 --> Router Class Initialized
INFO - 2018-10-26 15:32:01 --> Output Class Initialized
INFO - 2018-10-26 15:32:01 --> Security Class Initialized
DEBUG - 2018-10-26 15:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:32:01 --> Input Class Initialized
INFO - 2018-10-26 15:32:01 --> Language Class Initialized
INFO - 2018-10-26 15:32:01 --> Loader Class Initialized
INFO - 2018-10-26 15:32:01 --> Helper loaded: url_helper
INFO - 2018-10-26 15:32:01 --> Helper loaded: form_helper
INFO - 2018-10-26 15:32:01 --> Helper loaded: html_helper
INFO - 2018-10-26 15:32:01 --> Database Driver Class Initialized
INFO - 2018-10-26 15:32:01 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:32:01 --> Model "User_model" initialized
INFO - 2018-10-26 15:32:01 --> Controller Class Initialized
INFO - 2018-10-26 15:32:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:32:01 --> Config Class Initialized
INFO - 2018-10-26 15:32:01 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:32:01 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:32:01 --> Utf8 Class Initialized
INFO - 2018-10-26 15:32:01 --> URI Class Initialized
INFO - 2018-10-26 15:32:01 --> Router Class Initialized
INFO - 2018-10-26 15:32:01 --> Output Class Initialized
INFO - 2018-10-26 15:32:01 --> Security Class Initialized
DEBUG - 2018-10-26 15:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:32:01 --> Input Class Initialized
INFO - 2018-10-26 15:32:01 --> Language Class Initialized
INFO - 2018-10-26 15:32:01 --> Loader Class Initialized
INFO - 2018-10-26 15:32:01 --> Helper loaded: url_helper
INFO - 2018-10-26 15:32:01 --> Helper loaded: form_helper
INFO - 2018-10-26 15:32:01 --> Helper loaded: html_helper
INFO - 2018-10-26 15:32:01 --> Database Driver Class Initialized
INFO - 2018-10-26 15:32:01 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:32:01 --> Model "User_model" initialized
INFO - 2018-10-26 15:32:01 --> Controller Class Initialized
INFO - 2018-10-26 15:32:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:32:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:32:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:32:01 --> Final output sent to browser
DEBUG - 2018-10-26 15:32:01 --> Total execution time: 0.0420
INFO - 2018-10-26 15:32:49 --> Config Class Initialized
INFO - 2018-10-26 15:32:49 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:32:49 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:32:49 --> Utf8 Class Initialized
INFO - 2018-10-26 15:32:49 --> URI Class Initialized
INFO - 2018-10-26 15:32:49 --> Router Class Initialized
INFO - 2018-10-26 15:32:49 --> Output Class Initialized
INFO - 2018-10-26 15:32:49 --> Security Class Initialized
DEBUG - 2018-10-26 15:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:32:49 --> Input Class Initialized
INFO - 2018-10-26 15:32:49 --> Language Class Initialized
INFO - 2018-10-26 15:32:49 --> Loader Class Initialized
INFO - 2018-10-26 15:32:49 --> Helper loaded: url_helper
INFO - 2018-10-26 15:32:49 --> Helper loaded: form_helper
INFO - 2018-10-26 15:32:49 --> Helper loaded: html_helper
INFO - 2018-10-26 15:32:49 --> Database Driver Class Initialized
INFO - 2018-10-26 15:32:49 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:32:49 --> Model "User_model" initialized
INFO - 2018-10-26 15:32:49 --> Controller Class Initialized
INFO - 2018-10-26 15:32:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:32:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:32:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:32:49 --> Final output sent to browser
DEBUG - 2018-10-26 15:32:49 --> Total execution time: 0.0570
INFO - 2018-10-26 15:33:42 --> Config Class Initialized
INFO - 2018-10-26 15:33:42 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:33:42 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:33:42 --> Utf8 Class Initialized
INFO - 2018-10-26 15:33:42 --> URI Class Initialized
INFO - 2018-10-26 15:33:42 --> Router Class Initialized
INFO - 2018-10-26 15:33:42 --> Output Class Initialized
INFO - 2018-10-26 15:33:42 --> Security Class Initialized
DEBUG - 2018-10-26 15:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:33:42 --> Input Class Initialized
INFO - 2018-10-26 15:33:42 --> Language Class Initialized
INFO - 2018-10-26 15:33:42 --> Loader Class Initialized
INFO - 2018-10-26 15:33:42 --> Helper loaded: url_helper
INFO - 2018-10-26 15:33:42 --> Helper loaded: form_helper
INFO - 2018-10-26 15:33:42 --> Helper loaded: html_helper
INFO - 2018-10-26 15:33:42 --> Database Driver Class Initialized
INFO - 2018-10-26 15:33:42 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:33:42 --> Model "User_model" initialized
INFO - 2018-10-26 15:33:42 --> Controller Class Initialized
INFO - 2018-10-26 15:33:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:33:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:33:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:33:42 --> Final output sent to browser
DEBUG - 2018-10-26 15:33:42 --> Total execution time: 0.0440
INFO - 2018-10-26 15:33:47 --> Config Class Initialized
INFO - 2018-10-26 15:33:47 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:33:47 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:33:47 --> Utf8 Class Initialized
INFO - 2018-10-26 15:33:47 --> URI Class Initialized
INFO - 2018-10-26 15:33:47 --> Router Class Initialized
INFO - 2018-10-26 15:33:47 --> Output Class Initialized
INFO - 2018-10-26 15:33:47 --> Security Class Initialized
DEBUG - 2018-10-26 15:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:33:47 --> Input Class Initialized
INFO - 2018-10-26 15:33:47 --> Language Class Initialized
INFO - 2018-10-26 15:33:47 --> Loader Class Initialized
INFO - 2018-10-26 15:33:47 --> Helper loaded: url_helper
INFO - 2018-10-26 15:33:47 --> Helper loaded: form_helper
INFO - 2018-10-26 15:33:47 --> Helper loaded: html_helper
INFO - 2018-10-26 15:33:47 --> Database Driver Class Initialized
INFO - 2018-10-26 15:33:47 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:33:47 --> Model "User_model" initialized
INFO - 2018-10-26 15:33:47 --> Controller Class Initialized
INFO - 2018-10-26 15:33:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:33:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:33:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:33:47 --> Final output sent to browser
DEBUG - 2018-10-26 15:33:47 --> Total execution time: 0.0650
INFO - 2018-10-26 15:33:48 --> Config Class Initialized
INFO - 2018-10-26 15:33:48 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:33:48 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:33:48 --> Utf8 Class Initialized
INFO - 2018-10-26 15:33:48 --> URI Class Initialized
INFO - 2018-10-26 15:33:48 --> Router Class Initialized
INFO - 2018-10-26 15:33:48 --> Output Class Initialized
INFO - 2018-10-26 15:33:48 --> Security Class Initialized
DEBUG - 2018-10-26 15:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:33:48 --> Input Class Initialized
INFO - 2018-10-26 15:33:48 --> Language Class Initialized
INFO - 2018-10-26 15:33:48 --> Loader Class Initialized
INFO - 2018-10-26 15:33:48 --> Helper loaded: url_helper
INFO - 2018-10-26 15:33:48 --> Helper loaded: form_helper
INFO - 2018-10-26 15:33:48 --> Helper loaded: html_helper
INFO - 2018-10-26 15:33:48 --> Database Driver Class Initialized
INFO - 2018-10-26 15:33:48 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:33:48 --> Model "User_model" initialized
INFO - 2018-10-26 15:33:48 --> Controller Class Initialized
INFO - 2018-10-26 15:33:48 --> Config Class Initialized
INFO - 2018-10-26 15:33:48 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:33:48 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:33:48 --> Utf8 Class Initialized
INFO - 2018-10-26 15:33:48 --> URI Class Initialized
INFO - 2018-10-26 15:33:48 --> Router Class Initialized
INFO - 2018-10-26 15:33:48 --> Output Class Initialized
INFO - 2018-10-26 15:33:48 --> Security Class Initialized
DEBUG - 2018-10-26 15:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:33:48 --> Input Class Initialized
INFO - 2018-10-26 15:33:48 --> Language Class Initialized
INFO - 2018-10-26 15:33:48 --> Loader Class Initialized
INFO - 2018-10-26 15:33:48 --> Helper loaded: url_helper
INFO - 2018-10-26 15:33:48 --> Helper loaded: form_helper
INFO - 2018-10-26 15:33:48 --> Helper loaded: html_helper
INFO - 2018-10-26 15:33:48 --> Database Driver Class Initialized
INFO - 2018-10-26 15:33:48 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:33:48 --> Model "User_model" initialized
INFO - 2018-10-26 15:33:48 --> Controller Class Initialized
INFO - 2018-10-26 15:33:48 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:33:48 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:33:48 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:33:48 --> Final output sent to browser
DEBUG - 2018-10-26 15:33:48 --> Total execution time: 0.0350
INFO - 2018-10-26 15:33:49 --> Config Class Initialized
INFO - 2018-10-26 15:33:49 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:33:49 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:33:49 --> Utf8 Class Initialized
INFO - 2018-10-26 15:33:49 --> URI Class Initialized
INFO - 2018-10-26 15:33:49 --> Router Class Initialized
INFO - 2018-10-26 15:33:49 --> Output Class Initialized
INFO - 2018-10-26 15:33:49 --> Security Class Initialized
DEBUG - 2018-10-26 15:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:33:49 --> Input Class Initialized
INFO - 2018-10-26 15:33:49 --> Language Class Initialized
INFO - 2018-10-26 15:33:49 --> Loader Class Initialized
INFO - 2018-10-26 15:33:49 --> Helper loaded: url_helper
INFO - 2018-10-26 15:33:49 --> Helper loaded: form_helper
INFO - 2018-10-26 15:33:49 --> Helper loaded: html_helper
INFO - 2018-10-26 15:33:49 --> Database Driver Class Initialized
INFO - 2018-10-26 15:33:49 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:33:49 --> Model "User_model" initialized
INFO - 2018-10-26 15:33:49 --> Controller Class Initialized
INFO - 2018-10-26 15:33:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:33:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:33:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:33:49 --> Final output sent to browser
DEBUG - 2018-10-26 15:33:49 --> Total execution time: 0.0500
INFO - 2018-10-26 15:34:01 --> Config Class Initialized
INFO - 2018-10-26 15:34:01 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:34:01 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:34:01 --> Utf8 Class Initialized
INFO - 2018-10-26 15:34:01 --> URI Class Initialized
INFO - 2018-10-26 15:34:01 --> Router Class Initialized
INFO - 2018-10-26 15:34:01 --> Output Class Initialized
INFO - 2018-10-26 15:34:01 --> Security Class Initialized
DEBUG - 2018-10-26 15:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:34:01 --> Input Class Initialized
INFO - 2018-10-26 15:34:01 --> Language Class Initialized
INFO - 2018-10-26 15:34:01 --> Loader Class Initialized
INFO - 2018-10-26 15:34:01 --> Helper loaded: url_helper
INFO - 2018-10-26 15:34:01 --> Helper loaded: form_helper
INFO - 2018-10-26 15:34:01 --> Helper loaded: html_helper
INFO - 2018-10-26 15:34:01 --> Database Driver Class Initialized
INFO - 2018-10-26 15:34:01 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:34:01 --> Model "User_model" initialized
INFO - 2018-10-26 15:34:01 --> Controller Class Initialized
INFO - 2018-10-26 15:34:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:34:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:34:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:34:01 --> Final output sent to browser
DEBUG - 2018-10-26 15:34:01 --> Total execution time: 0.0640
INFO - 2018-10-26 15:34:09 --> Config Class Initialized
INFO - 2018-10-26 15:34:09 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:34:09 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:34:09 --> Utf8 Class Initialized
INFO - 2018-10-26 15:34:09 --> URI Class Initialized
INFO - 2018-10-26 15:34:09 --> Router Class Initialized
INFO - 2018-10-26 15:34:09 --> Output Class Initialized
INFO - 2018-10-26 15:34:09 --> Security Class Initialized
DEBUG - 2018-10-26 15:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:34:09 --> Input Class Initialized
INFO - 2018-10-26 15:34:09 --> Language Class Initialized
INFO - 2018-10-26 15:34:09 --> Loader Class Initialized
INFO - 2018-10-26 15:34:09 --> Helper loaded: url_helper
INFO - 2018-10-26 15:34:09 --> Helper loaded: form_helper
INFO - 2018-10-26 15:34:09 --> Helper loaded: html_helper
INFO - 2018-10-26 15:34:09 --> Database Driver Class Initialized
INFO - 2018-10-26 15:34:09 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:34:09 --> Model "User_model" initialized
INFO - 2018-10-26 15:34:09 --> Controller Class Initialized
INFO - 2018-10-26 15:34:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:34:10 --> Config Class Initialized
INFO - 2018-10-26 15:34:10 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:34:10 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:34:10 --> Utf8 Class Initialized
INFO - 2018-10-26 15:34:10 --> URI Class Initialized
INFO - 2018-10-26 15:34:10 --> Router Class Initialized
INFO - 2018-10-26 15:34:10 --> Output Class Initialized
INFO - 2018-10-26 15:34:10 --> Security Class Initialized
DEBUG - 2018-10-26 15:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:34:10 --> Input Class Initialized
INFO - 2018-10-26 15:34:10 --> Language Class Initialized
INFO - 2018-10-26 15:34:10 --> Loader Class Initialized
INFO - 2018-10-26 15:34:10 --> Helper loaded: url_helper
INFO - 2018-10-26 15:34:10 --> Helper loaded: form_helper
INFO - 2018-10-26 15:34:10 --> Helper loaded: html_helper
INFO - 2018-10-26 15:34:10 --> Database Driver Class Initialized
INFO - 2018-10-26 15:34:10 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:34:10 --> Model "User_model" initialized
INFO - 2018-10-26 15:34:10 --> Controller Class Initialized
INFO - 2018-10-26 15:34:10 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:34:10 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:34:10 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:34:10 --> Final output sent to browser
DEBUG - 2018-10-26 15:34:10 --> Total execution time: 0.0430
INFO - 2018-10-26 15:35:01 --> Config Class Initialized
INFO - 2018-10-26 15:35:01 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:35:01 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:35:01 --> Utf8 Class Initialized
INFO - 2018-10-26 15:35:01 --> URI Class Initialized
INFO - 2018-10-26 15:35:01 --> Router Class Initialized
INFO - 2018-10-26 15:35:01 --> Output Class Initialized
INFO - 2018-10-26 15:35:01 --> Security Class Initialized
DEBUG - 2018-10-26 15:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:35:01 --> Input Class Initialized
INFO - 2018-10-26 15:35:01 --> Language Class Initialized
INFO - 2018-10-26 15:35:01 --> Loader Class Initialized
INFO - 2018-10-26 15:35:01 --> Helper loaded: url_helper
INFO - 2018-10-26 15:35:01 --> Helper loaded: form_helper
INFO - 2018-10-26 15:35:01 --> Helper loaded: html_helper
INFO - 2018-10-26 15:35:01 --> Database Driver Class Initialized
INFO - 2018-10-26 15:35:01 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:35:01 --> Model "User_model" initialized
INFO - 2018-10-26 15:35:01 --> Controller Class Initialized
INFO - 2018-10-26 15:35:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:35:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:35:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:35:01 --> Final output sent to browser
DEBUG - 2018-10-26 15:35:01 --> Total execution time: 0.0610
INFO - 2018-10-26 15:35:14 --> Config Class Initialized
INFO - 2018-10-26 15:35:14 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:35:14 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:35:14 --> Utf8 Class Initialized
INFO - 2018-10-26 15:35:14 --> URI Class Initialized
INFO - 2018-10-26 15:35:14 --> Router Class Initialized
INFO - 2018-10-26 15:35:14 --> Output Class Initialized
INFO - 2018-10-26 15:35:14 --> Security Class Initialized
DEBUG - 2018-10-26 15:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:35:14 --> Input Class Initialized
INFO - 2018-10-26 15:35:14 --> Language Class Initialized
INFO - 2018-10-26 15:35:14 --> Loader Class Initialized
INFO - 2018-10-26 15:35:14 --> Helper loaded: url_helper
INFO - 2018-10-26 15:35:14 --> Helper loaded: form_helper
INFO - 2018-10-26 15:35:14 --> Helper loaded: html_helper
INFO - 2018-10-26 15:35:14 --> Database Driver Class Initialized
INFO - 2018-10-26 15:35:14 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:35:14 --> Model "User_model" initialized
INFO - 2018-10-26 15:35:14 --> Controller Class Initialized
INFO - 2018-10-26 15:35:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:35:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:35:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:35:14 --> Final output sent to browser
DEBUG - 2018-10-26 15:35:14 --> Total execution time: 0.0600
INFO - 2018-10-26 15:35:16 --> Config Class Initialized
INFO - 2018-10-26 15:35:16 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:35:16 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:35:16 --> Utf8 Class Initialized
INFO - 2018-10-26 15:35:16 --> URI Class Initialized
INFO - 2018-10-26 15:35:16 --> Router Class Initialized
INFO - 2018-10-26 15:35:16 --> Output Class Initialized
INFO - 2018-10-26 15:35:16 --> Security Class Initialized
DEBUG - 2018-10-26 15:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:35:16 --> Input Class Initialized
INFO - 2018-10-26 15:35:16 --> Language Class Initialized
INFO - 2018-10-26 15:35:16 --> Loader Class Initialized
INFO - 2018-10-26 15:35:16 --> Helper loaded: url_helper
INFO - 2018-10-26 15:35:16 --> Helper loaded: form_helper
INFO - 2018-10-26 15:35:16 --> Helper loaded: html_helper
INFO - 2018-10-26 15:35:16 --> Database Driver Class Initialized
INFO - 2018-10-26 15:35:16 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:35:16 --> Model "User_model" initialized
INFO - 2018-10-26 15:35:16 --> Controller Class Initialized
INFO - 2018-10-26 15:35:16 --> Config Class Initialized
INFO - 2018-10-26 15:35:16 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:35:16 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:35:16 --> Utf8 Class Initialized
INFO - 2018-10-26 15:35:16 --> URI Class Initialized
INFO - 2018-10-26 15:35:16 --> Router Class Initialized
INFO - 2018-10-26 15:35:16 --> Output Class Initialized
INFO - 2018-10-26 15:35:16 --> Security Class Initialized
DEBUG - 2018-10-26 15:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:35:16 --> Input Class Initialized
INFO - 2018-10-26 15:35:16 --> Language Class Initialized
INFO - 2018-10-26 15:35:16 --> Loader Class Initialized
INFO - 2018-10-26 15:35:16 --> Helper loaded: url_helper
INFO - 2018-10-26 15:35:16 --> Helper loaded: form_helper
INFO - 2018-10-26 15:35:16 --> Helper loaded: html_helper
INFO - 2018-10-26 15:35:16 --> Database Driver Class Initialized
INFO - 2018-10-26 15:35:16 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:35:16 --> Model "User_model" initialized
INFO - 2018-10-26 15:35:16 --> Controller Class Initialized
INFO - 2018-10-26 15:35:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:35:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:35:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:35:16 --> Final output sent to browser
DEBUG - 2018-10-26 15:35:16 --> Total execution time: 0.0400
INFO - 2018-10-26 15:35:17 --> Config Class Initialized
INFO - 2018-10-26 15:35:17 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:35:17 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:35:17 --> Utf8 Class Initialized
INFO - 2018-10-26 15:35:17 --> URI Class Initialized
INFO - 2018-10-26 15:35:17 --> Router Class Initialized
INFO - 2018-10-26 15:35:17 --> Output Class Initialized
INFO - 2018-10-26 15:35:17 --> Security Class Initialized
DEBUG - 2018-10-26 15:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:35:17 --> Input Class Initialized
INFO - 2018-10-26 15:35:17 --> Language Class Initialized
INFO - 2018-10-26 15:35:17 --> Loader Class Initialized
INFO - 2018-10-26 15:35:17 --> Helper loaded: url_helper
INFO - 2018-10-26 15:35:17 --> Helper loaded: form_helper
INFO - 2018-10-26 15:35:17 --> Helper loaded: html_helper
INFO - 2018-10-26 15:35:17 --> Database Driver Class Initialized
INFO - 2018-10-26 15:35:17 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:35:17 --> Model "User_model" initialized
INFO - 2018-10-26 15:35:17 --> Controller Class Initialized
INFO - 2018-10-26 15:35:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:35:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:35:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:35:17 --> Final output sent to browser
DEBUG - 2018-10-26 15:35:17 --> Total execution time: 0.0490
INFO - 2018-10-26 15:35:18 --> Config Class Initialized
INFO - 2018-10-26 15:35:18 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:35:18 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:35:18 --> Utf8 Class Initialized
INFO - 2018-10-26 15:35:18 --> URI Class Initialized
INFO - 2018-10-26 15:35:18 --> Router Class Initialized
INFO - 2018-10-26 15:35:18 --> Output Class Initialized
INFO - 2018-10-26 15:35:18 --> Security Class Initialized
DEBUG - 2018-10-26 15:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:35:18 --> Input Class Initialized
INFO - 2018-10-26 15:35:18 --> Language Class Initialized
INFO - 2018-10-26 15:35:18 --> Loader Class Initialized
INFO - 2018-10-26 15:35:18 --> Helper loaded: url_helper
INFO - 2018-10-26 15:35:18 --> Helper loaded: form_helper
INFO - 2018-10-26 15:35:18 --> Helper loaded: html_helper
INFO - 2018-10-26 15:35:18 --> Database Driver Class Initialized
INFO - 2018-10-26 15:35:18 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:35:18 --> Model "User_model" initialized
INFO - 2018-10-26 15:35:18 --> Controller Class Initialized
INFO - 2018-10-26 15:35:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:35:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:35:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:35:18 --> Final output sent to browser
DEBUG - 2018-10-26 15:35:18 --> Total execution time: 0.0620
INFO - 2018-10-26 15:35:19 --> Config Class Initialized
INFO - 2018-10-26 15:35:19 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:35:19 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:35:19 --> Utf8 Class Initialized
INFO - 2018-10-26 15:35:19 --> URI Class Initialized
INFO - 2018-10-26 15:35:19 --> Router Class Initialized
INFO - 2018-10-26 15:35:19 --> Output Class Initialized
INFO - 2018-10-26 15:35:19 --> Security Class Initialized
DEBUG - 2018-10-26 15:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:35:19 --> Input Class Initialized
INFO - 2018-10-26 15:35:19 --> Language Class Initialized
INFO - 2018-10-26 15:35:19 --> Loader Class Initialized
INFO - 2018-10-26 15:35:19 --> Helper loaded: url_helper
INFO - 2018-10-26 15:35:19 --> Helper loaded: form_helper
INFO - 2018-10-26 15:35:19 --> Helper loaded: html_helper
INFO - 2018-10-26 15:35:19 --> Database Driver Class Initialized
INFO - 2018-10-26 15:35:19 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:35:19 --> Model "User_model" initialized
INFO - 2018-10-26 15:35:19 --> Controller Class Initialized
INFO - 2018-10-26 15:35:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:35:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:35:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:35:19 --> Final output sent to browser
DEBUG - 2018-10-26 15:35:19 --> Total execution time: 0.0590
INFO - 2018-10-26 15:35:19 --> Config Class Initialized
INFO - 2018-10-26 15:35:19 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:35:19 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:35:19 --> Utf8 Class Initialized
INFO - 2018-10-26 15:35:19 --> URI Class Initialized
INFO - 2018-10-26 15:35:19 --> Router Class Initialized
INFO - 2018-10-26 15:35:19 --> Output Class Initialized
INFO - 2018-10-26 15:35:19 --> Security Class Initialized
DEBUG - 2018-10-26 15:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:35:19 --> Input Class Initialized
INFO - 2018-10-26 15:35:19 --> Language Class Initialized
INFO - 2018-10-26 15:35:19 --> Loader Class Initialized
INFO - 2018-10-26 15:35:19 --> Helper loaded: url_helper
INFO - 2018-10-26 15:35:19 --> Helper loaded: form_helper
INFO - 2018-10-26 15:35:19 --> Helper loaded: html_helper
INFO - 2018-10-26 15:35:19 --> Database Driver Class Initialized
INFO - 2018-10-26 15:35:19 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:35:19 --> Model "User_model" initialized
INFO - 2018-10-26 15:35:19 --> Controller Class Initialized
INFO - 2018-10-26 15:35:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:35:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:35:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:35:19 --> Final output sent to browser
DEBUG - 2018-10-26 15:35:19 --> Total execution time: 0.0550
INFO - 2018-10-26 15:36:42 --> Config Class Initialized
INFO - 2018-10-26 15:36:42 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:36:42 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:36:42 --> Utf8 Class Initialized
INFO - 2018-10-26 15:36:42 --> URI Class Initialized
INFO - 2018-10-26 15:36:42 --> Router Class Initialized
INFO - 2018-10-26 15:36:42 --> Output Class Initialized
INFO - 2018-10-26 15:36:42 --> Security Class Initialized
DEBUG - 2018-10-26 15:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:36:42 --> Input Class Initialized
INFO - 2018-10-26 15:36:42 --> Language Class Initialized
INFO - 2018-10-26 15:36:42 --> Loader Class Initialized
INFO - 2018-10-26 15:36:42 --> Helper loaded: url_helper
INFO - 2018-10-26 15:36:42 --> Helper loaded: form_helper
INFO - 2018-10-26 15:36:42 --> Helper loaded: html_helper
INFO - 2018-10-26 15:36:42 --> Database Driver Class Initialized
INFO - 2018-10-26 15:36:42 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:36:42 --> Model "User_model" initialized
INFO - 2018-10-26 15:36:42 --> Controller Class Initialized
INFO - 2018-10-26 15:36:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:36:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:36:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:36:42 --> Final output sent to browser
DEBUG - 2018-10-26 15:36:42 --> Total execution time: 0.0600
INFO - 2018-10-26 15:36:43 --> Config Class Initialized
INFO - 2018-10-26 15:36:43 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:36:43 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:36:43 --> Utf8 Class Initialized
INFO - 2018-10-26 15:36:43 --> URI Class Initialized
INFO - 2018-10-26 15:36:43 --> Router Class Initialized
INFO - 2018-10-26 15:36:43 --> Output Class Initialized
INFO - 2018-10-26 15:36:43 --> Security Class Initialized
DEBUG - 2018-10-26 15:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:36:43 --> Input Class Initialized
INFO - 2018-10-26 15:36:43 --> Language Class Initialized
INFO - 2018-10-26 15:36:43 --> Loader Class Initialized
INFO - 2018-10-26 15:36:43 --> Helper loaded: url_helper
INFO - 2018-10-26 15:36:43 --> Helper loaded: form_helper
INFO - 2018-10-26 15:36:43 --> Helper loaded: html_helper
INFO - 2018-10-26 15:36:43 --> Database Driver Class Initialized
INFO - 2018-10-26 15:36:43 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:36:43 --> Model "User_model" initialized
INFO - 2018-10-26 15:36:43 --> Controller Class Initialized
INFO - 2018-10-26 15:36:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:36:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:36:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:36:43 --> Final output sent to browser
DEBUG - 2018-10-26 15:36:43 --> Total execution time: 0.0640
INFO - 2018-10-26 15:36:52 --> Config Class Initialized
INFO - 2018-10-26 15:36:52 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:36:52 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:36:52 --> Utf8 Class Initialized
INFO - 2018-10-26 15:36:52 --> URI Class Initialized
INFO - 2018-10-26 15:36:52 --> Router Class Initialized
INFO - 2018-10-26 15:36:52 --> Output Class Initialized
INFO - 2018-10-26 15:36:52 --> Security Class Initialized
DEBUG - 2018-10-26 15:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:36:52 --> Input Class Initialized
INFO - 2018-10-26 15:36:52 --> Language Class Initialized
INFO - 2018-10-26 15:36:52 --> Loader Class Initialized
INFO - 2018-10-26 15:36:52 --> Helper loaded: url_helper
INFO - 2018-10-26 15:36:52 --> Helper loaded: form_helper
INFO - 2018-10-26 15:36:52 --> Helper loaded: html_helper
INFO - 2018-10-26 15:36:52 --> Database Driver Class Initialized
INFO - 2018-10-26 15:36:52 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:36:52 --> Model "User_model" initialized
INFO - 2018-10-26 15:36:52 --> Controller Class Initialized
INFO - 2018-10-26 15:36:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:36:53 --> Config Class Initialized
INFO - 2018-10-26 15:36:53 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:36:53 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:36:53 --> Utf8 Class Initialized
INFO - 2018-10-26 15:36:53 --> URI Class Initialized
INFO - 2018-10-26 15:36:53 --> Router Class Initialized
INFO - 2018-10-26 15:36:53 --> Output Class Initialized
INFO - 2018-10-26 15:36:53 --> Security Class Initialized
DEBUG - 2018-10-26 15:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:36:53 --> Input Class Initialized
INFO - 2018-10-26 15:36:53 --> Language Class Initialized
INFO - 2018-10-26 15:36:53 --> Loader Class Initialized
INFO - 2018-10-26 15:36:53 --> Helper loaded: url_helper
INFO - 2018-10-26 15:36:53 --> Helper loaded: form_helper
INFO - 2018-10-26 15:36:53 --> Helper loaded: html_helper
INFO - 2018-10-26 15:36:53 --> Database Driver Class Initialized
INFO - 2018-10-26 15:36:53 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:36:53 --> Model "User_model" initialized
INFO - 2018-10-26 15:36:53 --> Controller Class Initialized
INFO - 2018-10-26 15:36:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:36:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:36:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:36:53 --> Final output sent to browser
DEBUG - 2018-10-26 15:36:53 --> Total execution time: 0.0360
INFO - 2018-10-26 15:36:56 --> Config Class Initialized
INFO - 2018-10-26 15:36:56 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:36:56 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:36:56 --> Utf8 Class Initialized
INFO - 2018-10-26 15:36:56 --> URI Class Initialized
INFO - 2018-10-26 15:36:56 --> Router Class Initialized
INFO - 2018-10-26 15:36:56 --> Output Class Initialized
INFO - 2018-10-26 15:36:56 --> Security Class Initialized
DEBUG - 2018-10-26 15:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:36:56 --> Input Class Initialized
INFO - 2018-10-26 15:36:56 --> Language Class Initialized
INFO - 2018-10-26 15:36:56 --> Loader Class Initialized
INFO - 2018-10-26 15:36:56 --> Helper loaded: url_helper
INFO - 2018-10-26 15:36:56 --> Helper loaded: form_helper
INFO - 2018-10-26 15:36:56 --> Helper loaded: html_helper
INFO - 2018-10-26 15:36:56 --> Database Driver Class Initialized
INFO - 2018-10-26 15:36:56 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:36:56 --> Model "User_model" initialized
INFO - 2018-10-26 15:36:56 --> Controller Class Initialized
INFO - 2018-10-26 15:36:56 --> Config Class Initialized
INFO - 2018-10-26 15:36:56 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:36:56 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:36:56 --> Utf8 Class Initialized
INFO - 2018-10-26 15:36:56 --> URI Class Initialized
INFO - 2018-10-26 15:36:56 --> Router Class Initialized
INFO - 2018-10-26 15:36:56 --> Output Class Initialized
INFO - 2018-10-26 15:36:56 --> Security Class Initialized
DEBUG - 2018-10-26 15:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:36:56 --> Input Class Initialized
INFO - 2018-10-26 15:36:56 --> Language Class Initialized
INFO - 2018-10-26 15:36:56 --> Loader Class Initialized
INFO - 2018-10-26 15:36:56 --> Helper loaded: url_helper
INFO - 2018-10-26 15:36:56 --> Helper loaded: form_helper
INFO - 2018-10-26 15:36:56 --> Helper loaded: html_helper
INFO - 2018-10-26 15:36:56 --> Database Driver Class Initialized
INFO - 2018-10-26 15:36:56 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:36:56 --> Model "User_model" initialized
INFO - 2018-10-26 15:36:56 --> Controller Class Initialized
INFO - 2018-10-26 15:36:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:36:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:36:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:36:56 --> Final output sent to browser
DEBUG - 2018-10-26 15:36:56 --> Total execution time: 0.0440
INFO - 2018-10-26 15:37:03 --> Config Class Initialized
INFO - 2018-10-26 15:37:03 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:37:03 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:37:03 --> Utf8 Class Initialized
INFO - 2018-10-26 15:37:03 --> URI Class Initialized
INFO - 2018-10-26 15:37:03 --> Router Class Initialized
INFO - 2018-10-26 15:37:03 --> Output Class Initialized
INFO - 2018-10-26 15:37:03 --> Security Class Initialized
DEBUG - 2018-10-26 15:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:37:03 --> Input Class Initialized
INFO - 2018-10-26 15:37:03 --> Language Class Initialized
INFO - 2018-10-26 15:37:03 --> Loader Class Initialized
INFO - 2018-10-26 15:37:03 --> Helper loaded: url_helper
INFO - 2018-10-26 15:37:03 --> Helper loaded: form_helper
INFO - 2018-10-26 15:37:03 --> Helper loaded: html_helper
INFO - 2018-10-26 15:37:03 --> Database Driver Class Initialized
INFO - 2018-10-26 15:37:03 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:37:03 --> Model "User_model" initialized
INFO - 2018-10-26 15:37:03 --> Controller Class Initialized
INFO - 2018-10-26 15:37:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:37:03 --> Config Class Initialized
INFO - 2018-10-26 15:37:03 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:37:03 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:37:03 --> Utf8 Class Initialized
INFO - 2018-10-26 15:37:03 --> URI Class Initialized
INFO - 2018-10-26 15:37:03 --> Router Class Initialized
INFO - 2018-10-26 15:37:03 --> Output Class Initialized
INFO - 2018-10-26 15:37:03 --> Security Class Initialized
DEBUG - 2018-10-26 15:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:37:03 --> Input Class Initialized
INFO - 2018-10-26 15:37:03 --> Language Class Initialized
INFO - 2018-10-26 15:37:03 --> Loader Class Initialized
INFO - 2018-10-26 15:37:03 --> Helper loaded: url_helper
INFO - 2018-10-26 15:37:03 --> Helper loaded: form_helper
INFO - 2018-10-26 15:37:03 --> Helper loaded: html_helper
INFO - 2018-10-26 15:37:03 --> Database Driver Class Initialized
INFO - 2018-10-26 15:37:03 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:37:03 --> Model "User_model" initialized
INFO - 2018-10-26 15:37:03 --> Controller Class Initialized
INFO - 2018-10-26 15:37:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:37:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:37:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:37:03 --> Final output sent to browser
DEBUG - 2018-10-26 15:37:03 --> Total execution time: 0.0350
INFO - 2018-10-26 15:37:04 --> Config Class Initialized
INFO - 2018-10-26 15:37:04 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:37:04 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:37:04 --> Utf8 Class Initialized
INFO - 2018-10-26 15:37:04 --> URI Class Initialized
INFO - 2018-10-26 15:37:04 --> Router Class Initialized
INFO - 2018-10-26 15:37:04 --> Output Class Initialized
INFO - 2018-10-26 15:37:04 --> Security Class Initialized
DEBUG - 2018-10-26 15:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:37:04 --> Input Class Initialized
INFO - 2018-10-26 15:37:04 --> Language Class Initialized
INFO - 2018-10-26 15:37:04 --> Loader Class Initialized
INFO - 2018-10-26 15:37:04 --> Helper loaded: url_helper
INFO - 2018-10-26 15:37:04 --> Helper loaded: form_helper
INFO - 2018-10-26 15:37:04 --> Helper loaded: html_helper
INFO - 2018-10-26 15:37:04 --> Database Driver Class Initialized
INFO - 2018-10-26 15:37:04 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:37:04 --> Model "User_model" initialized
INFO - 2018-10-26 15:37:04 --> Controller Class Initialized
INFO - 2018-10-26 15:37:04 --> Config Class Initialized
INFO - 2018-10-26 15:37:04 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:37:04 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:37:04 --> Utf8 Class Initialized
INFO - 2018-10-26 15:37:04 --> URI Class Initialized
INFO - 2018-10-26 15:37:04 --> Router Class Initialized
INFO - 2018-10-26 15:37:04 --> Output Class Initialized
INFO - 2018-10-26 15:37:04 --> Security Class Initialized
DEBUG - 2018-10-26 15:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:37:04 --> Input Class Initialized
INFO - 2018-10-26 15:37:04 --> Language Class Initialized
INFO - 2018-10-26 15:37:04 --> Loader Class Initialized
INFO - 2018-10-26 15:37:04 --> Helper loaded: url_helper
INFO - 2018-10-26 15:37:04 --> Helper loaded: form_helper
INFO - 2018-10-26 15:37:04 --> Helper loaded: html_helper
INFO - 2018-10-26 15:37:04 --> Database Driver Class Initialized
INFO - 2018-10-26 15:37:04 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:37:04 --> Model "User_model" initialized
INFO - 2018-10-26 15:37:04 --> Controller Class Initialized
INFO - 2018-10-26 15:37:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:37:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:37:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:37:04 --> Final output sent to browser
DEBUG - 2018-10-26 15:37:04 --> Total execution time: 0.0420
INFO - 2018-10-26 15:37:31 --> Config Class Initialized
INFO - 2018-10-26 15:37:31 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:37:31 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:37:31 --> Utf8 Class Initialized
INFO - 2018-10-26 15:37:31 --> URI Class Initialized
INFO - 2018-10-26 15:37:31 --> Router Class Initialized
INFO - 2018-10-26 15:37:31 --> Output Class Initialized
INFO - 2018-10-26 15:37:31 --> Security Class Initialized
DEBUG - 2018-10-26 15:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:37:31 --> Input Class Initialized
INFO - 2018-10-26 15:37:31 --> Language Class Initialized
INFO - 2018-10-26 15:37:31 --> Loader Class Initialized
INFO - 2018-10-26 15:37:31 --> Helper loaded: url_helper
INFO - 2018-10-26 15:37:31 --> Helper loaded: form_helper
INFO - 2018-10-26 15:37:31 --> Helper loaded: html_helper
INFO - 2018-10-26 15:37:31 --> Database Driver Class Initialized
INFO - 2018-10-26 15:37:31 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:37:31 --> Model "User_model" initialized
INFO - 2018-10-26 15:37:31 --> Controller Class Initialized
INFO - 2018-10-26 15:37:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:37:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:37:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:37:31 --> Final output sent to browser
DEBUG - 2018-10-26 15:37:31 --> Total execution time: 0.0530
INFO - 2018-10-26 15:38:44 --> Config Class Initialized
INFO - 2018-10-26 15:38:44 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:38:44 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:38:44 --> Utf8 Class Initialized
INFO - 2018-10-26 15:38:44 --> URI Class Initialized
INFO - 2018-10-26 15:38:44 --> Router Class Initialized
INFO - 2018-10-26 15:38:44 --> Output Class Initialized
INFO - 2018-10-26 15:38:44 --> Security Class Initialized
DEBUG - 2018-10-26 15:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:38:44 --> Input Class Initialized
INFO - 2018-10-26 15:38:44 --> Language Class Initialized
INFO - 2018-10-26 15:38:44 --> Loader Class Initialized
INFO - 2018-10-26 15:38:44 --> Helper loaded: url_helper
INFO - 2018-10-26 15:38:44 --> Helper loaded: form_helper
INFO - 2018-10-26 15:38:44 --> Helper loaded: html_helper
INFO - 2018-10-26 15:38:44 --> Database Driver Class Initialized
INFO - 2018-10-26 15:38:44 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:38:44 --> Model "User_model" initialized
INFO - 2018-10-26 15:38:44 --> Controller Class Initialized
INFO - 2018-10-26 15:38:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:38:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:38:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:38:44 --> Final output sent to browser
DEBUG - 2018-10-26 15:38:44 --> Total execution time: 0.1000
INFO - 2018-10-26 15:38:45 --> Config Class Initialized
INFO - 2018-10-26 15:38:45 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:38:45 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:38:45 --> Utf8 Class Initialized
INFO - 2018-10-26 15:38:45 --> URI Class Initialized
INFO - 2018-10-26 15:38:45 --> Router Class Initialized
INFO - 2018-10-26 15:38:45 --> Output Class Initialized
INFO - 2018-10-26 15:38:45 --> Security Class Initialized
DEBUG - 2018-10-26 15:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:38:45 --> Input Class Initialized
INFO - 2018-10-26 15:38:45 --> Language Class Initialized
INFO - 2018-10-26 15:38:45 --> Loader Class Initialized
INFO - 2018-10-26 15:38:45 --> Helper loaded: url_helper
INFO - 2018-10-26 15:38:45 --> Helper loaded: form_helper
INFO - 2018-10-26 15:38:45 --> Helper loaded: html_helper
INFO - 2018-10-26 15:38:45 --> Database Driver Class Initialized
INFO - 2018-10-26 15:38:45 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:38:45 --> Model "User_model" initialized
INFO - 2018-10-26 15:38:45 --> Controller Class Initialized
INFO - 2018-10-26 15:38:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:38:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:38:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:38:45 --> Final output sent to browser
DEBUG - 2018-10-26 15:38:45 --> Total execution time: 0.0610
INFO - 2018-10-26 15:38:54 --> Config Class Initialized
INFO - 2018-10-26 15:38:54 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:38:54 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:38:54 --> Utf8 Class Initialized
INFO - 2018-10-26 15:38:54 --> URI Class Initialized
INFO - 2018-10-26 15:38:54 --> Router Class Initialized
INFO - 2018-10-26 15:38:54 --> Output Class Initialized
INFO - 2018-10-26 15:38:54 --> Security Class Initialized
DEBUG - 2018-10-26 15:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:38:54 --> Input Class Initialized
INFO - 2018-10-26 15:38:54 --> Language Class Initialized
INFO - 2018-10-26 15:38:54 --> Loader Class Initialized
INFO - 2018-10-26 15:38:54 --> Helper loaded: url_helper
INFO - 2018-10-26 15:38:54 --> Helper loaded: form_helper
INFO - 2018-10-26 15:38:54 --> Helper loaded: html_helper
INFO - 2018-10-26 15:38:54 --> Database Driver Class Initialized
INFO - 2018-10-26 15:38:54 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:38:54 --> Model "User_model" initialized
INFO - 2018-10-26 15:38:54 --> Controller Class Initialized
INFO - 2018-10-26 15:38:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:38:55 --> Config Class Initialized
INFO - 2018-10-26 15:38:55 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:38:55 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:38:55 --> Utf8 Class Initialized
INFO - 2018-10-26 15:38:55 --> URI Class Initialized
INFO - 2018-10-26 15:38:55 --> Router Class Initialized
INFO - 2018-10-26 15:38:55 --> Output Class Initialized
INFO - 2018-10-26 15:38:55 --> Security Class Initialized
DEBUG - 2018-10-26 15:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:38:55 --> Input Class Initialized
INFO - 2018-10-26 15:38:55 --> Language Class Initialized
INFO - 2018-10-26 15:38:55 --> Loader Class Initialized
INFO - 2018-10-26 15:38:55 --> Helper loaded: url_helper
INFO - 2018-10-26 15:38:55 --> Helper loaded: form_helper
INFO - 2018-10-26 15:38:55 --> Helper loaded: html_helper
INFO - 2018-10-26 15:38:55 --> Database Driver Class Initialized
INFO - 2018-10-26 15:38:55 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:38:55 --> Model "User_model" initialized
INFO - 2018-10-26 15:38:55 --> Controller Class Initialized
INFO - 2018-10-26 15:38:55 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:38:55 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:38:55 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:38:55 --> Final output sent to browser
DEBUG - 2018-10-26 15:38:55 --> Total execution time: 0.0410
INFO - 2018-10-26 15:38:57 --> Config Class Initialized
INFO - 2018-10-26 15:38:57 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:38:57 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:38:57 --> Utf8 Class Initialized
INFO - 2018-10-26 15:38:57 --> URI Class Initialized
INFO - 2018-10-26 15:38:57 --> Router Class Initialized
INFO - 2018-10-26 15:38:57 --> Output Class Initialized
INFO - 2018-10-26 15:38:57 --> Security Class Initialized
DEBUG - 2018-10-26 15:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:38:57 --> Input Class Initialized
INFO - 2018-10-26 15:38:57 --> Language Class Initialized
INFO - 2018-10-26 15:38:57 --> Loader Class Initialized
INFO - 2018-10-26 15:38:57 --> Helper loaded: url_helper
INFO - 2018-10-26 15:38:57 --> Helper loaded: form_helper
INFO - 2018-10-26 15:38:57 --> Helper loaded: html_helper
INFO - 2018-10-26 15:38:57 --> Database Driver Class Initialized
INFO - 2018-10-26 15:38:57 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:38:57 --> Model "User_model" initialized
INFO - 2018-10-26 15:38:57 --> Controller Class Initialized
INFO - 2018-10-26 15:38:57 --> Config Class Initialized
INFO - 2018-10-26 15:38:57 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:38:57 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:38:57 --> Utf8 Class Initialized
INFO - 2018-10-26 15:38:57 --> URI Class Initialized
INFO - 2018-10-26 15:38:57 --> Router Class Initialized
INFO - 2018-10-26 15:38:57 --> Output Class Initialized
INFO - 2018-10-26 15:38:57 --> Security Class Initialized
DEBUG - 2018-10-26 15:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:38:57 --> Input Class Initialized
INFO - 2018-10-26 15:38:57 --> Language Class Initialized
INFO - 2018-10-26 15:38:57 --> Loader Class Initialized
INFO - 2018-10-26 15:38:57 --> Helper loaded: url_helper
INFO - 2018-10-26 15:38:57 --> Helper loaded: form_helper
INFO - 2018-10-26 15:38:57 --> Helper loaded: html_helper
INFO - 2018-10-26 15:38:57 --> Database Driver Class Initialized
INFO - 2018-10-26 15:38:57 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:38:57 --> Model "User_model" initialized
INFO - 2018-10-26 15:38:57 --> Controller Class Initialized
INFO - 2018-10-26 15:38:57 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:38:57 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:38:57 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:38:57 --> Final output sent to browser
DEBUG - 2018-10-26 15:38:57 --> Total execution time: 0.0410
INFO - 2018-10-26 15:39:07 --> Config Class Initialized
INFO - 2018-10-26 15:39:07 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:39:07 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:39:07 --> Utf8 Class Initialized
INFO - 2018-10-26 15:39:07 --> URI Class Initialized
INFO - 2018-10-26 15:39:07 --> Router Class Initialized
INFO - 2018-10-26 15:39:07 --> Output Class Initialized
INFO - 2018-10-26 15:39:07 --> Security Class Initialized
DEBUG - 2018-10-26 15:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:39:07 --> Input Class Initialized
INFO - 2018-10-26 15:39:07 --> Language Class Initialized
INFO - 2018-10-26 15:39:07 --> Loader Class Initialized
INFO - 2018-10-26 15:39:07 --> Helper loaded: url_helper
INFO - 2018-10-26 15:39:07 --> Helper loaded: form_helper
INFO - 2018-10-26 15:39:07 --> Helper loaded: html_helper
INFO - 2018-10-26 15:39:07 --> Database Driver Class Initialized
INFO - 2018-10-26 15:39:07 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:39:07 --> Model "User_model" initialized
INFO - 2018-10-26 15:39:07 --> Controller Class Initialized
INFO - 2018-10-26 15:39:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:39:07 --> Config Class Initialized
INFO - 2018-10-26 15:39:07 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:39:07 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:39:07 --> Utf8 Class Initialized
INFO - 2018-10-26 15:39:07 --> URI Class Initialized
INFO - 2018-10-26 15:39:07 --> Router Class Initialized
INFO - 2018-10-26 15:39:07 --> Output Class Initialized
INFO - 2018-10-26 15:39:07 --> Security Class Initialized
DEBUG - 2018-10-26 15:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:39:07 --> Input Class Initialized
INFO - 2018-10-26 15:39:07 --> Language Class Initialized
INFO - 2018-10-26 15:39:07 --> Loader Class Initialized
INFO - 2018-10-26 15:39:07 --> Helper loaded: url_helper
INFO - 2018-10-26 15:39:07 --> Helper loaded: form_helper
INFO - 2018-10-26 15:39:07 --> Helper loaded: html_helper
INFO - 2018-10-26 15:39:07 --> Database Driver Class Initialized
INFO - 2018-10-26 15:39:07 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:39:07 --> Model "User_model" initialized
INFO - 2018-10-26 15:39:07 --> Controller Class Initialized
INFO - 2018-10-26 15:39:07 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:39:07 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:39:07 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:39:07 --> Final output sent to browser
DEBUG - 2018-10-26 15:39:07 --> Total execution time: 0.0410
INFO - 2018-10-26 15:39:09 --> Config Class Initialized
INFO - 2018-10-26 15:39:09 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:39:09 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:39:09 --> Utf8 Class Initialized
INFO - 2018-10-26 15:39:09 --> URI Class Initialized
INFO - 2018-10-26 15:39:09 --> Router Class Initialized
INFO - 2018-10-26 15:39:09 --> Output Class Initialized
INFO - 2018-10-26 15:39:09 --> Security Class Initialized
DEBUG - 2018-10-26 15:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:39:09 --> Input Class Initialized
INFO - 2018-10-26 15:39:09 --> Language Class Initialized
INFO - 2018-10-26 15:39:09 --> Loader Class Initialized
INFO - 2018-10-26 15:39:09 --> Helper loaded: url_helper
INFO - 2018-10-26 15:39:09 --> Helper loaded: form_helper
INFO - 2018-10-26 15:39:09 --> Helper loaded: html_helper
INFO - 2018-10-26 15:39:09 --> Database Driver Class Initialized
INFO - 2018-10-26 15:39:09 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:39:09 --> Model "User_model" initialized
INFO - 2018-10-26 15:39:09 --> Controller Class Initialized
INFO - 2018-10-26 15:39:09 --> Config Class Initialized
INFO - 2018-10-26 15:39:09 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:39:09 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:39:09 --> Utf8 Class Initialized
INFO - 2018-10-26 15:39:09 --> URI Class Initialized
INFO - 2018-10-26 15:39:09 --> Router Class Initialized
INFO - 2018-10-26 15:39:09 --> Output Class Initialized
INFO - 2018-10-26 15:39:09 --> Security Class Initialized
DEBUG - 2018-10-26 15:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:39:09 --> Input Class Initialized
INFO - 2018-10-26 15:39:09 --> Language Class Initialized
INFO - 2018-10-26 15:39:09 --> Loader Class Initialized
INFO - 2018-10-26 15:39:09 --> Helper loaded: url_helper
INFO - 2018-10-26 15:39:09 --> Helper loaded: form_helper
INFO - 2018-10-26 15:39:09 --> Helper loaded: html_helper
INFO - 2018-10-26 15:39:09 --> Database Driver Class Initialized
INFO - 2018-10-26 15:39:09 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:39:09 --> Model "User_model" initialized
INFO - 2018-10-26 15:39:09 --> Controller Class Initialized
INFO - 2018-10-26 15:39:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:39:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:39:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:39:09 --> Final output sent to browser
DEBUG - 2018-10-26 15:39:09 --> Total execution time: 0.0320
INFO - 2018-10-26 15:39:16 --> Config Class Initialized
INFO - 2018-10-26 15:39:16 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:39:16 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:39:16 --> Utf8 Class Initialized
INFO - 2018-10-26 15:39:16 --> URI Class Initialized
INFO - 2018-10-26 15:39:16 --> Router Class Initialized
INFO - 2018-10-26 15:39:16 --> Output Class Initialized
INFO - 2018-10-26 15:39:16 --> Security Class Initialized
DEBUG - 2018-10-26 15:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:39:16 --> Input Class Initialized
INFO - 2018-10-26 15:39:16 --> Language Class Initialized
INFO - 2018-10-26 15:39:16 --> Loader Class Initialized
INFO - 2018-10-26 15:39:16 --> Helper loaded: url_helper
INFO - 2018-10-26 15:39:16 --> Helper loaded: form_helper
INFO - 2018-10-26 15:39:16 --> Helper loaded: html_helper
INFO - 2018-10-26 15:39:16 --> Database Driver Class Initialized
INFO - 2018-10-26 15:39:16 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:39:16 --> Model "User_model" initialized
INFO - 2018-10-26 15:39:16 --> Controller Class Initialized
INFO - 2018-10-26 15:39:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:39:16 --> Config Class Initialized
INFO - 2018-10-26 15:39:16 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:39:16 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:39:16 --> Utf8 Class Initialized
INFO - 2018-10-26 15:39:16 --> URI Class Initialized
INFO - 2018-10-26 15:39:16 --> Router Class Initialized
INFO - 2018-10-26 15:39:16 --> Output Class Initialized
INFO - 2018-10-26 15:39:16 --> Security Class Initialized
DEBUG - 2018-10-26 15:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:39:16 --> Input Class Initialized
INFO - 2018-10-26 15:39:16 --> Language Class Initialized
INFO - 2018-10-26 15:39:16 --> Loader Class Initialized
INFO - 2018-10-26 15:39:16 --> Helper loaded: url_helper
INFO - 2018-10-26 15:39:16 --> Helper loaded: form_helper
INFO - 2018-10-26 15:39:16 --> Helper loaded: html_helper
INFO - 2018-10-26 15:39:16 --> Database Driver Class Initialized
INFO - 2018-10-26 15:39:16 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:39:16 --> Model "User_model" initialized
INFO - 2018-10-26 15:39:16 --> Controller Class Initialized
INFO - 2018-10-26 15:39:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:39:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:39:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:39:16 --> Final output sent to browser
DEBUG - 2018-10-26 15:39:16 --> Total execution time: 0.0350
INFO - 2018-10-26 15:39:17 --> Config Class Initialized
INFO - 2018-10-26 15:39:17 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:39:17 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:39:17 --> Utf8 Class Initialized
INFO - 2018-10-26 15:39:17 --> URI Class Initialized
INFO - 2018-10-26 15:39:17 --> Router Class Initialized
INFO - 2018-10-26 15:39:17 --> Output Class Initialized
INFO - 2018-10-26 15:39:17 --> Security Class Initialized
DEBUG - 2018-10-26 15:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:39:17 --> Input Class Initialized
INFO - 2018-10-26 15:39:17 --> Language Class Initialized
INFO - 2018-10-26 15:39:17 --> Loader Class Initialized
INFO - 2018-10-26 15:39:17 --> Helper loaded: url_helper
INFO - 2018-10-26 15:39:17 --> Helper loaded: form_helper
INFO - 2018-10-26 15:39:17 --> Helper loaded: html_helper
INFO - 2018-10-26 15:39:17 --> Database Driver Class Initialized
INFO - 2018-10-26 15:39:17 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:39:17 --> Model "User_model" initialized
INFO - 2018-10-26 15:39:17 --> Controller Class Initialized
INFO - 2018-10-26 15:39:17 --> Config Class Initialized
INFO - 2018-10-26 15:39:17 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:39:17 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:39:17 --> Utf8 Class Initialized
INFO - 2018-10-26 15:39:17 --> URI Class Initialized
INFO - 2018-10-26 15:39:17 --> Router Class Initialized
INFO - 2018-10-26 15:39:17 --> Output Class Initialized
INFO - 2018-10-26 15:39:17 --> Security Class Initialized
DEBUG - 2018-10-26 15:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:39:17 --> Input Class Initialized
INFO - 2018-10-26 15:39:17 --> Language Class Initialized
INFO - 2018-10-26 15:39:17 --> Loader Class Initialized
INFO - 2018-10-26 15:39:17 --> Helper loaded: url_helper
INFO - 2018-10-26 15:39:17 --> Helper loaded: form_helper
INFO - 2018-10-26 15:39:17 --> Helper loaded: html_helper
INFO - 2018-10-26 15:39:17 --> Database Driver Class Initialized
INFO - 2018-10-26 15:39:17 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:39:17 --> Model "User_model" initialized
INFO - 2018-10-26 15:39:17 --> Controller Class Initialized
INFO - 2018-10-26 15:39:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:39:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:39:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:39:17 --> Final output sent to browser
DEBUG - 2018-10-26 15:39:17 --> Total execution time: 0.0410
INFO - 2018-10-26 15:39:23 --> Config Class Initialized
INFO - 2018-10-26 15:39:23 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:39:23 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:39:23 --> Utf8 Class Initialized
INFO - 2018-10-26 15:39:23 --> URI Class Initialized
INFO - 2018-10-26 15:39:23 --> Router Class Initialized
INFO - 2018-10-26 15:39:23 --> Output Class Initialized
INFO - 2018-10-26 15:39:23 --> Security Class Initialized
DEBUG - 2018-10-26 15:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:39:23 --> Input Class Initialized
INFO - 2018-10-26 15:39:23 --> Language Class Initialized
INFO - 2018-10-26 15:39:23 --> Loader Class Initialized
INFO - 2018-10-26 15:39:23 --> Helper loaded: url_helper
INFO - 2018-10-26 15:39:23 --> Helper loaded: form_helper
INFO - 2018-10-26 15:39:23 --> Helper loaded: html_helper
INFO - 2018-10-26 15:39:23 --> Database Driver Class Initialized
INFO - 2018-10-26 15:39:23 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:39:23 --> Model "User_model" initialized
INFO - 2018-10-26 15:39:23 --> Controller Class Initialized
INFO - 2018-10-26 15:39:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:39:23 --> Config Class Initialized
INFO - 2018-10-26 15:39:23 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:39:23 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:39:23 --> Utf8 Class Initialized
INFO - 2018-10-26 15:39:23 --> URI Class Initialized
INFO - 2018-10-26 15:39:23 --> Router Class Initialized
INFO - 2018-10-26 15:39:23 --> Output Class Initialized
INFO - 2018-10-26 15:39:23 --> Security Class Initialized
DEBUG - 2018-10-26 15:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:39:23 --> Input Class Initialized
INFO - 2018-10-26 15:39:23 --> Language Class Initialized
INFO - 2018-10-26 15:39:23 --> Loader Class Initialized
INFO - 2018-10-26 15:39:23 --> Helper loaded: url_helper
INFO - 2018-10-26 15:39:23 --> Helper loaded: form_helper
INFO - 2018-10-26 15:39:23 --> Helper loaded: html_helper
INFO - 2018-10-26 15:39:23 --> Database Driver Class Initialized
INFO - 2018-10-26 15:39:23 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:39:23 --> Model "User_model" initialized
INFO - 2018-10-26 15:39:23 --> Controller Class Initialized
INFO - 2018-10-26 15:39:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:39:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:39:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:39:23 --> Final output sent to browser
DEBUG - 2018-10-26 15:39:23 --> Total execution time: 0.0300
INFO - 2018-10-26 15:43:43 --> Config Class Initialized
INFO - 2018-10-26 15:43:43 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:43:43 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:43:43 --> Utf8 Class Initialized
INFO - 2018-10-26 15:43:43 --> URI Class Initialized
INFO - 2018-10-26 15:43:43 --> Router Class Initialized
INFO - 2018-10-26 15:43:43 --> Output Class Initialized
INFO - 2018-10-26 15:43:43 --> Security Class Initialized
DEBUG - 2018-10-26 15:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:43:43 --> Input Class Initialized
INFO - 2018-10-26 15:43:43 --> Language Class Initialized
INFO - 2018-10-26 15:43:43 --> Loader Class Initialized
INFO - 2018-10-26 15:43:43 --> Helper loaded: url_helper
INFO - 2018-10-26 15:43:43 --> Helper loaded: form_helper
INFO - 2018-10-26 15:43:43 --> Helper loaded: html_helper
INFO - 2018-10-26 15:43:43 --> Database Driver Class Initialized
INFO - 2018-10-26 15:43:43 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:43:43 --> Model "User_model" initialized
INFO - 2018-10-26 15:43:43 --> Controller Class Initialized
INFO - 2018-10-26 15:43:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:43:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:43:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:43:43 --> Final output sent to browser
DEBUG - 2018-10-26 15:43:43 --> Total execution time: 0.0690
INFO - 2018-10-26 15:43:53 --> Config Class Initialized
INFO - 2018-10-26 15:43:53 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:43:53 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:43:53 --> Utf8 Class Initialized
INFO - 2018-10-26 15:43:53 --> URI Class Initialized
INFO - 2018-10-26 15:43:53 --> Router Class Initialized
INFO - 2018-10-26 15:43:53 --> Output Class Initialized
INFO - 2018-10-26 15:43:53 --> Security Class Initialized
DEBUG - 2018-10-26 15:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:43:53 --> Input Class Initialized
INFO - 2018-10-26 15:43:53 --> Language Class Initialized
INFO - 2018-10-26 15:43:53 --> Loader Class Initialized
INFO - 2018-10-26 15:43:53 --> Helper loaded: url_helper
INFO - 2018-10-26 15:43:53 --> Helper loaded: form_helper
INFO - 2018-10-26 15:43:53 --> Helper loaded: html_helper
INFO - 2018-10-26 15:43:53 --> Database Driver Class Initialized
INFO - 2018-10-26 15:43:53 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:43:53 --> Model "User_model" initialized
INFO - 2018-10-26 15:43:53 --> Controller Class Initialized
INFO - 2018-10-26 15:43:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:43:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:43:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:43:53 --> Final output sent to browser
DEBUG - 2018-10-26 15:43:53 --> Total execution time: 0.0400
INFO - 2018-10-26 15:48:02 --> Config Class Initialized
INFO - 2018-10-26 15:48:02 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:48:02 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:48:02 --> Utf8 Class Initialized
INFO - 2018-10-26 15:48:02 --> URI Class Initialized
INFO - 2018-10-26 15:48:02 --> Router Class Initialized
INFO - 2018-10-26 15:48:02 --> Output Class Initialized
INFO - 2018-10-26 15:48:02 --> Security Class Initialized
DEBUG - 2018-10-26 15:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:48:02 --> Input Class Initialized
INFO - 2018-10-26 15:48:02 --> Language Class Initialized
INFO - 2018-10-26 15:48:02 --> Loader Class Initialized
INFO - 2018-10-26 15:48:02 --> Helper loaded: url_helper
INFO - 2018-10-26 15:48:02 --> Helper loaded: form_helper
INFO - 2018-10-26 15:48:02 --> Helper loaded: html_helper
INFO - 2018-10-26 15:48:02 --> Database Driver Class Initialized
INFO - 2018-10-26 15:48:02 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:48:02 --> Model "User_model" initialized
INFO - 2018-10-26 15:48:02 --> Controller Class Initialized
INFO - 2018-10-26 15:48:02 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:48:02 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:48:02 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:48:02 --> Final output sent to browser
DEBUG - 2018-10-26 15:48:02 --> Total execution time: 0.0580
INFO - 2018-10-26 15:49:32 --> Config Class Initialized
INFO - 2018-10-26 15:49:32 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:49:32 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:49:32 --> Utf8 Class Initialized
INFO - 2018-10-26 15:49:32 --> URI Class Initialized
INFO - 2018-10-26 15:49:32 --> Router Class Initialized
INFO - 2018-10-26 15:49:32 --> Output Class Initialized
INFO - 2018-10-26 15:49:32 --> Security Class Initialized
DEBUG - 2018-10-26 15:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:49:32 --> Input Class Initialized
INFO - 2018-10-26 15:49:32 --> Language Class Initialized
INFO - 2018-10-26 15:49:32 --> Loader Class Initialized
INFO - 2018-10-26 15:49:32 --> Helper loaded: url_helper
INFO - 2018-10-26 15:49:32 --> Helper loaded: form_helper
INFO - 2018-10-26 15:49:32 --> Helper loaded: html_helper
INFO - 2018-10-26 15:49:32 --> Database Driver Class Initialized
INFO - 2018-10-26 15:49:32 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:49:32 --> Model "User_model" initialized
INFO - 2018-10-26 15:49:32 --> Controller Class Initialized
INFO - 2018-10-26 15:49:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:49:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:49:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:49:32 --> Final output sent to browser
DEBUG - 2018-10-26 15:49:32 --> Total execution time: 0.0620
INFO - 2018-10-26 15:49:41 --> Config Class Initialized
INFO - 2018-10-26 15:49:41 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:49:41 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:49:41 --> Utf8 Class Initialized
INFO - 2018-10-26 15:49:41 --> URI Class Initialized
INFO - 2018-10-26 15:49:41 --> Router Class Initialized
INFO - 2018-10-26 15:49:41 --> Output Class Initialized
INFO - 2018-10-26 15:49:41 --> Security Class Initialized
DEBUG - 2018-10-26 15:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:49:41 --> Input Class Initialized
INFO - 2018-10-26 15:49:41 --> Language Class Initialized
INFO - 2018-10-26 15:49:41 --> Loader Class Initialized
INFO - 2018-10-26 15:49:41 --> Helper loaded: url_helper
INFO - 2018-10-26 15:49:41 --> Helper loaded: form_helper
INFO - 2018-10-26 15:49:41 --> Helper loaded: html_helper
INFO - 2018-10-26 15:49:41 --> Database Driver Class Initialized
INFO - 2018-10-26 15:49:41 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:49:41 --> Model "User_model" initialized
INFO - 2018-10-26 15:49:41 --> Controller Class Initialized
INFO - 2018-10-26 15:49:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:49:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:49:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:49:41 --> Final output sent to browser
DEBUG - 2018-10-26 15:49:41 --> Total execution time: 0.0420
INFO - 2018-10-26 15:49:56 --> Config Class Initialized
INFO - 2018-10-26 15:49:56 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:49:56 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:49:56 --> Utf8 Class Initialized
INFO - 2018-10-26 15:49:56 --> URI Class Initialized
INFO - 2018-10-26 15:49:56 --> Router Class Initialized
INFO - 2018-10-26 15:49:56 --> Output Class Initialized
INFO - 2018-10-26 15:49:56 --> Security Class Initialized
DEBUG - 2018-10-26 15:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:49:56 --> Input Class Initialized
INFO - 2018-10-26 15:49:56 --> Language Class Initialized
INFO - 2018-10-26 15:49:56 --> Loader Class Initialized
INFO - 2018-10-26 15:49:56 --> Helper loaded: url_helper
INFO - 2018-10-26 15:49:56 --> Helper loaded: form_helper
INFO - 2018-10-26 15:49:56 --> Helper loaded: html_helper
INFO - 2018-10-26 15:49:56 --> Database Driver Class Initialized
INFO - 2018-10-26 15:49:56 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:49:56 --> Model "User_model" initialized
INFO - 2018-10-26 15:49:56 --> Controller Class Initialized
INFO - 2018-10-26 15:49:56 --> Config Class Initialized
INFO - 2018-10-26 15:49:56 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:49:56 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:49:56 --> Utf8 Class Initialized
INFO - 2018-10-26 15:49:56 --> URI Class Initialized
INFO - 2018-10-26 15:49:56 --> Router Class Initialized
INFO - 2018-10-26 15:49:56 --> Output Class Initialized
INFO - 2018-10-26 15:49:56 --> Security Class Initialized
DEBUG - 2018-10-26 15:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:49:56 --> Input Class Initialized
INFO - 2018-10-26 15:49:56 --> Language Class Initialized
INFO - 2018-10-26 15:49:56 --> Loader Class Initialized
INFO - 2018-10-26 15:49:56 --> Helper loaded: url_helper
INFO - 2018-10-26 15:49:56 --> Helper loaded: form_helper
INFO - 2018-10-26 15:49:56 --> Helper loaded: html_helper
INFO - 2018-10-26 15:49:56 --> Database Driver Class Initialized
INFO - 2018-10-26 15:49:56 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:49:56 --> Model "User_model" initialized
INFO - 2018-10-26 15:49:56 --> Controller Class Initialized
INFO - 2018-10-26 15:49:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:49:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:49:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:49:56 --> Final output sent to browser
DEBUG - 2018-10-26 15:49:56 --> Total execution time: 0.0410
INFO - 2018-10-26 15:50:02 --> Config Class Initialized
INFO - 2018-10-26 15:50:02 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:50:02 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:50:02 --> Utf8 Class Initialized
INFO - 2018-10-26 15:50:02 --> URI Class Initialized
INFO - 2018-10-26 15:50:02 --> Router Class Initialized
INFO - 2018-10-26 15:50:02 --> Output Class Initialized
INFO - 2018-10-26 15:50:02 --> Security Class Initialized
DEBUG - 2018-10-26 15:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:50:02 --> Input Class Initialized
INFO - 2018-10-26 15:50:02 --> Language Class Initialized
INFO - 2018-10-26 15:50:02 --> Loader Class Initialized
INFO - 2018-10-26 15:50:02 --> Helper loaded: url_helper
INFO - 2018-10-26 15:50:02 --> Helper loaded: form_helper
INFO - 2018-10-26 15:50:02 --> Helper loaded: html_helper
INFO - 2018-10-26 15:50:02 --> Database Driver Class Initialized
INFO - 2018-10-26 15:50:02 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:50:02 --> Model "User_model" initialized
INFO - 2018-10-26 15:50:02 --> Controller Class Initialized
INFO - 2018-10-26 15:50:02 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:50:02 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:50:02 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:50:02 --> Final output sent to browser
DEBUG - 2018-10-26 15:50:02 --> Total execution time: 0.0400
INFO - 2018-10-26 15:50:08 --> Config Class Initialized
INFO - 2018-10-26 15:50:08 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:50:08 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:50:08 --> Utf8 Class Initialized
INFO - 2018-10-26 15:50:08 --> URI Class Initialized
INFO - 2018-10-26 15:50:08 --> Router Class Initialized
INFO - 2018-10-26 15:50:08 --> Output Class Initialized
INFO - 2018-10-26 15:50:08 --> Security Class Initialized
DEBUG - 2018-10-26 15:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:50:08 --> Input Class Initialized
INFO - 2018-10-26 15:50:08 --> Language Class Initialized
INFO - 2018-10-26 15:50:08 --> Loader Class Initialized
INFO - 2018-10-26 15:50:08 --> Helper loaded: url_helper
INFO - 2018-10-26 15:50:08 --> Helper loaded: form_helper
INFO - 2018-10-26 15:50:08 --> Helper loaded: html_helper
INFO - 2018-10-26 15:50:08 --> Database Driver Class Initialized
INFO - 2018-10-26 15:50:08 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:50:08 --> Model "User_model" initialized
INFO - 2018-10-26 15:50:08 --> Controller Class Initialized
INFO - 2018-10-26 15:50:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:50:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:50:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:50:08 --> Final output sent to browser
DEBUG - 2018-10-26 15:50:08 --> Total execution time: 0.0480
INFO - 2018-10-26 15:50:08 --> Config Class Initialized
INFO - 2018-10-26 15:50:08 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:50:08 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:50:08 --> Utf8 Class Initialized
INFO - 2018-10-26 15:50:08 --> URI Class Initialized
INFO - 2018-10-26 15:50:08 --> Router Class Initialized
INFO - 2018-10-26 15:50:08 --> Output Class Initialized
INFO - 2018-10-26 15:50:08 --> Security Class Initialized
DEBUG - 2018-10-26 15:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:50:08 --> Input Class Initialized
INFO - 2018-10-26 15:50:08 --> Language Class Initialized
INFO - 2018-10-26 15:50:09 --> Loader Class Initialized
INFO - 2018-10-26 15:50:09 --> Helper loaded: url_helper
INFO - 2018-10-26 15:50:09 --> Helper loaded: form_helper
INFO - 2018-10-26 15:50:09 --> Helper loaded: html_helper
INFO - 2018-10-26 15:50:09 --> Database Driver Class Initialized
INFO - 2018-10-26 15:50:09 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:50:09 --> Model "User_model" initialized
INFO - 2018-10-26 15:50:09 --> Controller Class Initialized
INFO - 2018-10-26 15:50:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:50:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:50:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:50:09 --> Final output sent to browser
DEBUG - 2018-10-26 15:50:09 --> Total execution time: 0.0560
INFO - 2018-10-26 15:50:09 --> Config Class Initialized
INFO - 2018-10-26 15:50:09 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:50:09 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:50:09 --> Utf8 Class Initialized
INFO - 2018-10-26 15:50:09 --> URI Class Initialized
INFO - 2018-10-26 15:50:09 --> Router Class Initialized
INFO - 2018-10-26 15:50:09 --> Output Class Initialized
INFO - 2018-10-26 15:50:09 --> Security Class Initialized
DEBUG - 2018-10-26 15:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:50:09 --> Input Class Initialized
INFO - 2018-10-26 15:50:09 --> Language Class Initialized
INFO - 2018-10-26 15:50:09 --> Loader Class Initialized
INFO - 2018-10-26 15:50:09 --> Helper loaded: url_helper
INFO - 2018-10-26 15:50:09 --> Helper loaded: form_helper
INFO - 2018-10-26 15:50:09 --> Helper loaded: html_helper
INFO - 2018-10-26 15:50:09 --> Database Driver Class Initialized
INFO - 2018-10-26 15:50:09 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:50:09 --> Model "User_model" initialized
INFO - 2018-10-26 15:50:09 --> Controller Class Initialized
INFO - 2018-10-26 15:50:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:50:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:50:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:50:09 --> Final output sent to browser
DEBUG - 2018-10-26 15:50:09 --> Total execution time: 0.0440
INFO - 2018-10-26 15:50:16 --> Config Class Initialized
INFO - 2018-10-26 15:50:16 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:50:16 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:50:16 --> Utf8 Class Initialized
INFO - 2018-10-26 15:50:16 --> URI Class Initialized
INFO - 2018-10-26 15:50:16 --> Router Class Initialized
INFO - 2018-10-26 15:50:16 --> Output Class Initialized
INFO - 2018-10-26 15:50:16 --> Security Class Initialized
DEBUG - 2018-10-26 15:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:50:16 --> Input Class Initialized
INFO - 2018-10-26 15:50:16 --> Language Class Initialized
INFO - 2018-10-26 15:50:16 --> Loader Class Initialized
INFO - 2018-10-26 15:50:16 --> Helper loaded: url_helper
INFO - 2018-10-26 15:50:16 --> Helper loaded: form_helper
INFO - 2018-10-26 15:50:16 --> Helper loaded: html_helper
INFO - 2018-10-26 15:50:16 --> Database Driver Class Initialized
INFO - 2018-10-26 15:50:16 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:50:16 --> Model "User_model" initialized
INFO - 2018-10-26 15:50:16 --> Controller Class Initialized
INFO - 2018-10-26 15:50:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:50:16 --> Config Class Initialized
INFO - 2018-10-26 15:50:16 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:50:16 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:50:16 --> Utf8 Class Initialized
INFO - 2018-10-26 15:50:16 --> URI Class Initialized
INFO - 2018-10-26 15:50:16 --> Router Class Initialized
INFO - 2018-10-26 15:50:16 --> Output Class Initialized
INFO - 2018-10-26 15:50:16 --> Security Class Initialized
DEBUG - 2018-10-26 15:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:50:16 --> Input Class Initialized
INFO - 2018-10-26 15:50:16 --> Language Class Initialized
INFO - 2018-10-26 15:50:16 --> Loader Class Initialized
INFO - 2018-10-26 15:50:16 --> Helper loaded: url_helper
INFO - 2018-10-26 15:50:16 --> Helper loaded: form_helper
INFO - 2018-10-26 15:50:16 --> Helper loaded: html_helper
INFO - 2018-10-26 15:50:16 --> Database Driver Class Initialized
INFO - 2018-10-26 15:50:16 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:50:16 --> Model "User_model" initialized
INFO - 2018-10-26 15:50:16 --> Controller Class Initialized
INFO - 2018-10-26 15:50:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:50:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:50:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:50:16 --> Final output sent to browser
DEBUG - 2018-10-26 15:50:16 --> Total execution time: 0.0400
INFO - 2018-10-26 15:50:33 --> Config Class Initialized
INFO - 2018-10-26 15:50:33 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:50:33 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:50:33 --> Utf8 Class Initialized
INFO - 2018-10-26 15:50:33 --> URI Class Initialized
INFO - 2018-10-26 15:50:33 --> Router Class Initialized
INFO - 2018-10-26 15:50:33 --> Output Class Initialized
INFO - 2018-10-26 15:50:33 --> Security Class Initialized
DEBUG - 2018-10-26 15:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:50:33 --> Input Class Initialized
INFO - 2018-10-26 15:50:33 --> Language Class Initialized
INFO - 2018-10-26 15:50:33 --> Loader Class Initialized
INFO - 2018-10-26 15:50:33 --> Helper loaded: url_helper
INFO - 2018-10-26 15:50:33 --> Helper loaded: form_helper
INFO - 2018-10-26 15:50:33 --> Helper loaded: html_helper
INFO - 2018-10-26 15:50:33 --> Database Driver Class Initialized
INFO - 2018-10-26 15:50:33 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:50:33 --> Model "User_model" initialized
INFO - 2018-10-26 15:50:33 --> Controller Class Initialized
INFO - 2018-10-26 15:50:33 --> Config Class Initialized
INFO - 2018-10-26 15:50:33 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:50:33 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:50:33 --> Utf8 Class Initialized
INFO - 2018-10-26 15:50:33 --> URI Class Initialized
INFO - 2018-10-26 15:50:33 --> Router Class Initialized
INFO - 2018-10-26 15:50:33 --> Output Class Initialized
INFO - 2018-10-26 15:50:33 --> Security Class Initialized
DEBUG - 2018-10-26 15:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:50:33 --> Input Class Initialized
INFO - 2018-10-26 15:50:33 --> Language Class Initialized
INFO - 2018-10-26 15:50:33 --> Loader Class Initialized
INFO - 2018-10-26 15:50:33 --> Helper loaded: url_helper
INFO - 2018-10-26 15:50:33 --> Helper loaded: form_helper
INFO - 2018-10-26 15:50:33 --> Helper loaded: html_helper
INFO - 2018-10-26 15:50:33 --> Database Driver Class Initialized
INFO - 2018-10-26 15:50:33 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:50:33 --> Model "User_model" initialized
INFO - 2018-10-26 15:50:33 --> Controller Class Initialized
INFO - 2018-10-26 15:50:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:50:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:50:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:50:33 --> Final output sent to browser
DEBUG - 2018-10-26 15:50:33 --> Total execution time: 0.0420
INFO - 2018-10-26 15:50:45 --> Config Class Initialized
INFO - 2018-10-26 15:50:45 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:50:45 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:50:45 --> Utf8 Class Initialized
INFO - 2018-10-26 15:50:45 --> URI Class Initialized
INFO - 2018-10-26 15:50:45 --> Router Class Initialized
INFO - 2018-10-26 15:50:45 --> Output Class Initialized
INFO - 2018-10-26 15:50:45 --> Security Class Initialized
DEBUG - 2018-10-26 15:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:50:45 --> Input Class Initialized
INFO - 2018-10-26 15:50:45 --> Language Class Initialized
INFO - 2018-10-26 15:50:45 --> Loader Class Initialized
INFO - 2018-10-26 15:50:45 --> Helper loaded: url_helper
INFO - 2018-10-26 15:50:45 --> Helper loaded: form_helper
INFO - 2018-10-26 15:50:45 --> Helper loaded: html_helper
INFO - 2018-10-26 15:50:45 --> Database Driver Class Initialized
INFO - 2018-10-26 15:50:45 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:50:45 --> Model "User_model" initialized
INFO - 2018-10-26 15:50:45 --> Controller Class Initialized
INFO - 2018-10-26 15:50:45 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-26 15:50:45 --> Severity: Notice --> Trying to get property 'password' of non-object D:\xampp\htdocs\code_igniter\application\models\project_models\user_model.php 39
INFO - 2018-10-26 15:50:46 --> Config Class Initialized
INFO - 2018-10-26 15:50:46 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:50:46 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:50:46 --> Utf8 Class Initialized
INFO - 2018-10-26 15:50:46 --> URI Class Initialized
INFO - 2018-10-26 15:50:46 --> Router Class Initialized
INFO - 2018-10-26 15:50:46 --> Output Class Initialized
INFO - 2018-10-26 15:50:46 --> Security Class Initialized
DEBUG - 2018-10-26 15:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:50:46 --> Input Class Initialized
INFO - 2018-10-26 15:50:46 --> Language Class Initialized
INFO - 2018-10-26 15:50:46 --> Loader Class Initialized
INFO - 2018-10-26 15:50:46 --> Helper loaded: url_helper
INFO - 2018-10-26 15:50:46 --> Helper loaded: form_helper
INFO - 2018-10-26 15:50:46 --> Helper loaded: html_helper
INFO - 2018-10-26 15:50:46 --> Database Driver Class Initialized
INFO - 2018-10-26 15:50:46 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:50:46 --> Model "User_model" initialized
INFO - 2018-10-26 15:50:46 --> Controller Class Initialized
INFO - 2018-10-26 15:50:46 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:50:46 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:50:46 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:50:46 --> Final output sent to browser
DEBUG - 2018-10-26 15:50:46 --> Total execution time: 0.0340
INFO - 2018-10-26 15:51:00 --> Config Class Initialized
INFO - 2018-10-26 15:51:00 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:51:00 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:51:00 --> Utf8 Class Initialized
INFO - 2018-10-26 15:51:00 --> URI Class Initialized
INFO - 2018-10-26 15:51:00 --> Router Class Initialized
INFO - 2018-10-26 15:51:00 --> Output Class Initialized
INFO - 2018-10-26 15:51:00 --> Security Class Initialized
DEBUG - 2018-10-26 15:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:51:00 --> Input Class Initialized
INFO - 2018-10-26 15:51:00 --> Language Class Initialized
INFO - 2018-10-26 15:51:00 --> Loader Class Initialized
INFO - 2018-10-26 15:51:00 --> Helper loaded: url_helper
INFO - 2018-10-26 15:51:00 --> Helper loaded: form_helper
INFO - 2018-10-26 15:51:00 --> Helper loaded: html_helper
INFO - 2018-10-26 15:51:00 --> Database Driver Class Initialized
INFO - 2018-10-26 15:51:00 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:51:00 --> Model "User_model" initialized
INFO - 2018-10-26 15:51:00 --> Controller Class Initialized
INFO - 2018-10-26 15:51:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:51:00 --> Config Class Initialized
INFO - 2018-10-26 15:51:00 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:51:00 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:51:00 --> Utf8 Class Initialized
INFO - 2018-10-26 15:51:00 --> URI Class Initialized
INFO - 2018-10-26 15:51:00 --> Router Class Initialized
INFO - 2018-10-26 15:51:00 --> Output Class Initialized
INFO - 2018-10-26 15:51:00 --> Security Class Initialized
DEBUG - 2018-10-26 15:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:51:00 --> Input Class Initialized
INFO - 2018-10-26 15:51:00 --> Language Class Initialized
INFO - 2018-10-26 15:51:00 --> Loader Class Initialized
INFO - 2018-10-26 15:51:00 --> Helper loaded: url_helper
INFO - 2018-10-26 15:51:00 --> Helper loaded: form_helper
INFO - 2018-10-26 15:51:00 --> Helper loaded: html_helper
INFO - 2018-10-26 15:51:00 --> Database Driver Class Initialized
INFO - 2018-10-26 15:51:00 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:51:00 --> Model "User_model" initialized
INFO - 2018-10-26 15:51:00 --> Controller Class Initialized
INFO - 2018-10-26 15:51:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:51:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:51:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:51:00 --> Final output sent to browser
DEBUG - 2018-10-26 15:51:00 --> Total execution time: 0.0440
INFO - 2018-10-26 15:51:02 --> Config Class Initialized
INFO - 2018-10-26 15:51:02 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:51:02 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:51:02 --> Utf8 Class Initialized
INFO - 2018-10-26 15:51:02 --> URI Class Initialized
INFO - 2018-10-26 15:51:02 --> Router Class Initialized
INFO - 2018-10-26 15:51:02 --> Output Class Initialized
INFO - 2018-10-26 15:51:02 --> Security Class Initialized
DEBUG - 2018-10-26 15:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:51:02 --> Input Class Initialized
INFO - 2018-10-26 15:51:02 --> Language Class Initialized
INFO - 2018-10-26 15:51:02 --> Loader Class Initialized
INFO - 2018-10-26 15:51:02 --> Helper loaded: url_helper
INFO - 2018-10-26 15:51:02 --> Helper loaded: form_helper
INFO - 2018-10-26 15:51:02 --> Helper loaded: html_helper
INFO - 2018-10-26 15:51:02 --> Database Driver Class Initialized
INFO - 2018-10-26 15:51:02 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:51:02 --> Model "User_model" initialized
INFO - 2018-10-26 15:51:02 --> Controller Class Initialized
INFO - 2018-10-26 15:51:02 --> Config Class Initialized
INFO - 2018-10-26 15:51:02 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:51:02 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:51:02 --> Utf8 Class Initialized
INFO - 2018-10-26 15:51:02 --> URI Class Initialized
INFO - 2018-10-26 15:51:02 --> Router Class Initialized
INFO - 2018-10-26 15:51:02 --> Output Class Initialized
INFO - 2018-10-26 15:51:02 --> Security Class Initialized
DEBUG - 2018-10-26 15:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:51:02 --> Input Class Initialized
INFO - 2018-10-26 15:51:02 --> Language Class Initialized
INFO - 2018-10-26 15:51:02 --> Loader Class Initialized
INFO - 2018-10-26 15:51:02 --> Helper loaded: url_helper
INFO - 2018-10-26 15:51:02 --> Helper loaded: form_helper
INFO - 2018-10-26 15:51:02 --> Helper loaded: html_helper
INFO - 2018-10-26 15:51:02 --> Database Driver Class Initialized
INFO - 2018-10-26 15:51:02 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:51:02 --> Model "User_model" initialized
INFO - 2018-10-26 15:51:02 --> Controller Class Initialized
INFO - 2018-10-26 15:51:02 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:51:02 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:51:02 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:51:02 --> Final output sent to browser
DEBUG - 2018-10-26 15:51:02 --> Total execution time: 0.0420
INFO - 2018-10-26 15:51:03 --> Config Class Initialized
INFO - 2018-10-26 15:51:03 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:51:03 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:51:03 --> Utf8 Class Initialized
INFO - 2018-10-26 15:51:03 --> URI Class Initialized
INFO - 2018-10-26 15:51:03 --> Router Class Initialized
INFO - 2018-10-26 15:51:03 --> Output Class Initialized
INFO - 2018-10-26 15:51:03 --> Security Class Initialized
DEBUG - 2018-10-26 15:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:51:03 --> Input Class Initialized
INFO - 2018-10-26 15:51:03 --> Language Class Initialized
INFO - 2018-10-26 15:51:03 --> Loader Class Initialized
INFO - 2018-10-26 15:51:03 --> Helper loaded: url_helper
INFO - 2018-10-26 15:51:03 --> Helper loaded: form_helper
INFO - 2018-10-26 15:51:03 --> Helper loaded: html_helper
INFO - 2018-10-26 15:51:03 --> Database Driver Class Initialized
INFO - 2018-10-26 15:51:03 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:51:03 --> Model "User_model" initialized
INFO - 2018-10-26 15:51:03 --> Controller Class Initialized
INFO - 2018-10-26 15:51:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:51:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:51:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:51:03 --> Final output sent to browser
DEBUG - 2018-10-26 15:51:03 --> Total execution time: 0.0450
INFO - 2018-10-26 15:51:52 --> Config Class Initialized
INFO - 2018-10-26 15:51:52 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:51:52 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:51:52 --> Utf8 Class Initialized
INFO - 2018-10-26 15:51:52 --> URI Class Initialized
INFO - 2018-10-26 15:51:52 --> Router Class Initialized
INFO - 2018-10-26 15:51:52 --> Output Class Initialized
INFO - 2018-10-26 15:51:52 --> Security Class Initialized
DEBUG - 2018-10-26 15:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:51:52 --> Input Class Initialized
INFO - 2018-10-26 15:51:52 --> Language Class Initialized
INFO - 2018-10-26 15:51:52 --> Loader Class Initialized
INFO - 2018-10-26 15:51:52 --> Helper loaded: url_helper
INFO - 2018-10-26 15:51:52 --> Helper loaded: form_helper
INFO - 2018-10-26 15:51:52 --> Helper loaded: html_helper
INFO - 2018-10-26 15:51:52 --> Database Driver Class Initialized
INFO - 2018-10-26 15:51:52 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:51:52 --> Model "User_model" initialized
INFO - 2018-10-26 15:51:52 --> Controller Class Initialized
INFO - 2018-10-26 15:51:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:51:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:51:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:51:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:51:52 --> Final output sent to browser
DEBUG - 2018-10-26 15:51:52 --> Total execution time: 0.0540
INFO - 2018-10-26 15:52:21 --> Config Class Initialized
INFO - 2018-10-26 15:52:21 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:52:21 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:52:21 --> Utf8 Class Initialized
INFO - 2018-10-26 15:52:21 --> URI Class Initialized
INFO - 2018-10-26 15:52:21 --> Router Class Initialized
INFO - 2018-10-26 15:52:21 --> Output Class Initialized
INFO - 2018-10-26 15:52:21 --> Security Class Initialized
DEBUG - 2018-10-26 15:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:52:21 --> Input Class Initialized
INFO - 2018-10-26 15:52:21 --> Language Class Initialized
INFO - 2018-10-26 15:52:21 --> Loader Class Initialized
INFO - 2018-10-26 15:52:21 --> Helper loaded: url_helper
INFO - 2018-10-26 15:52:21 --> Helper loaded: form_helper
INFO - 2018-10-26 15:52:21 --> Helper loaded: html_helper
INFO - 2018-10-26 15:52:21 --> Database Driver Class Initialized
INFO - 2018-10-26 15:52:21 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:52:21 --> Model "User_model" initialized
INFO - 2018-10-26 15:52:21 --> Controller Class Initialized
INFO - 2018-10-26 15:52:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:52:21 --> Config Class Initialized
INFO - 2018-10-26 15:52:21 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:52:21 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:52:21 --> Utf8 Class Initialized
INFO - 2018-10-26 15:52:21 --> URI Class Initialized
INFO - 2018-10-26 15:52:21 --> Router Class Initialized
INFO - 2018-10-26 15:52:21 --> Output Class Initialized
INFO - 2018-10-26 15:52:21 --> Security Class Initialized
DEBUG - 2018-10-26 15:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:52:21 --> Input Class Initialized
INFO - 2018-10-26 15:52:21 --> Language Class Initialized
INFO - 2018-10-26 15:52:21 --> Loader Class Initialized
INFO - 2018-10-26 15:52:21 --> Helper loaded: url_helper
INFO - 2018-10-26 15:52:21 --> Helper loaded: form_helper
INFO - 2018-10-26 15:52:21 --> Helper loaded: html_helper
INFO - 2018-10-26 15:52:21 --> Database Driver Class Initialized
INFO - 2018-10-26 15:52:21 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:52:21 --> Model "User_model" initialized
INFO - 2018-10-26 15:52:21 --> Controller Class Initialized
INFO - 2018-10-26 15:52:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:52:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:52:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:52:21 --> Final output sent to browser
DEBUG - 2018-10-26 15:52:21 --> Total execution time: 0.0410
INFO - 2018-10-26 15:52:33 --> Config Class Initialized
INFO - 2018-10-26 15:52:33 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:52:33 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:52:33 --> Utf8 Class Initialized
INFO - 2018-10-26 15:52:33 --> URI Class Initialized
INFO - 2018-10-26 15:52:33 --> Router Class Initialized
INFO - 2018-10-26 15:52:33 --> Output Class Initialized
INFO - 2018-10-26 15:52:33 --> Security Class Initialized
DEBUG - 2018-10-26 15:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:52:33 --> Input Class Initialized
INFO - 2018-10-26 15:52:33 --> Language Class Initialized
INFO - 2018-10-26 15:52:33 --> Loader Class Initialized
INFO - 2018-10-26 15:52:33 --> Helper loaded: url_helper
INFO - 2018-10-26 15:52:33 --> Helper loaded: form_helper
INFO - 2018-10-26 15:52:33 --> Helper loaded: html_helper
INFO - 2018-10-26 15:52:33 --> Database Driver Class Initialized
INFO - 2018-10-26 15:52:33 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:52:33 --> Model "User_model" initialized
INFO - 2018-10-26 15:52:33 --> Controller Class Initialized
INFO - 2018-10-26 15:52:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 15:52:33 --> Config Class Initialized
INFO - 2018-10-26 15:52:33 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:52:33 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:52:33 --> Utf8 Class Initialized
INFO - 2018-10-26 15:52:33 --> URI Class Initialized
INFO - 2018-10-26 15:52:33 --> Router Class Initialized
INFO - 2018-10-26 15:52:33 --> Output Class Initialized
INFO - 2018-10-26 15:52:33 --> Security Class Initialized
DEBUG - 2018-10-26 15:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:52:33 --> Input Class Initialized
INFO - 2018-10-26 15:52:33 --> Language Class Initialized
INFO - 2018-10-26 15:52:33 --> Loader Class Initialized
INFO - 2018-10-26 15:52:33 --> Helper loaded: url_helper
INFO - 2018-10-26 15:52:33 --> Helper loaded: form_helper
INFO - 2018-10-26 15:52:33 --> Helper loaded: html_helper
INFO - 2018-10-26 15:52:33 --> Database Driver Class Initialized
INFO - 2018-10-26 15:52:33 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:52:33 --> Model "User_model" initialized
INFO - 2018-10-26 15:52:33 --> Controller Class Initialized
INFO - 2018-10-26 15:52:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:52:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:52:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:52:33 --> Final output sent to browser
DEBUG - 2018-10-26 15:52:33 --> Total execution time: 0.0410
INFO - 2018-10-26 15:52:35 --> Config Class Initialized
INFO - 2018-10-26 15:52:35 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:52:35 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:52:35 --> Utf8 Class Initialized
INFO - 2018-10-26 15:52:35 --> URI Class Initialized
INFO - 2018-10-26 15:52:35 --> Router Class Initialized
INFO - 2018-10-26 15:52:35 --> Output Class Initialized
INFO - 2018-10-26 15:52:35 --> Security Class Initialized
DEBUG - 2018-10-26 15:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:52:35 --> Input Class Initialized
INFO - 2018-10-26 15:52:35 --> Language Class Initialized
INFO - 2018-10-26 15:52:35 --> Loader Class Initialized
INFO - 2018-10-26 15:52:35 --> Helper loaded: url_helper
INFO - 2018-10-26 15:52:35 --> Helper loaded: form_helper
INFO - 2018-10-26 15:52:35 --> Helper loaded: html_helper
INFO - 2018-10-26 15:52:35 --> Database Driver Class Initialized
INFO - 2018-10-26 15:52:35 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:52:35 --> Model "User_model" initialized
INFO - 2018-10-26 15:52:35 --> Controller Class Initialized
INFO - 2018-10-26 15:52:35 --> Config Class Initialized
INFO - 2018-10-26 15:52:35 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:52:35 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:52:35 --> Utf8 Class Initialized
INFO - 2018-10-26 15:52:35 --> URI Class Initialized
INFO - 2018-10-26 15:52:35 --> Router Class Initialized
INFO - 2018-10-26 15:52:35 --> Output Class Initialized
INFO - 2018-10-26 15:52:35 --> Security Class Initialized
DEBUG - 2018-10-26 15:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:52:35 --> Input Class Initialized
INFO - 2018-10-26 15:52:35 --> Language Class Initialized
INFO - 2018-10-26 15:52:35 --> Loader Class Initialized
INFO - 2018-10-26 15:52:35 --> Helper loaded: url_helper
INFO - 2018-10-26 15:52:35 --> Helper loaded: form_helper
INFO - 2018-10-26 15:52:35 --> Helper loaded: html_helper
INFO - 2018-10-26 15:52:35 --> Database Driver Class Initialized
INFO - 2018-10-26 15:52:35 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:52:35 --> Model "User_model" initialized
INFO - 2018-10-26 15:52:35 --> Controller Class Initialized
INFO - 2018-10-26 15:52:36 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:52:36 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-26 15:52:36 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:52:36 --> Final output sent to browser
DEBUG - 2018-10-26 15:52:36 --> Total execution time: 0.0430
INFO - 2018-10-26 15:54:24 --> Config Class Initialized
INFO - 2018-10-26 15:54:24 --> Hooks Class Initialized
DEBUG - 2018-10-26 15:54:24 --> UTF-8 Support Enabled
INFO - 2018-10-26 15:54:24 --> Utf8 Class Initialized
INFO - 2018-10-26 15:54:24 --> URI Class Initialized
INFO - 2018-10-26 15:54:24 --> Router Class Initialized
INFO - 2018-10-26 15:54:24 --> Output Class Initialized
INFO - 2018-10-26 15:54:24 --> Security Class Initialized
DEBUG - 2018-10-26 15:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 15:54:24 --> Input Class Initialized
INFO - 2018-10-26 15:54:24 --> Language Class Initialized
INFO - 2018-10-26 15:54:24 --> Loader Class Initialized
INFO - 2018-10-26 15:54:24 --> Helper loaded: url_helper
INFO - 2018-10-26 15:54:24 --> Helper loaded: form_helper
INFO - 2018-10-26 15:54:24 --> Helper loaded: html_helper
INFO - 2018-10-26 15:54:24 --> Database Driver Class Initialized
INFO - 2018-10-26 15:54:24 --> Form Validation Class Initialized
DEBUG - 2018-10-26 15:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 15:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 15:54:24 --> Model "User_model" initialized
INFO - 2018-10-26 15:54:24 --> Controller Class Initialized
INFO - 2018-10-26 15:54:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 15:54:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 15:54:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 15:54:24 --> Final output sent to browser
DEBUG - 2018-10-26 15:54:24 --> Total execution time: 0.0520
INFO - 2018-10-26 16:00:31 --> Config Class Initialized
INFO - 2018-10-26 16:00:31 --> Hooks Class Initialized
DEBUG - 2018-10-26 16:00:31 --> UTF-8 Support Enabled
INFO - 2018-10-26 16:00:31 --> Utf8 Class Initialized
INFO - 2018-10-26 16:00:31 --> URI Class Initialized
INFO - 2018-10-26 16:00:31 --> Router Class Initialized
INFO - 2018-10-26 16:00:31 --> Output Class Initialized
INFO - 2018-10-26 16:00:31 --> Security Class Initialized
DEBUG - 2018-10-26 16:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 16:00:31 --> Input Class Initialized
INFO - 2018-10-26 16:00:31 --> Language Class Initialized
INFO - 2018-10-26 16:00:31 --> Loader Class Initialized
INFO - 2018-10-26 16:00:31 --> Helper loaded: url_helper
INFO - 2018-10-26 16:00:31 --> Helper loaded: form_helper
INFO - 2018-10-26 16:00:31 --> Helper loaded: html_helper
INFO - 2018-10-26 16:00:31 --> Database Driver Class Initialized
INFO - 2018-10-26 16:00:31 --> Form Validation Class Initialized
DEBUG - 2018-10-26 16:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 16:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 16:00:31 --> Model "User_model" initialized
INFO - 2018-10-26 16:00:31 --> Controller Class Initialized
INFO - 2018-10-26 16:00:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 16:00:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 16:00:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 16:00:31 --> Final output sent to browser
DEBUG - 2018-10-26 16:00:31 --> Total execution time: 0.0610
INFO - 2018-10-26 16:00:52 --> Config Class Initialized
INFO - 2018-10-26 16:00:52 --> Hooks Class Initialized
DEBUG - 2018-10-26 16:00:52 --> UTF-8 Support Enabled
INFO - 2018-10-26 16:00:52 --> Utf8 Class Initialized
INFO - 2018-10-26 16:00:52 --> URI Class Initialized
INFO - 2018-10-26 16:00:52 --> Router Class Initialized
INFO - 2018-10-26 16:00:52 --> Output Class Initialized
INFO - 2018-10-26 16:00:52 --> Security Class Initialized
DEBUG - 2018-10-26 16:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 16:00:52 --> Input Class Initialized
INFO - 2018-10-26 16:00:52 --> Language Class Initialized
INFO - 2018-10-26 16:00:52 --> Loader Class Initialized
INFO - 2018-10-26 16:00:52 --> Helper loaded: url_helper
INFO - 2018-10-26 16:00:52 --> Helper loaded: form_helper
INFO - 2018-10-26 16:00:52 --> Helper loaded: html_helper
INFO - 2018-10-26 16:00:52 --> Database Driver Class Initialized
INFO - 2018-10-26 16:00:52 --> Form Validation Class Initialized
DEBUG - 2018-10-26 16:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 16:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 16:00:52 --> Model "User_model" initialized
INFO - 2018-10-26 16:00:52 --> Controller Class Initialized
INFO - 2018-10-26 16:00:52 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-26 16:00:52 --> Could not find the language line "form_validation_password_check"
ERROR - 2018-10-26 16:00:52 --> Could not find the language line "form_validation_password_check"
INFO - 2018-10-26 16:00:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 16:00:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 16:00:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 16:00:52 --> Final output sent to browser
DEBUG - 2018-10-26 16:00:52 --> Total execution time: 0.0490
INFO - 2018-10-26 16:02:38 --> Config Class Initialized
INFO - 2018-10-26 16:02:38 --> Hooks Class Initialized
DEBUG - 2018-10-26 16:02:38 --> UTF-8 Support Enabled
INFO - 2018-10-26 16:02:38 --> Utf8 Class Initialized
INFO - 2018-10-26 16:02:38 --> URI Class Initialized
INFO - 2018-10-26 16:02:38 --> Router Class Initialized
INFO - 2018-10-26 16:02:38 --> Output Class Initialized
INFO - 2018-10-26 16:02:38 --> Security Class Initialized
DEBUG - 2018-10-26 16:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 16:02:38 --> Input Class Initialized
INFO - 2018-10-26 16:02:38 --> Language Class Initialized
INFO - 2018-10-26 16:02:38 --> Loader Class Initialized
INFO - 2018-10-26 16:02:38 --> Helper loaded: url_helper
INFO - 2018-10-26 16:02:38 --> Helper loaded: form_helper
INFO - 2018-10-26 16:02:38 --> Helper loaded: html_helper
INFO - 2018-10-26 16:02:38 --> Database Driver Class Initialized
INFO - 2018-10-26 16:02:38 --> Form Validation Class Initialized
DEBUG - 2018-10-26 16:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 16:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 16:02:38 --> Model "User_model" initialized
INFO - 2018-10-26 16:02:38 --> Controller Class Initialized
INFO - 2018-10-26 16:02:38 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-26 16:02:38 --> Could not find the language line "form_validation_password_check"
ERROR - 2018-10-26 16:02:38 --> Could not find the language line "form_validation_password_check"
INFO - 2018-10-26 16:02:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 16:02:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 16:02:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 16:02:38 --> Final output sent to browser
DEBUG - 2018-10-26 16:02:38 --> Total execution time: 0.0640
INFO - 2018-10-26 16:04:33 --> Config Class Initialized
INFO - 2018-10-26 16:04:33 --> Hooks Class Initialized
DEBUG - 2018-10-26 16:04:33 --> UTF-8 Support Enabled
INFO - 2018-10-26 16:04:33 --> Utf8 Class Initialized
INFO - 2018-10-26 16:04:33 --> URI Class Initialized
INFO - 2018-10-26 16:04:33 --> Router Class Initialized
INFO - 2018-10-26 16:04:33 --> Output Class Initialized
INFO - 2018-10-26 16:04:33 --> Security Class Initialized
DEBUG - 2018-10-26 16:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 16:04:33 --> Input Class Initialized
INFO - 2018-10-26 16:04:33 --> Language Class Initialized
INFO - 2018-10-26 16:04:33 --> Loader Class Initialized
INFO - 2018-10-26 16:04:33 --> Helper loaded: url_helper
INFO - 2018-10-26 16:04:33 --> Helper loaded: form_helper
INFO - 2018-10-26 16:04:33 --> Helper loaded: html_helper
INFO - 2018-10-26 16:04:33 --> Database Driver Class Initialized
INFO - 2018-10-26 16:04:33 --> Form Validation Class Initialized
DEBUG - 2018-10-26 16:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 16:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 16:04:33 --> Model "User_model" initialized
INFO - 2018-10-26 16:04:33 --> Controller Class Initialized
INFO - 2018-10-26 16:04:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 16:04:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 16:04:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 16:04:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 16:04:33 --> Final output sent to browser
DEBUG - 2018-10-26 16:04:33 --> Total execution time: 0.0730
INFO - 2018-10-26 16:04:47 --> Config Class Initialized
INFO - 2018-10-26 16:04:47 --> Hooks Class Initialized
DEBUG - 2018-10-26 16:04:47 --> UTF-8 Support Enabled
INFO - 2018-10-26 16:04:47 --> Utf8 Class Initialized
INFO - 2018-10-26 16:04:47 --> URI Class Initialized
INFO - 2018-10-26 16:04:47 --> Router Class Initialized
INFO - 2018-10-26 16:04:47 --> Output Class Initialized
INFO - 2018-10-26 16:04:47 --> Security Class Initialized
DEBUG - 2018-10-26 16:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 16:04:47 --> Input Class Initialized
INFO - 2018-10-26 16:04:47 --> Language Class Initialized
INFO - 2018-10-26 16:04:47 --> Loader Class Initialized
INFO - 2018-10-26 16:04:47 --> Helper loaded: url_helper
INFO - 2018-10-26 16:04:47 --> Helper loaded: form_helper
INFO - 2018-10-26 16:04:47 --> Helper loaded: html_helper
INFO - 2018-10-26 16:04:47 --> Database Driver Class Initialized
INFO - 2018-10-26 16:04:47 --> Form Validation Class Initialized
DEBUG - 2018-10-26 16:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 16:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 16:04:47 --> Model "User_model" initialized
INFO - 2018-10-26 16:04:47 --> Controller Class Initialized
INFO - 2018-10-26 16:04:47 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-26 16:04:47 --> Could not find the language line "form_validation_password_check"
ERROR - 2018-10-26 16:04:47 --> Could not find the language line "form_validation_password_check"
INFO - 2018-10-26 16:04:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 16:04:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 16:04:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 16:04:47 --> Final output sent to browser
DEBUG - 2018-10-26 16:04:47 --> Total execution time: 0.0630
INFO - 2018-10-26 16:06:12 --> Config Class Initialized
INFO - 2018-10-26 16:06:12 --> Hooks Class Initialized
DEBUG - 2018-10-26 16:06:12 --> UTF-8 Support Enabled
INFO - 2018-10-26 16:06:12 --> Utf8 Class Initialized
INFO - 2018-10-26 16:06:12 --> URI Class Initialized
INFO - 2018-10-26 16:06:12 --> Router Class Initialized
INFO - 2018-10-26 16:06:12 --> Output Class Initialized
INFO - 2018-10-26 16:06:12 --> Security Class Initialized
DEBUG - 2018-10-26 16:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 16:06:12 --> Input Class Initialized
INFO - 2018-10-26 16:06:12 --> Language Class Initialized
INFO - 2018-10-26 16:06:12 --> Loader Class Initialized
INFO - 2018-10-26 16:06:12 --> Helper loaded: url_helper
INFO - 2018-10-26 16:06:12 --> Helper loaded: form_helper
INFO - 2018-10-26 16:06:12 --> Helper loaded: html_helper
INFO - 2018-10-26 16:06:12 --> Database Driver Class Initialized
INFO - 2018-10-26 16:06:12 --> Form Validation Class Initialized
DEBUG - 2018-10-26 16:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 16:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 16:06:12 --> Model "User_model" initialized
INFO - 2018-10-26 16:06:12 --> Controller Class Initialized
INFO - 2018-10-26 16:06:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 16:06:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 16:06:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 16:06:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 16:06:12 --> Final output sent to browser
DEBUG - 2018-10-26 16:06:12 --> Total execution time: 0.0470
INFO - 2018-10-26 16:06:58 --> Config Class Initialized
INFO - 2018-10-26 16:06:58 --> Hooks Class Initialized
DEBUG - 2018-10-26 16:06:58 --> UTF-8 Support Enabled
INFO - 2018-10-26 16:06:58 --> Utf8 Class Initialized
INFO - 2018-10-26 16:06:58 --> URI Class Initialized
INFO - 2018-10-26 16:06:58 --> Router Class Initialized
INFO - 2018-10-26 16:06:58 --> Output Class Initialized
INFO - 2018-10-26 16:06:58 --> Security Class Initialized
DEBUG - 2018-10-26 16:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 16:06:58 --> Input Class Initialized
INFO - 2018-10-26 16:06:58 --> Language Class Initialized
INFO - 2018-10-26 16:06:58 --> Loader Class Initialized
INFO - 2018-10-26 16:06:58 --> Helper loaded: url_helper
INFO - 2018-10-26 16:06:58 --> Helper loaded: form_helper
INFO - 2018-10-26 16:06:58 --> Helper loaded: html_helper
INFO - 2018-10-26 16:06:58 --> Database Driver Class Initialized
INFO - 2018-10-26 16:06:58 --> Form Validation Class Initialized
DEBUG - 2018-10-26 16:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 16:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 16:06:58 --> Model "User_model" initialized
INFO - 2018-10-26 16:06:58 --> Controller Class Initialized
INFO - 2018-10-26 16:06:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-26 16:06:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 16:06:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 16:06:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 16:06:58 --> Final output sent to browser
DEBUG - 2018-10-26 16:06:58 --> Total execution time: 0.0590
INFO - 2018-10-26 16:12:40 --> Config Class Initialized
INFO - 2018-10-26 16:12:40 --> Hooks Class Initialized
DEBUG - 2018-10-26 16:12:40 --> UTF-8 Support Enabled
INFO - 2018-10-26 16:12:40 --> Utf8 Class Initialized
INFO - 2018-10-26 16:12:40 --> URI Class Initialized
INFO - 2018-10-26 16:12:40 --> Router Class Initialized
INFO - 2018-10-26 16:12:40 --> Output Class Initialized
INFO - 2018-10-26 16:12:40 --> Security Class Initialized
DEBUG - 2018-10-26 16:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 16:12:40 --> Input Class Initialized
INFO - 2018-10-26 16:12:40 --> Language Class Initialized
INFO - 2018-10-26 16:12:40 --> Loader Class Initialized
INFO - 2018-10-26 16:12:40 --> Helper loaded: url_helper
INFO - 2018-10-26 16:12:40 --> Helper loaded: form_helper
INFO - 2018-10-26 16:12:40 --> Helper loaded: html_helper
INFO - 2018-10-26 16:12:40 --> Database Driver Class Initialized
INFO - 2018-10-26 16:12:40 --> Form Validation Class Initialized
DEBUG - 2018-10-26 16:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 16:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 16:12:40 --> Model "User_model" initialized
INFO - 2018-10-26 16:12:40 --> Controller Class Initialized
INFO - 2018-10-26 16:12:40 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-26 16:12:40 --> Could not find the language line "form_validation_password_check"
ERROR - 2018-10-26 16:12:40 --> Could not find the language line "form_validation_password_check"
INFO - 2018-10-26 16:12:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 16:12:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 16:12:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 16:12:40 --> Final output sent to browser
DEBUG - 2018-10-26 16:12:40 --> Total execution time: 0.0700
INFO - 2018-10-26 16:13:11 --> Config Class Initialized
INFO - 2018-10-26 16:13:11 --> Hooks Class Initialized
DEBUG - 2018-10-26 16:13:11 --> UTF-8 Support Enabled
INFO - 2018-10-26 16:13:11 --> Utf8 Class Initialized
INFO - 2018-10-26 16:13:11 --> URI Class Initialized
INFO - 2018-10-26 16:13:11 --> Router Class Initialized
INFO - 2018-10-26 16:13:11 --> Output Class Initialized
INFO - 2018-10-26 16:13:11 --> Security Class Initialized
DEBUG - 2018-10-26 16:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-26 16:13:11 --> Input Class Initialized
INFO - 2018-10-26 16:13:11 --> Language Class Initialized
INFO - 2018-10-26 16:13:11 --> Loader Class Initialized
INFO - 2018-10-26 16:13:11 --> Helper loaded: url_helper
INFO - 2018-10-26 16:13:11 --> Helper loaded: form_helper
INFO - 2018-10-26 16:13:11 --> Helper loaded: html_helper
INFO - 2018-10-26 16:13:11 --> Database Driver Class Initialized
INFO - 2018-10-26 16:13:11 --> Form Validation Class Initialized
DEBUG - 2018-10-26 16:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-26 16:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-26 16:13:11 --> Model "User_model" initialized
INFO - 2018-10-26 16:13:11 --> Controller Class Initialized
INFO - 2018-10-26 16:13:11 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-10-26 16:13:11 --> Unable to find callback validation rule: password_check
ERROR - 2018-10-26 16:13:11 --> Could not find the language line "form_validation_password_check"
DEBUG - 2018-10-26 16:13:11 --> Unable to find callback validation rule: password_check
ERROR - 2018-10-26 16:13:11 --> Could not find the language line "form_validation_password_check"
INFO - 2018-10-26 16:13:11 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-26 16:13:11 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-26 16:13:11 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-26 16:13:11 --> Final output sent to browser
DEBUG - 2018-10-26 16:13:11 --> Total execution time: 0.0980
