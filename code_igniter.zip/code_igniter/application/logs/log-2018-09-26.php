<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-09-26 04:48:13 --> Config Class Initialized
INFO - 2018-09-26 04:48:13 --> Hooks Class Initialized
DEBUG - 2018-09-26 04:48:13 --> UTF-8 Support Enabled
INFO - 2018-09-26 04:48:13 --> Utf8 Class Initialized
INFO - 2018-09-26 04:48:13 --> URI Class Initialized
INFO - 2018-09-26 04:48:13 --> Router Class Initialized
INFO - 2018-09-26 04:48:13 --> Output Class Initialized
INFO - 2018-09-26 04:48:13 --> Security Class Initialized
DEBUG - 2018-09-26 04:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 04:48:13 --> Input Class Initialized
INFO - 2018-09-26 04:48:13 --> Language Class Initialized
INFO - 2018-09-26 04:48:13 --> Loader Class Initialized
INFO - 2018-09-26 04:48:13 --> Helper loaded: url_helper
INFO - 2018-09-26 04:48:13 --> Helper loaded: form_helper
INFO - 2018-09-26 04:48:13 --> Helper loaded: html_helper
INFO - 2018-09-26 04:48:13 --> Database Driver Class Initialized
INFO - 2018-09-26 04:48:13 --> Form Validation Class Initialized
DEBUG - 2018-09-26 04:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 04:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 04:48:13 --> Model "User_model" initialized
INFO - 2018-09-26 04:48:13 --> Model "Project_model" initialized
INFO - 2018-09-26 04:48:13 --> Model "Tasks_model" initialized
INFO - 2018-09-26 04:48:13 --> Model "Lists_model" initialized
INFO - 2018-09-26 04:48:13 --> Controller Class Initialized
INFO - 2018-09-26 04:48:13 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 04:48:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-26 04:48:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 04:48:14 --> Final output sent to browser
DEBUG - 2018-09-26 04:48:14 --> Total execution time: 0.5190
INFO - 2018-09-26 04:50:18 --> Config Class Initialized
INFO - 2018-09-26 04:50:18 --> Hooks Class Initialized
DEBUG - 2018-09-26 04:50:19 --> UTF-8 Support Enabled
INFO - 2018-09-26 04:50:19 --> Utf8 Class Initialized
INFO - 2018-09-26 04:50:19 --> URI Class Initialized
INFO - 2018-09-26 04:50:19 --> Router Class Initialized
INFO - 2018-09-26 04:50:19 --> Output Class Initialized
INFO - 2018-09-26 04:50:19 --> Security Class Initialized
DEBUG - 2018-09-26 04:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 04:50:19 --> Input Class Initialized
INFO - 2018-09-26 04:50:19 --> Language Class Initialized
INFO - 2018-09-26 04:50:19 --> Loader Class Initialized
INFO - 2018-09-26 04:50:19 --> Helper loaded: url_helper
INFO - 2018-09-26 04:50:19 --> Helper loaded: form_helper
INFO - 2018-09-26 04:50:19 --> Helper loaded: html_helper
INFO - 2018-09-26 04:50:19 --> Database Driver Class Initialized
INFO - 2018-09-26 04:50:19 --> Form Validation Class Initialized
DEBUG - 2018-09-26 04:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 04:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 04:50:19 --> Model "User_model" initialized
INFO - 2018-09-26 04:50:19 --> Model "Project_model" initialized
INFO - 2018-09-26 04:50:19 --> Model "Tasks_model" initialized
INFO - 2018-09-26 04:50:19 --> Model "Lists_model" initialized
INFO - 2018-09-26 04:50:19 --> Controller Class Initialized
ERROR - 2018-09-26 04:50:19 --> Severity: Notice --> Undefined property: CI_Loader::$test_library D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 71
ERROR - 2018-09-26 04:50:19 --> Severity: error --> Exception: Call to a member function show_hello_world() on null D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 71
INFO - 2018-09-26 04:50:50 --> Config Class Initialized
INFO - 2018-09-26 04:50:50 --> Hooks Class Initialized
DEBUG - 2018-09-26 04:50:50 --> UTF-8 Support Enabled
INFO - 2018-09-26 04:50:50 --> Utf8 Class Initialized
INFO - 2018-09-26 04:50:50 --> URI Class Initialized
INFO - 2018-09-26 04:50:50 --> Router Class Initialized
INFO - 2018-09-26 04:50:50 --> Output Class Initialized
INFO - 2018-09-26 04:50:50 --> Security Class Initialized
DEBUG - 2018-09-26 04:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 04:50:50 --> Input Class Initialized
INFO - 2018-09-26 04:50:50 --> Language Class Initialized
INFO - 2018-09-26 04:50:50 --> Loader Class Initialized
INFO - 2018-09-26 04:50:50 --> Helper loaded: url_helper
INFO - 2018-09-26 04:50:50 --> Helper loaded: form_helper
INFO - 2018-09-26 04:50:50 --> Helper loaded: html_helper
INFO - 2018-09-26 04:50:50 --> Database Driver Class Initialized
INFO - 2018-09-26 04:50:50 --> Form Validation Class Initialized
DEBUG - 2018-09-26 04:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 04:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 04:50:50 --> Model "User_model" initialized
INFO - 2018-09-26 04:50:50 --> Model "Project_model" initialized
INFO - 2018-09-26 04:50:50 --> Model "Tasks_model" initialized
INFO - 2018-09-26 04:50:50 --> Model "Lists_model" initialized
INFO - 2018-09-26 04:50:50 --> Controller Class Initialized
ERROR - 2018-09-26 04:50:50 --> Severity: Notice --> Undefined property: CI_Loader::$test_library D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 71
ERROR - 2018-09-26 04:50:50 --> Severity: error --> Exception: Call to a member function show_hello_world() on null D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 71
INFO - 2018-09-26 04:51:22 --> Config Class Initialized
INFO - 2018-09-26 04:51:22 --> Hooks Class Initialized
DEBUG - 2018-09-26 04:51:22 --> UTF-8 Support Enabled
INFO - 2018-09-26 04:51:22 --> Utf8 Class Initialized
INFO - 2018-09-26 04:51:22 --> URI Class Initialized
INFO - 2018-09-26 04:51:22 --> Router Class Initialized
INFO - 2018-09-26 04:51:22 --> Output Class Initialized
INFO - 2018-09-26 04:51:22 --> Security Class Initialized
DEBUG - 2018-09-26 04:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 04:51:22 --> Input Class Initialized
INFO - 2018-09-26 04:51:22 --> Language Class Initialized
INFO - 2018-09-26 04:51:23 --> Loader Class Initialized
INFO - 2018-09-26 04:51:23 --> Helper loaded: url_helper
INFO - 2018-09-26 04:51:23 --> Helper loaded: form_helper
INFO - 2018-09-26 04:51:23 --> Helper loaded: html_helper
INFO - 2018-09-26 04:51:23 --> Database Driver Class Initialized
INFO - 2018-09-26 04:51:23 --> Form Validation Class Initialized
DEBUG - 2018-09-26 04:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 04:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 04:51:23 --> Model "User_model" initialized
INFO - 2018-09-26 04:51:23 --> Model "Project_model" initialized
INFO - 2018-09-26 04:51:23 --> Model "Tasks_model" initialized
INFO - 2018-09-26 04:51:23 --> Model "Lists_model" initialized
INFO - 2018-09-26 04:51:23 --> Controller Class Initialized
INFO - 2018-09-26 04:51:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 04:51:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-26 04:51:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 04:51:23 --> Final output sent to browser
DEBUG - 2018-09-26 04:51:23 --> Total execution time: 0.0570
INFO - 2018-09-26 04:52:19 --> Config Class Initialized
INFO - 2018-09-26 04:52:19 --> Hooks Class Initialized
DEBUG - 2018-09-26 04:52:19 --> UTF-8 Support Enabled
INFO - 2018-09-26 04:52:19 --> Utf8 Class Initialized
INFO - 2018-09-26 04:52:19 --> URI Class Initialized
INFO - 2018-09-26 04:52:19 --> Router Class Initialized
INFO - 2018-09-26 04:52:19 --> Output Class Initialized
INFO - 2018-09-26 04:52:19 --> Security Class Initialized
DEBUG - 2018-09-26 04:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 04:52:19 --> Input Class Initialized
INFO - 2018-09-26 04:52:19 --> Language Class Initialized
INFO - 2018-09-26 04:52:19 --> Loader Class Initialized
INFO - 2018-09-26 04:52:19 --> Helper loaded: url_helper
INFO - 2018-09-26 04:52:19 --> Helper loaded: form_helper
INFO - 2018-09-26 04:52:19 --> Helper loaded: html_helper
INFO - 2018-09-26 04:52:19 --> Database Driver Class Initialized
INFO - 2018-09-26 04:52:19 --> Form Validation Class Initialized
DEBUG - 2018-09-26 04:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 04:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 04:52:19 --> Model "User_model" initialized
INFO - 2018-09-26 04:52:19 --> Model "Project_model" initialized
INFO - 2018-09-26 04:52:19 --> Model "Tasks_model" initialized
INFO - 2018-09-26 04:52:19 --> Model "Lists_model" initialized
INFO - 2018-09-26 04:52:19 --> Controller Class Initialized
ERROR - 2018-09-26 04:52:19 --> Severity: error --> Exception: Call to undefined function show_hello_world() D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 73
INFO - 2018-09-26 04:57:05 --> Config Class Initialized
INFO - 2018-09-26 04:57:05 --> Hooks Class Initialized
DEBUG - 2018-09-26 04:57:05 --> UTF-8 Support Enabled
INFO - 2018-09-26 04:57:05 --> Utf8 Class Initialized
INFO - 2018-09-26 04:57:05 --> URI Class Initialized
INFO - 2018-09-26 04:57:05 --> Router Class Initialized
INFO - 2018-09-26 04:57:05 --> Output Class Initialized
INFO - 2018-09-26 04:57:05 --> Security Class Initialized
DEBUG - 2018-09-26 04:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 04:57:05 --> Input Class Initialized
INFO - 2018-09-26 04:57:05 --> Language Class Initialized
INFO - 2018-09-26 04:57:05 --> Loader Class Initialized
INFO - 2018-09-26 04:57:05 --> Helper loaded: url_helper
INFO - 2018-09-26 04:57:05 --> Helper loaded: form_helper
INFO - 2018-09-26 04:57:05 --> Helper loaded: html_helper
INFO - 2018-09-26 04:57:05 --> Database Driver Class Initialized
INFO - 2018-09-26 04:57:05 --> Form Validation Class Initialized
DEBUG - 2018-09-26 04:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 04:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 04:57:05 --> Model "User_model" initialized
INFO - 2018-09-26 04:57:05 --> Model "Project_model" initialized
INFO - 2018-09-26 04:57:05 --> Model "Tasks_model" initialized
INFO - 2018-09-26 04:57:05 --> Model "Lists_model" initialized
INFO - 2018-09-26 04:57:05 --> Controller Class Initialized
ERROR - 2018-09-26 04:57:05 --> Severity: Notice --> Undefined property: CI_Loader::$test_library D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 73
ERROR - 2018-09-26 04:57:05 --> Severity: error --> Exception: Call to a member function generate() on null D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 73
INFO - 2018-09-26 04:57:24 --> Config Class Initialized
INFO - 2018-09-26 04:57:24 --> Hooks Class Initialized
DEBUG - 2018-09-26 04:57:24 --> UTF-8 Support Enabled
INFO - 2018-09-26 04:57:24 --> Utf8 Class Initialized
INFO - 2018-09-26 04:57:24 --> URI Class Initialized
INFO - 2018-09-26 04:57:24 --> Router Class Initialized
INFO - 2018-09-26 04:57:24 --> Output Class Initialized
INFO - 2018-09-26 04:57:24 --> Security Class Initialized
DEBUG - 2018-09-26 04:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 04:57:24 --> Input Class Initialized
INFO - 2018-09-26 04:57:24 --> Language Class Initialized
INFO - 2018-09-26 04:57:24 --> Loader Class Initialized
INFO - 2018-09-26 04:57:24 --> Helper loaded: url_helper
INFO - 2018-09-26 04:57:24 --> Helper loaded: form_helper
INFO - 2018-09-26 04:57:24 --> Helper loaded: html_helper
INFO - 2018-09-26 04:57:24 --> Database Driver Class Initialized
INFO - 2018-09-26 04:57:24 --> Form Validation Class Initialized
DEBUG - 2018-09-26 04:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 04:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 04:57:24 --> Model "User_model" initialized
INFO - 2018-09-26 04:57:24 --> Model "Project_model" initialized
INFO - 2018-09-26 04:57:24 --> Model "Tasks_model" initialized
INFO - 2018-09-26 04:57:24 --> Model "Lists_model" initialized
INFO - 2018-09-26 04:57:24 --> Controller Class Initialized
ERROR - 2018-09-26 04:57:24 --> Severity: Notice --> Undefined property: CI_Loader::$test_library D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 73
ERROR - 2018-09-26 04:57:24 --> Severity: error --> Exception: Call to a member function generate() on null D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 73
INFO - 2018-09-26 05:04:19 --> Config Class Initialized
INFO - 2018-09-26 05:04:19 --> Hooks Class Initialized
DEBUG - 2018-09-26 05:04:19 --> UTF-8 Support Enabled
INFO - 2018-09-26 05:04:19 --> Utf8 Class Initialized
INFO - 2018-09-26 05:04:19 --> URI Class Initialized
INFO - 2018-09-26 05:04:19 --> Router Class Initialized
INFO - 2018-09-26 05:04:19 --> Output Class Initialized
INFO - 2018-09-26 05:04:19 --> Security Class Initialized
DEBUG - 2018-09-26 05:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 05:04:19 --> Input Class Initialized
INFO - 2018-09-26 05:04:19 --> Language Class Initialized
INFO - 2018-09-26 05:04:19 --> Loader Class Initialized
INFO - 2018-09-26 05:04:19 --> Helper loaded: url_helper
INFO - 2018-09-26 05:04:19 --> Helper loaded: form_helper
INFO - 2018-09-26 05:04:19 --> Helper loaded: html_helper
INFO - 2018-09-26 05:04:19 --> Database Driver Class Initialized
INFO - 2018-09-26 05:04:19 --> Form Validation Class Initialized
DEBUG - 2018-09-26 05:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 05:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 05:04:19 --> Model "User_model" initialized
INFO - 2018-09-26 05:04:19 --> Model "Project_model" initialized
INFO - 2018-09-26 05:04:19 --> Model "Tasks_model" initialized
INFO - 2018-09-26 05:04:19 --> Model "Lists_model" initialized
INFO - 2018-09-26 05:04:19 --> Controller Class Initialized
INFO - 2018-09-26 05:04:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 05:04:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-26 05:04:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 05:04:19 --> Final output sent to browser
DEBUG - 2018-09-26 05:04:19 --> Total execution time: 0.0600
INFO - 2018-09-26 05:08:05 --> Config Class Initialized
INFO - 2018-09-26 05:08:05 --> Hooks Class Initialized
DEBUG - 2018-09-26 05:08:05 --> UTF-8 Support Enabled
INFO - 2018-09-26 05:08:05 --> Utf8 Class Initialized
INFO - 2018-09-26 05:08:05 --> URI Class Initialized
INFO - 2018-09-26 05:08:05 --> Router Class Initialized
INFO - 2018-09-26 05:08:05 --> Output Class Initialized
INFO - 2018-09-26 05:08:05 --> Security Class Initialized
DEBUG - 2018-09-26 05:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 05:08:05 --> Input Class Initialized
INFO - 2018-09-26 05:08:05 --> Language Class Initialized
INFO - 2018-09-26 05:08:05 --> Loader Class Initialized
INFO - 2018-09-26 05:08:05 --> Helper loaded: url_helper
INFO - 2018-09-26 05:08:05 --> Helper loaded: form_helper
INFO - 2018-09-26 05:08:05 --> Helper loaded: html_helper
INFO - 2018-09-26 05:08:05 --> Database Driver Class Initialized
INFO - 2018-09-26 05:08:05 --> Form Validation Class Initialized
DEBUG - 2018-09-26 05:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 05:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 05:08:05 --> Model "User_model" initialized
INFO - 2018-09-26 05:08:05 --> Model "Project_model" initialized
INFO - 2018-09-26 05:08:05 --> Model "Tasks_model" initialized
INFO - 2018-09-26 05:08:05 --> Model "Lists_model" initialized
INFO - 2018-09-26 05:08:05 --> Controller Class Initialized
ERROR - 2018-09-26 05:08:05 --> Severity: Notice --> Undefined property: CI_Loader::$test_library D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 73
ERROR - 2018-09-26 05:08:05 --> Severity: error --> Exception: Call to a member function show_hello_world() on null D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 73
INFO - 2018-09-26 05:09:38 --> Config Class Initialized
INFO - 2018-09-26 05:09:38 --> Hooks Class Initialized
DEBUG - 2018-09-26 05:09:38 --> UTF-8 Support Enabled
INFO - 2018-09-26 05:09:38 --> Utf8 Class Initialized
INFO - 2018-09-26 05:09:38 --> URI Class Initialized
INFO - 2018-09-26 05:09:38 --> Router Class Initialized
INFO - 2018-09-26 05:09:38 --> Output Class Initialized
INFO - 2018-09-26 05:09:38 --> Security Class Initialized
DEBUG - 2018-09-26 05:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 05:09:38 --> Input Class Initialized
INFO - 2018-09-26 05:09:38 --> Language Class Initialized
INFO - 2018-09-26 05:09:38 --> Loader Class Initialized
INFO - 2018-09-26 05:09:38 --> Helper loaded: url_helper
INFO - 2018-09-26 05:09:38 --> Helper loaded: form_helper
INFO - 2018-09-26 05:09:38 --> Helper loaded: html_helper
INFO - 2018-09-26 05:09:38 --> Database Driver Class Initialized
INFO - 2018-09-26 05:09:38 --> Form Validation Class Initialized
DEBUG - 2018-09-26 05:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 05:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 05:09:38 --> Model "User_model" initialized
INFO - 2018-09-26 05:09:38 --> Model "Project_model" initialized
INFO - 2018-09-26 05:09:38 --> Model "Tasks_model" initialized
INFO - 2018-09-26 05:09:38 --> Model "Lists_model" initialized
INFO - 2018-09-26 05:09:38 --> Controller Class Initialized
ERROR - 2018-09-26 05:09:38 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 73
INFO - 2018-09-26 05:09:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 05:09:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-26 05:09:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
ERROR - 2018-09-26 05:09:38 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 73
INFO - 2018-09-26 05:09:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 05:09:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-26 05:09:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 05:09:38 --> Final output sent to browser
DEBUG - 2018-09-26 05:09:38 --> Total execution time: 0.0600
INFO - 2018-09-26 05:10:43 --> Config Class Initialized
INFO - 2018-09-26 05:10:43 --> Hooks Class Initialized
DEBUG - 2018-09-26 05:10:43 --> UTF-8 Support Enabled
INFO - 2018-09-26 05:10:43 --> Utf8 Class Initialized
INFO - 2018-09-26 05:10:43 --> URI Class Initialized
INFO - 2018-09-26 05:10:43 --> Router Class Initialized
INFO - 2018-09-26 05:10:43 --> Output Class Initialized
INFO - 2018-09-26 05:10:43 --> Security Class Initialized
DEBUG - 2018-09-26 05:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 05:10:43 --> Input Class Initialized
INFO - 2018-09-26 05:10:43 --> Language Class Initialized
INFO - 2018-09-26 05:10:43 --> Loader Class Initialized
INFO - 2018-09-26 05:10:43 --> Helper loaded: url_helper
INFO - 2018-09-26 05:10:43 --> Helper loaded: form_helper
INFO - 2018-09-26 05:10:43 --> Helper loaded: html_helper
INFO - 2018-09-26 05:10:43 --> Database Driver Class Initialized
INFO - 2018-09-26 05:10:43 --> Form Validation Class Initialized
DEBUG - 2018-09-26 05:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 05:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 05:10:43 --> Model "User_model" initialized
INFO - 2018-09-26 05:10:43 --> Model "Project_model" initialized
INFO - 2018-09-26 05:10:43 --> Model "Tasks_model" initialized
INFO - 2018-09-26 05:10:43 --> Model "Lists_model" initialized
INFO - 2018-09-26 05:10:43 --> Controller Class Initialized
ERROR - 2018-09-26 05:10:43 --> Severity: Notice --> Undefined variable: test_library D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 73
ERROR - 2018-09-26 05:10:43 --> Severity: error --> Exception: Call to a member function show_hello_world() on null D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 73
INFO - 2018-09-26 05:12:42 --> Config Class Initialized
INFO - 2018-09-26 05:12:42 --> Hooks Class Initialized
DEBUG - 2018-09-26 05:12:42 --> UTF-8 Support Enabled
INFO - 2018-09-26 05:12:42 --> Utf8 Class Initialized
INFO - 2018-09-26 05:12:42 --> URI Class Initialized
INFO - 2018-09-26 05:12:42 --> Router Class Initialized
INFO - 2018-09-26 05:12:42 --> Output Class Initialized
INFO - 2018-09-26 05:12:42 --> Security Class Initialized
DEBUG - 2018-09-26 05:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 05:12:42 --> Input Class Initialized
INFO - 2018-09-26 05:12:42 --> Language Class Initialized
INFO - 2018-09-26 05:12:42 --> Loader Class Initialized
INFO - 2018-09-26 05:12:42 --> Helper loaded: url_helper
INFO - 2018-09-26 05:12:42 --> Helper loaded: form_helper
INFO - 2018-09-26 05:12:42 --> Helper loaded: html_helper
INFO - 2018-09-26 05:12:42 --> Database Driver Class Initialized
INFO - 2018-09-26 05:12:42 --> Form Validation Class Initialized
DEBUG - 2018-09-26 05:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 05:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 05:12:42 --> Model "User_model" initialized
INFO - 2018-09-26 05:12:42 --> Model "Project_model" initialized
INFO - 2018-09-26 05:12:42 --> Model "Tasks_model" initialized
INFO - 2018-09-26 05:12:42 --> Model "Lists_model" initialized
INFO - 2018-09-26 05:12:42 --> Controller Class Initialized
ERROR - 2018-09-26 05:12:42 --> Severity: error --> Exception: Call to undefined function show_hello_world() D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 73
INFO - 2018-09-26 05:19:04 --> Config Class Initialized
INFO - 2018-09-26 05:19:04 --> Hooks Class Initialized
DEBUG - 2018-09-26 05:19:04 --> UTF-8 Support Enabled
INFO - 2018-09-26 05:19:04 --> Utf8 Class Initialized
INFO - 2018-09-26 05:19:04 --> URI Class Initialized
INFO - 2018-09-26 05:19:04 --> Router Class Initialized
INFO - 2018-09-26 05:19:04 --> Output Class Initialized
INFO - 2018-09-26 05:19:04 --> Security Class Initialized
DEBUG - 2018-09-26 05:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 05:19:04 --> Input Class Initialized
INFO - 2018-09-26 05:19:04 --> Language Class Initialized
INFO - 2018-09-26 05:19:04 --> Loader Class Initialized
INFO - 2018-09-26 05:19:04 --> Helper loaded: url_helper
INFO - 2018-09-26 05:19:04 --> Helper loaded: form_helper
INFO - 2018-09-26 05:19:04 --> Helper loaded: html_helper
INFO - 2018-09-26 05:19:04 --> Database Driver Class Initialized
INFO - 2018-09-26 05:19:04 --> Form Validation Class Initialized
DEBUG - 2018-09-26 05:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 05:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 05:19:04 --> Model "User_model" initialized
INFO - 2018-09-26 05:19:04 --> Model "Project_model" initialized
INFO - 2018-09-26 05:19:04 --> Model "Tasks_model" initialized
INFO - 2018-09-26 05:19:04 --> Model "Lists_model" initialized
INFO - 2018-09-26 05:19:04 --> Controller Class Initialized
ERROR - 2018-09-26 05:19:04 --> Severity: Notice --> Undefined variable: list_library D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 73
ERROR - 2018-09-26 05:19:04 --> Severity: error --> Exception: Call to a member function show_hello_world() on null D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 73
INFO - 2018-09-26 05:19:49 --> Config Class Initialized
INFO - 2018-09-26 05:19:49 --> Hooks Class Initialized
DEBUG - 2018-09-26 05:19:49 --> UTF-8 Support Enabled
INFO - 2018-09-26 05:19:49 --> Utf8 Class Initialized
INFO - 2018-09-26 05:19:49 --> URI Class Initialized
INFO - 2018-09-26 05:19:49 --> Router Class Initialized
INFO - 2018-09-26 05:19:49 --> Output Class Initialized
INFO - 2018-09-26 05:19:49 --> Security Class Initialized
DEBUG - 2018-09-26 05:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 05:19:49 --> Input Class Initialized
INFO - 2018-09-26 05:19:49 --> Language Class Initialized
INFO - 2018-09-26 05:19:49 --> Loader Class Initialized
INFO - 2018-09-26 05:19:49 --> Helper loaded: url_helper
INFO - 2018-09-26 05:19:49 --> Helper loaded: form_helper
INFO - 2018-09-26 05:19:49 --> Helper loaded: html_helper
INFO - 2018-09-26 05:19:49 --> Database Driver Class Initialized
INFO - 2018-09-26 05:19:49 --> Form Validation Class Initialized
DEBUG - 2018-09-26 05:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 05:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 05:19:49 --> Model "User_model" initialized
INFO - 2018-09-26 05:19:49 --> Model "Project_model" initialized
INFO - 2018-09-26 05:19:49 --> Model "Tasks_model" initialized
INFO - 2018-09-26 05:19:49 --> Model "Lists_model" initialized
INFO - 2018-09-26 05:19:49 --> Controller Class Initialized
ERROR - 2018-09-26 05:19:49 --> Severity: Notice --> Undefined variable: list_library D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 73
INFO - 2018-09-26 05:19:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 05:19:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-26 05:19:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 05:19:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 05:19:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-26 05:19:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 05:19:49 --> Final output sent to browser
DEBUG - 2018-09-26 05:19:49 --> Total execution time: 0.0790
INFO - 2018-09-26 05:20:55 --> Config Class Initialized
INFO - 2018-09-26 05:20:55 --> Hooks Class Initialized
DEBUG - 2018-09-26 05:20:55 --> UTF-8 Support Enabled
INFO - 2018-09-26 05:20:55 --> Utf8 Class Initialized
INFO - 2018-09-26 05:20:55 --> URI Class Initialized
INFO - 2018-09-26 05:20:55 --> Router Class Initialized
INFO - 2018-09-26 05:20:55 --> Output Class Initialized
INFO - 2018-09-26 05:20:55 --> Security Class Initialized
DEBUG - 2018-09-26 05:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 05:20:55 --> Input Class Initialized
INFO - 2018-09-26 05:20:55 --> Language Class Initialized
INFO - 2018-09-26 05:20:55 --> Loader Class Initialized
INFO - 2018-09-26 05:20:55 --> Helper loaded: url_helper
INFO - 2018-09-26 05:20:55 --> Helper loaded: form_helper
INFO - 2018-09-26 05:20:55 --> Helper loaded: html_helper
INFO - 2018-09-26 05:20:55 --> Database Driver Class Initialized
INFO - 2018-09-26 05:20:55 --> Form Validation Class Initialized
DEBUG - 2018-09-26 05:20:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 05:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 05:20:55 --> Model "User_model" initialized
INFO - 2018-09-26 05:20:55 --> Model "Project_model" initialized
INFO - 2018-09-26 05:20:55 --> Model "Tasks_model" initialized
INFO - 2018-09-26 05:20:55 --> Model "Lists_model" initialized
INFO - 2018-09-26 05:20:55 --> Controller Class Initialized
INFO - 2018-09-26 05:20:55 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 05:20:55 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-26 05:20:55 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 05:20:55 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 05:20:55 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-26 05:20:55 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 05:20:55 --> Final output sent to browser
DEBUG - 2018-09-26 05:20:55 --> Total execution time: 0.0530
INFO - 2018-09-26 05:21:21 --> Config Class Initialized
INFO - 2018-09-26 05:21:21 --> Hooks Class Initialized
DEBUG - 2018-09-26 05:21:21 --> UTF-8 Support Enabled
INFO - 2018-09-26 05:21:21 --> Utf8 Class Initialized
INFO - 2018-09-26 05:21:21 --> URI Class Initialized
INFO - 2018-09-26 05:21:21 --> Router Class Initialized
INFO - 2018-09-26 05:21:21 --> Output Class Initialized
INFO - 2018-09-26 05:21:21 --> Security Class Initialized
DEBUG - 2018-09-26 05:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 05:21:21 --> Input Class Initialized
INFO - 2018-09-26 05:21:21 --> Language Class Initialized
INFO - 2018-09-26 05:21:21 --> Loader Class Initialized
INFO - 2018-09-26 05:21:21 --> Helper loaded: url_helper
INFO - 2018-09-26 05:21:21 --> Helper loaded: form_helper
INFO - 2018-09-26 05:21:21 --> Helper loaded: html_helper
INFO - 2018-09-26 05:21:21 --> Database Driver Class Initialized
INFO - 2018-09-26 05:21:21 --> Form Validation Class Initialized
DEBUG - 2018-09-26 05:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 05:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 05:21:21 --> Model "User_model" initialized
INFO - 2018-09-26 05:21:21 --> Model "Project_model" initialized
INFO - 2018-09-26 05:21:21 --> Model "Tasks_model" initialized
INFO - 2018-09-26 05:21:21 --> Model "Lists_model" initialized
INFO - 2018-09-26 05:21:21 --> Controller Class Initialized
INFO - 2018-09-26 05:21:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 05:21:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-26 05:21:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 05:21:21 --> Final output sent to browser
DEBUG - 2018-09-26 05:21:21 --> Total execution time: 0.0570
INFO - 2018-09-26 05:21:40 --> Config Class Initialized
INFO - 2018-09-26 05:21:40 --> Hooks Class Initialized
DEBUG - 2018-09-26 05:21:40 --> UTF-8 Support Enabled
INFO - 2018-09-26 05:21:40 --> Utf8 Class Initialized
INFO - 2018-09-26 05:21:40 --> URI Class Initialized
INFO - 2018-09-26 05:21:40 --> Router Class Initialized
INFO - 2018-09-26 05:21:40 --> Output Class Initialized
INFO - 2018-09-26 05:21:40 --> Security Class Initialized
DEBUG - 2018-09-26 05:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 05:21:40 --> Input Class Initialized
INFO - 2018-09-26 05:21:40 --> Language Class Initialized
INFO - 2018-09-26 05:21:40 --> Loader Class Initialized
INFO - 2018-09-26 05:21:40 --> Helper loaded: url_helper
INFO - 2018-09-26 05:21:40 --> Helper loaded: form_helper
INFO - 2018-09-26 05:21:40 --> Helper loaded: html_helper
INFO - 2018-09-26 05:21:40 --> Database Driver Class Initialized
INFO - 2018-09-26 05:21:40 --> Form Validation Class Initialized
DEBUG - 2018-09-26 05:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 05:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 05:21:40 --> Model "User_model" initialized
INFO - 2018-09-26 05:21:40 --> Model "Project_model" initialized
INFO - 2018-09-26 05:21:40 --> Model "Tasks_model" initialized
INFO - 2018-09-26 05:21:40 --> Model "Lists_model" initialized
INFO - 2018-09-26 05:21:40 --> Controller Class Initialized
INFO - 2018-09-26 05:21:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 05:21:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-26 05:21:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 05:21:40 --> Final output sent to browser
DEBUG - 2018-09-26 05:21:40 --> Total execution time: 0.0560
INFO - 2018-09-26 05:23:59 --> Config Class Initialized
INFO - 2018-09-26 05:23:59 --> Hooks Class Initialized
DEBUG - 2018-09-26 05:23:59 --> UTF-8 Support Enabled
INFO - 2018-09-26 05:23:59 --> Utf8 Class Initialized
INFO - 2018-09-26 05:23:59 --> URI Class Initialized
INFO - 2018-09-26 05:23:59 --> Router Class Initialized
INFO - 2018-09-26 05:23:59 --> Output Class Initialized
INFO - 2018-09-26 05:23:59 --> Security Class Initialized
DEBUG - 2018-09-26 05:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 05:23:59 --> Input Class Initialized
INFO - 2018-09-26 05:23:59 --> Language Class Initialized
INFO - 2018-09-26 05:23:59 --> Loader Class Initialized
INFO - 2018-09-26 05:23:59 --> Helper loaded: url_helper
INFO - 2018-09-26 05:23:59 --> Helper loaded: form_helper
INFO - 2018-09-26 05:23:59 --> Helper loaded: html_helper
INFO - 2018-09-26 05:23:59 --> Database Driver Class Initialized
INFO - 2018-09-26 05:23:59 --> Form Validation Class Initialized
DEBUG - 2018-09-26 05:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 05:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 05:23:59 --> Model "User_model" initialized
INFO - 2018-09-26 05:23:59 --> Model "Project_model" initialized
INFO - 2018-09-26 05:23:59 --> Model "Tasks_model" initialized
INFO - 2018-09-26 05:23:59 --> Model "Lists_model" initialized
INFO - 2018-09-26 05:23:59 --> Controller Class Initialized
INFO - 2018-09-26 05:23:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 05:23:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-26 05:23:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 05:23:59 --> Final output sent to browser
DEBUG - 2018-09-26 05:23:59 --> Total execution time: 0.0580
INFO - 2018-09-26 05:24:06 --> Config Class Initialized
INFO - 2018-09-26 05:24:06 --> Hooks Class Initialized
DEBUG - 2018-09-26 05:24:06 --> UTF-8 Support Enabled
INFO - 2018-09-26 05:24:06 --> Utf8 Class Initialized
INFO - 2018-09-26 05:24:06 --> URI Class Initialized
INFO - 2018-09-26 05:24:06 --> Router Class Initialized
INFO - 2018-09-26 05:24:06 --> Output Class Initialized
INFO - 2018-09-26 05:24:06 --> Security Class Initialized
DEBUG - 2018-09-26 05:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 05:24:06 --> Input Class Initialized
INFO - 2018-09-26 05:24:06 --> Language Class Initialized
INFO - 2018-09-26 05:24:06 --> Loader Class Initialized
INFO - 2018-09-26 05:24:06 --> Helper loaded: url_helper
INFO - 2018-09-26 05:24:06 --> Helper loaded: form_helper
INFO - 2018-09-26 05:24:06 --> Helper loaded: html_helper
INFO - 2018-09-26 05:24:06 --> Database Driver Class Initialized
INFO - 2018-09-26 05:24:06 --> Form Validation Class Initialized
DEBUG - 2018-09-26 05:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 05:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 05:24:06 --> Model "User_model" initialized
INFO - 2018-09-26 05:24:06 --> Model "Project_model" initialized
INFO - 2018-09-26 05:24:06 --> Model "Tasks_model" initialized
INFO - 2018-09-26 05:24:06 --> Model "Lists_model" initialized
INFO - 2018-09-26 05:24:06 --> Controller Class Initialized
INFO - 2018-09-26 05:24:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 05:24:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-26 05:24:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 05:24:06 --> Final output sent to browser
DEBUG - 2018-09-26 05:24:06 --> Total execution time: 0.0510
INFO - 2018-09-26 05:24:23 --> Config Class Initialized
INFO - 2018-09-26 05:24:23 --> Hooks Class Initialized
DEBUG - 2018-09-26 05:24:23 --> UTF-8 Support Enabled
INFO - 2018-09-26 05:24:23 --> Utf8 Class Initialized
INFO - 2018-09-26 05:24:23 --> URI Class Initialized
INFO - 2018-09-26 05:24:23 --> Router Class Initialized
INFO - 2018-09-26 05:24:23 --> Output Class Initialized
INFO - 2018-09-26 05:24:23 --> Security Class Initialized
DEBUG - 2018-09-26 05:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 05:24:23 --> Input Class Initialized
INFO - 2018-09-26 05:24:23 --> Language Class Initialized
INFO - 2018-09-26 05:24:23 --> Loader Class Initialized
INFO - 2018-09-26 05:24:23 --> Helper loaded: url_helper
INFO - 2018-09-26 05:24:23 --> Helper loaded: form_helper
INFO - 2018-09-26 05:24:23 --> Helper loaded: html_helper
INFO - 2018-09-26 05:24:23 --> Database Driver Class Initialized
INFO - 2018-09-26 05:24:23 --> Form Validation Class Initialized
DEBUG - 2018-09-26 05:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 05:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 05:24:23 --> Model "User_model" initialized
INFO - 2018-09-26 05:24:23 --> Model "Project_model" initialized
INFO - 2018-09-26 05:24:23 --> Model "Tasks_model" initialized
INFO - 2018-09-26 05:24:23 --> Model "Lists_model" initialized
INFO - 2018-09-26 05:24:23 --> Controller Class Initialized
INFO - 2018-09-26 05:24:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 05:24:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-26 05:24:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 05:24:23 --> Final output sent to browser
DEBUG - 2018-09-26 05:24:23 --> Total execution time: 0.0400
INFO - 2018-09-26 09:06:31 --> Config Class Initialized
INFO - 2018-09-26 09:06:31 --> Hooks Class Initialized
DEBUG - 2018-09-26 09:06:31 --> UTF-8 Support Enabled
INFO - 2018-09-26 09:06:31 --> Utf8 Class Initialized
INFO - 2018-09-26 09:06:31 --> URI Class Initialized
INFO - 2018-09-26 09:06:31 --> Router Class Initialized
INFO - 2018-09-26 09:06:31 --> Output Class Initialized
INFO - 2018-09-26 09:06:31 --> Security Class Initialized
DEBUG - 2018-09-26 09:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 09:06:31 --> Input Class Initialized
INFO - 2018-09-26 09:06:31 --> Language Class Initialized
INFO - 2018-09-26 09:06:31 --> Loader Class Initialized
INFO - 2018-09-26 09:06:31 --> Helper loaded: url_helper
INFO - 2018-09-26 09:06:31 --> Helper loaded: form_helper
INFO - 2018-09-26 09:06:31 --> Helper loaded: html_helper
INFO - 2018-09-26 09:06:31 --> Database Driver Class Initialized
INFO - 2018-09-26 09:06:31 --> Form Validation Class Initialized
DEBUG - 2018-09-26 09:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 09:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 09:06:31 --> Model "User_model" initialized
INFO - 2018-09-26 09:06:31 --> Model "Project_model" initialized
INFO - 2018-09-26 09:06:31 --> Model "Tasks_model" initialized
INFO - 2018-09-26 09:06:31 --> Model "Lists_model" initialized
INFO - 2018-09-26 09:06:31 --> Controller Class Initialized
INFO - 2018-09-26 09:06:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 09:06:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-26 09:06:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 09:06:31 --> Final output sent to browser
DEBUG - 2018-09-26 09:06:31 --> Total execution time: 0.1060
INFO - 2018-09-26 09:06:32 --> Config Class Initialized
INFO - 2018-09-26 09:06:32 --> Hooks Class Initialized
DEBUG - 2018-09-26 09:06:32 --> UTF-8 Support Enabled
INFO - 2018-09-26 09:06:32 --> Utf8 Class Initialized
INFO - 2018-09-26 09:06:32 --> URI Class Initialized
INFO - 2018-09-26 09:06:32 --> Router Class Initialized
INFO - 2018-09-26 09:06:32 --> Output Class Initialized
INFO - 2018-09-26 09:06:32 --> Security Class Initialized
DEBUG - 2018-09-26 09:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 09:06:32 --> Input Class Initialized
INFO - 2018-09-26 09:06:32 --> Language Class Initialized
INFO - 2018-09-26 09:06:32 --> Loader Class Initialized
INFO - 2018-09-26 09:06:32 --> Helper loaded: url_helper
INFO - 2018-09-26 09:06:32 --> Helper loaded: form_helper
INFO - 2018-09-26 09:06:32 --> Helper loaded: html_helper
INFO - 2018-09-26 09:06:32 --> Database Driver Class Initialized
INFO - 2018-09-26 09:06:32 --> Form Validation Class Initialized
DEBUG - 2018-09-26 09:06:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 09:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 09:06:32 --> Model "User_model" initialized
INFO - 2018-09-26 09:06:32 --> Model "Project_model" initialized
INFO - 2018-09-26 09:06:32 --> Model "Tasks_model" initialized
INFO - 2018-09-26 09:06:32 --> Model "Lists_model" initialized
INFO - 2018-09-26 09:06:32 --> Controller Class Initialized
INFO - 2018-09-26 09:06:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 09:06:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-26 09:06:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 09:06:32 --> Final output sent to browser
DEBUG - 2018-09-26 09:06:32 --> Total execution time: 0.0620
INFO - 2018-09-26 09:06:33 --> Config Class Initialized
INFO - 2018-09-26 09:06:33 --> Hooks Class Initialized
DEBUG - 2018-09-26 09:06:33 --> UTF-8 Support Enabled
INFO - 2018-09-26 09:06:33 --> Utf8 Class Initialized
INFO - 2018-09-26 09:06:33 --> URI Class Initialized
INFO - 2018-09-26 09:06:33 --> Router Class Initialized
INFO - 2018-09-26 09:06:33 --> Output Class Initialized
INFO - 2018-09-26 09:06:33 --> Security Class Initialized
DEBUG - 2018-09-26 09:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 09:06:33 --> Input Class Initialized
INFO - 2018-09-26 09:06:33 --> Language Class Initialized
INFO - 2018-09-26 09:06:33 --> Loader Class Initialized
INFO - 2018-09-26 09:06:33 --> Helper loaded: url_helper
INFO - 2018-09-26 09:06:33 --> Helper loaded: form_helper
INFO - 2018-09-26 09:06:33 --> Helper loaded: html_helper
INFO - 2018-09-26 09:06:33 --> Database Driver Class Initialized
INFO - 2018-09-26 09:06:33 --> Form Validation Class Initialized
DEBUG - 2018-09-26 09:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 09:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 09:06:33 --> Model "User_model" initialized
INFO - 2018-09-26 09:06:33 --> Model "Project_model" initialized
INFO - 2018-09-26 09:06:33 --> Model "Tasks_model" initialized
INFO - 2018-09-26 09:06:33 --> Model "Lists_model" initialized
INFO - 2018-09-26 09:06:33 --> Controller Class Initialized
INFO - 2018-09-26 09:06:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 09:06:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-26 09:06:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 09:06:33 --> Final output sent to browser
DEBUG - 2018-09-26 09:06:33 --> Total execution time: 0.0390
INFO - 2018-09-26 09:06:33 --> Config Class Initialized
INFO - 2018-09-26 09:06:33 --> Hooks Class Initialized
DEBUG - 2018-09-26 09:06:33 --> UTF-8 Support Enabled
INFO - 2018-09-26 09:06:33 --> Utf8 Class Initialized
INFO - 2018-09-26 09:06:33 --> URI Class Initialized
INFO - 2018-09-26 09:06:33 --> Router Class Initialized
INFO - 2018-09-26 09:06:33 --> Output Class Initialized
INFO - 2018-09-26 09:06:33 --> Security Class Initialized
DEBUG - 2018-09-26 09:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 09:06:33 --> Input Class Initialized
INFO - 2018-09-26 09:06:33 --> Language Class Initialized
INFO - 2018-09-26 09:06:33 --> Loader Class Initialized
INFO - 2018-09-26 09:06:33 --> Helper loaded: url_helper
INFO - 2018-09-26 09:06:33 --> Helper loaded: form_helper
INFO - 2018-09-26 09:06:33 --> Helper loaded: html_helper
INFO - 2018-09-26 09:06:33 --> Database Driver Class Initialized
INFO - 2018-09-26 09:06:33 --> Form Validation Class Initialized
DEBUG - 2018-09-26 09:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 09:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 09:06:33 --> Model "User_model" initialized
INFO - 2018-09-26 09:06:33 --> Model "Project_model" initialized
INFO - 2018-09-26 09:06:33 --> Model "Tasks_model" initialized
INFO - 2018-09-26 09:06:33 --> Model "Lists_model" initialized
INFO - 2018-09-26 09:06:33 --> Controller Class Initialized
INFO - 2018-09-26 09:06:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 09:06:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-26 09:06:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 09:06:33 --> Final output sent to browser
DEBUG - 2018-09-26 09:06:33 --> Total execution time: 0.0370
INFO - 2018-09-26 09:06:34 --> Config Class Initialized
INFO - 2018-09-26 09:06:34 --> Hooks Class Initialized
DEBUG - 2018-09-26 09:06:34 --> UTF-8 Support Enabled
INFO - 2018-09-26 09:06:34 --> Utf8 Class Initialized
INFO - 2018-09-26 09:06:34 --> URI Class Initialized
INFO - 2018-09-26 09:06:34 --> Router Class Initialized
INFO - 2018-09-26 09:06:34 --> Output Class Initialized
INFO - 2018-09-26 09:06:34 --> Security Class Initialized
DEBUG - 2018-09-26 09:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 09:06:34 --> Input Class Initialized
INFO - 2018-09-26 09:06:34 --> Language Class Initialized
INFO - 2018-09-26 09:06:34 --> Loader Class Initialized
INFO - 2018-09-26 09:06:34 --> Helper loaded: url_helper
INFO - 2018-09-26 09:06:34 --> Helper loaded: form_helper
INFO - 2018-09-26 09:06:34 --> Helper loaded: html_helper
INFO - 2018-09-26 09:06:34 --> Database Driver Class Initialized
INFO - 2018-09-26 09:06:34 --> Form Validation Class Initialized
DEBUG - 2018-09-26 09:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 09:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 09:06:34 --> Model "User_model" initialized
INFO - 2018-09-26 09:06:34 --> Model "Project_model" initialized
INFO - 2018-09-26 09:06:34 --> Model "Tasks_model" initialized
INFO - 2018-09-26 09:06:34 --> Model "Lists_model" initialized
INFO - 2018-09-26 09:06:34 --> Controller Class Initialized
INFO - 2018-09-26 09:06:34 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 09:06:34 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-26 09:06:34 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 09:06:34 --> Final output sent to browser
DEBUG - 2018-09-26 09:06:34 --> Total execution time: 0.4810
INFO - 2018-09-26 09:06:48 --> Config Class Initialized
INFO - 2018-09-26 09:06:48 --> Hooks Class Initialized
DEBUG - 2018-09-26 09:06:48 --> UTF-8 Support Enabled
INFO - 2018-09-26 09:06:48 --> Utf8 Class Initialized
INFO - 2018-09-26 09:06:48 --> URI Class Initialized
INFO - 2018-09-26 09:06:48 --> Router Class Initialized
INFO - 2018-09-26 09:06:48 --> Output Class Initialized
INFO - 2018-09-26 09:06:48 --> Security Class Initialized
DEBUG - 2018-09-26 09:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 09:06:48 --> Input Class Initialized
INFO - 2018-09-26 09:06:48 --> Language Class Initialized
INFO - 2018-09-26 09:06:48 --> Loader Class Initialized
INFO - 2018-09-26 09:06:48 --> Helper loaded: url_helper
INFO - 2018-09-26 09:06:48 --> Helper loaded: form_helper
INFO - 2018-09-26 09:06:48 --> Helper loaded: html_helper
INFO - 2018-09-26 09:06:48 --> Database Driver Class Initialized
INFO - 2018-09-26 09:06:48 --> Form Validation Class Initialized
DEBUG - 2018-09-26 09:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 09:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 09:06:48 --> Model "User_model" initialized
INFO - 2018-09-26 09:06:48 --> Model "Project_model" initialized
INFO - 2018-09-26 09:06:48 --> Model "Tasks_model" initialized
INFO - 2018-09-26 09:06:48 --> Model "Lists_model" initialized
INFO - 2018-09-26 09:06:48 --> Controller Class Initialized
ERROR - 2018-09-26 09:06:48 --> Severity: Notice --> Undefined property: Home::$test_library D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\home.php 18
ERROR - 2018-09-26 09:06:48 --> Severity: error --> Exception: Call to a member function show_hello_world() on null D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\home.php 18
INFO - 2018-09-26 09:07:10 --> Config Class Initialized
INFO - 2018-09-26 09:07:10 --> Hooks Class Initialized
DEBUG - 2018-09-26 09:07:10 --> UTF-8 Support Enabled
INFO - 2018-09-26 09:07:10 --> Utf8 Class Initialized
INFO - 2018-09-26 09:07:10 --> URI Class Initialized
INFO - 2018-09-26 09:07:10 --> Router Class Initialized
INFO - 2018-09-26 09:07:10 --> Output Class Initialized
INFO - 2018-09-26 09:07:10 --> Security Class Initialized
DEBUG - 2018-09-26 09:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 09:07:10 --> Input Class Initialized
INFO - 2018-09-26 09:07:10 --> Language Class Initialized
INFO - 2018-09-26 09:07:10 --> Loader Class Initialized
INFO - 2018-09-26 09:07:10 --> Helper loaded: url_helper
INFO - 2018-09-26 09:07:10 --> Helper loaded: form_helper
INFO - 2018-09-26 09:07:10 --> Helper loaded: html_helper
INFO - 2018-09-26 09:07:10 --> Database Driver Class Initialized
INFO - 2018-09-26 09:07:10 --> Form Validation Class Initialized
DEBUG - 2018-09-26 09:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 09:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 09:07:10 --> Model "User_model" initialized
INFO - 2018-09-26 09:07:10 --> Model "Project_model" initialized
INFO - 2018-09-26 09:07:10 --> Model "Tasks_model" initialized
INFO - 2018-09-26 09:07:10 --> Model "Lists_model" initialized
INFO - 2018-09-26 09:07:10 --> Controller Class Initialized
INFO - 2018-09-26 09:07:10 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 09:07:10 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-26 09:07:10 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 09:07:10 --> Final output sent to browser
DEBUG - 2018-09-26 09:07:10 --> Total execution time: 0.0860
INFO - 2018-09-26 09:07:51 --> Config Class Initialized
INFO - 2018-09-26 09:07:51 --> Hooks Class Initialized
DEBUG - 2018-09-26 09:07:51 --> UTF-8 Support Enabled
INFO - 2018-09-26 09:07:51 --> Utf8 Class Initialized
INFO - 2018-09-26 09:07:51 --> URI Class Initialized
INFO - 2018-09-26 09:07:51 --> Router Class Initialized
INFO - 2018-09-26 09:07:51 --> Output Class Initialized
INFO - 2018-09-26 09:07:51 --> Security Class Initialized
DEBUG - 2018-09-26 09:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 09:07:51 --> Input Class Initialized
INFO - 2018-09-26 09:07:51 --> Language Class Initialized
INFO - 2018-09-26 09:07:51 --> Loader Class Initialized
INFO - 2018-09-26 09:07:51 --> Helper loaded: url_helper
INFO - 2018-09-26 09:07:51 --> Helper loaded: form_helper
INFO - 2018-09-26 09:07:51 --> Helper loaded: html_helper
INFO - 2018-09-26 09:07:51 --> Database Driver Class Initialized
INFO - 2018-09-26 09:07:51 --> Form Validation Class Initialized
DEBUG - 2018-09-26 09:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 09:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 09:07:51 --> Model "User_model" initialized
INFO - 2018-09-26 09:07:51 --> Model "Project_model" initialized
INFO - 2018-09-26 09:07:51 --> Model "Tasks_model" initialized
INFO - 2018-09-26 09:07:51 --> Model "Lists_model" initialized
INFO - 2018-09-26 09:07:51 --> Controller Class Initialized
INFO - 2018-09-26 09:07:51 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 09:07:51 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-26 09:07:51 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 09:07:51 --> Final output sent to browser
DEBUG - 2018-09-26 09:07:51 --> Total execution time: 0.0500
INFO - 2018-09-26 09:27:00 --> Config Class Initialized
INFO - 2018-09-26 09:27:00 --> Hooks Class Initialized
DEBUG - 2018-09-26 09:27:00 --> UTF-8 Support Enabled
INFO - 2018-09-26 09:27:00 --> Utf8 Class Initialized
INFO - 2018-09-26 09:27:00 --> URI Class Initialized
INFO - 2018-09-26 09:27:00 --> Router Class Initialized
INFO - 2018-09-26 09:27:00 --> Output Class Initialized
INFO - 2018-09-26 09:27:00 --> Security Class Initialized
DEBUG - 2018-09-26 09:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 09:27:00 --> Input Class Initialized
INFO - 2018-09-26 09:27:00 --> Language Class Initialized
INFO - 2018-09-26 09:27:00 --> Loader Class Initialized
INFO - 2018-09-26 09:27:00 --> Helper loaded: url_helper
INFO - 2018-09-26 09:27:00 --> Helper loaded: form_helper
INFO - 2018-09-26 09:27:00 --> Helper loaded: html_helper
INFO - 2018-09-26 09:27:00 --> Database Driver Class Initialized
INFO - 2018-09-26 09:27:00 --> Form Validation Class Initialized
DEBUG - 2018-09-26 09:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 09:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 09:27:00 --> Model "User_model" initialized
INFO - 2018-09-26 09:27:00 --> Model "Project_model" initialized
INFO - 2018-09-26 09:27:00 --> Model "Tasks_model" initialized
INFO - 2018-09-26 09:27:00 --> Model "Lists_model" initialized
INFO - 2018-09-26 09:27:00 --> Controller Class Initialized
ERROR - 2018-09-26 09:27:00 --> Severity: Notice --> Undefined property: Home::$test_library D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\home.php 18
ERROR - 2018-09-26 09:27:00 --> Severity: error --> Exception: Call to a member function show_hello_world() on null D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\home.php 18
INFO - 2018-09-26 09:28:10 --> Config Class Initialized
INFO - 2018-09-26 09:28:10 --> Hooks Class Initialized
DEBUG - 2018-09-26 09:28:10 --> UTF-8 Support Enabled
INFO - 2018-09-26 09:28:10 --> Utf8 Class Initialized
INFO - 2018-09-26 09:28:10 --> URI Class Initialized
INFO - 2018-09-26 09:28:10 --> Router Class Initialized
INFO - 2018-09-26 09:28:10 --> Output Class Initialized
INFO - 2018-09-26 09:28:10 --> Security Class Initialized
DEBUG - 2018-09-26 09:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 09:28:10 --> Input Class Initialized
INFO - 2018-09-26 09:28:10 --> Language Class Initialized
INFO - 2018-09-26 09:28:10 --> Loader Class Initialized
INFO - 2018-09-26 09:28:10 --> Helper loaded: url_helper
INFO - 2018-09-26 09:28:10 --> Helper loaded: form_helper
INFO - 2018-09-26 09:28:10 --> Helper loaded: html_helper
INFO - 2018-09-26 09:28:10 --> Database Driver Class Initialized
INFO - 2018-09-26 09:28:10 --> Form Validation Class Initialized
DEBUG - 2018-09-26 09:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 09:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 09:28:10 --> Model "User_model" initialized
INFO - 2018-09-26 09:28:10 --> Model "Project_model" initialized
INFO - 2018-09-26 09:28:10 --> Model "Tasks_model" initialized
INFO - 2018-09-26 09:28:10 --> Model "Lists_model" initialized
INFO - 2018-09-26 09:28:10 --> Controller Class Initialized
ERROR - 2018-09-26 09:28:10 --> Severity: Notice --> Undefined property: Test_library::$load D:\xampp\htdocs\code_igniter\application\libraries\test_library.php 7
ERROR - 2018-09-26 09:28:10 --> Severity: error --> Exception: Call to a member function library() on null D:\xampp\htdocs\code_igniter\application\libraries\test_library.php 7
INFO - 2018-09-26 09:28:27 --> Config Class Initialized
INFO - 2018-09-26 09:28:27 --> Hooks Class Initialized
DEBUG - 2018-09-26 09:28:27 --> UTF-8 Support Enabled
INFO - 2018-09-26 09:28:27 --> Utf8 Class Initialized
INFO - 2018-09-26 09:28:27 --> URI Class Initialized
INFO - 2018-09-26 09:28:27 --> Router Class Initialized
INFO - 2018-09-26 09:28:27 --> Output Class Initialized
INFO - 2018-09-26 09:28:27 --> Security Class Initialized
DEBUG - 2018-09-26 09:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 09:28:27 --> Input Class Initialized
INFO - 2018-09-26 09:28:27 --> Language Class Initialized
INFO - 2018-09-26 09:28:27 --> Loader Class Initialized
INFO - 2018-09-26 09:28:27 --> Helper loaded: url_helper
INFO - 2018-09-26 09:28:27 --> Helper loaded: form_helper
INFO - 2018-09-26 09:28:27 --> Helper loaded: html_helper
INFO - 2018-09-26 09:28:27 --> Database Driver Class Initialized
INFO - 2018-09-26 09:28:27 --> Form Validation Class Initialized
DEBUG - 2018-09-26 09:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 09:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 09:28:27 --> Model "User_model" initialized
INFO - 2018-09-26 09:28:27 --> Model "Project_model" initialized
INFO - 2018-09-26 09:28:27 --> Model "Tasks_model" initialized
INFO - 2018-09-26 09:28:27 --> Model "Lists_model" initialized
INFO - 2018-09-26 09:28:27 --> Controller Class Initialized
INFO - 2018-09-26 09:28:27 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 09:28:27 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-26 09:28:27 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 09:28:27 --> Final output sent to browser
DEBUG - 2018-09-26 09:28:27 --> Total execution time: 0.0460
INFO - 2018-09-26 09:30:00 --> Config Class Initialized
INFO - 2018-09-26 09:30:00 --> Hooks Class Initialized
DEBUG - 2018-09-26 09:30:00 --> UTF-8 Support Enabled
INFO - 2018-09-26 09:30:00 --> Utf8 Class Initialized
INFO - 2018-09-26 09:30:00 --> URI Class Initialized
INFO - 2018-09-26 09:30:00 --> Router Class Initialized
INFO - 2018-09-26 09:30:00 --> Output Class Initialized
INFO - 2018-09-26 09:30:00 --> Security Class Initialized
DEBUG - 2018-09-26 09:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 09:30:00 --> Input Class Initialized
INFO - 2018-09-26 09:30:00 --> Language Class Initialized
INFO - 2018-09-26 09:30:00 --> Loader Class Initialized
INFO - 2018-09-26 09:30:00 --> Helper loaded: url_helper
INFO - 2018-09-26 09:30:00 --> Helper loaded: form_helper
INFO - 2018-09-26 09:30:00 --> Helper loaded: html_helper
INFO - 2018-09-26 09:30:00 --> Database Driver Class Initialized
INFO - 2018-09-26 09:30:00 --> Form Validation Class Initialized
DEBUG - 2018-09-26 09:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 09:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 09:30:00 --> Model "User_model" initialized
INFO - 2018-09-26 09:30:00 --> Model "Project_model" initialized
INFO - 2018-09-26 09:30:00 --> Model "Tasks_model" initialized
INFO - 2018-09-26 09:30:00 --> Model "Lists_model" initialized
INFO - 2018-09-26 09:30:00 --> Controller Class Initialized
INFO - 2018-09-26 09:30:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 09:30:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-26 09:30:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 09:30:00 --> Final output sent to browser
DEBUG - 2018-09-26 09:30:00 --> Total execution time: 0.0450
INFO - 2018-09-26 09:38:56 --> Config Class Initialized
INFO - 2018-09-26 09:38:56 --> Hooks Class Initialized
DEBUG - 2018-09-26 09:38:56 --> UTF-8 Support Enabled
INFO - 2018-09-26 09:38:56 --> Utf8 Class Initialized
INFO - 2018-09-26 09:38:56 --> URI Class Initialized
INFO - 2018-09-26 09:38:56 --> Router Class Initialized
INFO - 2018-09-26 09:38:56 --> Output Class Initialized
INFO - 2018-09-26 09:38:56 --> Security Class Initialized
DEBUG - 2018-09-26 09:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 09:38:56 --> Input Class Initialized
INFO - 2018-09-26 09:38:56 --> Language Class Initialized
INFO - 2018-09-26 09:38:56 --> Loader Class Initialized
INFO - 2018-09-26 09:38:56 --> Helper loaded: url_helper
INFO - 2018-09-26 09:38:56 --> Helper loaded: form_helper
INFO - 2018-09-26 09:38:56 --> Helper loaded: html_helper
INFO - 2018-09-26 09:38:56 --> Database Driver Class Initialized
INFO - 2018-09-26 09:38:56 --> Form Validation Class Initialized
DEBUG - 2018-09-26 09:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 09:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 09:38:56 --> Model "User_model" initialized
INFO - 2018-09-26 09:38:56 --> Model "Project_model" initialized
INFO - 2018-09-26 09:38:56 --> Model "Tasks_model" initialized
INFO - 2018-09-26 09:38:56 --> Model "Lists_model" initialized
INFO - 2018-09-26 09:38:56 --> Controller Class Initialized
INFO - 2018-09-26 09:38:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 09:38:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-26 09:38:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 09:38:56 --> Final output sent to browser
DEBUG - 2018-09-26 09:38:56 --> Total execution time: 0.0600
INFO - 2018-09-26 10:16:20 --> Config Class Initialized
INFO - 2018-09-26 10:16:20 --> Hooks Class Initialized
DEBUG - 2018-09-26 10:16:20 --> UTF-8 Support Enabled
INFO - 2018-09-26 10:16:20 --> Utf8 Class Initialized
INFO - 2018-09-26 10:16:20 --> URI Class Initialized
INFO - 2018-09-26 10:16:20 --> Router Class Initialized
INFO - 2018-09-26 10:16:20 --> Output Class Initialized
INFO - 2018-09-26 10:16:20 --> Security Class Initialized
DEBUG - 2018-09-26 10:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 10:16:20 --> Input Class Initialized
INFO - 2018-09-26 10:16:20 --> Language Class Initialized
ERROR - 2018-09-26 10:16:20 --> Severity: Notice --> Undefined property: Home::$session D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\home.php 13
ERROR - 2018-09-26 10:16:20 --> Severity: error --> Exception: Call to a member function userdata() on null D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\home.php 13
INFO - 2018-09-26 10:17:02 --> Config Class Initialized
INFO - 2018-09-26 10:17:02 --> Hooks Class Initialized
DEBUG - 2018-09-26 10:17:02 --> UTF-8 Support Enabled
INFO - 2018-09-26 10:17:02 --> Utf8 Class Initialized
INFO - 2018-09-26 10:17:02 --> URI Class Initialized
INFO - 2018-09-26 10:17:02 --> Router Class Initialized
INFO - 2018-09-26 10:17:02 --> Output Class Initialized
INFO - 2018-09-26 10:17:02 --> Security Class Initialized
DEBUG - 2018-09-26 10:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 10:17:02 --> Input Class Initialized
INFO - 2018-09-26 10:17:02 --> Language Class Initialized
INFO - 2018-09-26 10:17:02 --> Loader Class Initialized
INFO - 2018-09-26 10:17:02 --> Helper loaded: url_helper
INFO - 2018-09-26 10:17:02 --> Helper loaded: form_helper
INFO - 2018-09-26 10:17:02 --> Helper loaded: html_helper
INFO - 2018-09-26 10:17:02 --> Database Driver Class Initialized
INFO - 2018-09-26 10:17:02 --> Form Validation Class Initialized
DEBUG - 2018-09-26 10:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 10:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 10:17:02 --> Model "User_model" initialized
INFO - 2018-09-26 10:17:02 --> Model "Project_model" initialized
INFO - 2018-09-26 10:17:02 --> Model "Tasks_model" initialized
INFO - 2018-09-26 10:17:02 --> Model "Lists_model" initialized
INFO - 2018-09-26 10:17:02 --> Controller Class Initialized
ERROR - 2018-09-26 10:17:02 --> Severity: Notice --> Undefined variable: CI D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\home.php 27
ERROR - 2018-09-26 10:17:02 --> Severity: Notice --> Trying to get property 'test_library' of non-object D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\home.php 27
ERROR - 2018-09-26 10:17:02 --> Severity: error --> Exception: Call to a member function show_hello_world() on null D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\home.php 27
INFO - 2018-09-26 10:17:29 --> Config Class Initialized
INFO - 2018-09-26 10:17:29 --> Hooks Class Initialized
DEBUG - 2018-09-26 10:17:29 --> UTF-8 Support Enabled
INFO - 2018-09-26 10:17:29 --> Utf8 Class Initialized
INFO - 2018-09-26 10:17:29 --> URI Class Initialized
INFO - 2018-09-26 10:17:29 --> Router Class Initialized
INFO - 2018-09-26 10:17:29 --> Output Class Initialized
INFO - 2018-09-26 10:17:29 --> Security Class Initialized
DEBUG - 2018-09-26 10:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 10:17:29 --> Input Class Initialized
INFO - 2018-09-26 10:17:29 --> Language Class Initialized
INFO - 2018-09-26 10:17:29 --> Loader Class Initialized
INFO - 2018-09-26 10:17:29 --> Helper loaded: url_helper
INFO - 2018-09-26 10:17:29 --> Helper loaded: form_helper
INFO - 2018-09-26 10:17:29 --> Helper loaded: html_helper
INFO - 2018-09-26 10:17:29 --> Database Driver Class Initialized
INFO - 2018-09-26 10:17:29 --> Form Validation Class Initialized
DEBUG - 2018-09-26 10:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 10:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 10:17:29 --> Model "User_model" initialized
INFO - 2018-09-26 10:17:29 --> Model "Project_model" initialized
INFO - 2018-09-26 10:17:29 --> Model "Tasks_model" initialized
INFO - 2018-09-26 10:17:29 --> Model "Lists_model" initialized
INFO - 2018-09-26 10:17:29 --> Controller Class Initialized
ERROR - 2018-09-26 10:17:29 --> Severity: Notice --> Undefined property: Home::$CI D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\home.php 19
ERROR - 2018-09-26 10:17:29 --> Severity: Notice --> Trying to get property 'load' of non-object D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\home.php 19
ERROR - 2018-09-26 10:17:29 --> Severity: error --> Exception: Call to a member function library() on null D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\home.php 19
INFO - 2018-09-26 10:17:50 --> Config Class Initialized
INFO - 2018-09-26 10:17:50 --> Hooks Class Initialized
DEBUG - 2018-09-26 10:17:50 --> UTF-8 Support Enabled
INFO - 2018-09-26 10:17:50 --> Utf8 Class Initialized
INFO - 2018-09-26 10:17:50 --> URI Class Initialized
INFO - 2018-09-26 10:17:50 --> Router Class Initialized
INFO - 2018-09-26 10:17:50 --> Output Class Initialized
INFO - 2018-09-26 10:17:50 --> Security Class Initialized
DEBUG - 2018-09-26 10:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 10:17:50 --> Input Class Initialized
INFO - 2018-09-26 10:17:50 --> Language Class Initialized
INFO - 2018-09-26 10:17:50 --> Loader Class Initialized
INFO - 2018-09-26 10:17:50 --> Helper loaded: url_helper
INFO - 2018-09-26 10:17:50 --> Helper loaded: form_helper
INFO - 2018-09-26 10:17:50 --> Helper loaded: html_helper
INFO - 2018-09-26 10:17:50 --> Database Driver Class Initialized
INFO - 2018-09-26 10:17:50 --> Form Validation Class Initialized
DEBUG - 2018-09-26 10:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 10:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 10:17:50 --> Model "User_model" initialized
INFO - 2018-09-26 10:17:50 --> Model "Project_model" initialized
INFO - 2018-09-26 10:17:50 --> Model "Tasks_model" initialized
INFO - 2018-09-26 10:17:50 --> Model "Lists_model" initialized
INFO - 2018-09-26 10:17:50 --> Controller Class Initialized
ERROR - 2018-09-26 10:17:50 --> Severity: 4096 --> Object of class Home could not be converted to string D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\home.php 19
ERROR - 2018-09-26 10:17:50 --> Severity: Notice --> Undefined property: Home::$ D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\home.php 19
ERROR - 2018-09-26 10:17:50 --> Severity: Notice --> Trying to get property 'load' of non-object D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\home.php 19
ERROR - 2018-09-26 10:17:50 --> Severity: error --> Exception: Call to a member function library() on null D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\home.php 19
INFO - 2018-09-26 10:18:15 --> Config Class Initialized
INFO - 2018-09-26 10:18:15 --> Hooks Class Initialized
DEBUG - 2018-09-26 10:18:15 --> UTF-8 Support Enabled
INFO - 2018-09-26 10:18:15 --> Utf8 Class Initialized
INFO - 2018-09-26 10:18:15 --> URI Class Initialized
INFO - 2018-09-26 10:18:15 --> Router Class Initialized
INFO - 2018-09-26 10:18:15 --> Output Class Initialized
INFO - 2018-09-26 10:18:15 --> Security Class Initialized
DEBUG - 2018-09-26 10:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 10:18:15 --> Input Class Initialized
INFO - 2018-09-26 10:18:15 --> Language Class Initialized
INFO - 2018-09-26 10:18:15 --> Loader Class Initialized
INFO - 2018-09-26 10:18:15 --> Helper loaded: url_helper
INFO - 2018-09-26 10:18:15 --> Helper loaded: form_helper
INFO - 2018-09-26 10:18:15 --> Helper loaded: html_helper
INFO - 2018-09-26 10:18:15 --> Database Driver Class Initialized
INFO - 2018-09-26 10:18:15 --> Form Validation Class Initialized
DEBUG - 2018-09-26 10:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 10:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 10:18:15 --> Model "User_model" initialized
INFO - 2018-09-26 10:18:15 --> Model "Project_model" initialized
INFO - 2018-09-26 10:18:15 --> Model "Tasks_model" initialized
INFO - 2018-09-26 10:18:15 --> Model "Lists_model" initialized
INFO - 2018-09-26 10:18:15 --> Controller Class Initialized
INFO - 2018-09-26 10:18:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 10:18:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-26 10:18:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 10:18:15 --> Final output sent to browser
DEBUG - 2018-09-26 10:18:15 --> Total execution time: 0.0560
INFO - 2018-09-26 10:18:32 --> Config Class Initialized
INFO - 2018-09-26 10:18:32 --> Hooks Class Initialized
DEBUG - 2018-09-26 10:18:32 --> UTF-8 Support Enabled
INFO - 2018-09-26 10:18:32 --> Utf8 Class Initialized
INFO - 2018-09-26 10:18:32 --> URI Class Initialized
INFO - 2018-09-26 10:18:32 --> Router Class Initialized
INFO - 2018-09-26 10:18:32 --> Output Class Initialized
INFO - 2018-09-26 10:18:32 --> Security Class Initialized
DEBUG - 2018-09-26 10:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 10:18:32 --> Input Class Initialized
INFO - 2018-09-26 10:18:32 --> Language Class Initialized
INFO - 2018-09-26 10:18:32 --> Loader Class Initialized
INFO - 2018-09-26 10:18:32 --> Helper loaded: url_helper
INFO - 2018-09-26 10:18:32 --> Helper loaded: form_helper
INFO - 2018-09-26 10:18:32 --> Helper loaded: html_helper
INFO - 2018-09-26 10:18:32 --> Database Driver Class Initialized
INFO - 2018-09-26 10:18:32 --> Form Validation Class Initialized
DEBUG - 2018-09-26 10:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 10:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 10:18:32 --> Model "User_model" initialized
INFO - 2018-09-26 10:18:32 --> Model "Project_model" initialized
INFO - 2018-09-26 10:18:32 --> Model "Tasks_model" initialized
INFO - 2018-09-26 10:18:32 --> Model "Lists_model" initialized
INFO - 2018-09-26 10:18:32 --> Controller Class Initialized
ERROR - 2018-09-26 10:18:32 --> Severity: 4096 --> Object of class Home could not be converted to string D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\home.php 19
ERROR - 2018-09-26 10:18:32 --> Severity: Notice --> Undefined property: Home::$ D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\home.php 19
ERROR - 2018-09-26 10:18:32 --> Severity: Notice --> Trying to get property 'load' of non-object D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\home.php 19
ERROR - 2018-09-26 10:18:32 --> Severity: error --> Exception: Call to a member function library() on null D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\home.php 19
INFO - 2018-09-26 10:19:54 --> Config Class Initialized
INFO - 2018-09-26 10:19:54 --> Hooks Class Initialized
DEBUG - 2018-09-26 10:19:54 --> UTF-8 Support Enabled
INFO - 2018-09-26 10:19:54 --> Utf8 Class Initialized
INFO - 2018-09-26 10:19:54 --> URI Class Initialized
INFO - 2018-09-26 10:19:54 --> Router Class Initialized
INFO - 2018-09-26 10:19:54 --> Output Class Initialized
INFO - 2018-09-26 10:19:54 --> Security Class Initialized
DEBUG - 2018-09-26 10:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 10:19:54 --> Input Class Initialized
INFO - 2018-09-26 10:19:54 --> Language Class Initialized
INFO - 2018-09-26 10:19:54 --> Loader Class Initialized
INFO - 2018-09-26 10:19:54 --> Helper loaded: url_helper
INFO - 2018-09-26 10:19:54 --> Helper loaded: form_helper
INFO - 2018-09-26 10:19:54 --> Helper loaded: html_helper
INFO - 2018-09-26 10:19:54 --> Database Driver Class Initialized
INFO - 2018-09-26 10:19:54 --> Form Validation Class Initialized
DEBUG - 2018-09-26 10:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 10:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 10:19:54 --> Model "User_model" initialized
INFO - 2018-09-26 10:19:54 --> Model "Project_model" initialized
INFO - 2018-09-26 10:19:54 --> Model "Tasks_model" initialized
INFO - 2018-09-26 10:19:54 --> Model "Lists_model" initialized
INFO - 2018-09-26 10:19:54 --> Controller Class Initialized
INFO - 2018-09-26 10:19:54 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 10:19:54 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-26 10:19:54 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 10:19:54 --> Final output sent to browser
DEBUG - 2018-09-26 10:19:54 --> Total execution time: 0.0550
INFO - 2018-09-26 10:32:11 --> Config Class Initialized
INFO - 2018-09-26 10:32:11 --> Hooks Class Initialized
DEBUG - 2018-09-26 10:32:11 --> UTF-8 Support Enabled
INFO - 2018-09-26 10:32:11 --> Utf8 Class Initialized
INFO - 2018-09-26 10:32:11 --> URI Class Initialized
INFO - 2018-09-26 10:32:11 --> Router Class Initialized
INFO - 2018-09-26 10:32:11 --> Output Class Initialized
INFO - 2018-09-26 10:32:11 --> Security Class Initialized
DEBUG - 2018-09-26 10:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 10:32:11 --> Input Class Initialized
INFO - 2018-09-26 10:32:11 --> Language Class Initialized
INFO - 2018-09-26 10:32:11 --> Loader Class Initialized
INFO - 2018-09-26 10:32:11 --> Helper loaded: url_helper
INFO - 2018-09-26 10:32:11 --> Helper loaded: form_helper
INFO - 2018-09-26 10:32:11 --> Helper loaded: html_helper
INFO - 2018-09-26 10:32:11 --> Database Driver Class Initialized
INFO - 2018-09-26 10:32:11 --> Form Validation Class Initialized
DEBUG - 2018-09-26 10:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 10:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 10:32:11 --> Model "User_model" initialized
INFO - 2018-09-26 10:32:11 --> Model "Project_model" initialized
INFO - 2018-09-26 10:32:11 --> Model "Tasks_model" initialized
INFO - 2018-09-26 10:32:11 --> Model "Lists_model" initialized
INFO - 2018-09-26 10:32:11 --> Controller Class Initialized
INFO - 2018-09-26 10:32:11 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 10:32:11 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-26 10:32:11 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 10:32:11 --> Final output sent to browser
DEBUG - 2018-09-26 10:32:11 --> Total execution time: 0.0500
INFO - 2018-09-26 12:16:58 --> Config Class Initialized
INFO - 2018-09-26 12:16:58 --> Hooks Class Initialized
DEBUG - 2018-09-26 12:16:58 --> UTF-8 Support Enabled
INFO - 2018-09-26 12:16:58 --> Utf8 Class Initialized
INFO - 2018-09-26 12:16:58 --> URI Class Initialized
INFO - 2018-09-26 12:16:58 --> Router Class Initialized
INFO - 2018-09-26 12:16:58 --> Output Class Initialized
INFO - 2018-09-26 12:16:58 --> Security Class Initialized
DEBUG - 2018-09-26 12:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 12:16:58 --> Input Class Initialized
INFO - 2018-09-26 12:16:58 --> Language Class Initialized
ERROR - 2018-09-26 12:16:58 --> 404 Page Not Found: Home/index
INFO - 2018-09-26 12:17:14 --> Config Class Initialized
INFO - 2018-09-26 12:17:14 --> Hooks Class Initialized
DEBUG - 2018-09-26 12:17:14 --> UTF-8 Support Enabled
INFO - 2018-09-26 12:17:14 --> Utf8 Class Initialized
INFO - 2018-09-26 12:17:14 --> URI Class Initialized
INFO - 2018-09-26 12:17:14 --> Router Class Initialized
INFO - 2018-09-26 12:17:14 --> Output Class Initialized
INFO - 2018-09-26 12:17:14 --> Security Class Initialized
DEBUG - 2018-09-26 12:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 12:17:14 --> Input Class Initialized
INFO - 2018-09-26 12:17:14 --> Language Class Initialized
INFO - 2018-09-26 12:17:14 --> Loader Class Initialized
INFO - 2018-09-26 12:17:14 --> Helper loaded: url_helper
INFO - 2018-09-26 12:17:14 --> Helper loaded: form_helper
INFO - 2018-09-26 12:17:14 --> Helper loaded: html_helper
INFO - 2018-09-26 12:17:14 --> Database Driver Class Initialized
INFO - 2018-09-26 12:17:14 --> Form Validation Class Initialized
DEBUG - 2018-09-26 12:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 12:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 12:17:14 --> Model "User_model" initialized
INFO - 2018-09-26 12:17:14 --> Model "Project_model" initialized
INFO - 2018-09-26 12:17:14 --> Model "Tasks_model" initialized
INFO - 2018-09-26 12:17:14 --> Model "Lists_model" initialized
INFO - 2018-09-26 12:17:14 --> Controller Class Initialized
INFO - 2018-09-26 12:17:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 12:17:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-26 12:17:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 12:17:14 --> Final output sent to browser
DEBUG - 2018-09-26 12:17:14 --> Total execution time: 0.1290
INFO - 2018-09-26 12:17:56 --> Config Class Initialized
INFO - 2018-09-26 12:17:56 --> Hooks Class Initialized
DEBUG - 2018-09-26 12:17:56 --> UTF-8 Support Enabled
INFO - 2018-09-26 12:17:56 --> Utf8 Class Initialized
INFO - 2018-09-26 12:17:56 --> URI Class Initialized
INFO - 2018-09-26 12:17:56 --> Router Class Initialized
INFO - 2018-09-26 12:17:56 --> Output Class Initialized
INFO - 2018-09-26 12:17:56 --> Security Class Initialized
DEBUG - 2018-09-26 12:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 12:17:56 --> Input Class Initialized
INFO - 2018-09-26 12:17:56 --> Language Class Initialized
INFO - 2018-09-26 12:17:56 --> Loader Class Initialized
INFO - 2018-09-26 12:17:56 --> Helper loaded: url_helper
INFO - 2018-09-26 12:17:56 --> Helper loaded: form_helper
INFO - 2018-09-26 12:17:56 --> Helper loaded: html_helper
INFO - 2018-09-26 12:17:56 --> Database Driver Class Initialized
INFO - 2018-09-26 12:17:56 --> Form Validation Class Initialized
DEBUG - 2018-09-26 12:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 12:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 12:17:56 --> Model "User_model" initialized
INFO - 2018-09-26 12:17:56 --> Model "Project_model" initialized
INFO - 2018-09-26 12:17:56 --> Model "Tasks_model" initialized
INFO - 2018-09-26 12:17:56 --> Model "Lists_model" initialized
INFO - 2018-09-26 12:17:56 --> Controller Class Initialized
INFO - 2018-09-26 12:17:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 12:17:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-26 12:17:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 12:17:56 --> Final output sent to browser
DEBUG - 2018-09-26 12:17:56 --> Total execution time: 0.0580
INFO - 2018-09-26 12:24:27 --> Config Class Initialized
INFO - 2018-09-26 12:24:27 --> Hooks Class Initialized
DEBUG - 2018-09-26 12:24:27 --> UTF-8 Support Enabled
INFO - 2018-09-26 12:24:27 --> Utf8 Class Initialized
INFO - 2018-09-26 12:24:27 --> URI Class Initialized
INFO - 2018-09-26 12:24:27 --> Router Class Initialized
INFO - 2018-09-26 12:24:27 --> Output Class Initialized
INFO - 2018-09-26 12:24:27 --> Security Class Initialized
DEBUG - 2018-09-26 12:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 12:24:27 --> Input Class Initialized
INFO - 2018-09-26 12:24:27 --> Language Class Initialized
INFO - 2018-09-26 12:24:27 --> Loader Class Initialized
INFO - 2018-09-26 12:24:27 --> Helper loaded: url_helper
INFO - 2018-09-26 12:24:27 --> Helper loaded: form_helper
INFO - 2018-09-26 12:24:27 --> Helper loaded: html_helper
INFO - 2018-09-26 12:24:27 --> Database Driver Class Initialized
INFO - 2018-09-26 12:24:27 --> Form Validation Class Initialized
DEBUG - 2018-09-26 12:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 12:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 12:24:27 --> Model "User_model" initialized
INFO - 2018-09-26 12:24:27 --> Model "Project_model" initialized
INFO - 2018-09-26 12:24:27 --> Model "Tasks_model" initialized
INFO - 2018-09-26 12:24:27 --> Model "Lists_model" initialized
INFO - 2018-09-26 12:24:27 --> Controller Class Initialized
INFO - 2018-09-26 12:24:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-26 12:24:28 --> Config Class Initialized
INFO - 2018-09-26 12:24:28 --> Hooks Class Initialized
DEBUG - 2018-09-26 12:24:28 --> UTF-8 Support Enabled
INFO - 2018-09-26 12:24:28 --> Utf8 Class Initialized
INFO - 2018-09-26 12:24:28 --> URI Class Initialized
INFO - 2018-09-26 12:24:28 --> Router Class Initialized
INFO - 2018-09-26 12:24:28 --> Output Class Initialized
INFO - 2018-09-26 12:24:28 --> Security Class Initialized
DEBUG - 2018-09-26 12:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 12:24:28 --> Input Class Initialized
INFO - 2018-09-26 12:24:28 --> Language Class Initialized
INFO - 2018-09-26 12:24:28 --> Loader Class Initialized
INFO - 2018-09-26 12:24:28 --> Helper loaded: url_helper
INFO - 2018-09-26 12:24:28 --> Helper loaded: form_helper
INFO - 2018-09-26 12:24:28 --> Helper loaded: html_helper
INFO - 2018-09-26 12:24:28 --> Database Driver Class Initialized
INFO - 2018-09-26 12:24:28 --> Form Validation Class Initialized
DEBUG - 2018-09-26 12:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 12:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 12:24:28 --> Model "User_model" initialized
INFO - 2018-09-26 12:24:28 --> Model "Project_model" initialized
INFO - 2018-09-26 12:24:28 --> Model "Tasks_model" initialized
INFO - 2018-09-26 12:24:28 --> Model "Lists_model" initialized
INFO - 2018-09-26 12:24:28 --> Controller Class Initialized
INFO - 2018-09-26 12:24:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 12:24:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-26 12:24:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 12:24:28 --> Final output sent to browser
DEBUG - 2018-09-26 12:24:28 --> Total execution time: 0.1300
INFO - 2018-09-26 12:24:32 --> Config Class Initialized
INFO - 2018-09-26 12:24:32 --> Hooks Class Initialized
DEBUG - 2018-09-26 12:24:32 --> UTF-8 Support Enabled
INFO - 2018-09-26 12:24:32 --> Utf8 Class Initialized
INFO - 2018-09-26 12:24:32 --> URI Class Initialized
INFO - 2018-09-26 12:24:32 --> Router Class Initialized
INFO - 2018-09-26 12:24:32 --> Output Class Initialized
INFO - 2018-09-26 12:24:32 --> Security Class Initialized
DEBUG - 2018-09-26 12:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 12:24:32 --> Input Class Initialized
INFO - 2018-09-26 12:24:32 --> Language Class Initialized
INFO - 2018-09-26 12:24:32 --> Loader Class Initialized
INFO - 2018-09-26 12:24:32 --> Helper loaded: url_helper
INFO - 2018-09-26 12:24:32 --> Helper loaded: form_helper
INFO - 2018-09-26 12:24:32 --> Helper loaded: html_helper
INFO - 2018-09-26 12:24:32 --> Database Driver Class Initialized
INFO - 2018-09-26 12:24:32 --> Form Validation Class Initialized
DEBUG - 2018-09-26 12:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 12:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 12:24:32 --> Model "User_model" initialized
INFO - 2018-09-26 12:24:32 --> Model "Project_model" initialized
INFO - 2018-09-26 12:24:32 --> Model "Tasks_model" initialized
INFO - 2018-09-26 12:24:32 --> Model "Lists_model" initialized
INFO - 2018-09-26 12:24:32 --> Controller Class Initialized
ERROR - 2018-09-26 12:24:32 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\code_igniter\application\views\project_views\layouts\main.php 31
ERROR - 2018-09-26 12:24:32 --> Severity: Notice --> Undefined variable: list_library D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 71
INFO - 2018-09-26 12:24:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 12:24:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-26 12:24:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 12:24:32 --> Final output sent to browser
DEBUG - 2018-09-26 12:24:32 --> Total execution time: 0.1356
INFO - 2018-09-26 12:25:26 --> Config Class Initialized
INFO - 2018-09-26 12:25:26 --> Hooks Class Initialized
DEBUG - 2018-09-26 12:25:26 --> UTF-8 Support Enabled
INFO - 2018-09-26 12:25:26 --> Utf8 Class Initialized
INFO - 2018-09-26 12:25:26 --> URI Class Initialized
INFO - 2018-09-26 12:25:26 --> Router Class Initialized
INFO - 2018-09-26 12:25:26 --> Output Class Initialized
INFO - 2018-09-26 12:25:26 --> Security Class Initialized
DEBUG - 2018-09-26 12:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 12:25:26 --> Input Class Initialized
INFO - 2018-09-26 12:25:26 --> Language Class Initialized
INFO - 2018-09-26 12:25:26 --> Loader Class Initialized
INFO - 2018-09-26 12:25:26 --> Helper loaded: url_helper
INFO - 2018-09-26 12:25:26 --> Helper loaded: form_helper
INFO - 2018-09-26 12:25:26 --> Helper loaded: html_helper
INFO - 2018-09-26 12:25:26 --> Database Driver Class Initialized
INFO - 2018-09-26 12:25:26 --> Form Validation Class Initialized
DEBUG - 2018-09-26 12:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 12:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 12:25:26 --> Model "User_model" initialized
INFO - 2018-09-26 12:25:26 --> Model "Project_model" initialized
INFO - 2018-09-26 12:25:26 --> Model "Tasks_model" initialized
INFO - 2018-09-26 12:25:26 --> Model "Lists_model" initialized
INFO - 2018-09-26 12:25:26 --> Controller Class Initialized
ERROR - 2018-09-26 12:25:26 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\code_igniter\application\views\project_views\layouts\main.php 31
INFO - 2018-09-26 12:25:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 12:25:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-26 12:25:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 12:25:26 --> Final output sent to browser
DEBUG - 2018-09-26 12:25:26 --> Total execution time: 0.0790
INFO - 2018-09-26 12:25:31 --> Config Class Initialized
INFO - 2018-09-26 12:25:31 --> Hooks Class Initialized
DEBUG - 2018-09-26 12:25:31 --> UTF-8 Support Enabled
INFO - 2018-09-26 12:25:31 --> Utf8 Class Initialized
INFO - 2018-09-26 12:25:31 --> URI Class Initialized
INFO - 2018-09-26 12:25:31 --> Router Class Initialized
INFO - 2018-09-26 12:25:31 --> Output Class Initialized
INFO - 2018-09-26 12:25:31 --> Security Class Initialized
DEBUG - 2018-09-26 12:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 12:25:31 --> Input Class Initialized
INFO - 2018-09-26 12:25:31 --> Language Class Initialized
INFO - 2018-09-26 12:25:31 --> Loader Class Initialized
INFO - 2018-09-26 12:25:31 --> Helper loaded: url_helper
INFO - 2018-09-26 12:25:31 --> Helper loaded: form_helper
INFO - 2018-09-26 12:25:31 --> Helper loaded: html_helper
INFO - 2018-09-26 12:25:31 --> Database Driver Class Initialized
INFO - 2018-09-26 12:25:31 --> Form Validation Class Initialized
DEBUG - 2018-09-26 12:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 12:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 12:25:31 --> Model "User_model" initialized
INFO - 2018-09-26 12:25:31 --> Model "Project_model" initialized
INFO - 2018-09-26 12:25:31 --> Model "Tasks_model" initialized
INFO - 2018-09-26 12:25:31 --> Model "Lists_model" initialized
INFO - 2018-09-26 12:25:31 --> Controller Class Initialized
INFO - 2018-09-26 12:25:31 --> Config Class Initialized
INFO - 2018-09-26 12:25:31 --> Hooks Class Initialized
DEBUG - 2018-09-26 12:25:31 --> UTF-8 Support Enabled
INFO - 2018-09-26 12:25:31 --> Utf8 Class Initialized
INFO - 2018-09-26 12:25:31 --> URI Class Initialized
INFO - 2018-09-26 12:25:31 --> Router Class Initialized
INFO - 2018-09-26 12:25:31 --> Output Class Initialized
INFO - 2018-09-26 12:25:31 --> Security Class Initialized
DEBUG - 2018-09-26 12:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 12:25:31 --> Input Class Initialized
INFO - 2018-09-26 12:25:31 --> Language Class Initialized
INFO - 2018-09-26 12:25:31 --> Loader Class Initialized
INFO - 2018-09-26 12:25:31 --> Helper loaded: url_helper
INFO - 2018-09-26 12:25:31 --> Helper loaded: form_helper
INFO - 2018-09-26 12:25:31 --> Helper loaded: html_helper
INFO - 2018-09-26 12:25:31 --> Database Driver Class Initialized
INFO - 2018-09-26 12:25:31 --> Form Validation Class Initialized
DEBUG - 2018-09-26 12:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 12:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 12:25:31 --> Model "User_model" initialized
INFO - 2018-09-26 12:25:31 --> Model "Project_model" initialized
INFO - 2018-09-26 12:25:31 --> Model "Tasks_model" initialized
INFO - 2018-09-26 12:25:31 --> Model "Lists_model" initialized
INFO - 2018-09-26 12:25:31 --> Controller Class Initialized
INFO - 2018-09-26 12:25:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 12:25:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-26 12:25:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 12:25:31 --> Final output sent to browser
DEBUG - 2018-09-26 12:25:31 --> Total execution time: 0.0330
INFO - 2018-09-26 12:25:36 --> Config Class Initialized
INFO - 2018-09-26 12:25:36 --> Hooks Class Initialized
DEBUG - 2018-09-26 12:25:36 --> UTF-8 Support Enabled
INFO - 2018-09-26 12:25:36 --> Utf8 Class Initialized
INFO - 2018-09-26 12:25:36 --> URI Class Initialized
INFO - 2018-09-26 12:25:36 --> Router Class Initialized
INFO - 2018-09-26 12:25:36 --> Output Class Initialized
INFO - 2018-09-26 12:25:36 --> Security Class Initialized
DEBUG - 2018-09-26 12:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 12:25:36 --> Input Class Initialized
INFO - 2018-09-26 12:25:36 --> Language Class Initialized
INFO - 2018-09-26 12:25:36 --> Loader Class Initialized
INFO - 2018-09-26 12:25:36 --> Helper loaded: url_helper
INFO - 2018-09-26 12:25:36 --> Helper loaded: form_helper
INFO - 2018-09-26 12:25:36 --> Helper loaded: html_helper
INFO - 2018-09-26 12:25:36 --> Database Driver Class Initialized
INFO - 2018-09-26 12:25:36 --> Form Validation Class Initialized
DEBUG - 2018-09-26 12:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 12:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 12:25:36 --> Model "User_model" initialized
INFO - 2018-09-26 12:25:37 --> Model "Project_model" initialized
INFO - 2018-09-26 12:25:37 --> Model "Tasks_model" initialized
INFO - 2018-09-26 12:25:37 --> Model "Lists_model" initialized
INFO - 2018-09-26 12:25:37 --> Controller Class Initialized
INFO - 2018-09-26 12:25:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-26 12:25:37 --> Config Class Initialized
INFO - 2018-09-26 12:25:37 --> Hooks Class Initialized
DEBUG - 2018-09-26 12:25:37 --> UTF-8 Support Enabled
INFO - 2018-09-26 12:25:37 --> Utf8 Class Initialized
INFO - 2018-09-26 12:25:37 --> URI Class Initialized
INFO - 2018-09-26 12:25:37 --> Router Class Initialized
INFO - 2018-09-26 12:25:37 --> Output Class Initialized
INFO - 2018-09-26 12:25:37 --> Security Class Initialized
DEBUG - 2018-09-26 12:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 12:25:37 --> Input Class Initialized
INFO - 2018-09-26 12:25:37 --> Language Class Initialized
INFO - 2018-09-26 12:25:37 --> Loader Class Initialized
INFO - 2018-09-26 12:25:37 --> Helper loaded: url_helper
INFO - 2018-09-26 12:25:37 --> Helper loaded: form_helper
INFO - 2018-09-26 12:25:37 --> Helper loaded: html_helper
INFO - 2018-09-26 12:25:37 --> Database Driver Class Initialized
INFO - 2018-09-26 12:25:37 --> Form Validation Class Initialized
DEBUG - 2018-09-26 12:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 12:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 12:25:37 --> Model "User_model" initialized
INFO - 2018-09-26 12:25:37 --> Model "Project_model" initialized
INFO - 2018-09-26 12:25:37 --> Model "Tasks_model" initialized
INFO - 2018-09-26 12:25:37 --> Model "Lists_model" initialized
INFO - 2018-09-26 12:25:37 --> Controller Class Initialized
INFO - 2018-09-26 12:25:37 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 12:25:37 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-26 12:25:37 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 12:25:37 --> Final output sent to browser
DEBUG - 2018-09-26 12:25:37 --> Total execution time: 0.0380
INFO - 2018-09-26 12:25:39 --> Config Class Initialized
INFO - 2018-09-26 12:25:39 --> Hooks Class Initialized
DEBUG - 2018-09-26 12:25:39 --> UTF-8 Support Enabled
INFO - 2018-09-26 12:25:39 --> Utf8 Class Initialized
INFO - 2018-09-26 12:25:39 --> URI Class Initialized
INFO - 2018-09-26 12:25:39 --> Router Class Initialized
INFO - 2018-09-26 12:25:39 --> Output Class Initialized
INFO - 2018-09-26 12:25:39 --> Security Class Initialized
DEBUG - 2018-09-26 12:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 12:25:39 --> Input Class Initialized
INFO - 2018-09-26 12:25:39 --> Language Class Initialized
INFO - 2018-09-26 12:25:39 --> Loader Class Initialized
INFO - 2018-09-26 12:25:39 --> Helper loaded: url_helper
INFO - 2018-09-26 12:25:39 --> Helper loaded: form_helper
INFO - 2018-09-26 12:25:39 --> Helper loaded: html_helper
INFO - 2018-09-26 12:25:39 --> Database Driver Class Initialized
INFO - 2018-09-26 12:25:39 --> Form Validation Class Initialized
DEBUG - 2018-09-26 12:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 12:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 12:25:39 --> Model "User_model" initialized
INFO - 2018-09-26 12:25:39 --> Model "Project_model" initialized
INFO - 2018-09-26 12:25:39 --> Model "Tasks_model" initialized
INFO - 2018-09-26 12:25:39 --> Model "Lists_model" initialized
INFO - 2018-09-26 12:25:39 --> Controller Class Initialized
ERROR - 2018-09-26 12:25:39 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\code_igniter\application\views\project_views\layouts\main.php 31
INFO - 2018-09-26 12:25:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 12:25:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-26 12:25:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 12:25:39 --> Final output sent to browser
DEBUG - 2018-09-26 12:25:39 --> Total execution time: 0.0532
INFO - 2018-09-26 12:26:11 --> Config Class Initialized
INFO - 2018-09-26 12:26:11 --> Hooks Class Initialized
DEBUG - 2018-09-26 12:26:11 --> UTF-8 Support Enabled
INFO - 2018-09-26 12:26:11 --> Utf8 Class Initialized
INFO - 2018-09-26 12:26:11 --> URI Class Initialized
INFO - 2018-09-26 12:26:12 --> Router Class Initialized
INFO - 2018-09-26 12:26:12 --> Output Class Initialized
INFO - 2018-09-26 12:26:12 --> Security Class Initialized
DEBUG - 2018-09-26 12:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 12:26:12 --> Input Class Initialized
INFO - 2018-09-26 12:26:12 --> Language Class Initialized
INFO - 2018-09-26 12:26:12 --> Loader Class Initialized
INFO - 2018-09-26 12:26:12 --> Helper loaded: url_helper
INFO - 2018-09-26 12:26:12 --> Helper loaded: form_helper
INFO - 2018-09-26 12:26:12 --> Helper loaded: html_helper
INFO - 2018-09-26 12:26:12 --> Database Driver Class Initialized
INFO - 2018-09-26 12:26:12 --> Form Validation Class Initialized
DEBUG - 2018-09-26 12:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 12:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 12:26:12 --> Model "User_model" initialized
INFO - 2018-09-26 12:26:12 --> Model "Project_model" initialized
INFO - 2018-09-26 12:26:12 --> Model "Tasks_model" initialized
INFO - 2018-09-26 12:26:12 --> Model "Lists_model" initialized
INFO - 2018-09-26 12:26:12 --> Controller Class Initialized
INFO - 2018-09-26 12:26:12 --> Config Class Initialized
INFO - 2018-09-26 12:26:12 --> Hooks Class Initialized
DEBUG - 2018-09-26 12:26:12 --> UTF-8 Support Enabled
INFO - 2018-09-26 12:26:12 --> Utf8 Class Initialized
INFO - 2018-09-26 12:26:12 --> URI Class Initialized
INFO - 2018-09-26 12:26:12 --> Router Class Initialized
INFO - 2018-09-26 12:26:12 --> Output Class Initialized
INFO - 2018-09-26 12:26:12 --> Security Class Initialized
DEBUG - 2018-09-26 12:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-26 12:26:12 --> Input Class Initialized
INFO - 2018-09-26 12:26:12 --> Language Class Initialized
INFO - 2018-09-26 12:26:12 --> Loader Class Initialized
INFO - 2018-09-26 12:26:12 --> Helper loaded: url_helper
INFO - 2018-09-26 12:26:12 --> Helper loaded: form_helper
INFO - 2018-09-26 12:26:12 --> Helper loaded: html_helper
INFO - 2018-09-26 12:26:12 --> Database Driver Class Initialized
INFO - 2018-09-26 12:26:12 --> Form Validation Class Initialized
DEBUG - 2018-09-26 12:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-26 12:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-26 12:26:12 --> Model "User_model" initialized
INFO - 2018-09-26 12:26:12 --> Model "Project_model" initialized
INFO - 2018-09-26 12:26:12 --> Model "Tasks_model" initialized
INFO - 2018-09-26 12:26:12 --> Model "Lists_model" initialized
INFO - 2018-09-26 12:26:12 --> Controller Class Initialized
INFO - 2018-09-26 12:26:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-26 12:26:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-26 12:26:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-26 12:26:12 --> Final output sent to browser
DEBUG - 2018-09-26 12:26:12 --> Total execution time: 0.0430
