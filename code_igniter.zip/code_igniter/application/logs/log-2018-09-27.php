<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-09-27 03:57:32 --> Config Class Initialized
INFO - 2018-09-27 03:57:32 --> Hooks Class Initialized
DEBUG - 2018-09-27 03:57:32 --> UTF-8 Support Enabled
INFO - 2018-09-27 03:57:32 --> Utf8 Class Initialized
INFO - 2018-09-27 03:57:32 --> URI Class Initialized
INFO - 2018-09-27 03:57:32 --> Router Class Initialized
INFO - 2018-09-27 03:57:32 --> Output Class Initialized
INFO - 2018-09-27 03:57:32 --> Security Class Initialized
DEBUG - 2018-09-27 03:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 03:57:32 --> Input Class Initialized
INFO - 2018-09-27 03:57:32 --> Language Class Initialized
INFO - 2018-09-27 03:57:32 --> Loader Class Initialized
INFO - 2018-09-27 03:57:32 --> Helper loaded: url_helper
INFO - 2018-09-27 03:57:32 --> Helper loaded: form_helper
INFO - 2018-09-27 03:57:32 --> Helper loaded: html_helper
INFO - 2018-09-27 03:57:32 --> Database Driver Class Initialized
INFO - 2018-09-27 03:57:32 --> Form Validation Class Initialized
DEBUG - 2018-09-27 03:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 03:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 03:57:32 --> Model "User_model" initialized
INFO - 2018-09-27 03:57:32 --> Model "Project_model" initialized
INFO - 2018-09-27 03:57:32 --> Model "Tasks_model" initialized
INFO - 2018-09-27 03:57:32 --> Model "Lists_model" initialized
INFO - 2018-09-27 03:57:32 --> Controller Class Initialized
ERROR - 2018-09-27 03:57:32 --> Severity: error --> Exception: Too few arguments to function Home::index(), 0 passed in D:\xampp\htdocs\code_igniter\system\core\CodeIgniter.php on line 532 and exactly 1 expected D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\home.php 5
INFO - 2018-09-27 03:57:43 --> Config Class Initialized
INFO - 2018-09-27 03:57:43 --> Hooks Class Initialized
DEBUG - 2018-09-27 03:57:43 --> UTF-8 Support Enabled
INFO - 2018-09-27 03:57:43 --> Utf8 Class Initialized
INFO - 2018-09-27 03:57:43 --> URI Class Initialized
INFO - 2018-09-27 03:57:43 --> Router Class Initialized
INFO - 2018-09-27 03:57:43 --> Output Class Initialized
INFO - 2018-09-27 03:57:43 --> Security Class Initialized
DEBUG - 2018-09-27 03:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 03:57:43 --> Input Class Initialized
INFO - 2018-09-27 03:57:43 --> Language Class Initialized
INFO - 2018-09-27 03:57:43 --> Loader Class Initialized
INFO - 2018-09-27 03:57:43 --> Helper loaded: url_helper
INFO - 2018-09-27 03:57:43 --> Helper loaded: form_helper
INFO - 2018-09-27 03:57:43 --> Helper loaded: html_helper
INFO - 2018-09-27 03:57:43 --> Database Driver Class Initialized
INFO - 2018-09-27 03:57:43 --> Form Validation Class Initialized
DEBUG - 2018-09-27 03:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 03:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 03:57:43 --> Model "User_model" initialized
INFO - 2018-09-27 03:57:43 --> Model "Project_model" initialized
INFO - 2018-09-27 03:57:43 --> Model "Tasks_model" initialized
INFO - 2018-09-27 03:57:43 --> Model "Lists_model" initialized
INFO - 2018-09-27 03:57:43 --> Controller Class Initialized
ERROR - 2018-09-27 03:57:44 --> Severity: Warning --> Illegal string offset 'main_view' D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\home.php 14
ERROR - 2018-09-27 03:57:44 --> Severity: Warning --> Illegal string offset 'title' D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\home.php 15
ERROR - 2018-09-27 03:57:44 --> Severity: Warning --> Illegal string offset 'list_library' D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\home.php 20
ERROR - 2018-09-27 03:57:44 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\code_igniter\application\views\project_views\layouts\main.php 31
ERROR - 2018-09-27 03:57:44 --> Severity: Notice --> Undefined variable: list_library D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 70
INFO - 2018-09-27 03:57:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-27 03:57:44 --> Severity: Notice --> Undefined variable: main_view D:\xampp\htdocs\code_igniter\application\views\project_views\layouts\main.php 103
INFO - 2018-09-27 03:59:20 --> Config Class Initialized
INFO - 2018-09-27 03:59:20 --> Hooks Class Initialized
DEBUG - 2018-09-27 03:59:20 --> UTF-8 Support Enabled
INFO - 2018-09-27 03:59:20 --> Utf8 Class Initialized
INFO - 2018-09-27 03:59:20 --> URI Class Initialized
INFO - 2018-09-27 03:59:20 --> Router Class Initialized
INFO - 2018-09-27 03:59:20 --> Output Class Initialized
INFO - 2018-09-27 03:59:20 --> Security Class Initialized
DEBUG - 2018-09-27 03:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 03:59:20 --> Input Class Initialized
INFO - 2018-09-27 03:59:20 --> Language Class Initialized
INFO - 2018-09-27 03:59:20 --> Loader Class Initialized
INFO - 2018-09-27 03:59:20 --> Helper loaded: url_helper
INFO - 2018-09-27 03:59:20 --> Helper loaded: form_helper
INFO - 2018-09-27 03:59:20 --> Helper loaded: html_helper
INFO - 2018-09-27 03:59:20 --> Database Driver Class Initialized
INFO - 2018-09-27 03:59:20 --> Form Validation Class Initialized
DEBUG - 2018-09-27 03:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 03:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 03:59:20 --> Model "User_model" initialized
INFO - 2018-09-27 03:59:20 --> Model "Project_model" initialized
INFO - 2018-09-27 03:59:20 --> Model "Tasks_model" initialized
INFO - 2018-09-27 03:59:20 --> Model "Lists_model" initialized
INFO - 2018-09-27 03:59:20 --> Controller Class Initialized
ERROR - 2018-09-27 03:59:20 --> Severity: error --> Exception: Too few arguments to function Home::index(), 0 passed in D:\xampp\htdocs\code_igniter\system\core\CodeIgniter.php on line 532 and exactly 1 expected D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\home.php 5
INFO - 2018-09-27 03:59:35 --> Config Class Initialized
INFO - 2018-09-27 03:59:35 --> Hooks Class Initialized
DEBUG - 2018-09-27 03:59:35 --> UTF-8 Support Enabled
INFO - 2018-09-27 03:59:35 --> Utf8 Class Initialized
INFO - 2018-09-27 03:59:35 --> URI Class Initialized
INFO - 2018-09-27 03:59:35 --> Router Class Initialized
INFO - 2018-09-27 03:59:35 --> Output Class Initialized
INFO - 2018-09-27 03:59:35 --> Security Class Initialized
DEBUG - 2018-09-27 03:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 03:59:35 --> Input Class Initialized
INFO - 2018-09-27 03:59:35 --> Language Class Initialized
INFO - 2018-09-27 03:59:35 --> Loader Class Initialized
INFO - 2018-09-27 03:59:38 --> Helper loaded: url_helper
INFO - 2018-09-27 03:59:38 --> Helper loaded: form_helper
INFO - 2018-09-27 03:59:38 --> Helper loaded: html_helper
INFO - 2018-09-27 03:59:38 --> Database Driver Class Initialized
INFO - 2018-09-27 03:59:38 --> Form Validation Class Initialized
DEBUG - 2018-09-27 03:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 03:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 03:59:38 --> Model "User_model" initialized
INFO - 2018-09-27 03:59:38 --> Model "Project_model" initialized
INFO - 2018-09-27 03:59:38 --> Model "Tasks_model" initialized
INFO - 2018-09-27 03:59:38 --> Model "Lists_model" initialized
INFO - 2018-09-27 03:59:38 --> Controller Class Initialized
INFO - 2018-09-27 03:59:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 03:59:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 03:59:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 03:59:38 --> Final output sent to browser
DEBUG - 2018-09-27 03:59:38 --> Total execution time: 2.4591
INFO - 2018-09-27 03:59:54 --> Config Class Initialized
INFO - 2018-09-27 03:59:54 --> Hooks Class Initialized
DEBUG - 2018-09-27 03:59:54 --> UTF-8 Support Enabled
INFO - 2018-09-27 03:59:54 --> Utf8 Class Initialized
INFO - 2018-09-27 03:59:54 --> URI Class Initialized
INFO - 2018-09-27 03:59:54 --> Router Class Initialized
INFO - 2018-09-27 03:59:54 --> Output Class Initialized
INFO - 2018-09-27 03:59:54 --> Security Class Initialized
DEBUG - 2018-09-27 03:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 03:59:54 --> Input Class Initialized
INFO - 2018-09-27 03:59:54 --> Language Class Initialized
INFO - 2018-09-27 03:59:54 --> Loader Class Initialized
INFO - 2018-09-27 03:59:54 --> Helper loaded: url_helper
INFO - 2018-09-27 03:59:54 --> Helper loaded: form_helper
INFO - 2018-09-27 03:59:54 --> Helper loaded: html_helper
INFO - 2018-09-27 03:59:54 --> Database Driver Class Initialized
INFO - 2018-09-27 03:59:54 --> Form Validation Class Initialized
DEBUG - 2018-09-27 03:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 03:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 03:59:54 --> Model "User_model" initialized
INFO - 2018-09-27 03:59:54 --> Model "Project_model" initialized
INFO - 2018-09-27 03:59:54 --> Model "Tasks_model" initialized
INFO - 2018-09-27 03:59:54 --> Model "Lists_model" initialized
INFO - 2018-09-27 03:59:54 --> Controller Class Initialized
ERROR - 2018-09-27 03:59:54 --> Severity: Warning --> Illegal string offset 'main_view' D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\home.php 14
ERROR - 2018-09-27 03:59:54 --> Severity: Warning --> Illegal string offset 'title' D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\home.php 15
ERROR - 2018-09-27 03:59:54 --> Severity: Warning --> Illegal string offset 'list_library' D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\home.php 20
ERROR - 2018-09-27 03:59:54 --> Severity: Notice --> Undefined variable: title D:\xampp\htdocs\code_igniter\application\views\project_views\layouts\main.php 31
ERROR - 2018-09-27 03:59:54 --> Severity: Notice --> Undefined variable: list_library D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 70
INFO - 2018-09-27 03:59:54 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-27 03:59:54 --> Severity: Notice --> Undefined variable: main_view D:\xampp\htdocs\code_igniter\application\views\project_views\layouts\main.php 103
INFO - 2018-09-27 04:01:06 --> Config Class Initialized
INFO - 2018-09-27 04:01:06 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:01:06 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:01:06 --> Utf8 Class Initialized
INFO - 2018-09-27 04:01:06 --> URI Class Initialized
INFO - 2018-09-27 04:01:06 --> Router Class Initialized
INFO - 2018-09-27 04:01:06 --> Output Class Initialized
INFO - 2018-09-27 04:01:06 --> Security Class Initialized
DEBUG - 2018-09-27 04:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:01:06 --> Input Class Initialized
INFO - 2018-09-27 04:01:06 --> Language Class Initialized
INFO - 2018-09-27 04:01:06 --> Loader Class Initialized
INFO - 2018-09-27 04:01:06 --> Helper loaded: url_helper
INFO - 2018-09-27 04:01:06 --> Helper loaded: form_helper
INFO - 2018-09-27 04:01:06 --> Helper loaded: html_helper
INFO - 2018-09-27 04:01:06 --> Database Driver Class Initialized
INFO - 2018-09-27 04:01:06 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:01:06 --> Model "User_model" initialized
INFO - 2018-09-27 04:01:06 --> Model "Project_model" initialized
INFO - 2018-09-27 04:01:06 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:01:06 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:01:06 --> Controller Class Initialized
ERROR - 2018-09-27 04:01:06 --> Severity: error --> Exception: Too few arguments to function Home::index(), 0 passed in D:\xampp\htdocs\code_igniter\system\core\CodeIgniter.php on line 532 and exactly 1 expected D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\home.php 5
INFO - 2018-09-27 04:01:52 --> Config Class Initialized
INFO - 2018-09-27 04:01:52 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:01:52 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:01:52 --> Utf8 Class Initialized
INFO - 2018-09-27 04:01:52 --> URI Class Initialized
INFO - 2018-09-27 04:01:52 --> Router Class Initialized
INFO - 2018-09-27 04:01:52 --> Output Class Initialized
INFO - 2018-09-27 04:01:52 --> Security Class Initialized
DEBUG - 2018-09-27 04:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:01:52 --> Input Class Initialized
INFO - 2018-09-27 04:01:52 --> Language Class Initialized
INFO - 2018-09-27 04:01:52 --> Loader Class Initialized
INFO - 2018-09-27 04:01:52 --> Helper loaded: url_helper
INFO - 2018-09-27 04:01:52 --> Helper loaded: form_helper
INFO - 2018-09-27 04:01:52 --> Helper loaded: html_helper
INFO - 2018-09-27 04:01:52 --> Database Driver Class Initialized
INFO - 2018-09-27 04:01:52 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:01:52 --> Model "User_model" initialized
INFO - 2018-09-27 04:01:52 --> Model "Project_model" initialized
INFO - 2018-09-27 04:01:52 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:01:52 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:01:52 --> Controller Class Initialized
ERROR - 2018-09-27 04:01:52 --> Severity: error --> Exception: Too few arguments to function Home::index(), 0 passed in D:\xampp\htdocs\code_igniter\system\core\CodeIgniter.php on line 532 and exactly 1 expected D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\home.php 5
INFO - 2018-09-27 04:02:03 --> Config Class Initialized
INFO - 2018-09-27 04:02:03 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:02:03 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:02:03 --> Utf8 Class Initialized
INFO - 2018-09-27 04:02:03 --> URI Class Initialized
INFO - 2018-09-27 04:02:03 --> Router Class Initialized
INFO - 2018-09-27 04:02:03 --> Output Class Initialized
INFO - 2018-09-27 04:02:03 --> Security Class Initialized
DEBUG - 2018-09-27 04:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:02:03 --> Input Class Initialized
INFO - 2018-09-27 04:02:03 --> Language Class Initialized
INFO - 2018-09-27 04:02:03 --> Loader Class Initialized
INFO - 2018-09-27 04:02:03 --> Helper loaded: url_helper
INFO - 2018-09-27 04:02:03 --> Helper loaded: form_helper
INFO - 2018-09-27 04:02:03 --> Helper loaded: html_helper
INFO - 2018-09-27 04:02:03 --> Database Driver Class Initialized
INFO - 2018-09-27 04:02:03 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:02:03 --> Model "User_model" initialized
INFO - 2018-09-27 04:02:03 --> Model "Project_model" initialized
INFO - 2018-09-27 04:02:03 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:02:03 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:02:03 --> Controller Class Initialized
INFO - 2018-09-27 04:02:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:02:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:02:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:02:03 --> Final output sent to browser
DEBUG - 2018-09-27 04:02:03 --> Total execution time: 0.0530
INFO - 2018-09-27 04:04:00 --> Config Class Initialized
INFO - 2018-09-27 04:04:00 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:04:00 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:04:00 --> Utf8 Class Initialized
INFO - 2018-09-27 04:04:00 --> URI Class Initialized
INFO - 2018-09-27 04:04:00 --> Router Class Initialized
INFO - 2018-09-27 04:04:00 --> Output Class Initialized
INFO - 2018-09-27 04:04:00 --> Security Class Initialized
DEBUG - 2018-09-27 04:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:04:00 --> Input Class Initialized
INFO - 2018-09-27 04:04:00 --> Language Class Initialized
INFO - 2018-09-27 04:04:00 --> Loader Class Initialized
INFO - 2018-09-27 04:04:00 --> Helper loaded: url_helper
INFO - 2018-09-27 04:04:00 --> Helper loaded: form_helper
INFO - 2018-09-27 04:04:00 --> Helper loaded: html_helper
INFO - 2018-09-27 04:04:00 --> Database Driver Class Initialized
INFO - 2018-09-27 04:04:00 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:04:00 --> Model "User_model" initialized
INFO - 2018-09-27 04:04:00 --> Model "Project_model" initialized
INFO - 2018-09-27 04:04:00 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:04:00 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:04:00 --> Controller Class Initialized
INFO - 2018-09-27 04:04:00 --> Final output sent to browser
DEBUG - 2018-09-27 04:04:00 --> Total execution time: 0.0880
INFO - 2018-09-27 04:04:14 --> Config Class Initialized
INFO - 2018-09-27 04:04:14 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:04:14 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:04:14 --> Utf8 Class Initialized
INFO - 2018-09-27 04:04:14 --> URI Class Initialized
INFO - 2018-09-27 04:04:14 --> Router Class Initialized
INFO - 2018-09-27 04:04:14 --> Output Class Initialized
INFO - 2018-09-27 04:04:14 --> Security Class Initialized
DEBUG - 2018-09-27 04:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:04:14 --> Input Class Initialized
INFO - 2018-09-27 04:04:14 --> Language Class Initialized
INFO - 2018-09-27 04:04:14 --> Loader Class Initialized
INFO - 2018-09-27 04:04:14 --> Helper loaded: url_helper
INFO - 2018-09-27 04:04:14 --> Helper loaded: form_helper
INFO - 2018-09-27 04:04:14 --> Helper loaded: html_helper
INFO - 2018-09-27 04:04:14 --> Database Driver Class Initialized
INFO - 2018-09-27 04:04:14 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:04:14 --> Model "User_model" initialized
INFO - 2018-09-27 04:04:14 --> Model "Project_model" initialized
INFO - 2018-09-27 04:04:14 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:04:14 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:04:14 --> Controller Class Initialized
ERROR - 2018-09-27 04:04:14 --> Severity: Notice --> Undefined variable: list_library D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 70
INFO - 2018-09-27 04:04:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:04:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:04:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:04:14 --> Final output sent to browser
DEBUG - 2018-09-27 04:04:14 --> Total execution time: 0.0520
INFO - 2018-09-27 04:04:55 --> Config Class Initialized
INFO - 2018-09-27 04:04:55 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:04:55 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:04:55 --> Utf8 Class Initialized
INFO - 2018-09-27 04:04:55 --> URI Class Initialized
INFO - 2018-09-27 04:04:55 --> Router Class Initialized
INFO - 2018-09-27 04:04:55 --> Output Class Initialized
INFO - 2018-09-27 04:04:55 --> Security Class Initialized
DEBUG - 2018-09-27 04:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:04:55 --> Input Class Initialized
INFO - 2018-09-27 04:04:55 --> Language Class Initialized
INFO - 2018-09-27 04:04:55 --> Loader Class Initialized
INFO - 2018-09-27 04:04:55 --> Helper loaded: url_helper
INFO - 2018-09-27 04:04:55 --> Helper loaded: form_helper
INFO - 2018-09-27 04:04:55 --> Helper loaded: html_helper
INFO - 2018-09-27 04:04:55 --> Database Driver Class Initialized
INFO - 2018-09-27 04:04:55 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:04:55 --> Model "User_model" initialized
INFO - 2018-09-27 04:04:55 --> Model "Project_model" initialized
INFO - 2018-09-27 04:04:55 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:04:55 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:04:55 --> Controller Class Initialized
INFO - 2018-09-27 04:04:55 --> Final output sent to browser
DEBUG - 2018-09-27 04:04:55 --> Total execution time: 0.0490
INFO - 2018-09-27 04:05:09 --> Config Class Initialized
INFO - 2018-09-27 04:05:09 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:05:09 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:05:09 --> Utf8 Class Initialized
INFO - 2018-09-27 04:05:09 --> URI Class Initialized
INFO - 2018-09-27 04:05:09 --> Router Class Initialized
INFO - 2018-09-27 04:05:09 --> Output Class Initialized
INFO - 2018-09-27 04:05:09 --> Security Class Initialized
DEBUG - 2018-09-27 04:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:05:09 --> Input Class Initialized
INFO - 2018-09-27 04:05:09 --> Language Class Initialized
INFO - 2018-09-27 04:05:09 --> Loader Class Initialized
INFO - 2018-09-27 04:05:09 --> Helper loaded: url_helper
INFO - 2018-09-27 04:05:09 --> Helper loaded: form_helper
INFO - 2018-09-27 04:05:09 --> Helper loaded: html_helper
INFO - 2018-09-27 04:05:10 --> Database Driver Class Initialized
INFO - 2018-09-27 04:05:10 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:05:10 --> Model "User_model" initialized
INFO - 2018-09-27 04:05:10 --> Model "Project_model" initialized
INFO - 2018-09-27 04:05:10 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:05:10 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:05:10 --> Controller Class Initialized
ERROR - 2018-09-27 04:05:10 --> Severity: Notice --> Undefined variable: list_library D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 70
INFO - 2018-09-27 04:05:10 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:05:10 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:05:10 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:05:10 --> Final output sent to browser
DEBUG - 2018-09-27 04:05:10 --> Total execution time: 0.1220
INFO - 2018-09-27 04:05:21 --> Config Class Initialized
INFO - 2018-09-27 04:05:21 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:05:21 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:05:21 --> Utf8 Class Initialized
INFO - 2018-09-27 04:05:21 --> URI Class Initialized
INFO - 2018-09-27 04:05:21 --> Router Class Initialized
INFO - 2018-09-27 04:05:21 --> Output Class Initialized
INFO - 2018-09-27 04:05:21 --> Security Class Initialized
DEBUG - 2018-09-27 04:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:05:21 --> Input Class Initialized
INFO - 2018-09-27 04:05:21 --> Language Class Initialized
INFO - 2018-09-27 04:05:21 --> Loader Class Initialized
INFO - 2018-09-27 04:05:21 --> Helper loaded: url_helper
INFO - 2018-09-27 04:05:21 --> Helper loaded: form_helper
INFO - 2018-09-27 04:05:21 --> Helper loaded: html_helper
INFO - 2018-09-27 04:05:21 --> Database Driver Class Initialized
INFO - 2018-09-27 04:05:21 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:05:21 --> Model "User_model" initialized
INFO - 2018-09-27 04:05:21 --> Model "Project_model" initialized
INFO - 2018-09-27 04:05:21 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:05:21 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:05:21 --> Controller Class Initialized
INFO - 2018-09-27 04:05:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:05:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:05:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:05:21 --> Final output sent to browser
DEBUG - 2018-09-27 04:05:21 --> Total execution time: 0.0390
INFO - 2018-09-27 04:06:53 --> Config Class Initialized
INFO - 2018-09-27 04:06:53 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:06:53 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:06:53 --> Utf8 Class Initialized
INFO - 2018-09-27 04:06:53 --> URI Class Initialized
INFO - 2018-09-27 04:06:53 --> Router Class Initialized
INFO - 2018-09-27 04:06:53 --> Output Class Initialized
INFO - 2018-09-27 04:06:53 --> Security Class Initialized
DEBUG - 2018-09-27 04:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:06:53 --> Input Class Initialized
INFO - 2018-09-27 04:06:53 --> Language Class Initialized
INFO - 2018-09-27 04:06:53 --> Loader Class Initialized
INFO - 2018-09-27 04:06:53 --> Helper loaded: url_helper
INFO - 2018-09-27 04:06:53 --> Helper loaded: form_helper
INFO - 2018-09-27 04:06:53 --> Helper loaded: html_helper
INFO - 2018-09-27 04:06:53 --> Database Driver Class Initialized
INFO - 2018-09-27 04:06:53 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:06:53 --> Model "User_model" initialized
INFO - 2018-09-27 04:06:53 --> Model "Project_model" initialized
INFO - 2018-09-27 04:06:53 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:06:53 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:06:53 --> Controller Class Initialized
INFO - 2018-09-27 04:06:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:06:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:06:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:06:53 --> Final output sent to browser
DEBUG - 2018-09-27 04:06:53 --> Total execution time: 0.0570
INFO - 2018-09-27 04:08:32 --> Config Class Initialized
INFO - 2018-09-27 04:08:32 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:08:32 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:08:32 --> Utf8 Class Initialized
INFO - 2018-09-27 04:08:32 --> URI Class Initialized
INFO - 2018-09-27 04:08:32 --> Router Class Initialized
INFO - 2018-09-27 04:08:32 --> Output Class Initialized
INFO - 2018-09-27 04:08:32 --> Security Class Initialized
DEBUG - 2018-09-27 04:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:08:32 --> Input Class Initialized
INFO - 2018-09-27 04:08:32 --> Language Class Initialized
ERROR - 2018-09-27 04:08:32 --> 404 Page Not Found: project_controllers/Home/sdfsdfsdf
INFO - 2018-09-27 04:11:19 --> Config Class Initialized
INFO - 2018-09-27 04:11:19 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:11:19 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:11:19 --> Utf8 Class Initialized
INFO - 2018-09-27 04:11:19 --> URI Class Initialized
INFO - 2018-09-27 04:11:19 --> Router Class Initialized
INFO - 2018-09-27 04:11:19 --> Output Class Initialized
INFO - 2018-09-27 04:11:19 --> Security Class Initialized
DEBUG - 2018-09-27 04:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:11:19 --> Input Class Initialized
INFO - 2018-09-27 04:11:19 --> Language Class Initialized
ERROR - 2018-09-27 04:11:19 --> 404 Page Not Found: project_controllers/Sdfsdfsdf/index
INFO - 2018-09-27 04:11:52 --> Config Class Initialized
INFO - 2018-09-27 04:11:52 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:11:52 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:11:52 --> Utf8 Class Initialized
INFO - 2018-09-27 04:11:52 --> URI Class Initialized
INFO - 2018-09-27 04:11:52 --> Router Class Initialized
INFO - 2018-09-27 04:11:52 --> Output Class Initialized
INFO - 2018-09-27 04:11:52 --> Security Class Initialized
DEBUG - 2018-09-27 04:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:11:52 --> Input Class Initialized
INFO - 2018-09-27 04:11:52 --> Language Class Initialized
ERROR - 2018-09-27 04:11:52 --> 404 Page Not Found: project_controllers/Index/sdfsdfsdf
INFO - 2018-09-27 04:12:00 --> Config Class Initialized
INFO - 2018-09-27 04:12:00 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:12:00 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:12:00 --> Utf8 Class Initialized
INFO - 2018-09-27 04:12:00 --> URI Class Initialized
INFO - 2018-09-27 04:12:00 --> Router Class Initialized
INFO - 2018-09-27 04:12:00 --> Output Class Initialized
INFO - 2018-09-27 04:12:00 --> Security Class Initialized
DEBUG - 2018-09-27 04:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:12:00 --> Input Class Initialized
INFO - 2018-09-27 04:12:00 --> Language Class Initialized
INFO - 2018-09-27 04:12:00 --> Loader Class Initialized
INFO - 2018-09-27 04:12:00 --> Helper loaded: url_helper
INFO - 2018-09-27 04:12:00 --> Helper loaded: form_helper
INFO - 2018-09-27 04:12:00 --> Helper loaded: html_helper
INFO - 2018-09-27 04:12:00 --> Database Driver Class Initialized
INFO - 2018-09-27 04:12:00 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:12:00 --> Model "User_model" initialized
INFO - 2018-09-27 04:12:00 --> Model "Project_model" initialized
INFO - 2018-09-27 04:12:00 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:12:00 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:12:00 --> Controller Class Initialized
INFO - 2018-09-27 04:12:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:12:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:12:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:12:00 --> Final output sent to browser
DEBUG - 2018-09-27 04:12:00 --> Total execution time: 0.0460
INFO - 2018-09-27 04:12:05 --> Config Class Initialized
INFO - 2018-09-27 04:12:05 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:12:05 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:12:05 --> Utf8 Class Initialized
INFO - 2018-09-27 04:12:05 --> URI Class Initialized
INFO - 2018-09-27 04:12:05 --> Router Class Initialized
INFO - 2018-09-27 04:12:05 --> Output Class Initialized
INFO - 2018-09-27 04:12:05 --> Security Class Initialized
DEBUG - 2018-09-27 04:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:12:05 --> Input Class Initialized
INFO - 2018-09-27 04:12:05 --> Language Class Initialized
ERROR - 2018-09-27 04:12:05 --> 404 Page Not Found: project_controllers/Home/sdfasdfsdf
INFO - 2018-09-27 04:21:48 --> Config Class Initialized
INFO - 2018-09-27 04:21:48 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:21:48 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:21:48 --> Utf8 Class Initialized
INFO - 2018-09-27 04:21:48 --> URI Class Initialized
INFO - 2018-09-27 04:21:48 --> Router Class Initialized
INFO - 2018-09-27 04:21:48 --> Output Class Initialized
INFO - 2018-09-27 04:21:48 --> Security Class Initialized
DEBUG - 2018-09-27 04:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:21:48 --> Input Class Initialized
INFO - 2018-09-27 04:21:48 --> Language Class Initialized
ERROR - 2018-09-27 04:21:48 --> 404 Page Not Found: project_controllers/Index/sdfasdfsdf
INFO - 2018-09-27 04:22:00 --> Config Class Initialized
INFO - 2018-09-27 04:22:00 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:22:00 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:22:00 --> Utf8 Class Initialized
INFO - 2018-09-27 04:22:00 --> URI Class Initialized
INFO - 2018-09-27 04:22:00 --> Router Class Initialized
INFO - 2018-09-27 04:22:00 --> Output Class Initialized
INFO - 2018-09-27 04:22:00 --> Security Class Initialized
DEBUG - 2018-09-27 04:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:22:00 --> Input Class Initialized
INFO - 2018-09-27 04:22:00 --> Language Class Initialized
INFO - 2018-09-27 04:22:00 --> Loader Class Initialized
INFO - 2018-09-27 04:22:00 --> Helper loaded: url_helper
INFO - 2018-09-27 04:22:00 --> Helper loaded: form_helper
INFO - 2018-09-27 04:22:00 --> Helper loaded: html_helper
INFO - 2018-09-27 04:22:00 --> Database Driver Class Initialized
INFO - 2018-09-27 04:22:00 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:22:00 --> Model "User_model" initialized
INFO - 2018-09-27 04:22:00 --> Model "Project_model" initialized
INFO - 2018-09-27 04:22:00 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:22:00 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:22:00 --> Controller Class Initialized
INFO - 2018-09-27 04:22:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:22:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:22:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:22:00 --> Final output sent to browser
DEBUG - 2018-09-27 04:22:00 --> Total execution time: 0.0510
INFO - 2018-09-27 04:22:06 --> Config Class Initialized
INFO - 2018-09-27 04:22:06 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:22:06 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:22:06 --> Utf8 Class Initialized
INFO - 2018-09-27 04:22:06 --> URI Class Initialized
INFO - 2018-09-27 04:22:06 --> Router Class Initialized
INFO - 2018-09-27 04:22:06 --> Output Class Initialized
INFO - 2018-09-27 04:22:06 --> Security Class Initialized
DEBUG - 2018-09-27 04:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:22:06 --> Input Class Initialized
INFO - 2018-09-27 04:22:06 --> Language Class Initialized
INFO - 2018-09-27 04:22:06 --> Loader Class Initialized
INFO - 2018-09-27 04:22:06 --> Helper loaded: url_helper
INFO - 2018-09-27 04:22:06 --> Helper loaded: form_helper
INFO - 2018-09-27 04:22:06 --> Helper loaded: html_helper
INFO - 2018-09-27 04:22:06 --> Database Driver Class Initialized
INFO - 2018-09-27 04:22:06 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:22:06 --> Model "User_model" initialized
INFO - 2018-09-27 04:22:06 --> Model "Project_model" initialized
INFO - 2018-09-27 04:22:06 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:22:06 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:22:06 --> Controller Class Initialized
INFO - 2018-09-27 04:22:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:22:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:22:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:22:06 --> Final output sent to browser
DEBUG - 2018-09-27 04:22:06 --> Total execution time: 0.0530
INFO - 2018-09-27 04:22:10 --> Config Class Initialized
INFO - 2018-09-27 04:22:10 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:22:10 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:22:10 --> Utf8 Class Initialized
INFO - 2018-09-27 04:22:10 --> URI Class Initialized
INFO - 2018-09-27 04:22:10 --> Router Class Initialized
INFO - 2018-09-27 04:22:11 --> Output Class Initialized
INFO - 2018-09-27 04:22:11 --> Security Class Initialized
DEBUG - 2018-09-27 04:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:22:11 --> Input Class Initialized
INFO - 2018-09-27 04:22:11 --> Language Class Initialized
INFO - 2018-09-27 04:22:11 --> Loader Class Initialized
INFO - 2018-09-27 04:22:11 --> Helper loaded: url_helper
INFO - 2018-09-27 04:22:11 --> Helper loaded: form_helper
INFO - 2018-09-27 04:22:11 --> Helper loaded: html_helper
INFO - 2018-09-27 04:22:11 --> Database Driver Class Initialized
INFO - 2018-09-27 04:22:11 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:22:11 --> Model "User_model" initialized
INFO - 2018-09-27 04:22:11 --> Model "Project_model" initialized
INFO - 2018-09-27 04:22:11 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:22:11 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:22:11 --> Controller Class Initialized
INFO - 2018-09-27 04:22:11 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:22:11 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:22:11 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:22:11 --> Final output sent to browser
DEBUG - 2018-09-27 04:22:11 --> Total execution time: 0.1410
INFO - 2018-09-27 04:22:18 --> Config Class Initialized
INFO - 2018-09-27 04:22:18 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:22:18 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:22:18 --> Utf8 Class Initialized
INFO - 2018-09-27 04:22:18 --> URI Class Initialized
INFO - 2018-09-27 04:22:18 --> Router Class Initialized
INFO - 2018-09-27 04:22:18 --> Output Class Initialized
INFO - 2018-09-27 04:22:18 --> Security Class Initialized
DEBUG - 2018-09-27 04:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:22:18 --> Input Class Initialized
INFO - 2018-09-27 04:22:18 --> Language Class Initialized
ERROR - 2018-09-27 04:22:18 --> 404 Page Not Found: project_controllers/Home/index.php
INFO - 2018-09-27 04:22:24 --> Config Class Initialized
INFO - 2018-09-27 04:22:24 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:22:25 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:22:25 --> Utf8 Class Initialized
INFO - 2018-09-27 04:22:25 --> URI Class Initialized
INFO - 2018-09-27 04:22:25 --> Router Class Initialized
INFO - 2018-09-27 04:22:25 --> Output Class Initialized
INFO - 2018-09-27 04:22:25 --> Security Class Initialized
DEBUG - 2018-09-27 04:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:22:25 --> Input Class Initialized
INFO - 2018-09-27 04:22:25 --> Language Class Initialized
INFO - 2018-09-27 04:22:25 --> Loader Class Initialized
INFO - 2018-09-27 04:22:25 --> Helper loaded: url_helper
INFO - 2018-09-27 04:22:25 --> Helper loaded: form_helper
INFO - 2018-09-27 04:22:25 --> Helper loaded: html_helper
INFO - 2018-09-27 04:22:25 --> Database Driver Class Initialized
INFO - 2018-09-27 04:22:25 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:22:25 --> Model "User_model" initialized
INFO - 2018-09-27 04:22:25 --> Model "Project_model" initialized
INFO - 2018-09-27 04:22:25 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:22:25 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:22:25 --> Controller Class Initialized
INFO - 2018-09-27 04:22:25 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:22:25 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:22:25 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:22:25 --> Final output sent to browser
DEBUG - 2018-09-27 04:22:25 --> Total execution time: 0.0530
INFO - 2018-09-27 04:22:35 --> Config Class Initialized
INFO - 2018-09-27 04:22:35 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:22:35 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:22:35 --> Utf8 Class Initialized
INFO - 2018-09-27 04:22:35 --> URI Class Initialized
INFO - 2018-09-27 04:22:35 --> Router Class Initialized
INFO - 2018-09-27 04:22:35 --> Output Class Initialized
INFO - 2018-09-27 04:22:35 --> Security Class Initialized
DEBUG - 2018-09-27 04:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:22:35 --> Input Class Initialized
INFO - 2018-09-27 04:22:35 --> Language Class Initialized
INFO - 2018-09-27 04:22:35 --> Loader Class Initialized
INFO - 2018-09-27 04:22:35 --> Helper loaded: url_helper
INFO - 2018-09-27 04:22:35 --> Helper loaded: form_helper
INFO - 2018-09-27 04:22:35 --> Helper loaded: html_helper
INFO - 2018-09-27 04:22:35 --> Database Driver Class Initialized
INFO - 2018-09-27 04:22:35 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:22:35 --> Model "User_model" initialized
INFO - 2018-09-27 04:22:35 --> Model "Project_model" initialized
INFO - 2018-09-27 04:22:35 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:22:35 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:22:35 --> Controller Class Initialized
INFO - 2018-09-27 04:22:35 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:22:35 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:22:35 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:22:35 --> Final output sent to browser
DEBUG - 2018-09-27 04:22:35 --> Total execution time: 0.0460
INFO - 2018-09-27 04:22:43 --> Config Class Initialized
INFO - 2018-09-27 04:22:43 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:22:43 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:22:43 --> Utf8 Class Initialized
INFO - 2018-09-27 04:22:43 --> URI Class Initialized
INFO - 2018-09-27 04:22:43 --> Router Class Initialized
INFO - 2018-09-27 04:22:43 --> Output Class Initialized
INFO - 2018-09-27 04:22:43 --> Security Class Initialized
DEBUG - 2018-09-27 04:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:22:43 --> Input Class Initialized
INFO - 2018-09-27 04:22:43 --> Language Class Initialized
INFO - 2018-09-27 04:22:43 --> Loader Class Initialized
INFO - 2018-09-27 04:22:43 --> Helper loaded: url_helper
INFO - 2018-09-27 04:22:43 --> Helper loaded: form_helper
INFO - 2018-09-27 04:22:43 --> Helper loaded: html_helper
INFO - 2018-09-27 04:22:43 --> Database Driver Class Initialized
INFO - 2018-09-27 04:22:43 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:22:43 --> Model "User_model" initialized
INFO - 2018-09-27 04:22:43 --> Model "Project_model" initialized
INFO - 2018-09-27 04:22:43 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:22:43 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:22:43 --> Controller Class Initialized
INFO - 2018-09-27 04:22:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:22:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:22:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:22:43 --> Final output sent to browser
DEBUG - 2018-09-27 04:22:43 --> Total execution time: 0.1280
INFO - 2018-09-27 04:22:55 --> Config Class Initialized
INFO - 2018-09-27 04:22:55 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:22:55 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:22:55 --> Utf8 Class Initialized
INFO - 2018-09-27 04:22:55 --> URI Class Initialized
INFO - 2018-09-27 04:22:55 --> Router Class Initialized
INFO - 2018-09-27 04:22:55 --> Output Class Initialized
INFO - 2018-09-27 04:22:55 --> Security Class Initialized
DEBUG - 2018-09-27 04:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:22:55 --> Input Class Initialized
INFO - 2018-09-27 04:22:55 --> Language Class Initialized
ERROR - 2018-09-27 04:22:55 --> 404 Page Not Found: project_controllers/Home/jafjlksjdlfakjsdlfkajsldfkjlaskdfjalskdfjalsd
INFO - 2018-09-27 04:23:03 --> Config Class Initialized
INFO - 2018-09-27 04:23:03 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:23:03 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:23:03 --> Utf8 Class Initialized
INFO - 2018-09-27 04:23:03 --> URI Class Initialized
INFO - 2018-09-27 04:23:03 --> Router Class Initialized
INFO - 2018-09-27 04:23:03 --> Output Class Initialized
INFO - 2018-09-27 04:23:03 --> Security Class Initialized
DEBUG - 2018-09-27 04:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:23:03 --> Input Class Initialized
INFO - 2018-09-27 04:23:03 --> Language Class Initialized
INFO - 2018-09-27 04:23:03 --> Loader Class Initialized
INFO - 2018-09-27 04:23:03 --> Helper loaded: url_helper
INFO - 2018-09-27 04:23:03 --> Helper loaded: form_helper
INFO - 2018-09-27 04:23:03 --> Helper loaded: html_helper
INFO - 2018-09-27 04:23:03 --> Database Driver Class Initialized
INFO - 2018-09-27 04:23:03 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:23:03 --> Model "User_model" initialized
INFO - 2018-09-27 04:23:03 --> Model "Project_model" initialized
INFO - 2018-09-27 04:23:03 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:23:03 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:23:03 --> Controller Class Initialized
INFO - 2018-09-27 04:23:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:23:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:23:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:23:03 --> Final output sent to browser
DEBUG - 2018-09-27 04:23:03 --> Total execution time: 0.0510
INFO - 2018-09-27 04:23:31 --> Config Class Initialized
INFO - 2018-09-27 04:23:31 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:23:31 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:23:31 --> Utf8 Class Initialized
INFO - 2018-09-27 04:23:31 --> URI Class Initialized
INFO - 2018-09-27 04:23:31 --> Router Class Initialized
INFO - 2018-09-27 04:23:31 --> Output Class Initialized
INFO - 2018-09-27 04:23:31 --> Security Class Initialized
DEBUG - 2018-09-27 04:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:23:31 --> Input Class Initialized
INFO - 2018-09-27 04:23:31 --> Language Class Initialized
ERROR - 2018-09-27 04:23:31 --> 404 Page Not Found: project_controllers/Home/jafjlksjdlfakjsdlfkajsldfkjlaskdfjalskdfjalsd
INFO - 2018-09-27 04:23:46 --> Config Class Initialized
INFO - 2018-09-27 04:23:46 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:23:46 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:23:46 --> Utf8 Class Initialized
INFO - 2018-09-27 04:23:46 --> URI Class Initialized
INFO - 2018-09-27 04:23:46 --> Router Class Initialized
INFO - 2018-09-27 04:23:46 --> Output Class Initialized
INFO - 2018-09-27 04:23:46 --> Security Class Initialized
DEBUG - 2018-09-27 04:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:23:46 --> Input Class Initialized
INFO - 2018-09-27 04:23:46 --> Language Class Initialized
ERROR - 2018-09-27 04:23:46 --> 404 Page Not Found: project_controllers/Home/index.php
INFO - 2018-09-27 04:23:59 --> Config Class Initialized
INFO - 2018-09-27 04:23:59 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:23:59 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:23:59 --> Utf8 Class Initialized
INFO - 2018-09-27 04:23:59 --> URI Class Initialized
INFO - 2018-09-27 04:23:59 --> Router Class Initialized
INFO - 2018-09-27 04:23:59 --> Output Class Initialized
INFO - 2018-09-27 04:23:59 --> Security Class Initialized
DEBUG - 2018-09-27 04:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:23:59 --> Input Class Initialized
INFO - 2018-09-27 04:23:59 --> Language Class Initialized
INFO - 2018-09-27 04:23:59 --> Loader Class Initialized
INFO - 2018-09-27 04:23:59 --> Helper loaded: url_helper
INFO - 2018-09-27 04:23:59 --> Helper loaded: form_helper
INFO - 2018-09-27 04:23:59 --> Helper loaded: html_helper
INFO - 2018-09-27 04:23:59 --> Database Driver Class Initialized
INFO - 2018-09-27 04:23:59 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:23:59 --> Model "User_model" initialized
INFO - 2018-09-27 04:23:59 --> Model "Project_model" initialized
INFO - 2018-09-27 04:23:59 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:23:59 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:23:59 --> Controller Class Initialized
INFO - 2018-09-27 04:23:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:23:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:23:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:23:59 --> Final output sent to browser
DEBUG - 2018-09-27 04:23:59 --> Total execution time: 0.0560
INFO - 2018-09-27 04:24:04 --> Config Class Initialized
INFO - 2018-09-27 04:24:04 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:24:04 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:24:04 --> Utf8 Class Initialized
INFO - 2018-09-27 04:24:04 --> URI Class Initialized
INFO - 2018-09-27 04:24:04 --> Router Class Initialized
INFO - 2018-09-27 04:24:04 --> Output Class Initialized
INFO - 2018-09-27 04:24:04 --> Security Class Initialized
DEBUG - 2018-09-27 04:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:24:04 --> Input Class Initialized
INFO - 2018-09-27 04:24:04 --> Language Class Initialized
INFO - 2018-09-27 04:24:04 --> Loader Class Initialized
INFO - 2018-09-27 04:24:04 --> Helper loaded: url_helper
INFO - 2018-09-27 04:24:04 --> Helper loaded: form_helper
INFO - 2018-09-27 04:24:04 --> Helper loaded: html_helper
INFO - 2018-09-27 04:24:04 --> Database Driver Class Initialized
INFO - 2018-09-27 04:24:04 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:24:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:24:04 --> Model "User_model" initialized
INFO - 2018-09-27 04:24:04 --> Model "Project_model" initialized
INFO - 2018-09-27 04:24:04 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:24:04 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:24:04 --> Controller Class Initialized
INFO - 2018-09-27 04:24:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:24:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:24:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:24:04 --> Final output sent to browser
DEBUG - 2018-09-27 04:24:04 --> Total execution time: 0.0440
INFO - 2018-09-27 04:28:43 --> Config Class Initialized
INFO - 2018-09-27 04:28:43 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:28:43 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:28:43 --> Utf8 Class Initialized
INFO - 2018-09-27 04:28:43 --> URI Class Initialized
INFO - 2018-09-27 04:28:43 --> Router Class Initialized
INFO - 2018-09-27 04:28:43 --> Output Class Initialized
INFO - 2018-09-27 04:28:43 --> Security Class Initialized
DEBUG - 2018-09-27 04:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:28:43 --> Input Class Initialized
INFO - 2018-09-27 04:28:43 --> Language Class Initialized
INFO - 2018-09-27 04:28:43 --> Loader Class Initialized
INFO - 2018-09-27 04:28:43 --> Helper loaded: url_helper
INFO - 2018-09-27 04:28:43 --> Helper loaded: form_helper
INFO - 2018-09-27 04:28:43 --> Helper loaded: html_helper
INFO - 2018-09-27 04:28:43 --> Database Driver Class Initialized
INFO - 2018-09-27 04:28:43 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:28:43 --> Model "User_model" initialized
INFO - 2018-09-27 04:28:43 --> Model "Project_model" initialized
INFO - 2018-09-27 04:28:43 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:28:43 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:28:43 --> Controller Class Initialized
INFO - 2018-09-27 04:28:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:28:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:28:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:28:43 --> Final output sent to browser
DEBUG - 2018-09-27 04:28:43 --> Total execution time: 0.0720
INFO - 2018-09-27 04:28:47 --> Config Class Initialized
INFO - 2018-09-27 04:28:47 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:28:47 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:28:47 --> Utf8 Class Initialized
INFO - 2018-09-27 04:28:47 --> URI Class Initialized
INFO - 2018-09-27 04:28:47 --> Router Class Initialized
INFO - 2018-09-27 04:28:47 --> Output Class Initialized
INFO - 2018-09-27 04:28:47 --> Security Class Initialized
DEBUG - 2018-09-27 04:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:28:47 --> Input Class Initialized
INFO - 2018-09-27 04:28:47 --> Language Class Initialized
ERROR - 2018-09-27 04:28:47 --> 404 Page Not Found: project_controllers/Home/lsdjaflksdjfdfsd
INFO - 2018-09-27 04:29:12 --> Config Class Initialized
INFO - 2018-09-27 04:29:12 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:29:12 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:29:12 --> Utf8 Class Initialized
INFO - 2018-09-27 04:29:12 --> URI Class Initialized
INFO - 2018-09-27 04:29:12 --> Router Class Initialized
INFO - 2018-09-27 04:29:12 --> Output Class Initialized
INFO - 2018-09-27 04:29:12 --> Security Class Initialized
DEBUG - 2018-09-27 04:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:29:12 --> Input Class Initialized
INFO - 2018-09-27 04:29:12 --> Language Class Initialized
ERROR - 2018-09-27 04:29:12 --> 404 Page Not Found: project_controllers/Home/lsdjaflksdjfdfsd
INFO - 2018-09-27 04:29:16 --> Config Class Initialized
INFO - 2018-09-27 04:29:16 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:29:16 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:29:16 --> Utf8 Class Initialized
INFO - 2018-09-27 04:29:16 --> URI Class Initialized
INFO - 2018-09-27 04:29:16 --> Router Class Initialized
INFO - 2018-09-27 04:29:16 --> Output Class Initialized
INFO - 2018-09-27 04:29:16 --> Security Class Initialized
DEBUG - 2018-09-27 04:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:29:16 --> Input Class Initialized
INFO - 2018-09-27 04:29:16 --> Language Class Initialized
INFO - 2018-09-27 04:29:16 --> Loader Class Initialized
INFO - 2018-09-27 04:29:16 --> Helper loaded: url_helper
INFO - 2018-09-27 04:29:16 --> Helper loaded: form_helper
INFO - 2018-09-27 04:29:16 --> Helper loaded: html_helper
INFO - 2018-09-27 04:29:16 --> Database Driver Class Initialized
INFO - 2018-09-27 04:29:16 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:29:16 --> Model "User_model" initialized
INFO - 2018-09-27 04:29:16 --> Model "Project_model" initialized
INFO - 2018-09-27 04:29:16 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:29:16 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:29:16 --> Controller Class Initialized
INFO - 2018-09-27 04:29:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:29:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:29:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:29:16 --> Final output sent to browser
DEBUG - 2018-09-27 04:29:16 --> Total execution time: 0.0570
INFO - 2018-09-27 04:30:36 --> Config Class Initialized
INFO - 2018-09-27 04:30:36 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:30:36 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:30:36 --> Utf8 Class Initialized
INFO - 2018-09-27 04:30:36 --> URI Class Initialized
INFO - 2018-09-27 04:30:36 --> Router Class Initialized
INFO - 2018-09-27 04:30:36 --> Output Class Initialized
INFO - 2018-09-27 04:30:36 --> Security Class Initialized
DEBUG - 2018-09-27 04:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:30:36 --> Input Class Initialized
INFO - 2018-09-27 04:30:36 --> Language Class Initialized
ERROR - 2018-09-27 04:30:36 --> 404 Page Not Found: Home/index
INFO - 2018-09-27 04:30:45 --> Config Class Initialized
INFO - 2018-09-27 04:30:45 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:30:45 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:30:45 --> Utf8 Class Initialized
INFO - 2018-09-27 04:30:45 --> URI Class Initialized
INFO - 2018-09-27 04:30:45 --> Router Class Initialized
INFO - 2018-09-27 04:30:45 --> Output Class Initialized
INFO - 2018-09-27 04:30:45 --> Security Class Initialized
DEBUG - 2018-09-27 04:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:30:45 --> Input Class Initialized
INFO - 2018-09-27 04:30:45 --> Language Class Initialized
ERROR - 2018-09-27 04:30:45 --> 404 Page Not Found: Project_controller/home
INFO - 2018-09-27 04:30:51 --> Config Class Initialized
INFO - 2018-09-27 04:30:51 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:30:51 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:30:51 --> Utf8 Class Initialized
INFO - 2018-09-27 04:30:51 --> URI Class Initialized
INFO - 2018-09-27 04:30:51 --> Router Class Initialized
INFO - 2018-09-27 04:30:51 --> Output Class Initialized
INFO - 2018-09-27 04:30:51 --> Security Class Initialized
DEBUG - 2018-09-27 04:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:30:51 --> Input Class Initialized
INFO - 2018-09-27 04:30:51 --> Language Class Initialized
ERROR - 2018-09-27 04:30:51 --> 404 Page Not Found: Project_controller/home
INFO - 2018-09-27 04:30:58 --> Config Class Initialized
INFO - 2018-09-27 04:30:58 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:30:58 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:30:58 --> Utf8 Class Initialized
INFO - 2018-09-27 04:30:58 --> URI Class Initialized
INFO - 2018-09-27 04:30:58 --> Router Class Initialized
INFO - 2018-09-27 04:30:58 --> Output Class Initialized
INFO - 2018-09-27 04:30:58 --> Security Class Initialized
DEBUG - 2018-09-27 04:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:30:58 --> Input Class Initialized
INFO - 2018-09-27 04:30:58 --> Language Class Initialized
ERROR - 2018-09-27 04:30:58 --> 404 Page Not Found: Project_controller/home
INFO - 2018-09-27 04:32:21 --> Config Class Initialized
INFO - 2018-09-27 04:32:21 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:32:21 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:32:21 --> Utf8 Class Initialized
INFO - 2018-09-27 04:32:21 --> URI Class Initialized
INFO - 2018-09-27 04:32:21 --> Router Class Initialized
INFO - 2018-09-27 04:32:21 --> Output Class Initialized
INFO - 2018-09-27 04:32:21 --> Security Class Initialized
DEBUG - 2018-09-27 04:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:32:21 --> Input Class Initialized
INFO - 2018-09-27 04:32:21 --> Language Class Initialized
ERROR - 2018-09-27 04:32:21 --> 404 Page Not Found: Project_controller/home
INFO - 2018-09-27 04:32:40 --> Config Class Initialized
INFO - 2018-09-27 04:32:40 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:32:40 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:32:40 --> Utf8 Class Initialized
INFO - 2018-09-27 04:32:40 --> URI Class Initialized
INFO - 2018-09-27 04:32:40 --> Router Class Initialized
INFO - 2018-09-27 04:32:40 --> Output Class Initialized
INFO - 2018-09-27 04:32:40 --> Security Class Initialized
DEBUG - 2018-09-27 04:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:32:40 --> Input Class Initialized
INFO - 2018-09-27 04:32:40 --> Language Class Initialized
INFO - 2018-09-27 04:32:40 --> Loader Class Initialized
INFO - 2018-09-27 04:32:40 --> Helper loaded: url_helper
INFO - 2018-09-27 04:32:40 --> Helper loaded: form_helper
INFO - 2018-09-27 04:32:40 --> Helper loaded: html_helper
INFO - 2018-09-27 04:32:40 --> Database Driver Class Initialized
INFO - 2018-09-27 04:32:40 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:32:40 --> Model "User_model" initialized
INFO - 2018-09-27 04:32:40 --> Model "Project_model" initialized
INFO - 2018-09-27 04:32:40 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:32:40 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:32:40 --> Controller Class Initialized
INFO - 2018-09-27 04:32:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:32:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:32:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:32:40 --> Final output sent to browser
DEBUG - 2018-09-27 04:32:40 --> Total execution time: 0.0530
INFO - 2018-09-27 04:32:44 --> Config Class Initialized
INFO - 2018-09-27 04:32:44 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:32:44 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:32:44 --> Utf8 Class Initialized
INFO - 2018-09-27 04:32:44 --> URI Class Initialized
INFO - 2018-09-27 04:32:44 --> Router Class Initialized
INFO - 2018-09-27 04:32:44 --> Output Class Initialized
INFO - 2018-09-27 04:32:44 --> Security Class Initialized
DEBUG - 2018-09-27 04:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:32:44 --> Input Class Initialized
INFO - 2018-09-27 04:32:44 --> Language Class Initialized
INFO - 2018-09-27 04:32:44 --> Loader Class Initialized
INFO - 2018-09-27 04:32:44 --> Helper loaded: url_helper
INFO - 2018-09-27 04:32:44 --> Helper loaded: form_helper
INFO - 2018-09-27 04:32:44 --> Helper loaded: html_helper
INFO - 2018-09-27 04:32:44 --> Database Driver Class Initialized
INFO - 2018-09-27 04:32:44 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:32:44 --> Model "User_model" initialized
INFO - 2018-09-27 04:32:44 --> Model "Project_model" initialized
INFO - 2018-09-27 04:32:44 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:32:44 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:32:44 --> Controller Class Initialized
INFO - 2018-09-27 04:32:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:32:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:32:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:32:44 --> Final output sent to browser
DEBUG - 2018-09-27 04:32:44 --> Total execution time: 0.0570
INFO - 2018-09-27 04:38:22 --> Config Class Initialized
INFO - 2018-09-27 04:38:22 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:38:22 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:38:22 --> Utf8 Class Initialized
INFO - 2018-09-27 04:38:22 --> URI Class Initialized
INFO - 2018-09-27 04:38:22 --> Router Class Initialized
INFO - 2018-09-27 04:38:22 --> Output Class Initialized
INFO - 2018-09-27 04:38:22 --> Security Class Initialized
DEBUG - 2018-09-27 04:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:38:22 --> Input Class Initialized
INFO - 2018-09-27 04:38:22 --> Language Class Initialized
INFO - 2018-09-27 04:38:22 --> Loader Class Initialized
INFO - 2018-09-27 04:38:22 --> Helper loaded: url_helper
INFO - 2018-09-27 04:38:22 --> Helper loaded: form_helper
INFO - 2018-09-27 04:38:22 --> Helper loaded: html_helper
INFO - 2018-09-27 04:38:22 --> Database Driver Class Initialized
INFO - 2018-09-27 04:38:22 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:38:22 --> Model "User_model" initialized
INFO - 2018-09-27 04:38:22 --> Model "Project_model" initialized
INFO - 2018-09-27 04:38:22 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:38:22 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:38:22 --> Controller Class Initialized
INFO - 2018-09-27 04:38:22 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:38:22 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:38:22 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:38:22 --> Final output sent to browser
DEBUG - 2018-09-27 04:38:22 --> Total execution time: 0.0640
INFO - 2018-09-27 04:38:32 --> Config Class Initialized
INFO - 2018-09-27 04:38:32 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:38:32 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:38:32 --> Utf8 Class Initialized
INFO - 2018-09-27 04:38:32 --> URI Class Initialized
INFO - 2018-09-27 04:38:32 --> Router Class Initialized
INFO - 2018-09-27 04:38:32 --> Output Class Initialized
INFO - 2018-09-27 04:38:32 --> Security Class Initialized
DEBUG - 2018-09-27 04:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:38:32 --> Input Class Initialized
INFO - 2018-09-27 04:38:32 --> Language Class Initialized
INFO - 2018-09-27 04:38:32 --> Loader Class Initialized
INFO - 2018-09-27 04:38:32 --> Helper loaded: url_helper
INFO - 2018-09-27 04:38:32 --> Helper loaded: form_helper
INFO - 2018-09-27 04:38:32 --> Helper loaded: html_helper
INFO - 2018-09-27 04:38:32 --> Database Driver Class Initialized
INFO - 2018-09-27 04:38:32 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:38:32 --> Model "User_model" initialized
INFO - 2018-09-27 04:38:32 --> Model "Project_model" initialized
INFO - 2018-09-27 04:38:32 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:38:32 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:38:32 --> Controller Class Initialized
INFO - 2018-09-27 04:38:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:38:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:38:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:38:32 --> Final output sent to browser
DEBUG - 2018-09-27 04:38:32 --> Total execution time: 0.0500
INFO - 2018-09-27 04:41:33 --> Config Class Initialized
INFO - 2018-09-27 04:41:33 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:41:33 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:41:33 --> Utf8 Class Initialized
INFO - 2018-09-27 04:41:33 --> URI Class Initialized
INFO - 2018-09-27 04:41:33 --> Router Class Initialized
INFO - 2018-09-27 04:41:33 --> Output Class Initialized
INFO - 2018-09-27 04:41:33 --> Security Class Initialized
DEBUG - 2018-09-27 04:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:41:33 --> Input Class Initialized
INFO - 2018-09-27 04:41:33 --> Language Class Initialized
ERROR - 2018-09-27 04:41:33 --> 404 Page Not Found: project_controllers/Additionalmethod/index
INFO - 2018-09-27 04:41:49 --> Config Class Initialized
INFO - 2018-09-27 04:41:49 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:41:49 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:41:49 --> Utf8 Class Initialized
INFO - 2018-09-27 04:41:49 --> URI Class Initialized
INFO - 2018-09-27 04:41:49 --> Router Class Initialized
INFO - 2018-09-27 04:41:49 --> Output Class Initialized
INFO - 2018-09-27 04:41:49 --> Security Class Initialized
DEBUG - 2018-09-27 04:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:41:49 --> Input Class Initialized
INFO - 2018-09-27 04:41:49 --> Language Class Initialized
ERROR - 2018-09-27 04:41:49 --> 404 Page Not Found: project_controllers/Additional%20method/index
INFO - 2018-09-27 04:42:03 --> Config Class Initialized
INFO - 2018-09-27 04:42:03 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:42:04 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:42:04 --> Utf8 Class Initialized
INFO - 2018-09-27 04:42:04 --> URI Class Initialized
INFO - 2018-09-27 04:42:04 --> Router Class Initialized
INFO - 2018-09-27 04:42:04 --> Output Class Initialized
INFO - 2018-09-27 04:42:04 --> Security Class Initialized
DEBUG - 2018-09-27 04:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:42:04 --> Input Class Initialized
INFO - 2018-09-27 04:42:04 --> Language Class Initialized
INFO - 2018-09-27 04:42:04 --> Loader Class Initialized
INFO - 2018-09-27 04:42:04 --> Helper loaded: url_helper
INFO - 2018-09-27 04:42:04 --> Helper loaded: form_helper
INFO - 2018-09-27 04:42:04 --> Helper loaded: html_helper
INFO - 2018-09-27 04:42:04 --> Database Driver Class Initialized
INFO - 2018-09-27 04:42:04 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:42:04 --> Model "User_model" initialized
INFO - 2018-09-27 04:42:04 --> Model "Project_model" initialized
INFO - 2018-09-27 04:42:04 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:42:04 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:42:04 --> Controller Class Initialized
INFO - 2018-09-27 04:42:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:42:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:42:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:42:04 --> Final output sent to browser
DEBUG - 2018-09-27 04:42:04 --> Total execution time: 0.1150
INFO - 2018-09-27 04:42:09 --> Config Class Initialized
INFO - 2018-09-27 04:42:09 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:42:09 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:42:09 --> Utf8 Class Initialized
INFO - 2018-09-27 04:42:09 --> URI Class Initialized
INFO - 2018-09-27 04:42:09 --> Router Class Initialized
INFO - 2018-09-27 04:42:09 --> Output Class Initialized
INFO - 2018-09-27 04:42:09 --> Security Class Initialized
DEBUG - 2018-09-27 04:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:42:09 --> Input Class Initialized
INFO - 2018-09-27 04:42:09 --> Language Class Initialized
INFO - 2018-09-27 04:42:09 --> Loader Class Initialized
INFO - 2018-09-27 04:42:09 --> Helper loaded: url_helper
INFO - 2018-09-27 04:42:09 --> Helper loaded: form_helper
INFO - 2018-09-27 04:42:09 --> Helper loaded: html_helper
INFO - 2018-09-27 04:42:09 --> Database Driver Class Initialized
INFO - 2018-09-27 04:42:09 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:42:09 --> Model "User_model" initialized
INFO - 2018-09-27 04:42:09 --> Model "Project_model" initialized
INFO - 2018-09-27 04:42:09 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:42:09 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:42:09 --> Controller Class Initialized
INFO - 2018-09-27 04:42:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:42:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:42:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:42:09 --> Final output sent to browser
DEBUG - 2018-09-27 04:42:09 --> Total execution time: 0.0460
INFO - 2018-09-27 04:42:44 --> Config Class Initialized
INFO - 2018-09-27 04:42:44 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:42:44 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:42:44 --> Utf8 Class Initialized
INFO - 2018-09-27 04:42:44 --> URI Class Initialized
INFO - 2018-09-27 04:42:44 --> Router Class Initialized
INFO - 2018-09-27 04:42:44 --> Output Class Initialized
INFO - 2018-09-27 04:42:44 --> Security Class Initialized
DEBUG - 2018-09-27 04:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:42:44 --> Input Class Initialized
INFO - 2018-09-27 04:42:44 --> Language Class Initialized
INFO - 2018-09-27 04:42:44 --> Loader Class Initialized
INFO - 2018-09-27 04:42:44 --> Helper loaded: url_helper
INFO - 2018-09-27 04:42:44 --> Helper loaded: form_helper
INFO - 2018-09-27 04:42:44 --> Helper loaded: html_helper
INFO - 2018-09-27 04:42:44 --> Database Driver Class Initialized
INFO - 2018-09-27 04:42:44 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:42:44 --> Model "User_model" initialized
INFO - 2018-09-27 04:42:44 --> Model "Project_model" initialized
INFO - 2018-09-27 04:42:44 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:42:44 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:42:44 --> Controller Class Initialized
INFO - 2018-09-27 04:42:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:42:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:42:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:42:44 --> Final output sent to browser
DEBUG - 2018-09-27 04:42:44 --> Total execution time: 0.1340
INFO - 2018-09-27 04:43:14 --> Config Class Initialized
INFO - 2018-09-27 04:43:14 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:43:14 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:43:14 --> Utf8 Class Initialized
INFO - 2018-09-27 04:43:14 --> URI Class Initialized
INFO - 2018-09-27 04:43:14 --> Router Class Initialized
INFO - 2018-09-27 04:43:14 --> Output Class Initialized
INFO - 2018-09-27 04:43:14 --> Security Class Initialized
DEBUG - 2018-09-27 04:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:43:14 --> Input Class Initialized
INFO - 2018-09-27 04:43:14 --> Language Class Initialized
INFO - 2018-09-27 04:43:14 --> Loader Class Initialized
INFO - 2018-09-27 04:43:14 --> Helper loaded: url_helper
INFO - 2018-09-27 04:43:14 --> Helper loaded: form_helper
INFO - 2018-09-27 04:43:14 --> Helper loaded: html_helper
INFO - 2018-09-27 04:43:14 --> Database Driver Class Initialized
INFO - 2018-09-27 04:43:14 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:43:14 --> Model "User_model" initialized
INFO - 2018-09-27 04:43:14 --> Model "Project_model" initialized
INFO - 2018-09-27 04:43:14 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:43:14 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:43:14 --> Controller Class Initialized
INFO - 2018-09-27 04:43:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:43:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:43:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:43:14 --> Final output sent to browser
DEBUG - 2018-09-27 04:43:14 --> Total execution time: 0.0580
INFO - 2018-09-27 04:43:19 --> Config Class Initialized
INFO - 2018-09-27 04:43:19 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:43:19 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:43:19 --> Utf8 Class Initialized
INFO - 2018-09-27 04:43:19 --> URI Class Initialized
INFO - 2018-09-27 04:43:19 --> Router Class Initialized
INFO - 2018-09-27 04:43:19 --> Output Class Initialized
INFO - 2018-09-27 04:43:19 --> Security Class Initialized
DEBUG - 2018-09-27 04:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:43:19 --> Input Class Initialized
INFO - 2018-09-27 04:43:19 --> Language Class Initialized
INFO - 2018-09-27 04:43:19 --> Loader Class Initialized
INFO - 2018-09-27 04:43:19 --> Helper loaded: url_helper
INFO - 2018-09-27 04:43:19 --> Helper loaded: form_helper
INFO - 2018-09-27 04:43:19 --> Helper loaded: html_helper
INFO - 2018-09-27 04:43:19 --> Database Driver Class Initialized
INFO - 2018-09-27 04:43:19 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:43:19 --> Model "User_model" initialized
INFO - 2018-09-27 04:43:19 --> Model "Project_model" initialized
INFO - 2018-09-27 04:43:19 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:43:19 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:43:19 --> Controller Class Initialized
INFO - 2018-09-27 04:43:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:43:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:43:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:43:19 --> Final output sent to browser
DEBUG - 2018-09-27 04:43:19 --> Total execution time: 0.0480
INFO - 2018-09-27 04:43:23 --> Config Class Initialized
INFO - 2018-09-27 04:43:23 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:43:23 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:43:23 --> Utf8 Class Initialized
INFO - 2018-09-27 04:43:23 --> URI Class Initialized
INFO - 2018-09-27 04:43:23 --> Router Class Initialized
INFO - 2018-09-27 04:43:23 --> Output Class Initialized
INFO - 2018-09-27 04:43:23 --> Security Class Initialized
DEBUG - 2018-09-27 04:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:43:23 --> Input Class Initialized
INFO - 2018-09-27 04:43:23 --> Language Class Initialized
INFO - 2018-09-27 04:43:23 --> Loader Class Initialized
INFO - 2018-09-27 04:43:23 --> Helper loaded: url_helper
INFO - 2018-09-27 04:43:23 --> Helper loaded: form_helper
INFO - 2018-09-27 04:43:23 --> Helper loaded: html_helper
INFO - 2018-09-27 04:43:23 --> Database Driver Class Initialized
INFO - 2018-09-27 04:43:23 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:43:23 --> Model "User_model" initialized
INFO - 2018-09-27 04:43:23 --> Model "Project_model" initialized
INFO - 2018-09-27 04:43:23 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:43:23 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:43:23 --> Controller Class Initialized
INFO - 2018-09-27 04:43:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:43:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:43:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:43:23 --> Final output sent to browser
DEBUG - 2018-09-27 04:43:23 --> Total execution time: 0.0540
INFO - 2018-09-27 04:43:39 --> Config Class Initialized
INFO - 2018-09-27 04:43:39 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:43:39 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:43:39 --> Utf8 Class Initialized
INFO - 2018-09-27 04:43:39 --> URI Class Initialized
INFO - 2018-09-27 04:43:39 --> Router Class Initialized
INFO - 2018-09-27 04:43:39 --> Output Class Initialized
INFO - 2018-09-27 04:43:39 --> Security Class Initialized
DEBUG - 2018-09-27 04:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:43:39 --> Input Class Initialized
INFO - 2018-09-27 04:43:39 --> Language Class Initialized
INFO - 2018-09-27 04:43:39 --> Loader Class Initialized
INFO - 2018-09-27 04:43:39 --> Helper loaded: url_helper
INFO - 2018-09-27 04:43:39 --> Helper loaded: form_helper
INFO - 2018-09-27 04:43:39 --> Helper loaded: html_helper
INFO - 2018-09-27 04:43:39 --> Database Driver Class Initialized
INFO - 2018-09-27 04:43:39 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:43:39 --> Model "User_model" initialized
INFO - 2018-09-27 04:43:39 --> Model "Project_model" initialized
INFO - 2018-09-27 04:43:39 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:43:39 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:43:39 --> Controller Class Initialized
INFO - 2018-09-27 04:43:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:43:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:43:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:43:39 --> Final output sent to browser
DEBUG - 2018-09-27 04:43:39 --> Total execution time: 0.0640
INFO - 2018-09-27 04:44:37 --> Config Class Initialized
INFO - 2018-09-27 04:44:37 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:44:37 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:44:37 --> Utf8 Class Initialized
INFO - 2018-09-27 04:44:37 --> URI Class Initialized
INFO - 2018-09-27 04:44:37 --> Router Class Initialized
INFO - 2018-09-27 04:44:37 --> Output Class Initialized
INFO - 2018-09-27 04:44:37 --> Security Class Initialized
DEBUG - 2018-09-27 04:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:44:37 --> Input Class Initialized
INFO - 2018-09-27 04:44:37 --> Language Class Initialized
INFO - 2018-09-27 04:44:37 --> Loader Class Initialized
INFO - 2018-09-27 04:44:37 --> Helper loaded: url_helper
INFO - 2018-09-27 04:44:37 --> Helper loaded: form_helper
INFO - 2018-09-27 04:44:37 --> Helper loaded: html_helper
INFO - 2018-09-27 04:44:37 --> Database Driver Class Initialized
INFO - 2018-09-27 04:44:37 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:44:37 --> Model "User_model" initialized
INFO - 2018-09-27 04:44:37 --> Model "Project_model" initialized
INFO - 2018-09-27 04:44:37 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:44:37 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:44:37 --> Controller Class Initialized
INFO - 2018-09-27 04:44:37 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:44:37 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:44:37 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:44:37 --> Final output sent to browser
DEBUG - 2018-09-27 04:44:37 --> Total execution time: 0.0820
INFO - 2018-09-27 04:46:56 --> Config Class Initialized
INFO - 2018-09-27 04:46:56 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:46:56 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:46:56 --> Utf8 Class Initialized
INFO - 2018-09-27 04:46:56 --> URI Class Initialized
INFO - 2018-09-27 04:46:56 --> Router Class Initialized
INFO - 2018-09-27 04:46:56 --> Output Class Initialized
INFO - 2018-09-27 04:46:56 --> Security Class Initialized
DEBUG - 2018-09-27 04:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:46:56 --> Input Class Initialized
INFO - 2018-09-27 04:46:56 --> Language Class Initialized
ERROR - 2018-09-27 04:46:56 --> 404 Page Not Found: project_controllers/Home/view
INFO - 2018-09-27 04:47:31 --> Config Class Initialized
INFO - 2018-09-27 04:47:31 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:47:31 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:47:31 --> Utf8 Class Initialized
INFO - 2018-09-27 04:47:31 --> URI Class Initialized
INFO - 2018-09-27 04:47:31 --> Router Class Initialized
INFO - 2018-09-27 04:47:31 --> Output Class Initialized
INFO - 2018-09-27 04:47:31 --> Security Class Initialized
DEBUG - 2018-09-27 04:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:47:31 --> Input Class Initialized
INFO - 2018-09-27 04:47:31 --> Language Class Initialized
INFO - 2018-09-27 04:47:31 --> Loader Class Initialized
INFO - 2018-09-27 04:47:31 --> Helper loaded: url_helper
INFO - 2018-09-27 04:47:31 --> Helper loaded: form_helper
INFO - 2018-09-27 04:47:31 --> Helper loaded: html_helper
INFO - 2018-09-27 04:47:31 --> Database Driver Class Initialized
INFO - 2018-09-27 04:47:31 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:47:31 --> Model "User_model" initialized
INFO - 2018-09-27 04:47:31 --> Model "Project_model" initialized
INFO - 2018-09-27 04:47:31 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:47:31 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:47:31 --> Controller Class Initialized
INFO - 2018-09-27 04:47:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:47:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:47:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:47:31 --> Final output sent to browser
DEBUG - 2018-09-27 04:47:31 --> Total execution time: 0.0660
INFO - 2018-09-27 04:47:38 --> Config Class Initialized
INFO - 2018-09-27 04:47:38 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:47:38 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:47:38 --> Utf8 Class Initialized
INFO - 2018-09-27 04:47:38 --> URI Class Initialized
INFO - 2018-09-27 04:47:38 --> Router Class Initialized
INFO - 2018-09-27 04:47:38 --> Output Class Initialized
INFO - 2018-09-27 04:47:38 --> Security Class Initialized
DEBUG - 2018-09-27 04:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:47:38 --> Input Class Initialized
INFO - 2018-09-27 04:47:38 --> Language Class Initialized
ERROR - 2018-09-27 04:47:38 --> 404 Page Not Found: project_controllers/Home/view
INFO - 2018-09-27 04:47:53 --> Config Class Initialized
INFO - 2018-09-27 04:47:53 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:47:53 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:47:53 --> Utf8 Class Initialized
INFO - 2018-09-27 04:47:53 --> URI Class Initialized
INFO - 2018-09-27 04:47:53 --> Router Class Initialized
INFO - 2018-09-27 04:47:53 --> Output Class Initialized
INFO - 2018-09-27 04:47:53 --> Security Class Initialized
DEBUG - 2018-09-27 04:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:47:53 --> Input Class Initialized
INFO - 2018-09-27 04:47:53 --> Language Class Initialized
ERROR - 2018-09-27 04:47:53 --> 404 Page Not Found: project_controllers/Home/view
INFO - 2018-09-27 04:48:26 --> Config Class Initialized
INFO - 2018-09-27 04:48:26 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:48:26 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:48:26 --> Utf8 Class Initialized
INFO - 2018-09-27 04:48:26 --> URI Class Initialized
INFO - 2018-09-27 04:48:26 --> Router Class Initialized
INFO - 2018-09-27 04:48:26 --> Output Class Initialized
INFO - 2018-09-27 04:48:26 --> Security Class Initialized
DEBUG - 2018-09-27 04:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:48:26 --> Input Class Initialized
INFO - 2018-09-27 04:48:26 --> Language Class Initialized
ERROR - 2018-09-27 04:48:26 --> 404 Page Not Found: project_controllers/Home/view
INFO - 2018-09-27 04:48:55 --> Config Class Initialized
INFO - 2018-09-27 04:48:55 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:48:55 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:48:55 --> Utf8 Class Initialized
INFO - 2018-09-27 04:48:55 --> URI Class Initialized
INFO - 2018-09-27 04:48:55 --> Router Class Initialized
INFO - 2018-09-27 04:48:55 --> Output Class Initialized
INFO - 2018-09-27 04:48:55 --> Security Class Initialized
DEBUG - 2018-09-27 04:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:48:55 --> Input Class Initialized
INFO - 2018-09-27 04:48:55 --> Language Class Initialized
ERROR - 2018-09-27 04:48:55 --> 404 Page Not Found: project_controllers/Home/view
INFO - 2018-09-27 04:50:22 --> Config Class Initialized
INFO - 2018-09-27 04:50:22 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:50:22 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:50:22 --> Utf8 Class Initialized
INFO - 2018-09-27 04:50:22 --> URI Class Initialized
INFO - 2018-09-27 04:50:22 --> Router Class Initialized
INFO - 2018-09-27 04:50:22 --> Output Class Initialized
INFO - 2018-09-27 04:50:22 --> Security Class Initialized
DEBUG - 2018-09-27 04:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:50:22 --> Input Class Initialized
INFO - 2018-09-27 04:50:22 --> Language Class Initialized
ERROR - 2018-09-27 04:50:22 --> 404 Page Not Found: project_controllers/Home/view
INFO - 2018-09-27 04:51:18 --> Config Class Initialized
INFO - 2018-09-27 04:51:18 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:51:18 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:51:18 --> Utf8 Class Initialized
INFO - 2018-09-27 04:51:18 --> URI Class Initialized
INFO - 2018-09-27 04:51:18 --> Router Class Initialized
INFO - 2018-09-27 04:51:18 --> Output Class Initialized
INFO - 2018-09-27 04:51:18 --> Security Class Initialized
DEBUG - 2018-09-27 04:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:51:18 --> Input Class Initialized
INFO - 2018-09-27 04:51:18 --> Language Class Initialized
INFO - 2018-09-27 04:51:18 --> Loader Class Initialized
INFO - 2018-09-27 04:51:18 --> Helper loaded: url_helper
INFO - 2018-09-27 04:51:18 --> Helper loaded: form_helper
INFO - 2018-09-27 04:51:18 --> Helper loaded: html_helper
INFO - 2018-09-27 04:51:18 --> Database Driver Class Initialized
INFO - 2018-09-27 04:51:18 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:51:18 --> Model "User_model" initialized
INFO - 2018-09-27 04:51:18 --> Model "Project_model" initialized
INFO - 2018-09-27 04:51:18 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:51:18 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:51:18 --> Controller Class Initialized
INFO - 2018-09-27 04:51:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:51:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:51:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:51:18 --> Final output sent to browser
DEBUG - 2018-09-27 04:51:18 --> Total execution time: 0.0430
INFO - 2018-09-27 04:51:45 --> Config Class Initialized
INFO - 2018-09-27 04:51:45 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:51:45 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:51:45 --> Utf8 Class Initialized
INFO - 2018-09-27 04:51:45 --> URI Class Initialized
INFO - 2018-09-27 04:51:45 --> Router Class Initialized
INFO - 2018-09-27 04:51:45 --> Output Class Initialized
INFO - 2018-09-27 04:51:45 --> Security Class Initialized
DEBUG - 2018-09-27 04:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:51:45 --> Input Class Initialized
INFO - 2018-09-27 04:51:45 --> Language Class Initialized
INFO - 2018-09-27 04:51:45 --> Loader Class Initialized
INFO - 2018-09-27 04:51:45 --> Helper loaded: url_helper
INFO - 2018-09-27 04:51:45 --> Helper loaded: form_helper
INFO - 2018-09-27 04:51:45 --> Helper loaded: html_helper
INFO - 2018-09-27 04:51:45 --> Database Driver Class Initialized
INFO - 2018-09-27 04:51:45 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:51:45 --> Model "User_model" initialized
INFO - 2018-09-27 04:51:45 --> Model "Project_model" initialized
INFO - 2018-09-27 04:51:45 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:51:45 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:51:45 --> Controller Class Initialized
INFO - 2018-09-27 04:51:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:51:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:51:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:51:45 --> Final output sent to browser
DEBUG - 2018-09-27 04:51:45 --> Total execution time: 0.0530
INFO - 2018-09-27 04:51:56 --> Config Class Initialized
INFO - 2018-09-27 04:51:56 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:51:56 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:51:56 --> Utf8 Class Initialized
INFO - 2018-09-27 04:51:56 --> URI Class Initialized
INFO - 2018-09-27 04:51:56 --> Router Class Initialized
INFO - 2018-09-27 04:51:56 --> Output Class Initialized
INFO - 2018-09-27 04:51:56 --> Security Class Initialized
DEBUG - 2018-09-27 04:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:51:56 --> Input Class Initialized
INFO - 2018-09-27 04:51:56 --> Language Class Initialized
ERROR - 2018-09-27 04:51:56 --> 404 Page Not Found: project_controllers/Home/view
INFO - 2018-09-27 04:52:03 --> Config Class Initialized
INFO - 2018-09-27 04:52:03 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:52:03 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:52:03 --> Utf8 Class Initialized
INFO - 2018-09-27 04:52:03 --> URI Class Initialized
INFO - 2018-09-27 04:52:03 --> Router Class Initialized
INFO - 2018-09-27 04:52:03 --> Output Class Initialized
INFO - 2018-09-27 04:52:03 --> Security Class Initialized
DEBUG - 2018-09-27 04:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:52:03 --> Input Class Initialized
INFO - 2018-09-27 04:52:03 --> Language Class Initialized
INFO - 2018-09-27 04:52:03 --> Loader Class Initialized
INFO - 2018-09-27 04:52:03 --> Helper loaded: url_helper
INFO - 2018-09-27 04:52:03 --> Helper loaded: form_helper
INFO - 2018-09-27 04:52:03 --> Helper loaded: html_helper
INFO - 2018-09-27 04:52:03 --> Database Driver Class Initialized
INFO - 2018-09-27 04:52:03 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:52:03 --> Model "User_model" initialized
INFO - 2018-09-27 04:52:03 --> Model "Project_model" initialized
INFO - 2018-09-27 04:52:03 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:52:03 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:52:03 --> Controller Class Initialized
INFO - 2018-09-27 04:52:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:52:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:52:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:52:03 --> Final output sent to browser
DEBUG - 2018-09-27 04:52:03 --> Total execution time: 0.0480
INFO - 2018-09-27 04:52:24 --> Config Class Initialized
INFO - 2018-09-27 04:52:24 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:52:24 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:52:24 --> Utf8 Class Initialized
INFO - 2018-09-27 04:52:24 --> URI Class Initialized
INFO - 2018-09-27 04:52:24 --> Router Class Initialized
INFO - 2018-09-27 04:52:24 --> Output Class Initialized
INFO - 2018-09-27 04:52:24 --> Security Class Initialized
DEBUG - 2018-09-27 04:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:52:24 --> Input Class Initialized
INFO - 2018-09-27 04:52:24 --> Language Class Initialized
INFO - 2018-09-27 04:52:24 --> Loader Class Initialized
INFO - 2018-09-27 04:52:24 --> Helper loaded: url_helper
INFO - 2018-09-27 04:52:24 --> Helper loaded: form_helper
INFO - 2018-09-27 04:52:24 --> Helper loaded: html_helper
INFO - 2018-09-27 04:52:24 --> Database Driver Class Initialized
INFO - 2018-09-27 04:52:24 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:52:24 --> Model "User_model" initialized
INFO - 2018-09-27 04:52:24 --> Model "Project_model" initialized
INFO - 2018-09-27 04:52:24 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:52:24 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:52:24 --> Controller Class Initialized
INFO - 2018-09-27 04:52:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:52:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:52:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:52:24 --> Final output sent to browser
DEBUG - 2018-09-27 04:52:24 --> Total execution time: 0.0620
INFO - 2018-09-27 04:52:38 --> Config Class Initialized
INFO - 2018-09-27 04:52:38 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:52:38 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:52:38 --> Utf8 Class Initialized
INFO - 2018-09-27 04:52:38 --> URI Class Initialized
INFO - 2018-09-27 04:52:38 --> Router Class Initialized
INFO - 2018-09-27 04:52:38 --> Output Class Initialized
INFO - 2018-09-27 04:52:38 --> Security Class Initialized
DEBUG - 2018-09-27 04:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:52:38 --> Input Class Initialized
INFO - 2018-09-27 04:52:38 --> Language Class Initialized
INFO - 2018-09-27 04:52:38 --> Loader Class Initialized
INFO - 2018-09-27 04:52:38 --> Helper loaded: url_helper
INFO - 2018-09-27 04:52:38 --> Helper loaded: form_helper
INFO - 2018-09-27 04:52:38 --> Helper loaded: html_helper
INFO - 2018-09-27 04:52:38 --> Database Driver Class Initialized
INFO - 2018-09-27 04:52:38 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:52:38 --> Model "User_model" initialized
INFO - 2018-09-27 04:52:38 --> Model "Project_model" initialized
INFO - 2018-09-27 04:52:38 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:52:38 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:52:38 --> Controller Class Initialized
INFO - 2018-09-27 04:52:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:52:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:52:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:52:38 --> Final output sent to browser
DEBUG - 2018-09-27 04:52:38 --> Total execution time: 0.0550
INFO - 2018-09-27 04:52:57 --> Config Class Initialized
INFO - 2018-09-27 04:52:57 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:52:57 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:52:57 --> Utf8 Class Initialized
INFO - 2018-09-27 04:52:57 --> URI Class Initialized
INFO - 2018-09-27 04:52:57 --> Router Class Initialized
INFO - 2018-09-27 04:52:57 --> Output Class Initialized
INFO - 2018-09-27 04:52:57 --> Security Class Initialized
DEBUG - 2018-09-27 04:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:52:57 --> Input Class Initialized
INFO - 2018-09-27 04:52:57 --> Language Class Initialized
INFO - 2018-09-27 04:52:57 --> Loader Class Initialized
INFO - 2018-09-27 04:52:57 --> Helper loaded: url_helper
INFO - 2018-09-27 04:52:57 --> Helper loaded: form_helper
INFO - 2018-09-27 04:52:57 --> Helper loaded: html_helper
INFO - 2018-09-27 04:52:57 --> Database Driver Class Initialized
INFO - 2018-09-27 04:52:57 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:52:57 --> Model "User_model" initialized
INFO - 2018-09-27 04:52:57 --> Model "Project_model" initialized
INFO - 2018-09-27 04:52:57 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:52:57 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:52:57 --> Controller Class Initialized
INFO - 2018-09-27 04:52:57 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:52:57 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:52:57 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:52:57 --> Final output sent to browser
DEBUG - 2018-09-27 04:52:57 --> Total execution time: 0.0480
INFO - 2018-09-27 04:53:21 --> Config Class Initialized
INFO - 2018-09-27 04:53:21 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:53:21 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:53:21 --> Utf8 Class Initialized
INFO - 2018-09-27 04:53:21 --> URI Class Initialized
INFO - 2018-09-27 04:53:21 --> Router Class Initialized
INFO - 2018-09-27 04:53:21 --> Output Class Initialized
INFO - 2018-09-27 04:53:21 --> Security Class Initialized
DEBUG - 2018-09-27 04:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:53:21 --> Input Class Initialized
INFO - 2018-09-27 04:53:21 --> Language Class Initialized
INFO - 2018-09-27 04:53:21 --> Loader Class Initialized
INFO - 2018-09-27 04:53:21 --> Helper loaded: url_helper
INFO - 2018-09-27 04:53:21 --> Helper loaded: form_helper
INFO - 2018-09-27 04:53:21 --> Helper loaded: html_helper
INFO - 2018-09-27 04:53:21 --> Database Driver Class Initialized
INFO - 2018-09-27 04:53:21 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:53:21 --> Model "User_model" initialized
INFO - 2018-09-27 04:53:21 --> Model "Project_model" initialized
INFO - 2018-09-27 04:53:21 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:53:21 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:53:21 --> Controller Class Initialized
INFO - 2018-09-27 04:53:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:53:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:53:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:53:21 --> Final output sent to browser
DEBUG - 2018-09-27 04:53:21 --> Total execution time: 0.0550
INFO - 2018-09-27 04:53:36 --> Config Class Initialized
INFO - 2018-09-27 04:53:36 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:53:36 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:53:36 --> Utf8 Class Initialized
INFO - 2018-09-27 04:53:36 --> URI Class Initialized
INFO - 2018-09-27 04:53:36 --> Router Class Initialized
INFO - 2018-09-27 04:53:36 --> Output Class Initialized
INFO - 2018-09-27 04:53:36 --> Security Class Initialized
DEBUG - 2018-09-27 04:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:53:36 --> Input Class Initialized
INFO - 2018-09-27 04:53:36 --> Language Class Initialized
INFO - 2018-09-27 04:53:36 --> Loader Class Initialized
INFO - 2018-09-27 04:53:36 --> Helper loaded: url_helper
INFO - 2018-09-27 04:53:36 --> Helper loaded: form_helper
INFO - 2018-09-27 04:53:36 --> Helper loaded: html_helper
INFO - 2018-09-27 04:53:36 --> Database Driver Class Initialized
INFO - 2018-09-27 04:53:36 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:53:36 --> Model "User_model" initialized
INFO - 2018-09-27 04:53:36 --> Model "Project_model" initialized
INFO - 2018-09-27 04:53:36 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:53:36 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:53:36 --> Controller Class Initialized
INFO - 2018-09-27 04:53:36 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:53:36 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:53:36 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:53:36 --> Final output sent to browser
DEBUG - 2018-09-27 04:53:36 --> Total execution time: 0.0660
INFO - 2018-09-27 04:53:57 --> Config Class Initialized
INFO - 2018-09-27 04:53:57 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:53:57 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:53:57 --> Utf8 Class Initialized
INFO - 2018-09-27 04:53:57 --> URI Class Initialized
INFO - 2018-09-27 04:53:57 --> Router Class Initialized
INFO - 2018-09-27 04:53:57 --> Output Class Initialized
INFO - 2018-09-27 04:53:57 --> Security Class Initialized
DEBUG - 2018-09-27 04:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:53:57 --> Input Class Initialized
INFO - 2018-09-27 04:53:57 --> Language Class Initialized
INFO - 2018-09-27 04:53:57 --> Loader Class Initialized
INFO - 2018-09-27 04:53:57 --> Helper loaded: url_helper
INFO - 2018-09-27 04:53:57 --> Helper loaded: form_helper
INFO - 2018-09-27 04:53:57 --> Helper loaded: html_helper
INFO - 2018-09-27 04:53:57 --> Database Driver Class Initialized
INFO - 2018-09-27 04:53:57 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:53:57 --> Model "User_model" initialized
INFO - 2018-09-27 04:53:57 --> Model "Project_model" initialized
INFO - 2018-09-27 04:53:57 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:53:57 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:53:57 --> Controller Class Initialized
INFO - 2018-09-27 04:53:57 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:53:57 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:53:57 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:53:57 --> Final output sent to browser
DEBUG - 2018-09-27 04:53:57 --> Total execution time: 0.0490
INFO - 2018-09-27 04:54:36 --> Config Class Initialized
INFO - 2018-09-27 04:54:36 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:54:36 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:54:36 --> Utf8 Class Initialized
INFO - 2018-09-27 04:54:36 --> URI Class Initialized
INFO - 2018-09-27 04:54:36 --> Router Class Initialized
INFO - 2018-09-27 04:54:36 --> Output Class Initialized
INFO - 2018-09-27 04:54:36 --> Security Class Initialized
DEBUG - 2018-09-27 04:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:54:36 --> Input Class Initialized
INFO - 2018-09-27 04:54:36 --> Language Class Initialized
INFO - 2018-09-27 04:54:36 --> Loader Class Initialized
INFO - 2018-09-27 04:54:36 --> Helper loaded: url_helper
INFO - 2018-09-27 04:54:36 --> Helper loaded: form_helper
INFO - 2018-09-27 04:54:36 --> Helper loaded: html_helper
INFO - 2018-09-27 04:54:36 --> Database Driver Class Initialized
INFO - 2018-09-27 04:54:36 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:54:36 --> Model "User_model" initialized
INFO - 2018-09-27 04:54:36 --> Model "Project_model" initialized
INFO - 2018-09-27 04:54:36 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:54:36 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:54:36 --> Controller Class Initialized
INFO - 2018-09-27 04:54:36 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:54:36 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:54:36 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:54:36 --> Final output sent to browser
DEBUG - 2018-09-27 04:54:36 --> Total execution time: 0.0490
INFO - 2018-09-27 04:55:12 --> Config Class Initialized
INFO - 2018-09-27 04:55:12 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:55:12 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:55:12 --> Utf8 Class Initialized
INFO - 2018-09-27 04:55:12 --> URI Class Initialized
INFO - 2018-09-27 04:55:12 --> Router Class Initialized
INFO - 2018-09-27 04:55:12 --> Output Class Initialized
INFO - 2018-09-27 04:55:12 --> Security Class Initialized
DEBUG - 2018-09-27 04:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:55:12 --> Input Class Initialized
INFO - 2018-09-27 04:55:12 --> Language Class Initialized
INFO - 2018-09-27 04:55:12 --> Loader Class Initialized
INFO - 2018-09-27 04:55:12 --> Helper loaded: url_helper
INFO - 2018-09-27 04:55:12 --> Helper loaded: form_helper
INFO - 2018-09-27 04:55:12 --> Helper loaded: html_helper
INFO - 2018-09-27 04:55:12 --> Database Driver Class Initialized
INFO - 2018-09-27 04:55:12 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:55:12 --> Model "User_model" initialized
INFO - 2018-09-27 04:55:12 --> Model "Project_model" initialized
INFO - 2018-09-27 04:55:12 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:55:12 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:55:12 --> Controller Class Initialized
INFO - 2018-09-27 04:55:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:55:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:55:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:55:12 --> Final output sent to browser
DEBUG - 2018-09-27 04:55:12 --> Total execution time: 0.0560
INFO - 2018-09-27 04:55:34 --> Config Class Initialized
INFO - 2018-09-27 04:55:34 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:55:34 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:55:34 --> Utf8 Class Initialized
INFO - 2018-09-27 04:55:34 --> URI Class Initialized
INFO - 2018-09-27 04:55:34 --> Router Class Initialized
INFO - 2018-09-27 04:55:34 --> Output Class Initialized
INFO - 2018-09-27 04:55:34 --> Security Class Initialized
DEBUG - 2018-09-27 04:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:55:34 --> Input Class Initialized
INFO - 2018-09-27 04:55:34 --> Language Class Initialized
INFO - 2018-09-27 04:55:34 --> Loader Class Initialized
INFO - 2018-09-27 04:55:34 --> Helper loaded: url_helper
INFO - 2018-09-27 04:55:34 --> Helper loaded: form_helper
INFO - 2018-09-27 04:55:34 --> Helper loaded: html_helper
INFO - 2018-09-27 04:55:34 --> Database Driver Class Initialized
INFO - 2018-09-27 04:55:34 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:55:34 --> Model "User_model" initialized
INFO - 2018-09-27 04:55:34 --> Model "Project_model" initialized
INFO - 2018-09-27 04:55:34 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:55:34 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:55:34 --> Controller Class Initialized
INFO - 2018-09-27 04:55:34 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:55:34 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:55:34 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:55:34 --> Final output sent to browser
DEBUG - 2018-09-27 04:55:34 --> Total execution time: 0.0560
INFO - 2018-09-27 04:55:51 --> Config Class Initialized
INFO - 2018-09-27 04:55:51 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:55:51 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:55:51 --> Utf8 Class Initialized
INFO - 2018-09-27 04:55:51 --> URI Class Initialized
INFO - 2018-09-27 04:55:51 --> Router Class Initialized
INFO - 2018-09-27 04:55:51 --> Output Class Initialized
INFO - 2018-09-27 04:55:51 --> Security Class Initialized
DEBUG - 2018-09-27 04:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:55:51 --> Input Class Initialized
INFO - 2018-09-27 04:55:51 --> Language Class Initialized
ERROR - 2018-09-27 04:55:51 --> 404 Page Not Found: project_controllers/Home/view
INFO - 2018-09-27 04:56:26 --> Config Class Initialized
INFO - 2018-09-27 04:56:26 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:56:26 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:56:26 --> Utf8 Class Initialized
INFO - 2018-09-27 04:56:26 --> URI Class Initialized
INFO - 2018-09-27 04:56:26 --> Router Class Initialized
INFO - 2018-09-27 04:56:26 --> Output Class Initialized
INFO - 2018-09-27 04:56:26 --> Security Class Initialized
DEBUG - 2018-09-27 04:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:56:26 --> Input Class Initialized
INFO - 2018-09-27 04:56:26 --> Language Class Initialized
INFO - 2018-09-27 04:56:26 --> Loader Class Initialized
INFO - 2018-09-27 04:56:26 --> Helper loaded: url_helper
INFO - 2018-09-27 04:56:26 --> Helper loaded: form_helper
INFO - 2018-09-27 04:56:26 --> Helper loaded: html_helper
INFO - 2018-09-27 04:56:26 --> Database Driver Class Initialized
INFO - 2018-09-27 04:56:26 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:56:26 --> Model "User_model" initialized
INFO - 2018-09-27 04:56:26 --> Model "Project_model" initialized
INFO - 2018-09-27 04:56:26 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:56:26 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:56:26 --> Controller Class Initialized
INFO - 2018-09-27 04:56:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:56:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:56:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:56:26 --> Final output sent to browser
DEBUG - 2018-09-27 04:56:26 --> Total execution time: 0.0770
INFO - 2018-09-27 04:57:08 --> Config Class Initialized
INFO - 2018-09-27 04:57:08 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:57:08 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:57:08 --> Utf8 Class Initialized
INFO - 2018-09-27 04:57:08 --> URI Class Initialized
INFO - 2018-09-27 04:57:08 --> Router Class Initialized
INFO - 2018-09-27 04:57:08 --> Output Class Initialized
INFO - 2018-09-27 04:57:08 --> Security Class Initialized
DEBUG - 2018-09-27 04:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:57:08 --> Input Class Initialized
INFO - 2018-09-27 04:57:08 --> Language Class Initialized
INFO - 2018-09-27 04:57:08 --> Loader Class Initialized
INFO - 2018-09-27 04:57:08 --> Helper loaded: url_helper
INFO - 2018-09-27 04:57:08 --> Helper loaded: form_helper
INFO - 2018-09-27 04:57:08 --> Helper loaded: html_helper
INFO - 2018-09-27 04:57:08 --> Database Driver Class Initialized
INFO - 2018-09-27 04:57:08 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:57:08 --> Model "User_model" initialized
INFO - 2018-09-27 04:57:08 --> Model "Project_model" initialized
INFO - 2018-09-27 04:57:08 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:57:08 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:57:08 --> Controller Class Initialized
INFO - 2018-09-27 04:57:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:57:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:57:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:57:08 --> Final output sent to browser
DEBUG - 2018-09-27 04:57:08 --> Total execution time: 0.0550
INFO - 2018-09-27 04:57:18 --> Config Class Initialized
INFO - 2018-09-27 04:57:18 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:57:18 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:57:18 --> Utf8 Class Initialized
INFO - 2018-09-27 04:57:18 --> URI Class Initialized
INFO - 2018-09-27 04:57:18 --> Router Class Initialized
INFO - 2018-09-27 04:57:18 --> Output Class Initialized
INFO - 2018-09-27 04:57:18 --> Security Class Initialized
DEBUG - 2018-09-27 04:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:57:18 --> Input Class Initialized
INFO - 2018-09-27 04:57:18 --> Language Class Initialized
INFO - 2018-09-27 04:57:18 --> Loader Class Initialized
INFO - 2018-09-27 04:57:18 --> Helper loaded: url_helper
INFO - 2018-09-27 04:57:18 --> Helper loaded: form_helper
INFO - 2018-09-27 04:57:18 --> Helper loaded: html_helper
INFO - 2018-09-27 04:57:18 --> Database Driver Class Initialized
INFO - 2018-09-27 04:57:18 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:57:18 --> Model "User_model" initialized
INFO - 2018-09-27 04:57:18 --> Model "Project_model" initialized
INFO - 2018-09-27 04:57:18 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:57:18 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:57:18 --> Controller Class Initialized
INFO - 2018-09-27 04:57:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:57:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:57:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:57:18 --> Final output sent to browser
DEBUG - 2018-09-27 04:57:18 --> Total execution time: 0.0400
INFO - 2018-09-27 04:57:30 --> Config Class Initialized
INFO - 2018-09-27 04:57:30 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:57:30 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:57:30 --> Utf8 Class Initialized
INFO - 2018-09-27 04:57:30 --> URI Class Initialized
INFO - 2018-09-27 04:57:30 --> Router Class Initialized
INFO - 2018-09-27 04:57:30 --> Output Class Initialized
INFO - 2018-09-27 04:57:30 --> Security Class Initialized
DEBUG - 2018-09-27 04:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:57:30 --> Input Class Initialized
INFO - 2018-09-27 04:57:30 --> Language Class Initialized
INFO - 2018-09-27 04:57:30 --> Loader Class Initialized
INFO - 2018-09-27 04:57:30 --> Helper loaded: url_helper
INFO - 2018-09-27 04:57:30 --> Helper loaded: form_helper
INFO - 2018-09-27 04:57:30 --> Helper loaded: html_helper
INFO - 2018-09-27 04:57:30 --> Database Driver Class Initialized
INFO - 2018-09-27 04:57:30 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:57:30 --> Model "User_model" initialized
INFO - 2018-09-27 04:57:30 --> Model "Project_model" initialized
INFO - 2018-09-27 04:57:30 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:57:30 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:57:30 --> Controller Class Initialized
INFO - 2018-09-27 04:57:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:57:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:57:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:57:30 --> Final output sent to browser
DEBUG - 2018-09-27 04:57:30 --> Total execution time: 0.0560
INFO - 2018-09-27 04:59:14 --> Config Class Initialized
INFO - 2018-09-27 04:59:14 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:59:14 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:59:14 --> Utf8 Class Initialized
INFO - 2018-09-27 04:59:14 --> URI Class Initialized
INFO - 2018-09-27 04:59:14 --> Router Class Initialized
INFO - 2018-09-27 04:59:14 --> Output Class Initialized
INFO - 2018-09-27 04:59:14 --> Security Class Initialized
DEBUG - 2018-09-27 04:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:59:14 --> Input Class Initialized
INFO - 2018-09-27 04:59:14 --> Language Class Initialized
INFO - 2018-09-27 04:59:14 --> Loader Class Initialized
INFO - 2018-09-27 04:59:14 --> Helper loaded: url_helper
INFO - 2018-09-27 04:59:14 --> Helper loaded: form_helper
INFO - 2018-09-27 04:59:14 --> Helper loaded: html_helper
INFO - 2018-09-27 04:59:14 --> Database Driver Class Initialized
INFO - 2018-09-27 04:59:14 --> Form Validation Class Initialized
DEBUG - 2018-09-27 04:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 04:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 04:59:14 --> Model "User_model" initialized
INFO - 2018-09-27 04:59:14 --> Model "Project_model" initialized
INFO - 2018-09-27 04:59:14 --> Model "Tasks_model" initialized
INFO - 2018-09-27 04:59:14 --> Model "Lists_model" initialized
INFO - 2018-09-27 04:59:14 --> Controller Class Initialized
INFO - 2018-09-27 04:59:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 04:59:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 04:59:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 04:59:14 --> Final output sent to browser
DEBUG - 2018-09-27 04:59:14 --> Total execution time: 0.0750
INFO - 2018-09-27 04:59:28 --> Config Class Initialized
INFO - 2018-09-27 04:59:28 --> Hooks Class Initialized
DEBUG - 2018-09-27 04:59:28 --> UTF-8 Support Enabled
INFO - 2018-09-27 04:59:28 --> Utf8 Class Initialized
INFO - 2018-09-27 04:59:28 --> URI Class Initialized
INFO - 2018-09-27 04:59:28 --> Router Class Initialized
INFO - 2018-09-27 04:59:28 --> Output Class Initialized
INFO - 2018-09-27 04:59:28 --> Security Class Initialized
DEBUG - 2018-09-27 04:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 04:59:28 --> Input Class Initialized
INFO - 2018-09-27 04:59:28 --> Language Class Initialized
ERROR - 2018-09-27 04:59:28 --> 404 Page Not Found: project_controllers/Catalog/index
INFO - 2018-09-27 05:00:59 --> Config Class Initialized
INFO - 2018-09-27 05:00:59 --> Hooks Class Initialized
DEBUG - 2018-09-27 05:00:59 --> UTF-8 Support Enabled
INFO - 2018-09-27 05:00:59 --> Utf8 Class Initialized
INFO - 2018-09-27 05:00:59 --> URI Class Initialized
INFO - 2018-09-27 05:00:59 --> Router Class Initialized
INFO - 2018-09-27 05:00:59 --> Output Class Initialized
INFO - 2018-09-27 05:00:59 --> Security Class Initialized
DEBUG - 2018-09-27 05:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 05:00:59 --> Input Class Initialized
INFO - 2018-09-27 05:00:59 --> Language Class Initialized
INFO - 2018-09-27 05:00:59 --> Loader Class Initialized
INFO - 2018-09-27 05:00:59 --> Helper loaded: url_helper
INFO - 2018-09-27 05:00:59 --> Helper loaded: form_helper
INFO - 2018-09-27 05:00:59 --> Helper loaded: html_helper
INFO - 2018-09-27 05:00:59 --> Database Driver Class Initialized
INFO - 2018-09-27 05:00:59 --> Form Validation Class Initialized
DEBUG - 2018-09-27 05:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 05:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 05:00:59 --> Model "User_model" initialized
INFO - 2018-09-27 05:00:59 --> Model "Project_model" initialized
INFO - 2018-09-27 05:00:59 --> Model "Tasks_model" initialized
INFO - 2018-09-27 05:00:59 --> Model "Lists_model" initialized
INFO - 2018-09-27 05:00:59 --> Controller Class Initialized
INFO - 2018-09-27 05:00:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 05:00:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 05:00:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 05:00:59 --> Final output sent to browser
DEBUG - 2018-09-27 05:00:59 --> Total execution time: 0.0570
INFO - 2018-09-27 05:01:31 --> Config Class Initialized
INFO - 2018-09-27 05:01:31 --> Hooks Class Initialized
DEBUG - 2018-09-27 05:01:31 --> UTF-8 Support Enabled
INFO - 2018-09-27 05:01:31 --> Utf8 Class Initialized
INFO - 2018-09-27 05:01:31 --> URI Class Initialized
INFO - 2018-09-27 05:01:31 --> Router Class Initialized
INFO - 2018-09-27 05:01:31 --> Output Class Initialized
INFO - 2018-09-27 05:01:31 --> Security Class Initialized
DEBUG - 2018-09-27 05:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 05:01:31 --> Input Class Initialized
INFO - 2018-09-27 05:01:31 --> Language Class Initialized
INFO - 2018-09-27 05:01:31 --> Loader Class Initialized
INFO - 2018-09-27 05:01:31 --> Helper loaded: url_helper
INFO - 2018-09-27 05:01:31 --> Helper loaded: form_helper
INFO - 2018-09-27 05:01:31 --> Helper loaded: html_helper
INFO - 2018-09-27 05:01:31 --> Database Driver Class Initialized
INFO - 2018-09-27 05:01:31 --> Form Validation Class Initialized
DEBUG - 2018-09-27 05:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 05:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 05:01:31 --> Model "User_model" initialized
INFO - 2018-09-27 05:01:31 --> Model "Project_model" initialized
INFO - 2018-09-27 05:01:31 --> Model "Tasks_model" initialized
INFO - 2018-09-27 05:01:31 --> Model "Lists_model" initialized
INFO - 2018-09-27 05:01:31 --> Controller Class Initialized
INFO - 2018-09-27 05:01:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 05:01:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 05:01:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 05:01:31 --> Final output sent to browser
DEBUG - 2018-09-27 05:01:31 --> Total execution time: 0.0550
INFO - 2018-09-27 05:39:42 --> Config Class Initialized
INFO - 2018-09-27 05:39:42 --> Hooks Class Initialized
DEBUG - 2018-09-27 05:39:42 --> UTF-8 Support Enabled
INFO - 2018-09-27 05:39:42 --> Utf8 Class Initialized
INFO - 2018-09-27 05:39:42 --> URI Class Initialized
INFO - 2018-09-27 05:39:42 --> Router Class Initialized
INFO - 2018-09-27 05:39:42 --> Output Class Initialized
INFO - 2018-09-27 05:39:42 --> Security Class Initialized
DEBUG - 2018-09-27 05:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 05:39:42 --> Input Class Initialized
INFO - 2018-09-27 05:39:42 --> Language Class Initialized
INFO - 2018-09-27 05:39:42 --> Loader Class Initialized
INFO - 2018-09-27 05:39:42 --> Helper loaded: url_helper
INFO - 2018-09-27 05:39:42 --> Helper loaded: form_helper
INFO - 2018-09-27 05:39:42 --> Helper loaded: html_helper
INFO - 2018-09-27 05:39:42 --> Database Driver Class Initialized
INFO - 2018-09-27 05:39:42 --> Form Validation Class Initialized
DEBUG - 2018-09-27 05:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 05:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 05:39:42 --> Model "User_model" initialized
INFO - 2018-09-27 05:39:42 --> Model "Project_model" initialized
INFO - 2018-09-27 05:39:42 --> Model "Tasks_model" initialized
INFO - 2018-09-27 05:39:42 --> Model "Lists_model" initialized
INFO - 2018-09-27 05:39:42 --> Controller Class Initialized
INFO - 2018-09-27 05:39:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-27 05:39:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-27 05:39:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-27 05:39:42 --> Final output sent to browser
DEBUG - 2018-09-27 05:39:42 --> Total execution time: 0.0600
INFO - 2018-09-27 05:39:51 --> Config Class Initialized
INFO - 2018-09-27 05:39:51 --> Hooks Class Initialized
DEBUG - 2018-09-27 05:39:51 --> UTF-8 Support Enabled
INFO - 2018-09-27 05:39:51 --> Utf8 Class Initialized
INFO - 2018-09-27 05:39:51 --> URI Class Initialized
INFO - 2018-09-27 05:39:51 --> Router Class Initialized
INFO - 2018-09-27 05:39:51 --> Output Class Initialized
INFO - 2018-09-27 05:39:51 --> Security Class Initialized
DEBUG - 2018-09-27 05:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 05:39:51 --> Input Class Initialized
INFO - 2018-09-27 05:39:51 --> Language Class Initialized
INFO - 2018-09-27 05:39:51 --> Loader Class Initialized
INFO - 2018-09-27 05:39:51 --> Helper loaded: url_helper
INFO - 2018-09-27 05:39:51 --> Helper loaded: form_helper
INFO - 2018-09-27 05:39:51 --> Helper loaded: html_helper
INFO - 2018-09-27 05:39:51 --> Database Driver Class Initialized
INFO - 2018-09-27 05:39:51 --> Form Validation Class Initialized
DEBUG - 2018-09-27 05:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 05:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 05:39:51 --> Model "User_model" initialized
INFO - 2018-09-27 05:39:51 --> Model "Project_model" initialized
INFO - 2018-09-27 05:39:51 --> Model "Tasks_model" initialized
INFO - 2018-09-27 05:39:51 --> Model "Lists_model" initialized
INFO - 2018-09-27 05:39:51 --> Controller Class Initialized
INFO - 2018-09-27 05:40:30 --> Config Class Initialized
INFO - 2018-09-27 05:40:30 --> Hooks Class Initialized
DEBUG - 2018-09-27 05:40:30 --> UTF-8 Support Enabled
INFO - 2018-09-27 05:40:30 --> Utf8 Class Initialized
INFO - 2018-09-27 05:40:30 --> URI Class Initialized
INFO - 2018-09-27 05:40:30 --> Router Class Initialized
INFO - 2018-09-27 05:40:30 --> Output Class Initialized
INFO - 2018-09-27 05:40:30 --> Security Class Initialized
DEBUG - 2018-09-27 05:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 05:40:30 --> Input Class Initialized
INFO - 2018-09-27 05:40:30 --> Language Class Initialized
INFO - 2018-09-27 05:40:30 --> Loader Class Initialized
INFO - 2018-09-27 05:40:30 --> Helper loaded: url_helper
INFO - 2018-09-27 05:40:30 --> Helper loaded: form_helper
INFO - 2018-09-27 05:40:30 --> Helper loaded: html_helper
INFO - 2018-09-27 05:40:30 --> Database Driver Class Initialized
INFO - 2018-09-27 05:40:30 --> Form Validation Class Initialized
DEBUG - 2018-09-27 05:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 05:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 05:40:30 --> Model "User_model" initialized
INFO - 2018-09-27 05:40:30 --> Model "Project_model" initialized
INFO - 2018-09-27 05:40:30 --> Model "Tasks_model" initialized
INFO - 2018-09-27 05:40:30 --> Model "Lists_model" initialized
INFO - 2018-09-27 05:40:30 --> Controller Class Initialized
INFO - 2018-09-27 05:40:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/test.php
DEBUG - 2018-09-27 05:40:30 --> Cache file written: D:\xampp\htdocs\code_igniter\application\cache/5c0786693044f854aa1c9ca756c26557
INFO - 2018-09-27 05:40:30 --> Final output sent to browser
DEBUG - 2018-09-27 05:40:30 --> Total execution time: 0.0470
INFO - 2018-09-27 05:44:43 --> Config Class Initialized
INFO - 2018-09-27 05:44:43 --> Hooks Class Initialized
DEBUG - 2018-09-27 05:44:43 --> UTF-8 Support Enabled
INFO - 2018-09-27 05:44:43 --> Utf8 Class Initialized
INFO - 2018-09-27 05:44:43 --> URI Class Initialized
INFO - 2018-09-27 05:44:43 --> Router Class Initialized
INFO - 2018-09-27 05:44:43 --> Output Class Initialized
INFO - 2018-09-27 05:44:43 --> Security Class Initialized
DEBUG - 2018-09-27 05:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 05:44:43 --> Input Class Initialized
INFO - 2018-09-27 05:44:43 --> Language Class Initialized
ERROR - 2018-09-27 05:44:43 --> 404 Page Not Found: project_controllers/Cache_controller/delete
INFO - 2018-09-27 05:45:02 --> Config Class Initialized
INFO - 2018-09-27 05:45:02 --> Hooks Class Initialized
DEBUG - 2018-09-27 05:45:02 --> UTF-8 Support Enabled
INFO - 2018-09-27 05:45:02 --> Utf8 Class Initialized
INFO - 2018-09-27 05:45:02 --> URI Class Initialized
INFO - 2018-09-27 05:45:02 --> Router Class Initialized
INFO - 2018-09-27 05:45:02 --> Output Class Initialized
INFO - 2018-09-27 05:45:02 --> Security Class Initialized
DEBUG - 2018-09-27 05:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 05:45:02 --> Input Class Initialized
INFO - 2018-09-27 05:45:02 --> Language Class Initialized
INFO - 2018-09-27 05:45:02 --> Loader Class Initialized
INFO - 2018-09-27 05:45:02 --> Helper loaded: url_helper
INFO - 2018-09-27 05:45:02 --> Helper loaded: form_helper
INFO - 2018-09-27 05:45:02 --> Helper loaded: html_helper
INFO - 2018-09-27 05:45:02 --> Database Driver Class Initialized
INFO - 2018-09-27 05:45:02 --> Form Validation Class Initialized
DEBUG - 2018-09-27 05:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 05:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 05:45:02 --> Model "User_model" initialized
INFO - 2018-09-27 05:45:02 --> Model "Project_model" initialized
INFO - 2018-09-27 05:45:02 --> Model "Tasks_model" initialized
INFO - 2018-09-27 05:45:02 --> Model "Lists_model" initialized
INFO - 2018-09-27 05:45:02 --> Controller Class Initialized
ERROR - 2018-09-27 05:45:02 --> Unable to delete cache file for project_controllers
INFO - 2018-09-27 05:45:02 --> Final output sent to browser
DEBUG - 2018-09-27 05:45:02 --> Total execution time: 0.0900
INFO - 2018-09-27 05:45:37 --> Config Class Initialized
INFO - 2018-09-27 05:45:37 --> Hooks Class Initialized
DEBUG - 2018-09-27 05:45:37 --> UTF-8 Support Enabled
INFO - 2018-09-27 05:45:37 --> Utf8 Class Initialized
INFO - 2018-09-27 05:45:37 --> URI Class Initialized
INFO - 2018-09-27 05:45:37 --> Router Class Initialized
INFO - 2018-09-27 05:45:37 --> Output Class Initialized
INFO - 2018-09-27 05:45:37 --> Security Class Initialized
DEBUG - 2018-09-27 05:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 05:45:37 --> Input Class Initialized
INFO - 2018-09-27 05:45:37 --> Language Class Initialized
ERROR - 2018-09-27 05:45:37 --> 404 Page Not Found: project_controllers/Cachecontroller/delete
INFO - 2018-09-27 05:46:12 --> Config Class Initialized
INFO - 2018-09-27 05:46:12 --> Hooks Class Initialized
DEBUG - 2018-09-27 05:46:12 --> UTF-8 Support Enabled
INFO - 2018-09-27 05:46:12 --> Utf8 Class Initialized
INFO - 2018-09-27 05:46:12 --> URI Class Initialized
INFO - 2018-09-27 05:46:12 --> Router Class Initialized
INFO - 2018-09-27 05:46:12 --> Output Class Initialized
INFO - 2018-09-27 05:46:12 --> Security Class Initialized
DEBUG - 2018-09-27 05:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 05:46:12 --> Input Class Initialized
INFO - 2018-09-27 05:46:12 --> Language Class Initialized
ERROR - 2018-09-27 05:46:12 --> 404 Page Not Found: project_controllers/Cache_controller/delete
INFO - 2018-09-27 05:46:23 --> Config Class Initialized
INFO - 2018-09-27 05:46:23 --> Hooks Class Initialized
DEBUG - 2018-09-27 05:46:23 --> UTF-8 Support Enabled
INFO - 2018-09-27 05:46:23 --> Utf8 Class Initialized
INFO - 2018-09-27 05:46:23 --> URI Class Initialized
INFO - 2018-09-27 05:46:23 --> Router Class Initialized
INFO - 2018-09-27 05:46:23 --> Output Class Initialized
INFO - 2018-09-27 05:46:23 --> Security Class Initialized
DEBUG - 2018-09-27 05:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 05:46:23 --> Input Class Initialized
INFO - 2018-09-27 05:46:23 --> Language Class Initialized
INFO - 2018-09-27 05:46:23 --> Loader Class Initialized
INFO - 2018-09-27 05:46:23 --> Helper loaded: url_helper
INFO - 2018-09-27 05:46:23 --> Helper loaded: form_helper
INFO - 2018-09-27 05:46:23 --> Helper loaded: html_helper
INFO - 2018-09-27 05:46:23 --> Database Driver Class Initialized
INFO - 2018-09-27 05:46:23 --> Form Validation Class Initialized
DEBUG - 2018-09-27 05:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 05:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 05:46:23 --> Model "User_model" initialized
INFO - 2018-09-27 05:46:23 --> Model "Project_model" initialized
INFO - 2018-09-27 05:46:23 --> Model "Tasks_model" initialized
INFO - 2018-09-27 05:46:23 --> Model "Lists_model" initialized
INFO - 2018-09-27 05:46:23 --> Controller Class Initialized
ERROR - 2018-09-27 05:46:23 --> Unable to delete cache file for project_controllers
INFO - 2018-09-27 05:46:23 --> Final output sent to browser
DEBUG - 2018-09-27 05:46:23 --> Total execution time: 0.0590
INFO - 2018-09-27 05:46:26 --> Config Class Initialized
INFO - 2018-09-27 05:46:26 --> Hooks Class Initialized
DEBUG - 2018-09-27 05:46:26 --> UTF-8 Support Enabled
INFO - 2018-09-27 05:46:26 --> Utf8 Class Initialized
INFO - 2018-09-27 05:46:26 --> URI Class Initialized
INFO - 2018-09-27 05:46:26 --> Router Class Initialized
INFO - 2018-09-27 05:46:26 --> Output Class Initialized
INFO - 2018-09-27 05:46:26 --> Security Class Initialized
DEBUG - 2018-09-27 05:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 05:46:26 --> Input Class Initialized
INFO - 2018-09-27 05:46:26 --> Language Class Initialized
INFO - 2018-09-27 05:46:26 --> Loader Class Initialized
INFO - 2018-09-27 05:46:26 --> Helper loaded: url_helper
INFO - 2018-09-27 05:46:26 --> Helper loaded: form_helper
INFO - 2018-09-27 05:46:26 --> Helper loaded: html_helper
INFO - 2018-09-27 05:46:26 --> Database Driver Class Initialized
INFO - 2018-09-27 05:46:26 --> Form Validation Class Initialized
DEBUG - 2018-09-27 05:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 05:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 05:46:26 --> Model "User_model" initialized
INFO - 2018-09-27 05:46:26 --> Model "Project_model" initialized
INFO - 2018-09-27 05:46:26 --> Model "Tasks_model" initialized
INFO - 2018-09-27 05:46:26 --> Model "Lists_model" initialized
INFO - 2018-09-27 05:46:26 --> Controller Class Initialized
ERROR - 2018-09-27 05:46:26 --> Unable to delete cache file for project_controllers
INFO - 2018-09-27 05:46:26 --> Final output sent to browser
DEBUG - 2018-09-27 05:46:26 --> Total execution time: 0.0540
INFO - 2018-09-27 05:51:46 --> Config Class Initialized
INFO - 2018-09-27 05:51:46 --> Hooks Class Initialized
DEBUG - 2018-09-27 05:51:46 --> UTF-8 Support Enabled
INFO - 2018-09-27 05:51:46 --> Utf8 Class Initialized
INFO - 2018-09-27 05:51:46 --> URI Class Initialized
INFO - 2018-09-27 05:51:46 --> Router Class Initialized
INFO - 2018-09-27 05:51:46 --> Output Class Initialized
INFO - 2018-09-27 05:51:46 --> Security Class Initialized
DEBUG - 2018-09-27 05:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 05:51:46 --> Input Class Initialized
INFO - 2018-09-27 05:51:46 --> Language Class Initialized
ERROR - 2018-09-27 05:51:46 --> 404 Page Not Found: project_controllers/Cachecontroller/index
INFO - 2018-09-27 05:52:00 --> Config Class Initialized
INFO - 2018-09-27 05:52:00 --> Hooks Class Initialized
DEBUG - 2018-09-27 05:52:00 --> UTF-8 Support Enabled
INFO - 2018-09-27 05:52:00 --> Utf8 Class Initialized
INFO - 2018-09-27 05:52:00 --> URI Class Initialized
INFO - 2018-09-27 05:52:00 --> Router Class Initialized
INFO - 2018-09-27 05:52:00 --> Output Class Initialized
DEBUG - 2018-09-27 05:52:00 --> Cache file has expired. File deleted.
INFO - 2018-09-27 05:52:00 --> Security Class Initialized
DEBUG - 2018-09-27 05:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 05:52:00 --> Input Class Initialized
INFO - 2018-09-27 05:52:00 --> Language Class Initialized
INFO - 2018-09-27 05:52:00 --> Loader Class Initialized
INFO - 2018-09-27 05:52:00 --> Helper loaded: url_helper
INFO - 2018-09-27 05:52:00 --> Helper loaded: form_helper
INFO - 2018-09-27 05:52:00 --> Helper loaded: html_helper
INFO - 2018-09-27 05:52:00 --> Database Driver Class Initialized
INFO - 2018-09-27 05:52:00 --> Form Validation Class Initialized
DEBUG - 2018-09-27 05:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 05:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 05:52:00 --> Model "User_model" initialized
INFO - 2018-09-27 05:52:00 --> Model "Project_model" initialized
INFO - 2018-09-27 05:52:00 --> Model "Tasks_model" initialized
INFO - 2018-09-27 05:52:00 --> Model "Lists_model" initialized
INFO - 2018-09-27 05:52:00 --> Controller Class Initialized
INFO - 2018-09-27 05:52:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/test.php
DEBUG - 2018-09-27 05:52:00 --> Cache file written: D:\xampp\htdocs\code_igniter\application\cache/5c0786693044f854aa1c9ca756c26557
INFO - 2018-09-27 05:52:00 --> Final output sent to browser
DEBUG - 2018-09-27 05:52:00 --> Total execution time: 0.1120
INFO - 2018-09-27 05:52:34 --> Config Class Initialized
INFO - 2018-09-27 05:52:34 --> Hooks Class Initialized
DEBUG - 2018-09-27 05:52:34 --> UTF-8 Support Enabled
INFO - 2018-09-27 05:52:34 --> Utf8 Class Initialized
INFO - 2018-09-27 05:52:34 --> URI Class Initialized
INFO - 2018-09-27 05:52:34 --> Router Class Initialized
INFO - 2018-09-27 05:52:34 --> Output Class Initialized
INFO - 2018-09-27 05:52:34 --> Security Class Initialized
DEBUG - 2018-09-27 05:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 05:52:34 --> Input Class Initialized
INFO - 2018-09-27 05:52:34 --> Language Class Initialized
INFO - 2018-09-27 05:52:34 --> Loader Class Initialized
INFO - 2018-09-27 05:52:34 --> Helper loaded: url_helper
INFO - 2018-09-27 05:52:34 --> Helper loaded: form_helper
INFO - 2018-09-27 05:52:34 --> Helper loaded: html_helper
INFO - 2018-09-27 05:52:34 --> Database Driver Class Initialized
INFO - 2018-09-27 05:52:34 --> Form Validation Class Initialized
DEBUG - 2018-09-27 05:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 05:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 05:52:34 --> Model "User_model" initialized
INFO - 2018-09-27 05:52:34 --> Model "Project_model" initialized
INFO - 2018-09-27 05:52:34 --> Model "Tasks_model" initialized
INFO - 2018-09-27 05:52:34 --> Model "Lists_model" initialized
INFO - 2018-09-27 05:52:34 --> Controller Class Initialized
ERROR - 2018-09-27 05:52:34 --> Unable to delete cache file for cachecontroller
INFO - 2018-09-27 05:52:34 --> Final output sent to browser
DEBUG - 2018-09-27 05:52:34 --> Total execution time: 0.0510
INFO - 2018-09-27 05:53:00 --> Config Class Initialized
INFO - 2018-09-27 05:53:00 --> Hooks Class Initialized
DEBUG - 2018-09-27 05:53:00 --> UTF-8 Support Enabled
INFO - 2018-09-27 05:53:00 --> Utf8 Class Initialized
INFO - 2018-09-27 05:53:00 --> URI Class Initialized
INFO - 2018-09-27 05:53:00 --> Router Class Initialized
INFO - 2018-09-27 05:53:00 --> Output Class Initialized
INFO - 2018-09-27 05:53:00 --> Security Class Initialized
DEBUG - 2018-09-27 05:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 05:53:00 --> Input Class Initialized
INFO - 2018-09-27 05:53:00 --> Language Class Initialized
ERROR - 2018-09-27 05:53:00 --> 404 Page Not Found: project_controllers/Cachecontroller/delete
INFO - 2018-09-27 05:54:01 --> Config Class Initialized
INFO - 2018-09-27 05:54:01 --> Hooks Class Initialized
DEBUG - 2018-09-27 05:54:01 --> UTF-8 Support Enabled
INFO - 2018-09-27 05:54:01 --> Utf8 Class Initialized
INFO - 2018-09-27 05:54:01 --> URI Class Initialized
INFO - 2018-09-27 05:54:01 --> Router Class Initialized
INFO - 2018-09-27 05:54:01 --> Output Class Initialized
INFO - 2018-09-27 05:54:01 --> Security Class Initialized
DEBUG - 2018-09-27 05:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 05:54:01 --> Input Class Initialized
INFO - 2018-09-27 05:54:01 --> Language Class Initialized
ERROR - 2018-09-27 05:54:01 --> 404 Page Not Found: project_controllers/Cache_controller/delete
INFO - 2018-09-27 05:54:07 --> Config Class Initialized
INFO - 2018-09-27 05:54:07 --> Hooks Class Initialized
DEBUG - 2018-09-27 05:54:07 --> UTF-8 Support Enabled
INFO - 2018-09-27 05:54:07 --> Utf8 Class Initialized
INFO - 2018-09-27 05:54:07 --> URI Class Initialized
INFO - 2018-09-27 05:54:07 --> Router Class Initialized
INFO - 2018-09-27 05:54:07 --> Output Class Initialized
INFO - 2018-09-27 05:54:07 --> Security Class Initialized
DEBUG - 2018-09-27 05:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 05:54:07 --> Input Class Initialized
INFO - 2018-09-27 05:54:07 --> Language Class Initialized
INFO - 2018-09-27 05:54:07 --> Loader Class Initialized
INFO - 2018-09-27 05:54:07 --> Helper loaded: url_helper
INFO - 2018-09-27 05:54:07 --> Helper loaded: form_helper
INFO - 2018-09-27 05:54:07 --> Helper loaded: html_helper
INFO - 2018-09-27 05:54:07 --> Database Driver Class Initialized
INFO - 2018-09-27 05:54:07 --> Form Validation Class Initialized
DEBUG - 2018-09-27 05:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 05:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 05:54:07 --> Model "User_model" initialized
INFO - 2018-09-27 05:54:07 --> Model "Project_model" initialized
INFO - 2018-09-27 05:54:07 --> Model "Tasks_model" initialized
INFO - 2018-09-27 05:54:07 --> Model "Lists_model" initialized
INFO - 2018-09-27 05:54:07 --> Controller Class Initialized
ERROR - 2018-09-27 05:54:07 --> Unable to delete cache file for cachecontroller
INFO - 2018-09-27 05:54:07 --> Final output sent to browser
DEBUG - 2018-09-27 05:54:07 --> Total execution time: 0.0390
INFO - 2018-09-27 06:26:14 --> Config Class Initialized
INFO - 2018-09-27 06:26:14 --> Hooks Class Initialized
ERROR - 2018-09-27 06:26:14 --> Severity: error --> Exception: syntax error, unexpected end of file D:\xampp\htdocs\code_igniter\application\config\hooks.php 26
INFO - 2018-09-27 06:26:29 --> Config Class Initialized
INFO - 2018-09-27 06:26:29 --> Hooks Class Initialized
DEBUG - 2018-09-27 06:26:29 --> UTF-8 Support Enabled
INFO - 2018-09-27 06:26:29 --> Utf8 Class Initialized
INFO - 2018-09-27 06:26:29 --> URI Class Initialized
INFO - 2018-09-27 06:26:29 --> Router Class Initialized
INFO - 2018-09-27 06:26:29 --> Output Class Initialized
INFO - 2018-09-27 06:26:29 --> Security Class Initialized
DEBUG - 2018-09-27 06:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 06:26:29 --> Input Class Initialized
INFO - 2018-09-27 06:26:29 --> Language Class Initialized
INFO - 2018-09-27 06:26:29 --> Loader Class Initialized
INFO - 2018-09-27 06:26:29 --> Helper loaded: url_helper
INFO - 2018-09-27 06:26:29 --> Helper loaded: form_helper
INFO - 2018-09-27 06:26:29 --> Helper loaded: html_helper
INFO - 2018-09-27 06:26:29 --> Database Driver Class Initialized
INFO - 2018-09-27 06:26:29 --> Form Validation Class Initialized
DEBUG - 2018-09-27 06:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 06:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 06:26:29 --> Model "User_model" initialized
INFO - 2018-09-27 06:26:29 --> Model "Project_model" initialized
INFO - 2018-09-27 06:26:29 --> Model "Tasks_model" initialized
INFO - 2018-09-27 06:26:29 --> Model "Lists_model" initialized
INFO - 2018-09-27 06:26:29 --> Controller Class Initialized
INFO - 2018-09-27 06:26:29 --> Final output sent to browser
DEBUG - 2018-09-27 06:26:29 --> Total execution time: 0.0450
INFO - 2018-09-27 06:30:59 --> Config Class Initialized
INFO - 2018-09-27 06:30:59 --> Hooks Class Initialized
DEBUG - 2018-09-27 06:30:59 --> UTF-8 Support Enabled
INFO - 2018-09-27 06:30:59 --> Utf8 Class Initialized
INFO - 2018-09-27 06:30:59 --> URI Class Initialized
INFO - 2018-09-27 06:30:59 --> Router Class Initialized
INFO - 2018-09-27 06:30:59 --> Output Class Initialized
INFO - 2018-09-27 06:30:59 --> Security Class Initialized
DEBUG - 2018-09-27 06:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 06:30:59 --> Input Class Initialized
INFO - 2018-09-27 06:30:59 --> Language Class Initialized
INFO - 2018-09-27 06:30:59 --> Loader Class Initialized
INFO - 2018-09-27 06:30:59 --> Helper loaded: url_helper
INFO - 2018-09-27 06:30:59 --> Helper loaded: form_helper
INFO - 2018-09-27 06:30:59 --> Helper loaded: html_helper
INFO - 2018-09-27 06:30:59 --> Database Driver Class Initialized
INFO - 2018-09-27 06:30:59 --> Form Validation Class Initialized
DEBUG - 2018-09-27 06:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 06:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 06:30:59 --> Model "User_model" initialized
INFO - 2018-09-27 06:30:59 --> Model "Project_model" initialized
INFO - 2018-09-27 06:30:59 --> Model "Tasks_model" initialized
INFO - 2018-09-27 06:30:59 --> Model "Lists_model" initialized
INFO - 2018-09-27 06:30:59 --> Controller Class Initialized
ERROR - 2018-09-27 06:30:59 --> Severity: Notice --> Undefined property: Sample::$load D:\xampp\htdocs\code_igniter\system\libraries\Form_validation.php 147
ERROR - 2018-09-27 06:30:59 --> Severity: error --> Exception: Call to a member function helper() on null D:\xampp\htdocs\code_igniter\system\libraries\Form_validation.php 147
INFO - 2018-09-27 06:33:39 --> Config Class Initialized
INFO - 2018-09-27 06:33:39 --> Hooks Class Initialized
DEBUG - 2018-09-27 06:33:39 --> UTF-8 Support Enabled
INFO - 2018-09-27 06:33:39 --> Utf8 Class Initialized
INFO - 2018-09-27 06:33:39 --> URI Class Initialized
INFO - 2018-09-27 06:33:39 --> Router Class Initialized
INFO - 2018-09-27 06:33:39 --> Output Class Initialized
INFO - 2018-09-27 06:33:39 --> Security Class Initialized
DEBUG - 2018-09-27 06:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 06:33:39 --> Input Class Initialized
INFO - 2018-09-27 06:33:39 --> Language Class Initialized
ERROR - 2018-09-27 06:33:39 --> 404 Page Not Found: project_controllers/Example/index
INFO - 2018-09-27 06:33:49 --> Config Class Initialized
INFO - 2018-09-27 06:33:49 --> Hooks Class Initialized
DEBUG - 2018-09-27 06:33:49 --> UTF-8 Support Enabled
INFO - 2018-09-27 06:33:49 --> Utf8 Class Initialized
INFO - 2018-09-27 06:33:49 --> URI Class Initialized
INFO - 2018-09-27 06:33:49 --> Router Class Initialized
INFO - 2018-09-27 06:33:49 --> Output Class Initialized
INFO - 2018-09-27 06:33:49 --> Security Class Initialized
DEBUG - 2018-09-27 06:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 06:33:49 --> Input Class Initialized
INFO - 2018-09-27 06:33:49 --> Language Class Initialized
INFO - 2018-09-27 06:33:49 --> Loader Class Initialized
INFO - 2018-09-27 06:33:49 --> Helper loaded: url_helper
INFO - 2018-09-27 06:33:49 --> Helper loaded: form_helper
INFO - 2018-09-27 06:33:49 --> Helper loaded: html_helper
INFO - 2018-09-27 06:33:49 --> Database Driver Class Initialized
INFO - 2018-09-27 06:33:49 --> Form Validation Class Initialized
DEBUG - 2018-09-27 06:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 06:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 06:33:49 --> Model "User_model" initialized
INFO - 2018-09-27 06:33:49 --> Model "Project_model" initialized
INFO - 2018-09-27 06:33:49 --> Model "Tasks_model" initialized
INFO - 2018-09-27 06:33:49 --> Model "Lists_model" initialized
INFO - 2018-09-27 06:33:49 --> Controller Class Initialized
ERROR - 2018-09-27 06:33:49 --> Severity: Notice --> Undefined property: Sample::$load D:\xampp\htdocs\code_igniter\system\libraries\Form_validation.php 147
ERROR - 2018-09-27 06:33:49 --> Severity: error --> Exception: Call to a member function helper() on null D:\xampp\htdocs\code_igniter\system\libraries\Form_validation.php 147
INFO - 2018-09-27 06:34:41 --> Config Class Initialized
INFO - 2018-09-27 06:34:41 --> Hooks Class Initialized
DEBUG - 2018-09-27 06:34:41 --> UTF-8 Support Enabled
INFO - 2018-09-27 06:34:41 --> Utf8 Class Initialized
INFO - 2018-09-27 06:34:41 --> URI Class Initialized
INFO - 2018-09-27 06:34:41 --> Router Class Initialized
INFO - 2018-09-27 06:34:41 --> Output Class Initialized
INFO - 2018-09-27 06:34:41 --> Security Class Initialized
DEBUG - 2018-09-27 06:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 06:34:41 --> Input Class Initialized
INFO - 2018-09-27 06:34:41 --> Language Class Initialized
INFO - 2018-09-27 06:34:41 --> Loader Class Initialized
INFO - 2018-09-27 06:34:41 --> Helper loaded: url_helper
INFO - 2018-09-27 06:34:41 --> Helper loaded: form_helper
INFO - 2018-09-27 06:34:41 --> Helper loaded: html_helper
INFO - 2018-09-27 06:34:41 --> Database Driver Class Initialized
INFO - 2018-09-27 06:34:41 --> Form Validation Class Initialized
DEBUG - 2018-09-27 06:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 06:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 06:34:41 --> Model "User_model" initialized
INFO - 2018-09-27 06:34:41 --> Model "Project_model" initialized
INFO - 2018-09-27 06:34:41 --> Model "Tasks_model" initialized
INFO - 2018-09-27 06:34:41 --> Model "Lists_model" initialized
INFO - 2018-09-27 06:34:41 --> Controller Class Initialized
ERROR - 2018-09-27 06:34:41 --> Severity: Notice --> Undefined property: Sample::$load D:\xampp\htdocs\code_igniter\system\libraries\Form_validation.php 147
ERROR - 2018-09-27 06:34:41 --> Severity: error --> Exception: Call to a member function helper() on null D:\xampp\htdocs\code_igniter\system\libraries\Form_validation.php 147
INFO - 2018-09-27 06:39:41 --> Config Class Initialized
INFO - 2018-09-27 06:39:41 --> Hooks Class Initialized
ERROR - 2018-09-27 06:39:41 --> Severity: error --> Exception: syntax error, unexpected end of file D:\xampp\htdocs\code_igniter\application\config\hooks.php 34
INFO - 2018-09-27 06:39:51 --> Config Class Initialized
INFO - 2018-09-27 06:39:51 --> Hooks Class Initialized
DEBUG - 2018-09-27 06:39:51 --> UTF-8 Support Enabled
INFO - 2018-09-27 06:39:51 --> Utf8 Class Initialized
INFO - 2018-09-27 06:39:51 --> URI Class Initialized
INFO - 2018-09-27 06:39:51 --> Router Class Initialized
INFO - 2018-09-27 06:39:51 --> Output Class Initialized
INFO - 2018-09-27 06:39:51 --> Security Class Initialized
DEBUG - 2018-09-27 06:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 06:39:51 --> Input Class Initialized
INFO - 2018-09-27 06:39:51 --> Language Class Initialized
INFO - 2018-09-27 06:39:51 --> Loader Class Initialized
INFO - 2018-09-27 06:39:51 --> Helper loaded: url_helper
INFO - 2018-09-27 06:39:51 --> Helper loaded: form_helper
INFO - 2018-09-27 06:39:51 --> Helper loaded: html_helper
INFO - 2018-09-27 06:39:51 --> Database Driver Class Initialized
INFO - 2018-09-27 06:39:51 --> Form Validation Class Initialized
DEBUG - 2018-09-27 06:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 06:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 06:39:51 --> Model "User_model" initialized
INFO - 2018-09-27 06:39:51 --> Model "Project_model" initialized
INFO - 2018-09-27 06:39:51 --> Model "Tasks_model" initialized
INFO - 2018-09-27 06:39:51 --> Model "Lists_model" initialized
INFO - 2018-09-27 06:39:51 --> Controller Class Initialized
ERROR - 2018-09-27 06:39:51 --> Severity: Notice --> Undefined property: Sample::$load D:\xampp\htdocs\code_igniter\system\libraries\Form_validation.php 147
ERROR - 2018-09-27 06:39:51 --> Severity: error --> Exception: Call to a member function helper() on null D:\xampp\htdocs\code_igniter\system\libraries\Form_validation.php 147
INFO - 2018-09-27 06:44:56 --> Config Class Initialized
INFO - 2018-09-27 06:44:56 --> Hooks Class Initialized
DEBUG - 2018-09-27 06:44:56 --> UTF-8 Support Enabled
INFO - 2018-09-27 06:44:56 --> Utf8 Class Initialized
INFO - 2018-09-27 06:44:56 --> URI Class Initialized
INFO - 2018-09-27 06:44:56 --> Router Class Initialized
INFO - 2018-09-27 06:44:56 --> Output Class Initialized
INFO - 2018-09-27 06:44:56 --> Security Class Initialized
DEBUG - 2018-09-27 06:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 06:44:56 --> Input Class Initialized
INFO - 2018-09-27 06:44:56 --> Language Class Initialized
INFO - 2018-09-27 06:44:56 --> Loader Class Initialized
INFO - 2018-09-27 06:44:56 --> Helper loaded: url_helper
INFO - 2018-09-27 06:44:56 --> Helper loaded: form_helper
INFO - 2018-09-27 06:44:56 --> Helper loaded: html_helper
INFO - 2018-09-27 06:44:56 --> Database Driver Class Initialized
INFO - 2018-09-27 06:44:56 --> Form Validation Class Initialized
DEBUG - 2018-09-27 06:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 06:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 06:44:56 --> Model "User_model" initialized
INFO - 2018-09-27 06:44:56 --> Model "Project_model" initialized
INFO - 2018-09-27 06:44:56 --> Model "Tasks_model" initialized
INFO - 2018-09-27 06:44:56 --> Model "Lists_model" initialized
INFO - 2018-09-27 06:44:56 --> Controller Class Initialized
ERROR - 2018-09-27 06:44:56 --> Severity: Notice --> Undefined property: Sample::$load D:\xampp\htdocs\code_igniter\system\libraries\Form_validation.php 147
ERROR - 2018-09-27 06:44:56 --> Severity: error --> Exception: Call to a member function helper() on null D:\xampp\htdocs\code_igniter\system\libraries\Form_validation.php 147
INFO - 2018-09-27 06:46:55 --> Config Class Initialized
INFO - 2018-09-27 06:46:55 --> Hooks Class Initialized
DEBUG - 2018-09-27 06:46:55 --> UTF-8 Support Enabled
INFO - 2018-09-27 06:46:55 --> Utf8 Class Initialized
INFO - 2018-09-27 06:46:55 --> URI Class Initialized
INFO - 2018-09-27 06:46:55 --> Router Class Initialized
INFO - 2018-09-27 06:46:55 --> Output Class Initialized
INFO - 2018-09-27 06:46:55 --> Security Class Initialized
DEBUG - 2018-09-27 06:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 06:46:55 --> Input Class Initialized
INFO - 2018-09-27 06:46:55 --> Language Class Initialized
INFO - 2018-09-27 06:46:55 --> Loader Class Initialized
INFO - 2018-09-27 06:46:55 --> Helper loaded: url_helper
INFO - 2018-09-27 06:46:55 --> Helper loaded: form_helper
INFO - 2018-09-27 06:46:55 --> Helper loaded: html_helper
INFO - 2018-09-27 06:46:55 --> Database Driver Class Initialized
INFO - 2018-09-27 06:46:55 --> Form Validation Class Initialized
DEBUG - 2018-09-27 06:46:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 06:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 06:46:55 --> Model "User_model" initialized
INFO - 2018-09-27 06:46:55 --> Model "Project_model" initialized
INFO - 2018-09-27 06:46:55 --> Model "Tasks_model" initialized
INFO - 2018-09-27 06:46:55 --> Model "Lists_model" initialized
INFO - 2018-09-27 06:46:55 --> Controller Class Initialized
INFO - 2018-09-27 06:46:55 --> Final output sent to browser
DEBUG - 2018-09-27 06:46:55 --> Total execution time: 0.0680
INFO - 2018-09-27 06:47:23 --> Config Class Initialized
INFO - 2018-09-27 06:47:23 --> Hooks Class Initialized
DEBUG - 2018-09-27 06:47:23 --> UTF-8 Support Enabled
INFO - 2018-09-27 06:47:23 --> Utf8 Class Initialized
INFO - 2018-09-27 06:47:23 --> URI Class Initialized
INFO - 2018-09-27 06:47:23 --> Router Class Initialized
INFO - 2018-09-27 06:47:23 --> Output Class Initialized
INFO - 2018-09-27 06:47:23 --> Security Class Initialized
DEBUG - 2018-09-27 06:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 06:47:23 --> Input Class Initialized
INFO - 2018-09-27 06:47:23 --> Language Class Initialized
INFO - 2018-09-27 06:47:23 --> Loader Class Initialized
INFO - 2018-09-27 06:47:23 --> Helper loaded: url_helper
INFO - 2018-09-27 06:47:23 --> Helper loaded: form_helper
INFO - 2018-09-27 06:47:23 --> Helper loaded: html_helper
INFO - 2018-09-27 06:47:23 --> Database Driver Class Initialized
INFO - 2018-09-27 06:47:23 --> Form Validation Class Initialized
DEBUG - 2018-09-27 06:47:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 06:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 06:47:23 --> Model "User_model" initialized
INFO - 2018-09-27 06:47:23 --> Model "Project_model" initialized
INFO - 2018-09-27 06:47:23 --> Model "Tasks_model" initialized
INFO - 2018-09-27 06:47:23 --> Model "Lists_model" initialized
INFO - 2018-09-27 06:47:23 --> Controller Class Initialized
ERROR - 2018-09-27 06:47:23 --> Severity: Notice --> Undefined property: Sample::$load D:\xampp\htdocs\code_igniter\system\libraries\Form_validation.php 147
ERROR - 2018-09-27 06:47:23 --> Severity: error --> Exception: Call to a member function helper() on null D:\xampp\htdocs\code_igniter\system\libraries\Form_validation.php 147
INFO - 2018-09-27 06:48:41 --> Config Class Initialized
INFO - 2018-09-27 06:48:41 --> Hooks Class Initialized
DEBUG - 2018-09-27 06:48:41 --> UTF-8 Support Enabled
INFO - 2018-09-27 06:48:41 --> Utf8 Class Initialized
INFO - 2018-09-27 06:48:41 --> URI Class Initialized
INFO - 2018-09-27 06:48:41 --> Router Class Initialized
INFO - 2018-09-27 06:48:41 --> Output Class Initialized
INFO - 2018-09-27 06:48:42 --> Security Class Initialized
DEBUG - 2018-09-27 06:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-27 06:48:42 --> Input Class Initialized
INFO - 2018-09-27 06:48:42 --> Language Class Initialized
INFO - 2018-09-27 06:48:42 --> Loader Class Initialized
INFO - 2018-09-27 06:48:42 --> Helper loaded: url_helper
INFO - 2018-09-27 06:48:42 --> Helper loaded: form_helper
INFO - 2018-09-27 06:48:42 --> Helper loaded: html_helper
INFO - 2018-09-27 06:48:42 --> Database Driver Class Initialized
INFO - 2018-09-27 06:48:42 --> Form Validation Class Initialized
DEBUG - 2018-09-27 06:48:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-27 06:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-27 06:48:42 --> Model "User_model" initialized
INFO - 2018-09-27 06:48:42 --> Model "Project_model" initialized
INFO - 2018-09-27 06:48:42 --> Model "Tasks_model" initialized
INFO - 2018-09-27 06:48:42 --> Model "Lists_model" initialized
INFO - 2018-09-27 06:48:42 --> Controller Class Initialized
ERROR - 2018-09-27 06:48:42 --> Severity: Notice --> Undefined property: Sample::$load D:\xampp\htdocs\code_igniter\system\libraries\Form_validation.php 147
ERROR - 2018-09-27 06:48:42 --> Severity: error --> Exception: Call to a member function helper() on null D:\xampp\htdocs\code_igniter\system\libraries\Form_validation.php 147
