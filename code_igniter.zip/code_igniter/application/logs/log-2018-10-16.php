<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-16 13:40:34 --> Config Class Initialized
INFO - 2018-10-16 13:40:34 --> Hooks Class Initialized
DEBUG - 2018-10-16 13:40:34 --> UTF-8 Support Enabled
INFO - 2018-10-16 13:40:34 --> Utf8 Class Initialized
INFO - 2018-10-16 13:40:34 --> URI Class Initialized
INFO - 2018-10-16 13:40:34 --> Router Class Initialized
INFO - 2018-10-16 13:40:34 --> Output Class Initialized
INFO - 2018-10-16 13:40:34 --> Security Class Initialized
DEBUG - 2018-10-16 13:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 13:40:34 --> Input Class Initialized
INFO - 2018-10-16 13:40:34 --> Language Class Initialized
INFO - 2018-10-16 13:40:34 --> Loader Class Initialized
INFO - 2018-10-16 13:40:34 --> Helper loaded: url_helper
INFO - 2018-10-16 13:40:34 --> Helper loaded: form_helper
INFO - 2018-10-16 13:40:34 --> Helper loaded: html_helper
INFO - 2018-10-16 13:40:35 --> Database Driver Class Initialized
INFO - 2018-10-16 13:40:35 --> Form Validation Class Initialized
DEBUG - 2018-10-16 13:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 13:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 13:40:35 --> Model "User_model" initialized
INFO - 2018-10-16 13:40:35 --> Model "Project_model" initialized
INFO - 2018-10-16 13:40:35 --> Model "Tasks_model" initialized
INFO - 2018-10-16 13:40:35 --> Model "Lists_model" initialized
INFO - 2018-10-16 13:40:35 --> Controller Class Initialized
INFO - 2018-10-16 13:40:35 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-16 13:40:35 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-16 13:40:35 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-16 13:40:35 --> Final output sent to browser
DEBUG - 2018-10-16 13:40:35 --> Total execution time: 0.9481
INFO - 2018-10-16 13:57:04 --> Config Class Initialized
INFO - 2018-10-16 13:57:04 --> Hooks Class Initialized
DEBUG - 2018-10-16 13:57:04 --> UTF-8 Support Enabled
INFO - 2018-10-16 13:57:04 --> Utf8 Class Initialized
INFO - 2018-10-16 13:57:04 --> URI Class Initialized
INFO - 2018-10-16 13:57:04 --> Router Class Initialized
INFO - 2018-10-16 13:57:04 --> Output Class Initialized
INFO - 2018-10-16 13:57:04 --> Security Class Initialized
DEBUG - 2018-10-16 13:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 13:57:04 --> Input Class Initialized
INFO - 2018-10-16 13:57:04 --> Language Class Initialized
INFO - 2018-10-16 13:57:04 --> Loader Class Initialized
INFO - 2018-10-16 13:57:04 --> Helper loaded: url_helper
INFO - 2018-10-16 13:57:04 --> Helper loaded: form_helper
INFO - 2018-10-16 13:57:04 --> Helper loaded: html_helper
INFO - 2018-10-16 13:57:04 --> Database Driver Class Initialized
INFO - 2018-10-16 13:57:04 --> Form Validation Class Initialized
DEBUG - 2018-10-16 13:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 13:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 13:57:04 --> Model "User_model" initialized
INFO - 2018-10-16 13:57:04 --> Model "Project_model" initialized
INFO - 2018-10-16 13:57:04 --> Model "Tasks_model" initialized
INFO - 2018-10-16 13:57:04 --> Model "Lists_model" initialized
INFO - 2018-10-16 13:57:04 --> Controller Class Initialized
INFO - 2018-10-16 13:57:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-16 13:57:04 --> Config Class Initialized
INFO - 2018-10-16 13:57:04 --> Hooks Class Initialized
DEBUG - 2018-10-16 13:57:04 --> UTF-8 Support Enabled
INFO - 2018-10-16 13:57:04 --> Utf8 Class Initialized
INFO - 2018-10-16 13:57:04 --> URI Class Initialized
INFO - 2018-10-16 13:57:04 --> Router Class Initialized
INFO - 2018-10-16 13:57:04 --> Output Class Initialized
INFO - 2018-10-16 13:57:04 --> Security Class Initialized
DEBUG - 2018-10-16 13:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 13:57:04 --> Input Class Initialized
INFO - 2018-10-16 13:57:04 --> Language Class Initialized
INFO - 2018-10-16 13:57:04 --> Loader Class Initialized
INFO - 2018-10-16 13:57:04 --> Helper loaded: url_helper
INFO - 2018-10-16 13:57:04 --> Helper loaded: form_helper
INFO - 2018-10-16 13:57:04 --> Helper loaded: html_helper
INFO - 2018-10-16 13:57:04 --> Database Driver Class Initialized
INFO - 2018-10-16 13:57:04 --> Form Validation Class Initialized
DEBUG - 2018-10-16 13:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 13:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 13:57:04 --> Model "User_model" initialized
INFO - 2018-10-16 13:57:04 --> Model "Project_model" initialized
INFO - 2018-10-16 13:57:04 --> Model "Tasks_model" initialized
INFO - 2018-10-16 13:57:04 --> Model "Lists_model" initialized
INFO - 2018-10-16 13:57:04 --> Controller Class Initialized
INFO - 2018-10-16 13:57:05 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-16 13:57:05 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-16 13:57:05 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-16 13:57:05 --> Final output sent to browser
DEBUG - 2018-10-16 13:57:05 --> Total execution time: 0.1060
INFO - 2018-10-16 14:22:37 --> Config Class Initialized
INFO - 2018-10-16 14:22:37 --> Hooks Class Initialized
DEBUG - 2018-10-16 14:22:37 --> UTF-8 Support Enabled
INFO - 2018-10-16 14:22:37 --> Utf8 Class Initialized
INFO - 2018-10-16 14:22:37 --> URI Class Initialized
INFO - 2018-10-16 14:22:37 --> Router Class Initialized
INFO - 2018-10-16 14:22:37 --> Output Class Initialized
INFO - 2018-10-16 14:22:37 --> Security Class Initialized
DEBUG - 2018-10-16 14:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 14:22:37 --> Input Class Initialized
INFO - 2018-10-16 14:22:37 --> Language Class Initialized
INFO - 2018-10-16 14:22:37 --> Loader Class Initialized
INFO - 2018-10-16 14:22:37 --> Helper loaded: url_helper
INFO - 2018-10-16 14:22:37 --> Helper loaded: form_helper
INFO - 2018-10-16 14:22:37 --> Helper loaded: html_helper
INFO - 2018-10-16 14:22:37 --> Database Driver Class Initialized
INFO - 2018-10-16 14:22:37 --> Form Validation Class Initialized
DEBUG - 2018-10-16 14:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 14:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 14:22:37 --> Model "User_model" initialized
INFO - 2018-10-16 14:22:37 --> Model "Project_model" initialized
INFO - 2018-10-16 14:22:37 --> Model "Tasks_model" initialized
INFO - 2018-10-16 14:22:37 --> Model "Lists_model" initialized
INFO - 2018-10-16 14:22:37 --> Controller Class Initialized
INFO - 2018-10-16 14:22:37 --> Config Class Initialized
INFO - 2018-10-16 14:22:37 --> Hooks Class Initialized
DEBUG - 2018-10-16 14:22:37 --> UTF-8 Support Enabled
INFO - 2018-10-16 14:22:37 --> Utf8 Class Initialized
INFO - 2018-10-16 14:22:37 --> URI Class Initialized
INFO - 2018-10-16 14:22:37 --> Router Class Initialized
INFO - 2018-10-16 14:22:37 --> Output Class Initialized
INFO - 2018-10-16 14:22:37 --> Security Class Initialized
DEBUG - 2018-10-16 14:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-16 14:22:37 --> Input Class Initialized
INFO - 2018-10-16 14:22:37 --> Language Class Initialized
INFO - 2018-10-16 14:22:37 --> Loader Class Initialized
INFO - 2018-10-16 14:22:37 --> Helper loaded: url_helper
INFO - 2018-10-16 14:22:37 --> Helper loaded: form_helper
INFO - 2018-10-16 14:22:37 --> Helper loaded: html_helper
INFO - 2018-10-16 14:22:37 --> Database Driver Class Initialized
INFO - 2018-10-16 14:22:37 --> Form Validation Class Initialized
DEBUG - 2018-10-16 14:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-16 14:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-16 14:22:37 --> Model "User_model" initialized
INFO - 2018-10-16 14:22:37 --> Model "Project_model" initialized
INFO - 2018-10-16 14:22:37 --> Model "Tasks_model" initialized
INFO - 2018-10-16 14:22:37 --> Model "Lists_model" initialized
INFO - 2018-10-16 14:22:37 --> Controller Class Initialized
INFO - 2018-10-16 14:22:37 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-16 14:22:37 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-16 14:22:37 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-16 14:22:37 --> Final output sent to browser
DEBUG - 2018-10-16 14:22:37 --> Total execution time: 0.0560
