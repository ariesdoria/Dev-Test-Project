<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-09-30 03:57:46 --> Config Class Initialized
INFO - 2018-09-30 03:57:46 --> Hooks Class Initialized
DEBUG - 2018-09-30 03:57:46 --> UTF-8 Support Enabled
INFO - 2018-09-30 03:57:46 --> Utf8 Class Initialized
INFO - 2018-09-30 03:57:46 --> URI Class Initialized
INFO - 2018-09-30 03:57:46 --> Router Class Initialized
INFO - 2018-09-30 03:57:46 --> Output Class Initialized
INFO - 2018-09-30 03:57:46 --> Security Class Initialized
DEBUG - 2018-09-30 03:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 03:57:46 --> Input Class Initialized
INFO - 2018-09-30 03:57:46 --> Language Class Initialized
INFO - 2018-09-30 03:57:46 --> Loader Class Initialized
INFO - 2018-09-30 03:57:46 --> Helper loaded: url_helper
INFO - 2018-09-30 03:57:46 --> Helper loaded: form_helper
INFO - 2018-09-30 03:57:46 --> Helper loaded: html_helper
INFO - 2018-09-30 03:57:46 --> Database Driver Class Initialized
INFO - 2018-09-30 03:57:46 --> Form Validation Class Initialized
DEBUG - 2018-09-30 03:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 03:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 03:57:46 --> Model "User_model" initialized
INFO - 2018-09-30 03:57:47 --> Model "Project_model" initialized
INFO - 2018-09-30 03:57:47 --> Model "Tasks_model" initialized
INFO - 2018-09-30 03:57:47 --> Model "Lists_model" initialized
INFO - 2018-09-30 03:57:47 --> Controller Class Initialized
INFO - 2018-09-30 03:57:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 03:57:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 03:57:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 03:57:47 --> Final output sent to browser
DEBUG - 2018-09-30 03:57:47 --> Total execution time: 0.2460
INFO - 2018-09-30 05:27:33 --> Config Class Initialized
INFO - 2018-09-30 05:27:33 --> Hooks Class Initialized
DEBUG - 2018-09-30 05:27:33 --> UTF-8 Support Enabled
INFO - 2018-09-30 05:27:33 --> Utf8 Class Initialized
INFO - 2018-09-30 05:27:33 --> URI Class Initialized
INFO - 2018-09-30 05:27:33 --> Router Class Initialized
INFO - 2018-09-30 05:27:33 --> Output Class Initialized
INFO - 2018-09-30 05:27:33 --> Security Class Initialized
DEBUG - 2018-09-30 05:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 05:27:33 --> Input Class Initialized
INFO - 2018-09-30 05:27:33 --> Language Class Initialized
INFO - 2018-09-30 05:27:33 --> Loader Class Initialized
INFO - 2018-09-30 05:27:33 --> Helper loaded: url_helper
INFO - 2018-09-30 05:27:33 --> Helper loaded: form_helper
INFO - 2018-09-30 05:27:33 --> Helper loaded: html_helper
INFO - 2018-09-30 05:27:33 --> Database Driver Class Initialized
INFO - 2018-09-30 05:27:33 --> Form Validation Class Initialized
DEBUG - 2018-09-30 05:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 05:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 05:27:33 --> Model "User_model" initialized
INFO - 2018-09-30 05:27:33 --> Model "Project_model" initialized
INFO - 2018-09-30 05:27:33 --> Model "Tasks_model" initialized
INFO - 2018-09-30 05:27:33 --> Model "Lists_model" initialized
INFO - 2018-09-30 05:27:33 --> Controller Class Initialized
INFO - 2018-09-30 05:27:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-30 05:27:34 --> Config Class Initialized
INFO - 2018-09-30 05:27:34 --> Hooks Class Initialized
DEBUG - 2018-09-30 05:27:34 --> UTF-8 Support Enabled
INFO - 2018-09-30 05:27:34 --> Utf8 Class Initialized
INFO - 2018-09-30 05:27:34 --> URI Class Initialized
INFO - 2018-09-30 05:27:34 --> Router Class Initialized
INFO - 2018-09-30 05:27:34 --> Output Class Initialized
INFO - 2018-09-30 05:27:34 --> Security Class Initialized
DEBUG - 2018-09-30 05:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 05:27:34 --> Input Class Initialized
INFO - 2018-09-30 05:27:34 --> Language Class Initialized
INFO - 2018-09-30 05:27:34 --> Loader Class Initialized
INFO - 2018-09-30 05:27:34 --> Helper loaded: url_helper
INFO - 2018-09-30 05:27:34 --> Helper loaded: form_helper
INFO - 2018-09-30 05:27:34 --> Helper loaded: html_helper
INFO - 2018-09-30 05:27:34 --> Database Driver Class Initialized
INFO - 2018-09-30 05:27:34 --> Form Validation Class Initialized
DEBUG - 2018-09-30 05:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 05:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 05:27:34 --> Model "User_model" initialized
INFO - 2018-09-30 05:27:34 --> Model "Project_model" initialized
INFO - 2018-09-30 05:27:34 --> Model "Tasks_model" initialized
INFO - 2018-09-30 05:27:34 --> Model "Lists_model" initialized
INFO - 2018-09-30 05:27:34 --> Controller Class Initialized
INFO - 2018-09-30 05:27:34 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 05:27:34 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 05:27:34 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 05:27:34 --> Final output sent to browser
DEBUG - 2018-09-30 05:27:34 --> Total execution time: 0.0460
INFO - 2018-09-30 05:27:38 --> Config Class Initialized
INFO - 2018-09-30 05:27:38 --> Hooks Class Initialized
DEBUG - 2018-09-30 05:27:38 --> UTF-8 Support Enabled
INFO - 2018-09-30 05:27:38 --> Utf8 Class Initialized
INFO - 2018-09-30 05:27:38 --> URI Class Initialized
INFO - 2018-09-30 05:27:38 --> Router Class Initialized
INFO - 2018-09-30 05:27:38 --> Output Class Initialized
INFO - 2018-09-30 05:27:38 --> Security Class Initialized
DEBUG - 2018-09-30 05:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 05:27:38 --> Input Class Initialized
INFO - 2018-09-30 05:27:38 --> Language Class Initialized
INFO - 2018-09-30 05:27:38 --> Loader Class Initialized
INFO - 2018-09-30 05:27:38 --> Helper loaded: url_helper
INFO - 2018-09-30 05:27:38 --> Helper loaded: form_helper
INFO - 2018-09-30 05:27:38 --> Helper loaded: html_helper
INFO - 2018-09-30 05:27:38 --> Database Driver Class Initialized
INFO - 2018-09-30 05:27:38 --> Form Validation Class Initialized
DEBUG - 2018-09-30 05:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 05:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 05:27:38 --> Model "User_model" initialized
INFO - 2018-09-30 05:27:38 --> Model "Project_model" initialized
INFO - 2018-09-30 05:27:38 --> Model "Tasks_model" initialized
INFO - 2018-09-30 05:27:38 --> Model "Lists_model" initialized
INFO - 2018-09-30 05:27:38 --> Controller Class Initialized
INFO - 2018-09-30 05:27:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 05:27:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/create_project.php
INFO - 2018-09-30 05:27:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 05:27:38 --> Final output sent to browser
DEBUG - 2018-09-30 05:27:38 --> Total execution time: 0.0590
INFO - 2018-09-30 05:27:50 --> Config Class Initialized
INFO - 2018-09-30 05:27:50 --> Hooks Class Initialized
DEBUG - 2018-09-30 05:27:50 --> UTF-8 Support Enabled
INFO - 2018-09-30 05:27:50 --> Utf8 Class Initialized
INFO - 2018-09-30 05:27:51 --> URI Class Initialized
INFO - 2018-09-30 05:27:51 --> Router Class Initialized
INFO - 2018-09-30 05:27:51 --> Output Class Initialized
INFO - 2018-09-30 05:27:51 --> Security Class Initialized
DEBUG - 2018-09-30 05:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 05:27:51 --> Input Class Initialized
INFO - 2018-09-30 05:27:51 --> Language Class Initialized
INFO - 2018-09-30 05:27:51 --> Loader Class Initialized
INFO - 2018-09-30 05:27:51 --> Helper loaded: url_helper
INFO - 2018-09-30 05:27:51 --> Helper loaded: form_helper
INFO - 2018-09-30 05:27:51 --> Helper loaded: html_helper
INFO - 2018-09-30 05:27:51 --> Database Driver Class Initialized
INFO - 2018-09-30 05:27:51 --> Form Validation Class Initialized
DEBUG - 2018-09-30 05:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 05:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 05:27:51 --> Model "User_model" initialized
INFO - 2018-09-30 05:27:51 --> Model "Project_model" initialized
INFO - 2018-09-30 05:27:51 --> Model "Tasks_model" initialized
INFO - 2018-09-30 05:27:51 --> Model "Lists_model" initialized
INFO - 2018-09-30 05:27:51 --> Controller Class Initialized
INFO - 2018-09-30 05:27:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-30 05:27:51 --> Config Class Initialized
INFO - 2018-09-30 05:27:51 --> Hooks Class Initialized
DEBUG - 2018-09-30 05:27:51 --> UTF-8 Support Enabled
INFO - 2018-09-30 05:27:51 --> Utf8 Class Initialized
INFO - 2018-09-30 05:27:51 --> URI Class Initialized
INFO - 2018-09-30 05:27:51 --> Router Class Initialized
INFO - 2018-09-30 05:27:51 --> Output Class Initialized
INFO - 2018-09-30 05:27:51 --> Security Class Initialized
DEBUG - 2018-09-30 05:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 05:27:51 --> Input Class Initialized
INFO - 2018-09-30 05:27:51 --> Language Class Initialized
INFO - 2018-09-30 05:27:51 --> Loader Class Initialized
INFO - 2018-09-30 05:27:51 --> Helper loaded: url_helper
INFO - 2018-09-30 05:27:51 --> Helper loaded: form_helper
INFO - 2018-09-30 05:27:51 --> Helper loaded: html_helper
INFO - 2018-09-30 05:27:51 --> Database Driver Class Initialized
INFO - 2018-09-30 05:27:51 --> Form Validation Class Initialized
DEBUG - 2018-09-30 05:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 05:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 05:27:51 --> Model "User_model" initialized
INFO - 2018-09-30 05:27:51 --> Model "Project_model" initialized
INFO - 2018-09-30 05:27:51 --> Model "Tasks_model" initialized
INFO - 2018-09-30 05:27:51 --> Model "Lists_model" initialized
INFO - 2018-09-30 05:27:51 --> Controller Class Initialized
INFO - 2018-09-30 05:27:51 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 05:27:51 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 05:27:51 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 05:27:51 --> Final output sent to browser
DEBUG - 2018-09-30 05:27:51 --> Total execution time: 0.0460
INFO - 2018-09-30 05:31:39 --> Config Class Initialized
INFO - 2018-09-30 05:31:39 --> Hooks Class Initialized
DEBUG - 2018-09-30 05:31:39 --> UTF-8 Support Enabled
INFO - 2018-09-30 05:31:39 --> Utf8 Class Initialized
INFO - 2018-09-30 05:31:39 --> URI Class Initialized
INFO - 2018-09-30 05:31:39 --> Router Class Initialized
INFO - 2018-09-30 05:31:39 --> Output Class Initialized
INFO - 2018-09-30 05:31:39 --> Security Class Initialized
DEBUG - 2018-09-30 05:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 05:31:39 --> Input Class Initialized
INFO - 2018-09-30 05:31:39 --> Language Class Initialized
INFO - 2018-09-30 05:31:39 --> Loader Class Initialized
INFO - 2018-09-30 05:31:39 --> Helper loaded: url_helper
INFO - 2018-09-30 05:31:39 --> Helper loaded: form_helper
INFO - 2018-09-30 05:31:39 --> Helper loaded: html_helper
INFO - 2018-09-30 05:31:39 --> Database Driver Class Initialized
INFO - 2018-09-30 05:31:39 --> Form Validation Class Initialized
DEBUG - 2018-09-30 05:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 05:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 05:31:39 --> Model "User_model" initialized
INFO - 2018-09-30 05:31:39 --> Model "Project_model" initialized
INFO - 2018-09-30 05:31:39 --> Model "Tasks_model" initialized
INFO - 2018-09-30 05:31:39 --> Model "Lists_model" initialized
INFO - 2018-09-30 05:31:39 --> Controller Class Initialized
INFO - 2018-09-30 05:31:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 05:31:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 05:31:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 05:31:39 --> Final output sent to browser
DEBUG - 2018-09-30 05:31:39 --> Total execution time: 0.0700
INFO - 2018-09-30 05:34:32 --> Config Class Initialized
INFO - 2018-09-30 05:34:32 --> Hooks Class Initialized
DEBUG - 2018-09-30 05:34:32 --> UTF-8 Support Enabled
INFO - 2018-09-30 05:34:32 --> Utf8 Class Initialized
INFO - 2018-09-30 05:34:32 --> URI Class Initialized
INFO - 2018-09-30 05:34:32 --> Router Class Initialized
INFO - 2018-09-30 05:34:32 --> Output Class Initialized
INFO - 2018-09-30 05:34:32 --> Security Class Initialized
DEBUG - 2018-09-30 05:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 05:34:32 --> Input Class Initialized
INFO - 2018-09-30 05:34:32 --> Language Class Initialized
INFO - 2018-09-30 05:34:32 --> Loader Class Initialized
INFO - 2018-09-30 05:34:32 --> Helper loaded: url_helper
INFO - 2018-09-30 05:34:32 --> Helper loaded: form_helper
INFO - 2018-09-30 05:34:32 --> Helper loaded: html_helper
INFO - 2018-09-30 05:34:32 --> Database Driver Class Initialized
INFO - 2018-09-30 05:34:32 --> Form Validation Class Initialized
DEBUG - 2018-09-30 05:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 05:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 05:34:32 --> Model "User_model" initialized
INFO - 2018-09-30 05:34:32 --> Model "Project_model" initialized
INFO - 2018-09-30 05:34:32 --> Model "Tasks_model" initialized
INFO - 2018-09-30 05:34:32 --> Model "Lists_model" initialized
INFO - 2018-09-30 05:34:32 --> Controller Class Initialized
INFO - 2018-09-30 05:34:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 05:34:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/create_project.php
INFO - 2018-09-30 05:34:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 05:34:32 --> Final output sent to browser
DEBUG - 2018-09-30 05:34:32 --> Total execution time: 0.0600
INFO - 2018-09-30 05:35:00 --> Config Class Initialized
INFO - 2018-09-30 05:35:00 --> Hooks Class Initialized
DEBUG - 2018-09-30 05:35:00 --> UTF-8 Support Enabled
INFO - 2018-09-30 05:35:00 --> Utf8 Class Initialized
INFO - 2018-09-30 05:35:00 --> URI Class Initialized
INFO - 2018-09-30 05:35:00 --> Router Class Initialized
INFO - 2018-09-30 05:35:00 --> Output Class Initialized
INFO - 2018-09-30 05:35:00 --> Security Class Initialized
DEBUG - 2018-09-30 05:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 05:35:00 --> Input Class Initialized
INFO - 2018-09-30 05:35:00 --> Language Class Initialized
INFO - 2018-09-30 05:35:00 --> Loader Class Initialized
INFO - 2018-09-30 05:35:00 --> Helper loaded: url_helper
INFO - 2018-09-30 05:35:00 --> Helper loaded: form_helper
INFO - 2018-09-30 05:35:00 --> Helper loaded: html_helper
INFO - 2018-09-30 05:35:00 --> Database Driver Class Initialized
INFO - 2018-09-30 05:35:00 --> Form Validation Class Initialized
DEBUG - 2018-09-30 05:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 05:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 05:35:00 --> Model "User_model" initialized
INFO - 2018-09-30 05:35:00 --> Model "Project_model" initialized
INFO - 2018-09-30 05:35:00 --> Model "Tasks_model" initialized
INFO - 2018-09-30 05:35:00 --> Model "Lists_model" initialized
INFO - 2018-09-30 05:35:00 --> Controller Class Initialized
INFO - 2018-09-30 05:35:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-30 05:35:00 --> Config Class Initialized
INFO - 2018-09-30 05:35:00 --> Hooks Class Initialized
DEBUG - 2018-09-30 05:35:00 --> UTF-8 Support Enabled
INFO - 2018-09-30 05:35:00 --> Utf8 Class Initialized
INFO - 2018-09-30 05:35:00 --> URI Class Initialized
INFO - 2018-09-30 05:35:00 --> Router Class Initialized
INFO - 2018-09-30 05:35:00 --> Output Class Initialized
INFO - 2018-09-30 05:35:00 --> Security Class Initialized
DEBUG - 2018-09-30 05:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 05:35:00 --> Input Class Initialized
INFO - 2018-09-30 05:35:00 --> Language Class Initialized
INFO - 2018-09-30 05:35:00 --> Loader Class Initialized
INFO - 2018-09-30 05:35:00 --> Helper loaded: url_helper
INFO - 2018-09-30 05:35:00 --> Helper loaded: form_helper
INFO - 2018-09-30 05:35:00 --> Helper loaded: html_helper
INFO - 2018-09-30 05:35:00 --> Database Driver Class Initialized
INFO - 2018-09-30 05:35:00 --> Form Validation Class Initialized
DEBUG - 2018-09-30 05:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 05:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 05:35:00 --> Model "User_model" initialized
INFO - 2018-09-30 05:35:00 --> Model "Project_model" initialized
INFO - 2018-09-30 05:35:00 --> Model "Tasks_model" initialized
INFO - 2018-09-30 05:35:00 --> Model "Lists_model" initialized
INFO - 2018-09-30 05:35:00 --> Controller Class Initialized
INFO - 2018-09-30 05:35:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 05:35:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 05:35:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 05:35:00 --> Final output sent to browser
DEBUG - 2018-09-30 05:35:00 --> Total execution time: 0.0450
INFO - 2018-09-30 05:42:04 --> Config Class Initialized
INFO - 2018-09-30 05:42:04 --> Hooks Class Initialized
DEBUG - 2018-09-30 05:42:04 --> UTF-8 Support Enabled
INFO - 2018-09-30 05:42:04 --> Utf8 Class Initialized
INFO - 2018-09-30 05:42:04 --> URI Class Initialized
INFO - 2018-09-30 05:42:04 --> Router Class Initialized
INFO - 2018-09-30 05:42:04 --> Output Class Initialized
INFO - 2018-09-30 05:42:04 --> Security Class Initialized
DEBUG - 2018-09-30 05:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 05:42:04 --> Input Class Initialized
INFO - 2018-09-30 05:42:04 --> Language Class Initialized
INFO - 2018-09-30 05:42:04 --> Loader Class Initialized
INFO - 2018-09-30 05:42:04 --> Helper loaded: url_helper
INFO - 2018-09-30 05:42:04 --> Helper loaded: form_helper
INFO - 2018-09-30 05:42:04 --> Helper loaded: html_helper
INFO - 2018-09-30 05:42:05 --> Database Driver Class Initialized
INFO - 2018-09-30 05:42:05 --> Form Validation Class Initialized
DEBUG - 2018-09-30 05:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 05:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 05:42:05 --> Model "User_model" initialized
INFO - 2018-09-30 05:42:05 --> Model "Project_model" initialized
INFO - 2018-09-30 05:42:05 --> Model "Tasks_model" initialized
INFO - 2018-09-30 05:42:05 --> Model "Lists_model" initialized
INFO - 2018-09-30 05:42:05 --> Controller Class Initialized
INFO - 2018-09-30 05:42:05 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 05:42:05 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 05:42:05 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 05:42:05 --> Final output sent to browser
DEBUG - 2018-09-30 05:42:05 --> Total execution time: 0.0670
INFO - 2018-09-30 05:42:08 --> Config Class Initialized
INFO - 2018-09-30 05:42:08 --> Hooks Class Initialized
DEBUG - 2018-09-30 05:42:08 --> UTF-8 Support Enabled
INFO - 2018-09-30 05:42:08 --> Utf8 Class Initialized
INFO - 2018-09-30 05:42:08 --> URI Class Initialized
INFO - 2018-09-30 05:42:08 --> Router Class Initialized
INFO - 2018-09-30 05:42:08 --> Output Class Initialized
INFO - 2018-09-30 05:42:08 --> Security Class Initialized
DEBUG - 2018-09-30 05:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 05:42:08 --> Input Class Initialized
INFO - 2018-09-30 05:42:08 --> Language Class Initialized
INFO - 2018-09-30 05:42:08 --> Loader Class Initialized
INFO - 2018-09-30 05:42:08 --> Helper loaded: url_helper
INFO - 2018-09-30 05:42:08 --> Helper loaded: form_helper
INFO - 2018-09-30 05:42:08 --> Helper loaded: html_helper
INFO - 2018-09-30 05:42:08 --> Database Driver Class Initialized
INFO - 2018-09-30 05:42:09 --> Form Validation Class Initialized
DEBUG - 2018-09-30 05:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 05:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 05:42:09 --> Model "User_model" initialized
INFO - 2018-09-30 05:42:09 --> Model "Project_model" initialized
INFO - 2018-09-30 05:42:09 --> Model "Tasks_model" initialized
INFO - 2018-09-30 05:42:09 --> Model "Lists_model" initialized
INFO - 2018-09-30 05:42:09 --> Controller Class Initialized
INFO - 2018-09-30 05:42:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 05:42:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 05:42:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 05:42:09 --> Final output sent to browser
DEBUG - 2018-09-30 05:42:09 --> Total execution time: 0.0660
INFO - 2018-09-30 05:42:10 --> Config Class Initialized
INFO - 2018-09-30 05:42:10 --> Hooks Class Initialized
DEBUG - 2018-09-30 05:42:10 --> UTF-8 Support Enabled
INFO - 2018-09-30 05:42:10 --> Utf8 Class Initialized
INFO - 2018-09-30 05:42:10 --> URI Class Initialized
INFO - 2018-09-30 05:42:10 --> Router Class Initialized
INFO - 2018-09-30 05:42:10 --> Output Class Initialized
INFO - 2018-09-30 05:42:10 --> Security Class Initialized
DEBUG - 2018-09-30 05:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 05:42:10 --> Input Class Initialized
INFO - 2018-09-30 05:42:10 --> Language Class Initialized
INFO - 2018-09-30 05:42:10 --> Loader Class Initialized
INFO - 2018-09-30 05:42:10 --> Helper loaded: url_helper
INFO - 2018-09-30 05:42:10 --> Helper loaded: form_helper
INFO - 2018-09-30 05:42:10 --> Helper loaded: html_helper
INFO - 2018-09-30 05:42:10 --> Database Driver Class Initialized
INFO - 2018-09-30 05:42:10 --> Form Validation Class Initialized
DEBUG - 2018-09-30 05:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 05:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 05:42:10 --> Model "User_model" initialized
INFO - 2018-09-30 05:42:10 --> Model "Project_model" initialized
INFO - 2018-09-30 05:42:10 --> Model "Tasks_model" initialized
INFO - 2018-09-30 05:42:10 --> Model "Lists_model" initialized
INFO - 2018-09-30 05:42:10 --> Controller Class Initialized
INFO - 2018-09-30 05:42:10 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 05:42:10 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 05:42:10 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 05:42:10 --> Final output sent to browser
DEBUG - 2018-09-30 05:42:10 --> Total execution time: 0.0550
INFO - 2018-09-30 05:42:58 --> Config Class Initialized
INFO - 2018-09-30 05:42:58 --> Hooks Class Initialized
DEBUG - 2018-09-30 05:42:58 --> UTF-8 Support Enabled
INFO - 2018-09-30 05:42:58 --> Utf8 Class Initialized
INFO - 2018-09-30 05:42:58 --> URI Class Initialized
INFO - 2018-09-30 05:42:58 --> Router Class Initialized
INFO - 2018-09-30 05:42:58 --> Output Class Initialized
INFO - 2018-09-30 05:42:58 --> Security Class Initialized
DEBUG - 2018-09-30 05:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 05:42:58 --> Input Class Initialized
INFO - 2018-09-30 05:42:58 --> Language Class Initialized
INFO - 2018-09-30 05:42:58 --> Loader Class Initialized
INFO - 2018-09-30 05:42:58 --> Helper loaded: url_helper
INFO - 2018-09-30 05:42:58 --> Helper loaded: form_helper
INFO - 2018-09-30 05:42:58 --> Helper loaded: html_helper
INFO - 2018-09-30 05:42:58 --> Database Driver Class Initialized
INFO - 2018-09-30 05:42:58 --> Form Validation Class Initialized
DEBUG - 2018-09-30 05:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 05:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 05:42:58 --> Model "User_model" initialized
INFO - 2018-09-30 05:42:58 --> Model "Project_model" initialized
INFO - 2018-09-30 05:42:58 --> Model "Tasks_model" initialized
INFO - 2018-09-30 05:42:58 --> Model "Lists_model" initialized
INFO - 2018-09-30 05:42:58 --> Controller Class Initialized
INFO - 2018-09-30 05:42:59 --> Config Class Initialized
INFO - 2018-09-30 05:42:59 --> Hooks Class Initialized
DEBUG - 2018-09-30 05:42:59 --> UTF-8 Support Enabled
INFO - 2018-09-30 05:42:59 --> Utf8 Class Initialized
INFO - 2018-09-30 05:42:59 --> URI Class Initialized
INFO - 2018-09-30 05:42:59 --> Router Class Initialized
INFO - 2018-09-30 05:42:59 --> Output Class Initialized
INFO - 2018-09-30 05:42:59 --> Security Class Initialized
DEBUG - 2018-09-30 05:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 05:42:59 --> Input Class Initialized
INFO - 2018-09-30 05:42:59 --> Language Class Initialized
INFO - 2018-09-30 05:42:59 --> Loader Class Initialized
INFO - 2018-09-30 05:42:59 --> Helper loaded: url_helper
INFO - 2018-09-30 05:42:59 --> Helper loaded: form_helper
INFO - 2018-09-30 05:42:59 --> Helper loaded: html_helper
INFO - 2018-09-30 05:42:59 --> Database Driver Class Initialized
INFO - 2018-09-30 05:42:59 --> Form Validation Class Initialized
DEBUG - 2018-09-30 05:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 05:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 05:42:59 --> Model "User_model" initialized
INFO - 2018-09-30 05:42:59 --> Model "Project_model" initialized
INFO - 2018-09-30 05:42:59 --> Model "Tasks_model" initialized
INFO - 2018-09-30 05:42:59 --> Model "Lists_model" initialized
INFO - 2018-09-30 05:42:59 --> Controller Class Initialized
INFO - 2018-09-30 05:42:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 05:42:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 05:42:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 05:42:59 --> Final output sent to browser
DEBUG - 2018-09-30 05:42:59 --> Total execution time: 0.0600
INFO - 2018-09-30 05:43:04 --> Config Class Initialized
INFO - 2018-09-30 05:43:04 --> Hooks Class Initialized
DEBUG - 2018-09-30 05:43:04 --> UTF-8 Support Enabled
INFO - 2018-09-30 05:43:04 --> Utf8 Class Initialized
INFO - 2018-09-30 05:43:04 --> URI Class Initialized
INFO - 2018-09-30 05:43:04 --> Router Class Initialized
INFO - 2018-09-30 05:43:04 --> Output Class Initialized
INFO - 2018-09-30 05:43:04 --> Security Class Initialized
DEBUG - 2018-09-30 05:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 05:43:04 --> Input Class Initialized
INFO - 2018-09-30 05:43:04 --> Language Class Initialized
INFO - 2018-09-30 05:43:04 --> Loader Class Initialized
INFO - 2018-09-30 05:43:04 --> Helper loaded: url_helper
INFO - 2018-09-30 05:43:04 --> Helper loaded: form_helper
INFO - 2018-09-30 05:43:04 --> Helper loaded: html_helper
INFO - 2018-09-30 05:43:04 --> Database Driver Class Initialized
INFO - 2018-09-30 05:43:04 --> Form Validation Class Initialized
DEBUG - 2018-09-30 05:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 05:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 05:43:04 --> Model "User_model" initialized
INFO - 2018-09-30 05:43:04 --> Model "Project_model" initialized
INFO - 2018-09-30 05:43:04 --> Model "Tasks_model" initialized
INFO - 2018-09-30 05:43:04 --> Model "Lists_model" initialized
INFO - 2018-09-30 05:43:04 --> Controller Class Initialized
INFO - 2018-09-30 05:43:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-30 05:43:04 --> Config Class Initialized
INFO - 2018-09-30 05:43:04 --> Hooks Class Initialized
DEBUG - 2018-09-30 05:43:04 --> UTF-8 Support Enabled
INFO - 2018-09-30 05:43:04 --> Utf8 Class Initialized
INFO - 2018-09-30 05:43:04 --> URI Class Initialized
INFO - 2018-09-30 05:43:04 --> Router Class Initialized
INFO - 2018-09-30 05:43:04 --> Output Class Initialized
INFO - 2018-09-30 05:43:04 --> Security Class Initialized
DEBUG - 2018-09-30 05:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 05:43:04 --> Input Class Initialized
INFO - 2018-09-30 05:43:04 --> Language Class Initialized
INFO - 2018-09-30 05:43:04 --> Loader Class Initialized
INFO - 2018-09-30 05:43:04 --> Helper loaded: url_helper
INFO - 2018-09-30 05:43:04 --> Helper loaded: form_helper
INFO - 2018-09-30 05:43:04 --> Helper loaded: html_helper
INFO - 2018-09-30 05:43:04 --> Database Driver Class Initialized
INFO - 2018-09-30 05:43:04 --> Form Validation Class Initialized
DEBUG - 2018-09-30 05:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 05:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 05:43:04 --> Model "User_model" initialized
INFO - 2018-09-30 05:43:04 --> Model "Project_model" initialized
INFO - 2018-09-30 05:43:04 --> Model "Tasks_model" initialized
INFO - 2018-09-30 05:43:04 --> Model "Lists_model" initialized
INFO - 2018-09-30 05:43:04 --> Controller Class Initialized
INFO - 2018-09-30 05:43:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 05:43:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 05:43:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 05:43:04 --> Final output sent to browser
DEBUG - 2018-09-30 05:43:04 --> Total execution time: 0.0380
INFO - 2018-09-30 05:45:35 --> Config Class Initialized
INFO - 2018-09-30 05:45:35 --> Hooks Class Initialized
DEBUG - 2018-09-30 05:45:35 --> UTF-8 Support Enabled
INFO - 2018-09-30 05:45:35 --> Utf8 Class Initialized
INFO - 2018-09-30 05:45:35 --> URI Class Initialized
INFO - 2018-09-30 05:45:35 --> Router Class Initialized
INFO - 2018-09-30 05:45:35 --> Output Class Initialized
INFO - 2018-09-30 05:45:35 --> Security Class Initialized
DEBUG - 2018-09-30 05:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 05:45:35 --> Input Class Initialized
INFO - 2018-09-30 05:45:35 --> Language Class Initialized
INFO - 2018-09-30 05:45:35 --> Loader Class Initialized
INFO - 2018-09-30 05:45:35 --> Helper loaded: url_helper
INFO - 2018-09-30 05:45:35 --> Helper loaded: form_helper
INFO - 2018-09-30 05:45:35 --> Helper loaded: html_helper
INFO - 2018-09-30 05:45:35 --> Database Driver Class Initialized
INFO - 2018-09-30 05:45:35 --> Form Validation Class Initialized
DEBUG - 2018-09-30 05:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 05:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 05:45:35 --> Model "User_model" initialized
INFO - 2018-09-30 05:45:35 --> Model "Project_model" initialized
INFO - 2018-09-30 05:45:35 --> Model "Tasks_model" initialized
INFO - 2018-09-30 05:45:35 --> Model "Lists_model" initialized
INFO - 2018-09-30 05:45:35 --> Controller Class Initialized
INFO - 2018-09-30 05:45:35 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 05:45:35 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 05:45:35 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 05:45:35 --> Final output sent to browser
DEBUG - 2018-09-30 05:45:35 --> Total execution time: 0.0600
INFO - 2018-09-30 05:47:12 --> Config Class Initialized
INFO - 2018-09-30 05:47:12 --> Hooks Class Initialized
DEBUG - 2018-09-30 05:47:12 --> UTF-8 Support Enabled
INFO - 2018-09-30 05:47:12 --> Utf8 Class Initialized
INFO - 2018-09-30 05:47:12 --> URI Class Initialized
INFO - 2018-09-30 05:47:12 --> Router Class Initialized
INFO - 2018-09-30 05:47:12 --> Output Class Initialized
INFO - 2018-09-30 05:47:12 --> Security Class Initialized
DEBUG - 2018-09-30 05:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 05:47:12 --> Input Class Initialized
INFO - 2018-09-30 05:47:12 --> Language Class Initialized
INFO - 2018-09-30 05:47:12 --> Loader Class Initialized
INFO - 2018-09-30 05:47:12 --> Helper loaded: url_helper
INFO - 2018-09-30 05:47:12 --> Helper loaded: form_helper
INFO - 2018-09-30 05:47:12 --> Helper loaded: html_helper
INFO - 2018-09-30 05:47:12 --> Database Driver Class Initialized
INFO - 2018-09-30 05:47:12 --> Form Validation Class Initialized
DEBUG - 2018-09-30 05:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 05:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 05:47:12 --> Model "User_model" initialized
INFO - 2018-09-30 05:47:12 --> Model "Project_model" initialized
INFO - 2018-09-30 05:47:12 --> Model "Tasks_model" initialized
INFO - 2018-09-30 05:47:12 --> Model "Lists_model" initialized
INFO - 2018-09-30 05:47:12 --> Controller Class Initialized
INFO - 2018-09-30 05:47:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 05:47:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 05:47:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 05:47:12 --> Final output sent to browser
DEBUG - 2018-09-30 05:47:12 --> Total execution time: 0.0520
INFO - 2018-09-30 05:47:14 --> Config Class Initialized
INFO - 2018-09-30 05:47:14 --> Hooks Class Initialized
DEBUG - 2018-09-30 05:47:14 --> UTF-8 Support Enabled
INFO - 2018-09-30 05:47:14 --> Utf8 Class Initialized
INFO - 2018-09-30 05:47:14 --> URI Class Initialized
INFO - 2018-09-30 05:47:14 --> Router Class Initialized
INFO - 2018-09-30 05:47:14 --> Output Class Initialized
INFO - 2018-09-30 05:47:14 --> Security Class Initialized
DEBUG - 2018-09-30 05:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 05:47:14 --> Input Class Initialized
INFO - 2018-09-30 05:47:14 --> Language Class Initialized
INFO - 2018-09-30 05:47:14 --> Loader Class Initialized
INFO - 2018-09-30 05:47:14 --> Helper loaded: url_helper
INFO - 2018-09-30 05:47:14 --> Helper loaded: form_helper
INFO - 2018-09-30 05:47:14 --> Helper loaded: html_helper
INFO - 2018-09-30 05:47:14 --> Database Driver Class Initialized
INFO - 2018-09-30 05:47:14 --> Form Validation Class Initialized
DEBUG - 2018-09-30 05:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 05:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 05:47:14 --> Model "User_model" initialized
INFO - 2018-09-30 05:47:14 --> Model "Project_model" initialized
INFO - 2018-09-30 05:47:14 --> Model "Tasks_model" initialized
INFO - 2018-09-30 05:47:14 --> Model "Lists_model" initialized
INFO - 2018-09-30 05:47:14 --> Controller Class Initialized
INFO - 2018-09-30 05:47:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 05:47:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 05:47:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 05:47:14 --> Final output sent to browser
DEBUG - 2018-09-30 05:47:14 --> Total execution time: 0.0670
INFO - 2018-09-30 05:47:29 --> Config Class Initialized
INFO - 2018-09-30 05:47:29 --> Hooks Class Initialized
DEBUG - 2018-09-30 05:47:29 --> UTF-8 Support Enabled
INFO - 2018-09-30 05:47:29 --> Utf8 Class Initialized
INFO - 2018-09-30 05:47:29 --> URI Class Initialized
INFO - 2018-09-30 05:47:29 --> Router Class Initialized
INFO - 2018-09-30 05:47:29 --> Output Class Initialized
INFO - 2018-09-30 05:47:29 --> Security Class Initialized
DEBUG - 2018-09-30 05:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 05:47:29 --> Input Class Initialized
INFO - 2018-09-30 05:47:29 --> Language Class Initialized
INFO - 2018-09-30 05:47:29 --> Loader Class Initialized
INFO - 2018-09-30 05:47:29 --> Helper loaded: url_helper
INFO - 2018-09-30 05:47:29 --> Helper loaded: form_helper
INFO - 2018-09-30 05:47:29 --> Helper loaded: html_helper
INFO - 2018-09-30 05:47:29 --> Database Driver Class Initialized
INFO - 2018-09-30 05:47:29 --> Form Validation Class Initialized
DEBUG - 2018-09-30 05:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 05:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 05:47:29 --> Model "User_model" initialized
INFO - 2018-09-30 05:47:29 --> Model "Project_model" initialized
INFO - 2018-09-30 05:47:29 --> Model "Tasks_model" initialized
INFO - 2018-09-30 05:47:29 --> Model "Lists_model" initialized
INFO - 2018-09-30 05:47:29 --> Controller Class Initialized
INFO - 2018-09-30 05:47:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 05:47:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 05:47:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 05:47:29 --> Final output sent to browser
DEBUG - 2018-09-30 05:47:29 --> Total execution time: 0.0480
INFO - 2018-09-30 05:47:31 --> Config Class Initialized
INFO - 2018-09-30 05:47:31 --> Hooks Class Initialized
DEBUG - 2018-09-30 05:47:31 --> UTF-8 Support Enabled
INFO - 2018-09-30 05:47:31 --> Utf8 Class Initialized
INFO - 2018-09-30 05:47:31 --> URI Class Initialized
INFO - 2018-09-30 05:47:31 --> Router Class Initialized
INFO - 2018-09-30 05:47:31 --> Output Class Initialized
INFO - 2018-09-30 05:47:31 --> Security Class Initialized
DEBUG - 2018-09-30 05:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 05:47:31 --> Input Class Initialized
INFO - 2018-09-30 05:47:31 --> Language Class Initialized
INFO - 2018-09-30 05:47:31 --> Loader Class Initialized
INFO - 2018-09-30 05:47:31 --> Helper loaded: url_helper
INFO - 2018-09-30 05:47:31 --> Helper loaded: form_helper
INFO - 2018-09-30 05:47:31 --> Helper loaded: html_helper
INFO - 2018-09-30 05:47:31 --> Database Driver Class Initialized
INFO - 2018-09-30 05:47:31 --> Form Validation Class Initialized
DEBUG - 2018-09-30 05:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 05:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 05:47:31 --> Model "User_model" initialized
INFO - 2018-09-30 05:47:31 --> Model "Project_model" initialized
INFO - 2018-09-30 05:47:31 --> Model "Tasks_model" initialized
INFO - 2018-09-30 05:47:31 --> Model "Lists_model" initialized
INFO - 2018-09-30 05:47:31 --> Controller Class Initialized
INFO - 2018-09-30 05:47:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 05:47:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 05:47:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 05:47:31 --> Final output sent to browser
DEBUG - 2018-09-30 05:47:31 --> Total execution time: 0.0540
INFO - 2018-09-30 05:47:31 --> Config Class Initialized
INFO - 2018-09-30 05:47:31 --> Hooks Class Initialized
DEBUG - 2018-09-30 05:47:31 --> UTF-8 Support Enabled
INFO - 2018-09-30 05:47:31 --> Utf8 Class Initialized
INFO - 2018-09-30 05:47:31 --> URI Class Initialized
INFO - 2018-09-30 05:47:31 --> Router Class Initialized
INFO - 2018-09-30 05:47:31 --> Output Class Initialized
INFO - 2018-09-30 05:47:31 --> Security Class Initialized
DEBUG - 2018-09-30 05:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 05:47:31 --> Input Class Initialized
INFO - 2018-09-30 05:47:31 --> Language Class Initialized
INFO - 2018-09-30 05:47:31 --> Loader Class Initialized
INFO - 2018-09-30 05:47:31 --> Helper loaded: url_helper
INFO - 2018-09-30 05:47:31 --> Helper loaded: form_helper
INFO - 2018-09-30 05:47:31 --> Helper loaded: html_helper
INFO - 2018-09-30 05:47:31 --> Database Driver Class Initialized
INFO - 2018-09-30 05:47:32 --> Form Validation Class Initialized
DEBUG - 2018-09-30 05:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 05:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 05:47:32 --> Model "User_model" initialized
INFO - 2018-09-30 05:47:32 --> Model "Project_model" initialized
INFO - 2018-09-30 05:47:32 --> Model "Tasks_model" initialized
INFO - 2018-09-30 05:47:32 --> Model "Lists_model" initialized
INFO - 2018-09-30 05:47:32 --> Controller Class Initialized
INFO - 2018-09-30 05:47:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 05:47:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 05:47:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 05:47:32 --> Final output sent to browser
DEBUG - 2018-09-30 05:47:32 --> Total execution time: 0.0580
INFO - 2018-09-30 05:47:32 --> Config Class Initialized
INFO - 2018-09-30 05:47:32 --> Hooks Class Initialized
DEBUG - 2018-09-30 05:47:32 --> UTF-8 Support Enabled
INFO - 2018-09-30 05:47:32 --> Utf8 Class Initialized
INFO - 2018-09-30 05:47:32 --> URI Class Initialized
INFO - 2018-09-30 05:47:32 --> Router Class Initialized
INFO - 2018-09-30 05:47:32 --> Output Class Initialized
INFO - 2018-09-30 05:47:32 --> Security Class Initialized
DEBUG - 2018-09-30 05:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 05:47:32 --> Input Class Initialized
INFO - 2018-09-30 05:47:32 --> Language Class Initialized
INFO - 2018-09-30 05:47:32 --> Loader Class Initialized
INFO - 2018-09-30 05:47:32 --> Helper loaded: url_helper
INFO - 2018-09-30 05:47:32 --> Helper loaded: form_helper
INFO - 2018-09-30 05:47:32 --> Helper loaded: html_helper
INFO - 2018-09-30 05:47:32 --> Database Driver Class Initialized
INFO - 2018-09-30 05:47:32 --> Form Validation Class Initialized
DEBUG - 2018-09-30 05:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 05:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 05:47:32 --> Model "User_model" initialized
INFO - 2018-09-30 05:47:32 --> Model "Project_model" initialized
INFO - 2018-09-30 05:47:32 --> Model "Tasks_model" initialized
INFO - 2018-09-30 05:47:32 --> Model "Lists_model" initialized
INFO - 2018-09-30 05:47:32 --> Controller Class Initialized
INFO - 2018-09-30 05:47:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 05:47:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 05:47:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 05:47:32 --> Final output sent to browser
DEBUG - 2018-09-30 05:47:32 --> Total execution time: 0.0410
INFO - 2018-09-30 05:47:32 --> Config Class Initialized
INFO - 2018-09-30 05:47:32 --> Hooks Class Initialized
DEBUG - 2018-09-30 05:47:32 --> UTF-8 Support Enabled
INFO - 2018-09-30 05:47:32 --> Utf8 Class Initialized
INFO - 2018-09-30 05:47:32 --> URI Class Initialized
INFO - 2018-09-30 05:47:32 --> Router Class Initialized
INFO - 2018-09-30 05:47:32 --> Output Class Initialized
INFO - 2018-09-30 05:47:32 --> Security Class Initialized
DEBUG - 2018-09-30 05:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 05:47:32 --> Input Class Initialized
INFO - 2018-09-30 05:47:32 --> Language Class Initialized
INFO - 2018-09-30 05:47:32 --> Loader Class Initialized
INFO - 2018-09-30 05:47:32 --> Helper loaded: url_helper
INFO - 2018-09-30 05:47:32 --> Helper loaded: form_helper
INFO - 2018-09-30 05:47:32 --> Helper loaded: html_helper
INFO - 2018-09-30 05:47:32 --> Database Driver Class Initialized
INFO - 2018-09-30 05:47:32 --> Form Validation Class Initialized
DEBUG - 2018-09-30 05:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 05:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 05:47:32 --> Model "User_model" initialized
INFO - 2018-09-30 05:47:32 --> Model "Project_model" initialized
INFO - 2018-09-30 05:47:32 --> Model "Tasks_model" initialized
INFO - 2018-09-30 05:47:32 --> Model "Lists_model" initialized
INFO - 2018-09-30 05:47:32 --> Controller Class Initialized
INFO - 2018-09-30 05:47:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 05:47:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 05:47:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 05:47:32 --> Final output sent to browser
DEBUG - 2018-09-30 05:47:32 --> Total execution time: 0.0390
INFO - 2018-09-30 08:58:55 --> Config Class Initialized
INFO - 2018-09-30 08:58:55 --> Hooks Class Initialized
DEBUG - 2018-09-30 08:58:55 --> UTF-8 Support Enabled
INFO - 2018-09-30 08:58:55 --> Utf8 Class Initialized
INFO - 2018-09-30 08:58:55 --> URI Class Initialized
INFO - 2018-09-30 08:58:55 --> Router Class Initialized
INFO - 2018-09-30 08:58:55 --> Output Class Initialized
INFO - 2018-09-30 08:58:55 --> Security Class Initialized
DEBUG - 2018-09-30 08:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 08:58:55 --> Input Class Initialized
INFO - 2018-09-30 08:58:55 --> Language Class Initialized
INFO - 2018-09-30 08:58:55 --> Loader Class Initialized
INFO - 2018-09-30 08:58:55 --> Helper loaded: url_helper
INFO - 2018-09-30 08:58:55 --> Helper loaded: form_helper
INFO - 2018-09-30 08:58:55 --> Helper loaded: html_helper
INFO - 2018-09-30 08:58:55 --> Database Driver Class Initialized
INFO - 2018-09-30 08:58:55 --> Form Validation Class Initialized
DEBUG - 2018-09-30 08:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 08:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 08:58:55 --> Model "User_model" initialized
INFO - 2018-09-30 08:58:55 --> Model "Project_model" initialized
INFO - 2018-09-30 08:58:55 --> Model "Tasks_model" initialized
INFO - 2018-09-30 08:58:55 --> Model "Lists_model" initialized
INFO - 2018-09-30 08:58:55 --> Controller Class Initialized
INFO - 2018-09-30 08:58:55 --> Config Class Initialized
INFO - 2018-09-30 08:58:55 --> Hooks Class Initialized
DEBUG - 2018-09-30 08:58:55 --> UTF-8 Support Enabled
INFO - 2018-09-30 08:58:55 --> Utf8 Class Initialized
INFO - 2018-09-30 08:58:55 --> URI Class Initialized
INFO - 2018-09-30 08:58:55 --> Router Class Initialized
INFO - 2018-09-30 08:58:55 --> Output Class Initialized
INFO - 2018-09-30 08:58:55 --> Security Class Initialized
DEBUG - 2018-09-30 08:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 08:58:55 --> Input Class Initialized
INFO - 2018-09-30 08:58:55 --> Language Class Initialized
INFO - 2018-09-30 08:58:55 --> Loader Class Initialized
INFO - 2018-09-30 08:58:55 --> Helper loaded: url_helper
INFO - 2018-09-30 08:58:55 --> Helper loaded: form_helper
INFO - 2018-09-30 08:58:55 --> Helper loaded: html_helper
INFO - 2018-09-30 08:58:55 --> Database Driver Class Initialized
INFO - 2018-09-30 08:58:55 --> Form Validation Class Initialized
DEBUG - 2018-09-30 08:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 08:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 08:58:55 --> Model "User_model" initialized
INFO - 2018-09-30 08:58:55 --> Model "Project_model" initialized
INFO - 2018-09-30 08:58:55 --> Model "Tasks_model" initialized
INFO - 2018-09-30 08:58:55 --> Model "Lists_model" initialized
INFO - 2018-09-30 08:58:55 --> Controller Class Initialized
INFO - 2018-09-30 08:58:55 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 08:58:55 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 08:58:55 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 08:58:55 --> Final output sent to browser
DEBUG - 2018-09-30 08:58:55 --> Total execution time: 0.0650
INFO - 2018-09-30 08:59:00 --> Config Class Initialized
INFO - 2018-09-30 08:59:00 --> Hooks Class Initialized
DEBUG - 2018-09-30 08:59:00 --> UTF-8 Support Enabled
INFO - 2018-09-30 08:59:00 --> Utf8 Class Initialized
INFO - 2018-09-30 08:59:00 --> URI Class Initialized
INFO - 2018-09-30 08:59:00 --> Router Class Initialized
INFO - 2018-09-30 08:59:00 --> Output Class Initialized
INFO - 2018-09-30 08:59:00 --> Security Class Initialized
DEBUG - 2018-09-30 08:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 08:59:00 --> Input Class Initialized
INFO - 2018-09-30 08:59:00 --> Language Class Initialized
INFO - 2018-09-30 08:59:00 --> Loader Class Initialized
INFO - 2018-09-30 08:59:00 --> Helper loaded: url_helper
INFO - 2018-09-30 08:59:00 --> Helper loaded: form_helper
INFO - 2018-09-30 08:59:00 --> Helper loaded: html_helper
INFO - 2018-09-30 08:59:00 --> Database Driver Class Initialized
INFO - 2018-09-30 08:59:00 --> Form Validation Class Initialized
DEBUG - 2018-09-30 08:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 08:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 08:59:00 --> Model "User_model" initialized
INFO - 2018-09-30 08:59:00 --> Model "Project_model" initialized
INFO - 2018-09-30 08:59:00 --> Model "Tasks_model" initialized
INFO - 2018-09-30 08:59:00 --> Model "Lists_model" initialized
INFO - 2018-09-30 08:59:00 --> Controller Class Initialized
INFO - 2018-09-30 08:59:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-30 08:59:00 --> Config Class Initialized
INFO - 2018-09-30 08:59:00 --> Hooks Class Initialized
DEBUG - 2018-09-30 08:59:00 --> UTF-8 Support Enabled
INFO - 2018-09-30 08:59:00 --> Utf8 Class Initialized
INFO - 2018-09-30 08:59:00 --> URI Class Initialized
INFO - 2018-09-30 08:59:00 --> Router Class Initialized
INFO - 2018-09-30 08:59:00 --> Output Class Initialized
INFO - 2018-09-30 08:59:00 --> Security Class Initialized
DEBUG - 2018-09-30 08:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 08:59:00 --> Input Class Initialized
INFO - 2018-09-30 08:59:00 --> Language Class Initialized
INFO - 2018-09-30 08:59:00 --> Loader Class Initialized
INFO - 2018-09-30 08:59:00 --> Helper loaded: url_helper
INFO - 2018-09-30 08:59:00 --> Helper loaded: form_helper
INFO - 2018-09-30 08:59:00 --> Helper loaded: html_helper
INFO - 2018-09-30 08:59:00 --> Database Driver Class Initialized
INFO - 2018-09-30 08:59:00 --> Form Validation Class Initialized
DEBUG - 2018-09-30 08:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 08:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 08:59:00 --> Model "User_model" initialized
INFO - 2018-09-30 08:59:00 --> Model "Project_model" initialized
INFO - 2018-09-30 08:59:00 --> Model "Tasks_model" initialized
INFO - 2018-09-30 08:59:00 --> Model "Lists_model" initialized
INFO - 2018-09-30 08:59:00 --> Controller Class Initialized
INFO - 2018-09-30 08:59:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 08:59:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 08:59:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 08:59:00 --> Final output sent to browser
DEBUG - 2018-09-30 08:59:00 --> Total execution time: 0.0410
INFO - 2018-09-30 08:59:04 --> Config Class Initialized
INFO - 2018-09-30 08:59:04 --> Hooks Class Initialized
DEBUG - 2018-09-30 08:59:04 --> UTF-8 Support Enabled
INFO - 2018-09-30 08:59:04 --> Utf8 Class Initialized
INFO - 2018-09-30 08:59:04 --> URI Class Initialized
INFO - 2018-09-30 08:59:04 --> Router Class Initialized
INFO - 2018-09-30 08:59:04 --> Output Class Initialized
INFO - 2018-09-30 08:59:04 --> Security Class Initialized
DEBUG - 2018-09-30 08:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 08:59:04 --> Input Class Initialized
INFO - 2018-09-30 08:59:04 --> Language Class Initialized
INFO - 2018-09-30 08:59:04 --> Loader Class Initialized
INFO - 2018-09-30 08:59:04 --> Helper loaded: url_helper
INFO - 2018-09-30 08:59:04 --> Helper loaded: form_helper
INFO - 2018-09-30 08:59:04 --> Helper loaded: html_helper
INFO - 2018-09-30 08:59:04 --> Database Driver Class Initialized
INFO - 2018-09-30 08:59:04 --> Form Validation Class Initialized
DEBUG - 2018-09-30 08:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 08:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 08:59:04 --> Model "User_model" initialized
INFO - 2018-09-30 08:59:04 --> Model "Project_model" initialized
INFO - 2018-09-30 08:59:04 --> Model "Tasks_model" initialized
INFO - 2018-09-30 08:59:04 --> Model "Lists_model" initialized
INFO - 2018-09-30 08:59:04 --> Controller Class Initialized
INFO - 2018-09-30 08:59:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 08:59:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 08:59:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 08:59:04 --> Final output sent to browser
DEBUG - 2018-09-30 08:59:04 --> Total execution time: 0.0550
INFO - 2018-09-30 08:59:06 --> Config Class Initialized
INFO - 2018-09-30 08:59:06 --> Hooks Class Initialized
DEBUG - 2018-09-30 08:59:06 --> UTF-8 Support Enabled
INFO - 2018-09-30 08:59:06 --> Utf8 Class Initialized
INFO - 2018-09-30 08:59:06 --> URI Class Initialized
INFO - 2018-09-30 08:59:06 --> Router Class Initialized
INFO - 2018-09-30 08:59:06 --> Output Class Initialized
INFO - 2018-09-30 08:59:06 --> Security Class Initialized
DEBUG - 2018-09-30 08:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 08:59:06 --> Input Class Initialized
INFO - 2018-09-30 08:59:06 --> Language Class Initialized
INFO - 2018-09-30 08:59:06 --> Loader Class Initialized
INFO - 2018-09-30 08:59:06 --> Helper loaded: url_helper
INFO - 2018-09-30 08:59:06 --> Helper loaded: form_helper
INFO - 2018-09-30 08:59:06 --> Helper loaded: html_helper
INFO - 2018-09-30 08:59:06 --> Database Driver Class Initialized
INFO - 2018-09-30 08:59:06 --> Form Validation Class Initialized
DEBUG - 2018-09-30 08:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 08:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 08:59:06 --> Model "User_model" initialized
INFO - 2018-09-30 08:59:06 --> Model "Project_model" initialized
INFO - 2018-09-30 08:59:06 --> Model "Tasks_model" initialized
INFO - 2018-09-30 08:59:06 --> Model "Lists_model" initialized
INFO - 2018-09-30 08:59:06 --> Controller Class Initialized
INFO - 2018-09-30 08:59:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 08:59:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/edit_project.php
INFO - 2018-09-30 08:59:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 08:59:06 --> Final output sent to browser
DEBUG - 2018-09-30 08:59:06 --> Total execution time: 0.1030
INFO - 2018-09-30 08:59:11 --> Config Class Initialized
INFO - 2018-09-30 08:59:11 --> Hooks Class Initialized
DEBUG - 2018-09-30 08:59:11 --> UTF-8 Support Enabled
INFO - 2018-09-30 08:59:11 --> Utf8 Class Initialized
INFO - 2018-09-30 08:59:11 --> URI Class Initialized
INFO - 2018-09-30 08:59:11 --> Router Class Initialized
INFO - 2018-09-30 08:59:11 --> Output Class Initialized
INFO - 2018-09-30 08:59:11 --> Security Class Initialized
DEBUG - 2018-09-30 08:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 08:59:11 --> Input Class Initialized
INFO - 2018-09-30 08:59:11 --> Language Class Initialized
INFO - 2018-09-30 08:59:11 --> Loader Class Initialized
INFO - 2018-09-30 08:59:11 --> Helper loaded: url_helper
INFO - 2018-09-30 08:59:11 --> Helper loaded: form_helper
INFO - 2018-09-30 08:59:11 --> Helper loaded: html_helper
INFO - 2018-09-30 08:59:11 --> Database Driver Class Initialized
INFO - 2018-09-30 08:59:11 --> Form Validation Class Initialized
DEBUG - 2018-09-30 08:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 08:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 08:59:11 --> Model "User_model" initialized
INFO - 2018-09-30 08:59:11 --> Model "Project_model" initialized
INFO - 2018-09-30 08:59:11 --> Model "Tasks_model" initialized
INFO - 2018-09-30 08:59:11 --> Model "Lists_model" initialized
INFO - 2018-09-30 08:59:11 --> Controller Class Initialized
INFO - 2018-09-30 08:59:11 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 08:59:11 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 08:59:11 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 08:59:11 --> Final output sent to browser
DEBUG - 2018-09-30 08:59:11 --> Total execution time: 0.0700
INFO - 2018-09-30 08:59:12 --> Config Class Initialized
INFO - 2018-09-30 08:59:12 --> Hooks Class Initialized
DEBUG - 2018-09-30 08:59:12 --> UTF-8 Support Enabled
INFO - 2018-09-30 08:59:12 --> Utf8 Class Initialized
INFO - 2018-09-30 08:59:12 --> URI Class Initialized
INFO - 2018-09-30 08:59:12 --> Router Class Initialized
INFO - 2018-09-30 08:59:12 --> Output Class Initialized
INFO - 2018-09-30 08:59:12 --> Security Class Initialized
DEBUG - 2018-09-30 08:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 08:59:12 --> Input Class Initialized
INFO - 2018-09-30 08:59:12 --> Language Class Initialized
INFO - 2018-09-30 08:59:12 --> Loader Class Initialized
INFO - 2018-09-30 08:59:12 --> Helper loaded: url_helper
INFO - 2018-09-30 08:59:12 --> Helper loaded: form_helper
INFO - 2018-09-30 08:59:12 --> Helper loaded: html_helper
INFO - 2018-09-30 08:59:12 --> Database Driver Class Initialized
INFO - 2018-09-30 08:59:12 --> Form Validation Class Initialized
DEBUG - 2018-09-30 08:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 08:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 08:59:12 --> Model "User_model" initialized
INFO - 2018-09-30 08:59:12 --> Model "Project_model" initialized
INFO - 2018-09-30 08:59:12 --> Model "Tasks_model" initialized
INFO - 2018-09-30 08:59:12 --> Model "Lists_model" initialized
INFO - 2018-09-30 08:59:12 --> Controller Class Initialized
INFO - 2018-09-30 08:59:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 08:59:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 08:59:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 08:59:12 --> Final output sent to browser
DEBUG - 2018-09-30 08:59:12 --> Total execution time: 0.0520
INFO - 2018-09-30 08:59:17 --> Config Class Initialized
INFO - 2018-09-30 08:59:17 --> Hooks Class Initialized
DEBUG - 2018-09-30 08:59:17 --> UTF-8 Support Enabled
INFO - 2018-09-30 08:59:17 --> Utf8 Class Initialized
INFO - 2018-09-30 08:59:17 --> URI Class Initialized
INFO - 2018-09-30 08:59:17 --> Router Class Initialized
INFO - 2018-09-30 08:59:17 --> Output Class Initialized
INFO - 2018-09-30 08:59:17 --> Security Class Initialized
DEBUG - 2018-09-30 08:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 08:59:17 --> Input Class Initialized
INFO - 2018-09-30 08:59:17 --> Language Class Initialized
INFO - 2018-09-30 08:59:17 --> Loader Class Initialized
INFO - 2018-09-30 08:59:17 --> Helper loaded: url_helper
INFO - 2018-09-30 08:59:17 --> Helper loaded: form_helper
INFO - 2018-09-30 08:59:17 --> Helper loaded: html_helper
INFO - 2018-09-30 08:59:17 --> Database Driver Class Initialized
INFO - 2018-09-30 08:59:17 --> Form Validation Class Initialized
DEBUG - 2018-09-30 08:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 08:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 08:59:17 --> Model "User_model" initialized
INFO - 2018-09-30 08:59:17 --> Model "Project_model" initialized
INFO - 2018-09-30 08:59:17 --> Model "Tasks_model" initialized
INFO - 2018-09-30 08:59:17 --> Model "Lists_model" initialized
INFO - 2018-09-30 08:59:17 --> Controller Class Initialized
INFO - 2018-09-30 08:59:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 08:59:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 08:59:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 08:59:17 --> Final output sent to browser
DEBUG - 2018-09-30 08:59:17 --> Total execution time: 0.0640
INFO - 2018-09-30 08:59:19 --> Config Class Initialized
INFO - 2018-09-30 08:59:19 --> Hooks Class Initialized
DEBUG - 2018-09-30 08:59:19 --> UTF-8 Support Enabled
INFO - 2018-09-30 08:59:19 --> Utf8 Class Initialized
INFO - 2018-09-30 08:59:19 --> URI Class Initialized
INFO - 2018-09-30 08:59:19 --> Router Class Initialized
INFO - 2018-09-30 08:59:19 --> Output Class Initialized
INFO - 2018-09-30 08:59:19 --> Security Class Initialized
DEBUG - 2018-09-30 08:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 08:59:19 --> Input Class Initialized
INFO - 2018-09-30 08:59:19 --> Language Class Initialized
INFO - 2018-09-30 08:59:19 --> Loader Class Initialized
INFO - 2018-09-30 08:59:19 --> Helper loaded: url_helper
INFO - 2018-09-30 08:59:19 --> Helper loaded: form_helper
INFO - 2018-09-30 08:59:19 --> Helper loaded: html_helper
INFO - 2018-09-30 08:59:19 --> Database Driver Class Initialized
INFO - 2018-09-30 08:59:19 --> Form Validation Class Initialized
DEBUG - 2018-09-30 08:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 08:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 08:59:19 --> Model "User_model" initialized
INFO - 2018-09-30 08:59:19 --> Model "Project_model" initialized
INFO - 2018-09-30 08:59:19 --> Model "Tasks_model" initialized
INFO - 2018-09-30 08:59:19 --> Model "Lists_model" initialized
INFO - 2018-09-30 08:59:19 --> Controller Class Initialized
INFO - 2018-09-30 08:59:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 08:59:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 08:59:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 08:59:19 --> Final output sent to browser
DEBUG - 2018-09-30 08:59:19 --> Total execution time: 0.0710
INFO - 2018-09-30 08:59:21 --> Config Class Initialized
INFO - 2018-09-30 08:59:21 --> Hooks Class Initialized
DEBUG - 2018-09-30 08:59:21 --> UTF-8 Support Enabled
INFO - 2018-09-30 08:59:21 --> Utf8 Class Initialized
INFO - 2018-09-30 08:59:21 --> URI Class Initialized
INFO - 2018-09-30 08:59:21 --> Router Class Initialized
INFO - 2018-09-30 08:59:21 --> Output Class Initialized
INFO - 2018-09-30 08:59:21 --> Security Class Initialized
DEBUG - 2018-09-30 08:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 08:59:21 --> Input Class Initialized
INFO - 2018-09-30 08:59:21 --> Language Class Initialized
INFO - 2018-09-30 08:59:21 --> Loader Class Initialized
INFO - 2018-09-30 08:59:21 --> Helper loaded: url_helper
INFO - 2018-09-30 08:59:21 --> Helper loaded: form_helper
INFO - 2018-09-30 08:59:21 --> Helper loaded: html_helper
INFO - 2018-09-30 08:59:21 --> Database Driver Class Initialized
INFO - 2018-09-30 08:59:21 --> Form Validation Class Initialized
DEBUG - 2018-09-30 08:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 08:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 08:59:21 --> Model "User_model" initialized
INFO - 2018-09-30 08:59:21 --> Model "Project_model" initialized
INFO - 2018-09-30 08:59:21 --> Model "Tasks_model" initialized
INFO - 2018-09-30 08:59:21 --> Model "Lists_model" initialized
INFO - 2018-09-30 08:59:21 --> Controller Class Initialized
INFO - 2018-09-30 08:59:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 08:59:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/edit_project.php
INFO - 2018-09-30 08:59:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 08:59:21 --> Final output sent to browser
DEBUG - 2018-09-30 08:59:21 --> Total execution time: 0.0630
INFO - 2018-09-30 08:59:31 --> Config Class Initialized
INFO - 2018-09-30 08:59:31 --> Hooks Class Initialized
DEBUG - 2018-09-30 08:59:31 --> UTF-8 Support Enabled
INFO - 2018-09-30 08:59:31 --> Utf8 Class Initialized
INFO - 2018-09-30 08:59:31 --> URI Class Initialized
INFO - 2018-09-30 08:59:31 --> Router Class Initialized
INFO - 2018-09-30 08:59:31 --> Output Class Initialized
INFO - 2018-09-30 08:59:31 --> Security Class Initialized
DEBUG - 2018-09-30 08:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 08:59:31 --> Input Class Initialized
INFO - 2018-09-30 08:59:31 --> Language Class Initialized
INFO - 2018-09-30 08:59:31 --> Loader Class Initialized
INFO - 2018-09-30 08:59:31 --> Helper loaded: url_helper
INFO - 2018-09-30 08:59:31 --> Helper loaded: form_helper
INFO - 2018-09-30 08:59:31 --> Helper loaded: html_helper
INFO - 2018-09-30 08:59:31 --> Database Driver Class Initialized
INFO - 2018-09-30 08:59:31 --> Form Validation Class Initialized
DEBUG - 2018-09-30 08:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 08:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 08:59:31 --> Model "User_model" initialized
INFO - 2018-09-30 08:59:31 --> Model "Project_model" initialized
INFO - 2018-09-30 08:59:31 --> Model "Tasks_model" initialized
INFO - 2018-09-30 08:59:31 --> Model "Lists_model" initialized
INFO - 2018-09-30 08:59:31 --> Controller Class Initialized
INFO - 2018-09-30 08:59:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-30 08:59:31 --> Config Class Initialized
INFO - 2018-09-30 08:59:31 --> Hooks Class Initialized
DEBUG - 2018-09-30 08:59:31 --> UTF-8 Support Enabled
INFO - 2018-09-30 08:59:31 --> Utf8 Class Initialized
INFO - 2018-09-30 08:59:31 --> URI Class Initialized
INFO - 2018-09-30 08:59:31 --> Router Class Initialized
INFO - 2018-09-30 08:59:31 --> Output Class Initialized
INFO - 2018-09-30 08:59:31 --> Security Class Initialized
DEBUG - 2018-09-30 08:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 08:59:31 --> Input Class Initialized
INFO - 2018-09-30 08:59:31 --> Language Class Initialized
INFO - 2018-09-30 08:59:31 --> Loader Class Initialized
INFO - 2018-09-30 08:59:31 --> Helper loaded: url_helper
INFO - 2018-09-30 08:59:31 --> Helper loaded: form_helper
INFO - 2018-09-30 08:59:31 --> Helper loaded: html_helper
INFO - 2018-09-30 08:59:31 --> Database Driver Class Initialized
INFO - 2018-09-30 08:59:31 --> Form Validation Class Initialized
DEBUG - 2018-09-30 08:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 08:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 08:59:31 --> Model "User_model" initialized
INFO - 2018-09-30 08:59:31 --> Model "Project_model" initialized
INFO - 2018-09-30 08:59:31 --> Model "Tasks_model" initialized
INFO - 2018-09-30 08:59:31 --> Model "Lists_model" initialized
INFO - 2018-09-30 08:59:31 --> Controller Class Initialized
INFO - 2018-09-30 08:59:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 08:59:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 08:59:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 08:59:31 --> Final output sent to browser
DEBUG - 2018-09-30 08:59:31 --> Total execution time: 0.0430
INFO - 2018-09-30 08:59:37 --> Config Class Initialized
INFO - 2018-09-30 08:59:37 --> Hooks Class Initialized
DEBUG - 2018-09-30 08:59:37 --> UTF-8 Support Enabled
INFO - 2018-09-30 08:59:37 --> Utf8 Class Initialized
INFO - 2018-09-30 08:59:37 --> URI Class Initialized
INFO - 2018-09-30 08:59:37 --> Router Class Initialized
INFO - 2018-09-30 08:59:37 --> Output Class Initialized
INFO - 2018-09-30 08:59:37 --> Security Class Initialized
DEBUG - 2018-09-30 08:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 08:59:37 --> Input Class Initialized
INFO - 2018-09-30 08:59:37 --> Language Class Initialized
INFO - 2018-09-30 08:59:37 --> Loader Class Initialized
INFO - 2018-09-30 08:59:37 --> Helper loaded: url_helper
INFO - 2018-09-30 08:59:37 --> Helper loaded: form_helper
INFO - 2018-09-30 08:59:37 --> Helper loaded: html_helper
INFO - 2018-09-30 08:59:37 --> Database Driver Class Initialized
INFO - 2018-09-30 08:59:37 --> Form Validation Class Initialized
DEBUG - 2018-09-30 08:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 08:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 08:59:37 --> Model "User_model" initialized
INFO - 2018-09-30 08:59:37 --> Model "Project_model" initialized
INFO - 2018-09-30 08:59:37 --> Model "Tasks_model" initialized
INFO - 2018-09-30 08:59:37 --> Model "Lists_model" initialized
INFO - 2018-09-30 08:59:37 --> Controller Class Initialized
INFO - 2018-09-30 08:59:37 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 08:59:37 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 08:59:37 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 08:59:37 --> Final output sent to browser
DEBUG - 2018-09-30 08:59:37 --> Total execution time: 0.0500
INFO - 2018-09-30 09:00:27 --> Config Class Initialized
INFO - 2018-09-30 09:00:27 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:00:27 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:00:27 --> Utf8 Class Initialized
INFO - 2018-09-30 09:00:27 --> URI Class Initialized
INFO - 2018-09-30 09:00:27 --> Router Class Initialized
INFO - 2018-09-30 09:00:27 --> Output Class Initialized
INFO - 2018-09-30 09:00:27 --> Security Class Initialized
DEBUG - 2018-09-30 09:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:00:27 --> Input Class Initialized
INFO - 2018-09-30 09:00:27 --> Language Class Initialized
INFO - 2018-09-30 09:00:27 --> Loader Class Initialized
INFO - 2018-09-30 09:00:27 --> Helper loaded: url_helper
INFO - 2018-09-30 09:00:27 --> Helper loaded: form_helper
INFO - 2018-09-30 09:00:27 --> Helper loaded: html_helper
INFO - 2018-09-30 09:00:27 --> Database Driver Class Initialized
INFO - 2018-09-30 09:00:27 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:00:27 --> Model "User_model" initialized
INFO - 2018-09-30 09:00:27 --> Model "Project_model" initialized
INFO - 2018-09-30 09:00:27 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:00:27 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:00:27 --> Controller Class Initialized
INFO - 2018-09-30 09:00:27 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:00:27 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 09:00:27 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:00:27 --> Final output sent to browser
DEBUG - 2018-09-30 09:00:27 --> Total execution time: 0.0500
INFO - 2018-09-30 09:00:29 --> Config Class Initialized
INFO - 2018-09-30 09:00:29 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:00:29 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:00:29 --> Utf8 Class Initialized
INFO - 2018-09-30 09:00:29 --> URI Class Initialized
INFO - 2018-09-30 09:00:29 --> Router Class Initialized
INFO - 2018-09-30 09:00:29 --> Output Class Initialized
INFO - 2018-09-30 09:00:29 --> Security Class Initialized
DEBUG - 2018-09-30 09:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:00:29 --> Input Class Initialized
INFO - 2018-09-30 09:00:29 --> Language Class Initialized
INFO - 2018-09-30 09:00:29 --> Loader Class Initialized
INFO - 2018-09-30 09:00:29 --> Helper loaded: url_helper
INFO - 2018-09-30 09:00:29 --> Helper loaded: form_helper
INFO - 2018-09-30 09:00:29 --> Helper loaded: html_helper
INFO - 2018-09-30 09:00:29 --> Database Driver Class Initialized
INFO - 2018-09-30 09:00:29 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:00:29 --> Model "User_model" initialized
INFO - 2018-09-30 09:00:29 --> Model "Project_model" initialized
INFO - 2018-09-30 09:00:29 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:00:29 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:00:29 --> Controller Class Initialized
INFO - 2018-09-30 09:00:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:00:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 09:00:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:00:29 --> Final output sent to browser
DEBUG - 2018-09-30 09:00:29 --> Total execution time: 0.0660
INFO - 2018-09-30 09:00:30 --> Config Class Initialized
INFO - 2018-09-30 09:00:30 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:00:30 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:00:30 --> Utf8 Class Initialized
INFO - 2018-09-30 09:00:30 --> URI Class Initialized
INFO - 2018-09-30 09:00:30 --> Router Class Initialized
INFO - 2018-09-30 09:00:30 --> Output Class Initialized
INFO - 2018-09-30 09:00:31 --> Security Class Initialized
DEBUG - 2018-09-30 09:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:00:31 --> Input Class Initialized
INFO - 2018-09-30 09:00:31 --> Language Class Initialized
INFO - 2018-09-30 09:00:31 --> Loader Class Initialized
INFO - 2018-09-30 09:00:31 --> Helper loaded: url_helper
INFO - 2018-09-30 09:00:31 --> Helper loaded: form_helper
INFO - 2018-09-30 09:00:31 --> Helper loaded: html_helper
INFO - 2018-09-30 09:00:31 --> Database Driver Class Initialized
INFO - 2018-09-30 09:00:31 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:00:31 --> Model "User_model" initialized
INFO - 2018-09-30 09:00:31 --> Model "Project_model" initialized
INFO - 2018-09-30 09:00:31 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:00:31 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:00:31 --> Controller Class Initialized
INFO - 2018-09-30 09:00:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:00:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/edit_project.php
INFO - 2018-09-30 09:00:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:00:31 --> Final output sent to browser
DEBUG - 2018-09-30 09:00:31 --> Total execution time: 0.0550
INFO - 2018-09-30 09:00:40 --> Config Class Initialized
INFO - 2018-09-30 09:00:40 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:00:40 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:00:40 --> Utf8 Class Initialized
INFO - 2018-09-30 09:00:40 --> URI Class Initialized
INFO - 2018-09-30 09:00:40 --> Router Class Initialized
INFO - 2018-09-30 09:00:40 --> Output Class Initialized
INFO - 2018-09-30 09:00:40 --> Security Class Initialized
DEBUG - 2018-09-30 09:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:00:40 --> Input Class Initialized
INFO - 2018-09-30 09:00:40 --> Language Class Initialized
INFO - 2018-09-30 09:00:40 --> Loader Class Initialized
INFO - 2018-09-30 09:00:40 --> Helper loaded: url_helper
INFO - 2018-09-30 09:00:40 --> Helper loaded: form_helper
INFO - 2018-09-30 09:00:40 --> Helper loaded: html_helper
INFO - 2018-09-30 09:00:40 --> Database Driver Class Initialized
INFO - 2018-09-30 09:00:40 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:00:40 --> Model "User_model" initialized
INFO - 2018-09-30 09:00:40 --> Model "Project_model" initialized
INFO - 2018-09-30 09:00:40 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:00:40 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:00:40 --> Controller Class Initialized
INFO - 2018-09-30 09:00:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-30 09:00:40 --> Config Class Initialized
INFO - 2018-09-30 09:00:40 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:00:40 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:00:40 --> Utf8 Class Initialized
INFO - 2018-09-30 09:00:40 --> URI Class Initialized
INFO - 2018-09-30 09:00:40 --> Router Class Initialized
INFO - 2018-09-30 09:00:40 --> Output Class Initialized
INFO - 2018-09-30 09:00:40 --> Security Class Initialized
DEBUG - 2018-09-30 09:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:00:40 --> Input Class Initialized
INFO - 2018-09-30 09:00:40 --> Language Class Initialized
INFO - 2018-09-30 09:00:40 --> Loader Class Initialized
INFO - 2018-09-30 09:00:40 --> Helper loaded: url_helper
INFO - 2018-09-30 09:00:40 --> Helper loaded: form_helper
INFO - 2018-09-30 09:00:40 --> Helper loaded: html_helper
INFO - 2018-09-30 09:00:40 --> Database Driver Class Initialized
INFO - 2018-09-30 09:00:40 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:00:40 --> Model "User_model" initialized
INFO - 2018-09-30 09:00:40 --> Model "Project_model" initialized
INFO - 2018-09-30 09:00:40 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:00:40 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:00:40 --> Controller Class Initialized
INFO - 2018-09-30 09:00:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:00:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 09:00:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:00:40 --> Final output sent to browser
DEBUG - 2018-09-30 09:00:40 --> Total execution time: 0.0440
INFO - 2018-09-30 09:20:12 --> Config Class Initialized
INFO - 2018-09-30 09:20:12 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:20:12 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:20:12 --> Utf8 Class Initialized
INFO - 2018-09-30 09:20:12 --> URI Class Initialized
INFO - 2018-09-30 09:20:12 --> Router Class Initialized
INFO - 2018-09-30 09:20:12 --> Output Class Initialized
INFO - 2018-09-30 09:20:12 --> Security Class Initialized
DEBUG - 2018-09-30 09:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:20:12 --> Input Class Initialized
INFO - 2018-09-30 09:20:12 --> Language Class Initialized
INFO - 2018-09-30 09:20:12 --> Loader Class Initialized
INFO - 2018-09-30 09:20:12 --> Helper loaded: url_helper
INFO - 2018-09-30 09:20:12 --> Helper loaded: form_helper
INFO - 2018-09-30 09:20:12 --> Helper loaded: html_helper
INFO - 2018-09-30 09:20:12 --> Database Driver Class Initialized
INFO - 2018-09-30 09:20:12 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:20:12 --> Model "User_model" initialized
INFO - 2018-09-30 09:20:12 --> Model "Project_model" initialized
INFO - 2018-09-30 09:20:12 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:20:12 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:20:12 --> Controller Class Initialized
INFO - 2018-09-30 09:20:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:20:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 09:20:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:20:12 --> Final output sent to browser
DEBUG - 2018-09-30 09:20:12 --> Total execution time: 0.0510
INFO - 2018-09-30 09:20:29 --> Config Class Initialized
INFO - 2018-09-30 09:20:29 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:20:29 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:20:29 --> Utf8 Class Initialized
INFO - 2018-09-30 09:20:29 --> URI Class Initialized
INFO - 2018-09-30 09:20:29 --> Router Class Initialized
INFO - 2018-09-30 09:20:29 --> Output Class Initialized
INFO - 2018-09-30 09:20:29 --> Security Class Initialized
DEBUG - 2018-09-30 09:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:20:29 --> Input Class Initialized
INFO - 2018-09-30 09:20:29 --> Language Class Initialized
INFO - 2018-09-30 09:20:29 --> Loader Class Initialized
INFO - 2018-09-30 09:20:29 --> Helper loaded: url_helper
INFO - 2018-09-30 09:20:29 --> Helper loaded: form_helper
INFO - 2018-09-30 09:20:29 --> Helper loaded: html_helper
INFO - 2018-09-30 09:20:29 --> Database Driver Class Initialized
INFO - 2018-09-30 09:20:29 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:20:29 --> Model "User_model" initialized
INFO - 2018-09-30 09:20:29 --> Model "Project_model" initialized
INFO - 2018-09-30 09:20:29 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:20:29 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:20:29 --> Controller Class Initialized
INFO - 2018-09-30 09:20:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:20:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 09:20:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:20:29 --> Final output sent to browser
DEBUG - 2018-09-30 09:20:29 --> Total execution time: 0.0520
INFO - 2018-09-30 09:22:38 --> Config Class Initialized
INFO - 2018-09-30 09:22:38 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:22:38 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:22:38 --> Utf8 Class Initialized
INFO - 2018-09-30 09:22:38 --> URI Class Initialized
INFO - 2018-09-30 09:22:38 --> Router Class Initialized
INFO - 2018-09-30 09:22:38 --> Output Class Initialized
INFO - 2018-09-30 09:22:38 --> Security Class Initialized
DEBUG - 2018-09-30 09:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:22:38 --> Input Class Initialized
INFO - 2018-09-30 09:22:38 --> Language Class Initialized
INFO - 2018-09-30 09:22:38 --> Loader Class Initialized
INFO - 2018-09-30 09:22:38 --> Helper loaded: url_helper
INFO - 2018-09-30 09:22:38 --> Helper loaded: form_helper
INFO - 2018-09-30 09:22:38 --> Helper loaded: html_helper
INFO - 2018-09-30 09:22:38 --> Database Driver Class Initialized
INFO - 2018-09-30 09:22:38 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:22:38 --> Model "User_model" initialized
INFO - 2018-09-30 09:22:38 --> Model "Project_model" initialized
INFO - 2018-09-30 09:22:38 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:22:38 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:22:38 --> Controller Class Initialized
INFO - 2018-09-30 09:22:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:22:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 09:22:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:22:38 --> Final output sent to browser
DEBUG - 2018-09-30 09:22:38 --> Total execution time: 0.0530
INFO - 2018-09-30 09:22:39 --> Config Class Initialized
INFO - 2018-09-30 09:22:39 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:22:39 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:22:39 --> Utf8 Class Initialized
INFO - 2018-09-30 09:22:39 --> URI Class Initialized
INFO - 2018-09-30 09:22:39 --> Router Class Initialized
INFO - 2018-09-30 09:22:39 --> Output Class Initialized
INFO - 2018-09-30 09:22:39 --> Security Class Initialized
DEBUG - 2018-09-30 09:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:22:39 --> Input Class Initialized
INFO - 2018-09-30 09:22:39 --> Language Class Initialized
INFO - 2018-09-30 09:22:39 --> Loader Class Initialized
INFO - 2018-09-30 09:22:39 --> Helper loaded: url_helper
INFO - 2018-09-30 09:22:39 --> Helper loaded: form_helper
INFO - 2018-09-30 09:22:39 --> Helper loaded: html_helper
INFO - 2018-09-30 09:22:39 --> Database Driver Class Initialized
INFO - 2018-09-30 09:22:39 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:22:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:22:39 --> Model "User_model" initialized
INFO - 2018-09-30 09:22:39 --> Model "Project_model" initialized
INFO - 2018-09-30 09:22:39 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:22:39 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:22:39 --> Controller Class Initialized
INFO - 2018-09-30 09:22:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:22:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 09:22:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:22:39 --> Final output sent to browser
DEBUG - 2018-09-30 09:22:39 --> Total execution time: 0.0630
INFO - 2018-09-30 09:22:40 --> Config Class Initialized
INFO - 2018-09-30 09:22:40 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:22:40 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:22:40 --> Utf8 Class Initialized
INFO - 2018-09-30 09:22:40 --> URI Class Initialized
INFO - 2018-09-30 09:22:40 --> Router Class Initialized
INFO - 2018-09-30 09:22:40 --> Output Class Initialized
INFO - 2018-09-30 09:22:40 --> Security Class Initialized
DEBUG - 2018-09-30 09:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:22:40 --> Input Class Initialized
INFO - 2018-09-30 09:22:40 --> Language Class Initialized
INFO - 2018-09-30 09:22:40 --> Loader Class Initialized
INFO - 2018-09-30 09:22:40 --> Helper loaded: url_helper
INFO - 2018-09-30 09:22:40 --> Helper loaded: form_helper
INFO - 2018-09-30 09:22:40 --> Helper loaded: html_helper
INFO - 2018-09-30 09:22:40 --> Database Driver Class Initialized
INFO - 2018-09-30 09:22:40 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:22:40 --> Model "User_model" initialized
INFO - 2018-09-30 09:22:40 --> Model "Project_model" initialized
INFO - 2018-09-30 09:22:40 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:22:40 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:22:40 --> Controller Class Initialized
INFO - 2018-09-30 09:22:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:22:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 09:22:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:22:40 --> Final output sent to browser
DEBUG - 2018-09-30 09:22:40 --> Total execution time: 0.0930
INFO - 2018-09-30 09:22:42 --> Config Class Initialized
INFO - 2018-09-30 09:22:42 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:22:42 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:22:42 --> Utf8 Class Initialized
INFO - 2018-09-30 09:22:42 --> URI Class Initialized
INFO - 2018-09-30 09:22:42 --> Router Class Initialized
INFO - 2018-09-30 09:22:42 --> Output Class Initialized
INFO - 2018-09-30 09:22:42 --> Security Class Initialized
DEBUG - 2018-09-30 09:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:22:42 --> Input Class Initialized
INFO - 2018-09-30 09:22:42 --> Language Class Initialized
INFO - 2018-09-30 09:22:42 --> Loader Class Initialized
INFO - 2018-09-30 09:22:42 --> Helper loaded: url_helper
INFO - 2018-09-30 09:22:42 --> Helper loaded: form_helper
INFO - 2018-09-30 09:22:42 --> Helper loaded: html_helper
INFO - 2018-09-30 09:22:42 --> Database Driver Class Initialized
INFO - 2018-09-30 09:22:42 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:22:42 --> Model "User_model" initialized
INFO - 2018-09-30 09:22:42 --> Model "Project_model" initialized
INFO - 2018-09-30 09:22:42 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:22:42 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:22:42 --> Controller Class Initialized
INFO - 2018-09-30 09:22:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:22:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 09:22:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:22:42 --> Final output sent to browser
DEBUG - 2018-09-30 09:22:42 --> Total execution time: 0.0810
INFO - 2018-09-30 09:22:45 --> Config Class Initialized
INFO - 2018-09-30 09:22:45 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:22:45 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:22:45 --> Utf8 Class Initialized
INFO - 2018-09-30 09:22:45 --> URI Class Initialized
INFO - 2018-09-30 09:22:45 --> Router Class Initialized
INFO - 2018-09-30 09:22:45 --> Output Class Initialized
INFO - 2018-09-30 09:22:45 --> Security Class Initialized
DEBUG - 2018-09-30 09:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:22:45 --> Input Class Initialized
INFO - 2018-09-30 09:22:45 --> Language Class Initialized
INFO - 2018-09-30 09:22:45 --> Loader Class Initialized
INFO - 2018-09-30 09:22:45 --> Helper loaded: url_helper
INFO - 2018-09-30 09:22:45 --> Helper loaded: form_helper
INFO - 2018-09-30 09:22:45 --> Helper loaded: html_helper
INFO - 2018-09-30 09:22:45 --> Database Driver Class Initialized
INFO - 2018-09-30 09:22:45 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:22:45 --> Model "User_model" initialized
INFO - 2018-09-30 09:22:45 --> Model "Project_model" initialized
INFO - 2018-09-30 09:22:45 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:22:45 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:22:45 --> Controller Class Initialized
ERROR - 2018-09-30 09:22:45 --> Severity: error --> Exception: Call to undefined method Project_model::get_project() D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\projects.php 23
INFO - 2018-09-30 09:22:56 --> Config Class Initialized
INFO - 2018-09-30 09:22:56 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:22:56 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:22:56 --> Utf8 Class Initialized
INFO - 2018-09-30 09:22:56 --> URI Class Initialized
INFO - 2018-09-30 09:22:56 --> Router Class Initialized
INFO - 2018-09-30 09:22:56 --> Output Class Initialized
INFO - 2018-09-30 09:22:56 --> Security Class Initialized
DEBUG - 2018-09-30 09:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:22:56 --> Input Class Initialized
INFO - 2018-09-30 09:22:56 --> Language Class Initialized
INFO - 2018-09-30 09:22:56 --> Loader Class Initialized
INFO - 2018-09-30 09:22:56 --> Helper loaded: url_helper
INFO - 2018-09-30 09:22:56 --> Helper loaded: form_helper
INFO - 2018-09-30 09:22:56 --> Helper loaded: html_helper
INFO - 2018-09-30 09:22:56 --> Database Driver Class Initialized
INFO - 2018-09-30 09:22:56 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:22:56 --> Model "User_model" initialized
INFO - 2018-09-30 09:22:56 --> Model "Project_model" initialized
INFO - 2018-09-30 09:22:56 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:22:56 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:22:56 --> Controller Class Initialized
INFO - 2018-09-30 09:22:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:22:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 09:22:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:22:56 --> Final output sent to browser
DEBUG - 2018-09-30 09:22:56 --> Total execution time: 0.0490
INFO - 2018-09-30 09:22:58 --> Config Class Initialized
INFO - 2018-09-30 09:22:58 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:22:58 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:22:58 --> Utf8 Class Initialized
INFO - 2018-09-30 09:22:58 --> URI Class Initialized
INFO - 2018-09-30 09:22:58 --> Router Class Initialized
INFO - 2018-09-30 09:22:58 --> Output Class Initialized
INFO - 2018-09-30 09:22:58 --> Security Class Initialized
DEBUG - 2018-09-30 09:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:22:58 --> Input Class Initialized
INFO - 2018-09-30 09:22:58 --> Language Class Initialized
INFO - 2018-09-30 09:22:58 --> Loader Class Initialized
INFO - 2018-09-30 09:22:58 --> Helper loaded: url_helper
INFO - 2018-09-30 09:22:58 --> Helper loaded: form_helper
INFO - 2018-09-30 09:22:58 --> Helper loaded: html_helper
INFO - 2018-09-30 09:22:58 --> Database Driver Class Initialized
INFO - 2018-09-30 09:22:58 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:22:58 --> Model "User_model" initialized
INFO - 2018-09-30 09:22:58 --> Model "Project_model" initialized
INFO - 2018-09-30 09:22:58 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:22:58 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:22:58 --> Controller Class Initialized
INFO - 2018-09-30 09:22:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:22:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 09:22:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:22:58 --> Final output sent to browser
DEBUG - 2018-09-30 09:22:58 --> Total execution time: 0.0820
INFO - 2018-09-30 09:23:00 --> Config Class Initialized
INFO - 2018-09-30 09:23:00 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:23:00 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:23:00 --> Utf8 Class Initialized
INFO - 2018-09-30 09:23:00 --> URI Class Initialized
INFO - 2018-09-30 09:23:00 --> Router Class Initialized
INFO - 2018-09-30 09:23:00 --> Output Class Initialized
INFO - 2018-09-30 09:23:00 --> Security Class Initialized
DEBUG - 2018-09-30 09:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:23:00 --> Input Class Initialized
INFO - 2018-09-30 09:23:00 --> Language Class Initialized
INFO - 2018-09-30 09:23:00 --> Loader Class Initialized
INFO - 2018-09-30 09:23:00 --> Helper loaded: url_helper
INFO - 2018-09-30 09:23:00 --> Helper loaded: form_helper
INFO - 2018-09-30 09:23:00 --> Helper loaded: html_helper
INFO - 2018-09-30 09:23:00 --> Database Driver Class Initialized
INFO - 2018-09-30 09:23:00 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:23:00 --> Model "User_model" initialized
INFO - 2018-09-30 09:23:00 --> Model "Project_model" initialized
INFO - 2018-09-30 09:23:00 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:23:00 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:23:00 --> Controller Class Initialized
INFO - 2018-09-30 09:23:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:23:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 09:23:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:23:00 --> Final output sent to browser
DEBUG - 2018-09-30 09:23:00 --> Total execution time: 0.0650
INFO - 2018-09-30 09:23:08 --> Config Class Initialized
INFO - 2018-09-30 09:23:08 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:23:08 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:23:08 --> Utf8 Class Initialized
INFO - 2018-09-30 09:23:08 --> URI Class Initialized
INFO - 2018-09-30 09:23:08 --> Router Class Initialized
INFO - 2018-09-30 09:23:08 --> Output Class Initialized
INFO - 2018-09-30 09:23:08 --> Security Class Initialized
DEBUG - 2018-09-30 09:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:23:08 --> Input Class Initialized
INFO - 2018-09-30 09:23:08 --> Language Class Initialized
INFO - 2018-09-30 09:23:08 --> Loader Class Initialized
INFO - 2018-09-30 09:23:08 --> Helper loaded: url_helper
INFO - 2018-09-30 09:23:08 --> Helper loaded: form_helper
INFO - 2018-09-30 09:23:08 --> Helper loaded: html_helper
INFO - 2018-09-30 09:23:08 --> Database Driver Class Initialized
INFO - 2018-09-30 09:23:08 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:23:08 --> Model "User_model" initialized
INFO - 2018-09-30 09:23:08 --> Model "Project_model" initialized
INFO - 2018-09-30 09:23:08 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:23:08 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:23:08 --> Controller Class Initialized
INFO - 2018-09-30 09:23:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-30 09:23:08 --> Severity: Notice --> Trying to get property 'project_name' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 3
ERROR - 2018-09-30 09:23:08 --> Severity: Notice --> Trying to get property 'date_created' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 4
ERROR - 2018-09-30 09:23:08 --> Severity: Notice --> Trying to get property 'project_body' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 7
ERROR - 2018-09-30 09:23:08 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 27
ERROR - 2018-09-30 09:23:08 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 53
ERROR - 2018-09-30 09:23:08 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 69
ERROR - 2018-09-30 09:23:08 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 74
ERROR - 2018-09-30 09:23:08 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 79
INFO - 2018-09-30 09:23:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 09:23:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:23:08 --> Final output sent to browser
DEBUG - 2018-09-30 09:23:08 --> Total execution time: 0.0790
INFO - 2018-09-30 09:23:19 --> Config Class Initialized
INFO - 2018-09-30 09:23:19 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:23:20 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:23:20 --> Utf8 Class Initialized
INFO - 2018-09-30 09:23:20 --> URI Class Initialized
INFO - 2018-09-30 09:23:20 --> Router Class Initialized
INFO - 2018-09-30 09:23:20 --> Output Class Initialized
INFO - 2018-09-30 09:23:20 --> Security Class Initialized
DEBUG - 2018-09-30 09:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:23:20 --> Input Class Initialized
INFO - 2018-09-30 09:23:20 --> Language Class Initialized
INFO - 2018-09-30 09:23:20 --> Loader Class Initialized
INFO - 2018-09-30 09:23:20 --> Helper loaded: url_helper
INFO - 2018-09-30 09:23:20 --> Helper loaded: form_helper
INFO - 2018-09-30 09:23:20 --> Helper loaded: html_helper
INFO - 2018-09-30 09:23:20 --> Database Driver Class Initialized
INFO - 2018-09-30 09:23:20 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:23:20 --> Model "User_model" initialized
INFO - 2018-09-30 09:23:20 --> Model "Project_model" initialized
INFO - 2018-09-30 09:23:20 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:23:20 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:23:20 --> Controller Class Initialized
INFO - 2018-09-30 09:23:20 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:23:20 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 09:23:20 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:23:20 --> Final output sent to browser
DEBUG - 2018-09-30 09:23:20 --> Total execution time: 0.0600
INFO - 2018-09-30 09:24:41 --> Config Class Initialized
INFO - 2018-09-30 09:24:41 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:24:41 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:24:41 --> Utf8 Class Initialized
INFO - 2018-09-30 09:24:41 --> URI Class Initialized
INFO - 2018-09-30 09:24:41 --> Router Class Initialized
INFO - 2018-09-30 09:24:41 --> Output Class Initialized
INFO - 2018-09-30 09:24:41 --> Security Class Initialized
DEBUG - 2018-09-30 09:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:24:41 --> Input Class Initialized
INFO - 2018-09-30 09:24:41 --> Language Class Initialized
INFO - 2018-09-30 09:24:41 --> Loader Class Initialized
INFO - 2018-09-30 09:24:41 --> Helper loaded: url_helper
INFO - 2018-09-30 09:24:41 --> Helper loaded: form_helper
INFO - 2018-09-30 09:24:41 --> Helper loaded: html_helper
INFO - 2018-09-30 09:24:41 --> Database Driver Class Initialized
INFO - 2018-09-30 09:24:42 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:24:42 --> Model "User_model" initialized
INFO - 2018-09-30 09:24:42 --> Model "Project_model" initialized
INFO - 2018-09-30 09:24:42 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:24:42 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:24:42 --> Controller Class Initialized
INFO - 2018-09-30 09:24:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:24:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 09:24:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:24:42 --> Final output sent to browser
DEBUG - 2018-09-30 09:24:42 --> Total execution time: 0.0690
INFO - 2018-09-30 09:24:43 --> Config Class Initialized
INFO - 2018-09-30 09:24:43 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:24:43 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:24:43 --> Utf8 Class Initialized
INFO - 2018-09-30 09:24:43 --> URI Class Initialized
INFO - 2018-09-30 09:24:43 --> Router Class Initialized
INFO - 2018-09-30 09:24:43 --> Output Class Initialized
INFO - 2018-09-30 09:24:43 --> Security Class Initialized
DEBUG - 2018-09-30 09:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:24:43 --> Input Class Initialized
INFO - 2018-09-30 09:24:43 --> Language Class Initialized
INFO - 2018-09-30 09:24:43 --> Loader Class Initialized
INFO - 2018-09-30 09:24:43 --> Helper loaded: url_helper
INFO - 2018-09-30 09:24:43 --> Helper loaded: form_helper
INFO - 2018-09-30 09:24:43 --> Helper loaded: html_helper
INFO - 2018-09-30 09:24:43 --> Database Driver Class Initialized
INFO - 2018-09-30 09:24:43 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:24:43 --> Model "User_model" initialized
INFO - 2018-09-30 09:24:43 --> Model "Project_model" initialized
INFO - 2018-09-30 09:24:43 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:24:43 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:24:43 --> Controller Class Initialized
INFO - 2018-09-30 09:24:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-30 09:24:43 --> Severity: Notice --> Trying to get property 'project_name' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 3
ERROR - 2018-09-30 09:24:43 --> Severity: Notice --> Trying to get property 'date_created' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 4
ERROR - 2018-09-30 09:24:43 --> Severity: Notice --> Trying to get property 'project_body' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 7
ERROR - 2018-09-30 09:24:43 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 27
ERROR - 2018-09-30 09:24:43 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 53
ERROR - 2018-09-30 09:24:43 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 69
ERROR - 2018-09-30 09:24:43 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 74
ERROR - 2018-09-30 09:24:43 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 79
INFO - 2018-09-30 09:24:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 09:24:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:24:43 --> Final output sent to browser
DEBUG - 2018-09-30 09:24:43 --> Total execution time: 0.0640
INFO - 2018-09-30 09:25:59 --> Config Class Initialized
INFO - 2018-09-30 09:25:59 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:25:59 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:25:59 --> Utf8 Class Initialized
INFO - 2018-09-30 09:25:59 --> URI Class Initialized
INFO - 2018-09-30 09:25:59 --> Router Class Initialized
INFO - 2018-09-30 09:25:59 --> Output Class Initialized
INFO - 2018-09-30 09:25:59 --> Security Class Initialized
DEBUG - 2018-09-30 09:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:25:59 --> Input Class Initialized
INFO - 2018-09-30 09:25:59 --> Language Class Initialized
INFO - 2018-09-30 09:25:59 --> Loader Class Initialized
INFO - 2018-09-30 09:25:59 --> Helper loaded: url_helper
INFO - 2018-09-30 09:25:59 --> Helper loaded: form_helper
INFO - 2018-09-30 09:25:59 --> Helper loaded: html_helper
INFO - 2018-09-30 09:25:59 --> Database Driver Class Initialized
INFO - 2018-09-30 09:25:59 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:25:59 --> Model "User_model" initialized
INFO - 2018-09-30 09:25:59 --> Model "Project_model" initialized
INFO - 2018-09-30 09:25:59 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:25:59 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:25:59 --> Controller Class Initialized
INFO - 2018-09-30 09:25:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-30 09:25:59 --> Severity: Notice --> Trying to get property 'project_name' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 3
ERROR - 2018-09-30 09:25:59 --> Severity: Notice --> Trying to get property 'date_created' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 4
ERROR - 2018-09-30 09:25:59 --> Severity: Notice --> Trying to get property 'project_body' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 7
ERROR - 2018-09-30 09:25:59 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 27
ERROR - 2018-09-30 09:25:59 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 53
ERROR - 2018-09-30 09:25:59 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 69
ERROR - 2018-09-30 09:25:59 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 74
ERROR - 2018-09-30 09:25:59 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 79
INFO - 2018-09-30 09:25:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 09:25:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:25:59 --> Final output sent to browser
DEBUG - 2018-09-30 09:25:59 --> Total execution time: 0.0490
INFO - 2018-09-30 09:26:08 --> Config Class Initialized
INFO - 2018-09-30 09:26:08 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:26:08 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:26:08 --> Utf8 Class Initialized
INFO - 2018-09-30 09:26:08 --> URI Class Initialized
INFO - 2018-09-30 09:26:08 --> Router Class Initialized
INFO - 2018-09-30 09:26:08 --> Output Class Initialized
INFO - 2018-09-30 09:26:08 --> Security Class Initialized
DEBUG - 2018-09-30 09:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:26:08 --> Input Class Initialized
INFO - 2018-09-30 09:26:08 --> Language Class Initialized
INFO - 2018-09-30 09:26:08 --> Loader Class Initialized
INFO - 2018-09-30 09:26:08 --> Helper loaded: url_helper
INFO - 2018-09-30 09:26:08 --> Helper loaded: form_helper
INFO - 2018-09-30 09:26:08 --> Helper loaded: html_helper
INFO - 2018-09-30 09:26:08 --> Database Driver Class Initialized
INFO - 2018-09-30 09:26:08 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:26:08 --> Model "User_model" initialized
INFO - 2018-09-30 09:26:08 --> Model "Project_model" initialized
INFO - 2018-09-30 09:26:08 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:26:08 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:26:08 --> Controller Class Initialized
INFO - 2018-09-30 09:26:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-30 09:26:08 --> Severity: Notice --> Trying to get property 'project_name' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 3
ERROR - 2018-09-30 09:26:08 --> Severity: Notice --> Trying to get property 'date_created' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 4
ERROR - 2018-09-30 09:26:08 --> Severity: Notice --> Trying to get property 'project_body' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 7
ERROR - 2018-09-30 09:26:08 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 27
ERROR - 2018-09-30 09:26:08 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 53
ERROR - 2018-09-30 09:26:08 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 69
ERROR - 2018-09-30 09:26:08 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 74
ERROR - 2018-09-30 09:26:08 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 79
INFO - 2018-09-30 09:26:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 09:26:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:26:08 --> Final output sent to browser
DEBUG - 2018-09-30 09:26:08 --> Total execution time: 0.0650
INFO - 2018-09-30 09:27:33 --> Config Class Initialized
INFO - 2018-09-30 09:27:33 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:27:33 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:27:33 --> Utf8 Class Initialized
INFO - 2018-09-30 09:27:33 --> URI Class Initialized
INFO - 2018-09-30 09:27:33 --> Router Class Initialized
INFO - 2018-09-30 09:27:33 --> Output Class Initialized
INFO - 2018-09-30 09:27:33 --> Security Class Initialized
DEBUG - 2018-09-30 09:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:27:33 --> Input Class Initialized
INFO - 2018-09-30 09:27:33 --> Language Class Initialized
INFO - 2018-09-30 09:27:33 --> Loader Class Initialized
INFO - 2018-09-30 09:27:33 --> Helper loaded: url_helper
INFO - 2018-09-30 09:27:33 --> Helper loaded: form_helper
INFO - 2018-09-30 09:27:33 --> Helper loaded: html_helper
INFO - 2018-09-30 09:27:33 --> Database Driver Class Initialized
INFO - 2018-09-30 09:27:33 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:27:33 --> Model "User_model" initialized
INFO - 2018-09-30 09:27:33 --> Model "Project_model" initialized
INFO - 2018-09-30 09:27:33 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:27:33 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:27:33 --> Controller Class Initialized
INFO - 2018-09-30 09:27:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:27:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 09:27:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:27:33 --> Final output sent to browser
DEBUG - 2018-09-30 09:27:33 --> Total execution time: 0.0580
INFO - 2018-09-30 09:28:34 --> Config Class Initialized
INFO - 2018-09-30 09:28:34 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:28:34 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:28:34 --> Utf8 Class Initialized
INFO - 2018-09-30 09:28:34 --> URI Class Initialized
INFO - 2018-09-30 09:28:34 --> Router Class Initialized
INFO - 2018-09-30 09:28:34 --> Output Class Initialized
INFO - 2018-09-30 09:28:34 --> Security Class Initialized
DEBUG - 2018-09-30 09:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:28:34 --> Input Class Initialized
INFO - 2018-09-30 09:28:34 --> Language Class Initialized
INFO - 2018-09-30 09:28:34 --> Loader Class Initialized
INFO - 2018-09-30 09:28:34 --> Helper loaded: url_helper
INFO - 2018-09-30 09:28:34 --> Helper loaded: form_helper
INFO - 2018-09-30 09:28:34 --> Helper loaded: html_helper
INFO - 2018-09-30 09:28:34 --> Database Driver Class Initialized
INFO - 2018-09-30 09:28:34 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:28:34 --> Model "User_model" initialized
INFO - 2018-09-30 09:28:34 --> Model "Project_model" initialized
INFO - 2018-09-30 09:28:34 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:28:34 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:28:34 --> Controller Class Initialized
INFO - 2018-09-30 09:28:34 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-30 09:28:34 --> Severity: Notice --> Trying to get property 'project_name' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 3
ERROR - 2018-09-30 09:28:34 --> Severity: Notice --> Trying to get property 'date_created' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 4
ERROR - 2018-09-30 09:28:34 --> Severity: Notice --> Trying to get property 'project_body' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 7
ERROR - 2018-09-30 09:28:34 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 27
ERROR - 2018-09-30 09:28:34 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 53
ERROR - 2018-09-30 09:28:34 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 69
ERROR - 2018-09-30 09:28:34 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 74
ERROR - 2018-09-30 09:28:34 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 79
INFO - 2018-09-30 09:28:34 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 09:28:34 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:28:34 --> Final output sent to browser
DEBUG - 2018-09-30 09:28:34 --> Total execution time: 0.0570
INFO - 2018-09-30 09:32:17 --> Config Class Initialized
INFO - 2018-09-30 09:32:17 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:32:17 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:32:17 --> Utf8 Class Initialized
INFO - 2018-09-30 09:32:17 --> URI Class Initialized
INFO - 2018-09-30 09:32:17 --> Router Class Initialized
INFO - 2018-09-30 09:32:17 --> Output Class Initialized
INFO - 2018-09-30 09:32:17 --> Security Class Initialized
DEBUG - 2018-09-30 09:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:32:17 --> Input Class Initialized
INFO - 2018-09-30 09:32:17 --> Language Class Initialized
INFO - 2018-09-30 09:32:17 --> Loader Class Initialized
INFO - 2018-09-30 09:32:17 --> Helper loaded: url_helper
INFO - 2018-09-30 09:32:17 --> Helper loaded: form_helper
INFO - 2018-09-30 09:32:17 --> Helper loaded: html_helper
INFO - 2018-09-30 09:32:17 --> Database Driver Class Initialized
INFO - 2018-09-30 09:32:17 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:32:17 --> Model "User_model" initialized
INFO - 2018-09-30 09:32:17 --> Model "Project_model" initialized
INFO - 2018-09-30 09:32:17 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:32:17 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:32:17 --> Controller Class Initialized
INFO - 2018-09-30 09:32:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-30 09:32:17 --> Severity: Notice --> Trying to get property 'project_name' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 3
ERROR - 2018-09-30 09:32:17 --> Severity: Notice --> Trying to get property 'date_created' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 4
ERROR - 2018-09-30 09:32:17 --> Severity: Notice --> Trying to get property 'project_body' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 7
ERROR - 2018-09-30 09:32:17 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 27
ERROR - 2018-09-30 09:32:17 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 53
ERROR - 2018-09-30 09:32:17 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 69
ERROR - 2018-09-30 09:32:17 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 74
ERROR - 2018-09-30 09:32:17 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 79
INFO - 2018-09-30 09:32:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 09:32:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:32:17 --> Final output sent to browser
DEBUG - 2018-09-30 09:32:17 --> Total execution time: 0.0520
INFO - 2018-09-30 09:32:25 --> Config Class Initialized
INFO - 2018-09-30 09:32:25 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:32:25 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:32:25 --> Utf8 Class Initialized
INFO - 2018-09-30 09:32:25 --> URI Class Initialized
INFO - 2018-09-30 09:32:25 --> Router Class Initialized
INFO - 2018-09-30 09:32:25 --> Output Class Initialized
INFO - 2018-09-30 09:32:25 --> Security Class Initialized
DEBUG - 2018-09-30 09:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:32:25 --> Input Class Initialized
INFO - 2018-09-30 09:32:25 --> Language Class Initialized
INFO - 2018-09-30 09:32:25 --> Loader Class Initialized
INFO - 2018-09-30 09:32:25 --> Helper loaded: url_helper
INFO - 2018-09-30 09:32:25 --> Helper loaded: form_helper
INFO - 2018-09-30 09:32:25 --> Helper loaded: html_helper
INFO - 2018-09-30 09:32:25 --> Database Driver Class Initialized
INFO - 2018-09-30 09:32:25 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:32:25 --> Model "User_model" initialized
INFO - 2018-09-30 09:32:25 --> Model "Project_model" initialized
INFO - 2018-09-30 09:32:25 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:32:25 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:32:25 --> Controller Class Initialized
INFO - 2018-09-30 09:32:25 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-30 09:32:25 --> Severity: Notice --> Trying to get property 'project_name' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 3
ERROR - 2018-09-30 09:32:25 --> Severity: Notice --> Trying to get property 'date_created' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 4
ERROR - 2018-09-30 09:32:25 --> Severity: Notice --> Trying to get property 'project_body' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 7
ERROR - 2018-09-30 09:32:25 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 27
ERROR - 2018-09-30 09:32:25 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 53
ERROR - 2018-09-30 09:32:25 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 69
ERROR - 2018-09-30 09:32:25 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 74
ERROR - 2018-09-30 09:32:25 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 79
INFO - 2018-09-30 09:32:25 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 09:32:25 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:32:25 --> Final output sent to browser
DEBUG - 2018-09-30 09:32:25 --> Total execution time: 0.0490
INFO - 2018-09-30 09:33:48 --> Config Class Initialized
INFO - 2018-09-30 09:33:48 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:33:48 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:33:48 --> Utf8 Class Initialized
INFO - 2018-09-30 09:33:48 --> URI Class Initialized
INFO - 2018-09-30 09:33:48 --> Router Class Initialized
INFO - 2018-09-30 09:33:48 --> Output Class Initialized
INFO - 2018-09-30 09:33:48 --> Security Class Initialized
DEBUG - 2018-09-30 09:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:33:48 --> Input Class Initialized
INFO - 2018-09-30 09:33:48 --> Language Class Initialized
INFO - 2018-09-30 09:33:48 --> Loader Class Initialized
INFO - 2018-09-30 09:33:48 --> Helper loaded: url_helper
INFO - 2018-09-30 09:33:48 --> Helper loaded: form_helper
INFO - 2018-09-30 09:33:48 --> Helper loaded: html_helper
INFO - 2018-09-30 09:33:48 --> Database Driver Class Initialized
INFO - 2018-09-30 09:33:48 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:33:48 --> Model "User_model" initialized
INFO - 2018-09-30 09:33:48 --> Model "Project_model" initialized
INFO - 2018-09-30 09:33:48 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:33:48 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:33:48 --> Controller Class Initialized
INFO - 2018-09-30 09:33:48 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-30 09:33:48 --> Severity: Notice --> Trying to get property 'date_created' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 4
ERROR - 2018-09-30 09:33:48 --> Severity: Notice --> Trying to get property 'project_body' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 7
ERROR - 2018-09-30 09:33:48 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 27
ERROR - 2018-09-30 09:33:48 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 53
ERROR - 2018-09-30 09:33:48 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 69
ERROR - 2018-09-30 09:33:48 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 74
ERROR - 2018-09-30 09:33:48 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 79
INFO - 2018-09-30 09:33:48 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 09:33:48 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:33:48 --> Final output sent to browser
DEBUG - 2018-09-30 09:33:48 --> Total execution time: 0.0620
INFO - 2018-09-30 09:34:13 --> Config Class Initialized
INFO - 2018-09-30 09:34:13 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:34:13 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:34:13 --> Utf8 Class Initialized
INFO - 2018-09-30 09:34:13 --> URI Class Initialized
INFO - 2018-09-30 09:34:13 --> Router Class Initialized
INFO - 2018-09-30 09:34:13 --> Output Class Initialized
INFO - 2018-09-30 09:34:13 --> Security Class Initialized
DEBUG - 2018-09-30 09:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:34:13 --> Input Class Initialized
INFO - 2018-09-30 09:34:13 --> Language Class Initialized
INFO - 2018-09-30 09:34:13 --> Loader Class Initialized
INFO - 2018-09-30 09:34:13 --> Helper loaded: url_helper
INFO - 2018-09-30 09:34:13 --> Helper loaded: form_helper
INFO - 2018-09-30 09:34:13 --> Helper loaded: html_helper
INFO - 2018-09-30 09:34:13 --> Database Driver Class Initialized
INFO - 2018-09-30 09:34:13 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:34:13 --> Model "User_model" initialized
INFO - 2018-09-30 09:34:13 --> Model "Project_model" initialized
INFO - 2018-09-30 09:34:13 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:34:13 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:34:13 --> Controller Class Initialized
INFO - 2018-09-30 09:34:13 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-30 09:34:13 --> Severity: Notice --> Trying to get property 'project_body' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 7
ERROR - 2018-09-30 09:34:13 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 27
ERROR - 2018-09-30 09:34:13 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 53
ERROR - 2018-09-30 09:34:13 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 69
ERROR - 2018-09-30 09:34:13 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 74
ERROR - 2018-09-30 09:34:13 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 79
INFO - 2018-09-30 09:34:13 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 09:34:13 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:34:13 --> Final output sent to browser
DEBUG - 2018-09-30 09:34:13 --> Total execution time: 0.0580
INFO - 2018-09-30 09:34:32 --> Config Class Initialized
INFO - 2018-09-30 09:34:32 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:34:32 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:34:32 --> Utf8 Class Initialized
INFO - 2018-09-30 09:34:32 --> URI Class Initialized
INFO - 2018-09-30 09:34:32 --> Router Class Initialized
INFO - 2018-09-30 09:34:32 --> Output Class Initialized
INFO - 2018-09-30 09:34:32 --> Security Class Initialized
DEBUG - 2018-09-30 09:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:34:32 --> Input Class Initialized
INFO - 2018-09-30 09:34:32 --> Language Class Initialized
INFO - 2018-09-30 09:34:32 --> Loader Class Initialized
INFO - 2018-09-30 09:34:32 --> Helper loaded: url_helper
INFO - 2018-09-30 09:34:32 --> Helper loaded: form_helper
INFO - 2018-09-30 09:34:32 --> Helper loaded: html_helper
INFO - 2018-09-30 09:34:32 --> Database Driver Class Initialized
INFO - 2018-09-30 09:34:32 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:34:32 --> Model "User_model" initialized
INFO - 2018-09-30 09:34:32 --> Model "Project_model" initialized
INFO - 2018-09-30 09:34:32 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:34:32 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:34:32 --> Controller Class Initialized
INFO - 2018-09-30 09:34:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-30 09:34:32 --> Severity: Warning --> Use of undefined constant project_body - assumed 'project_body' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 7
ERROR - 2018-09-30 09:34:32 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 27
ERROR - 2018-09-30 09:34:32 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 53
ERROR - 2018-09-30 09:34:32 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 69
ERROR - 2018-09-30 09:34:32 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 74
ERROR - 2018-09-30 09:34:32 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 79
INFO - 2018-09-30 09:34:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 09:34:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:34:32 --> Final output sent to browser
DEBUG - 2018-09-30 09:34:32 --> Total execution time: 0.1120
INFO - 2018-09-30 09:35:47 --> Config Class Initialized
INFO - 2018-09-30 09:35:47 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:35:47 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:35:47 --> Utf8 Class Initialized
INFO - 2018-09-30 09:35:47 --> URI Class Initialized
INFO - 2018-09-30 09:35:47 --> Router Class Initialized
INFO - 2018-09-30 09:35:47 --> Output Class Initialized
INFO - 2018-09-30 09:35:47 --> Security Class Initialized
DEBUG - 2018-09-30 09:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:35:47 --> Input Class Initialized
INFO - 2018-09-30 09:35:47 --> Language Class Initialized
INFO - 2018-09-30 09:35:47 --> Loader Class Initialized
INFO - 2018-09-30 09:35:47 --> Helper loaded: url_helper
INFO - 2018-09-30 09:35:47 --> Helper loaded: form_helper
INFO - 2018-09-30 09:35:47 --> Helper loaded: html_helper
INFO - 2018-09-30 09:35:47 --> Database Driver Class Initialized
INFO - 2018-09-30 09:35:47 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:35:47 --> Model "User_model" initialized
INFO - 2018-09-30 09:35:47 --> Model "Project_model" initialized
INFO - 2018-09-30 09:35:47 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:35:47 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:35:47 --> Controller Class Initialized
INFO - 2018-09-30 09:35:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-30 09:35:47 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 27
ERROR - 2018-09-30 09:35:47 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 53
ERROR - 2018-09-30 09:35:47 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 69
ERROR - 2018-09-30 09:35:47 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 74
ERROR - 2018-09-30 09:35:47 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 79
INFO - 2018-09-30 09:35:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 09:35:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:35:47 --> Final output sent to browser
DEBUG - 2018-09-30 09:35:47 --> Total execution time: 0.0520
INFO - 2018-09-30 09:36:21 --> Config Class Initialized
INFO - 2018-09-30 09:36:21 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:36:21 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:36:21 --> Utf8 Class Initialized
INFO - 2018-09-30 09:36:21 --> URI Class Initialized
INFO - 2018-09-30 09:36:21 --> Router Class Initialized
INFO - 2018-09-30 09:36:21 --> Output Class Initialized
INFO - 2018-09-30 09:36:21 --> Security Class Initialized
DEBUG - 2018-09-30 09:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:36:21 --> Input Class Initialized
INFO - 2018-09-30 09:36:21 --> Language Class Initialized
INFO - 2018-09-30 09:36:21 --> Loader Class Initialized
INFO - 2018-09-30 09:36:21 --> Helper loaded: url_helper
INFO - 2018-09-30 09:36:21 --> Helper loaded: form_helper
INFO - 2018-09-30 09:36:21 --> Helper loaded: html_helper
INFO - 2018-09-30 09:36:21 --> Database Driver Class Initialized
INFO - 2018-09-30 09:36:21 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:36:21 --> Model "User_model" initialized
INFO - 2018-09-30 09:36:21 --> Model "Project_model" initialized
INFO - 2018-09-30 09:36:21 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:36:21 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:36:21 --> Controller Class Initialized
INFO - 2018-09-30 09:36:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-30 09:36:21 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 53
ERROR - 2018-09-30 09:36:21 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 69
ERROR - 2018-09-30 09:36:21 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 74
ERROR - 2018-09-30 09:36:21 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 79
INFO - 2018-09-30 09:36:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 09:36:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:36:21 --> Final output sent to browser
DEBUG - 2018-09-30 09:36:21 --> Total execution time: 0.0400
INFO - 2018-09-30 09:38:04 --> Config Class Initialized
INFO - 2018-09-30 09:38:04 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:38:04 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:38:04 --> Utf8 Class Initialized
INFO - 2018-09-30 09:38:04 --> URI Class Initialized
INFO - 2018-09-30 09:38:04 --> Router Class Initialized
INFO - 2018-09-30 09:38:04 --> Output Class Initialized
INFO - 2018-09-30 09:38:04 --> Security Class Initialized
DEBUG - 2018-09-30 09:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:38:04 --> Input Class Initialized
INFO - 2018-09-30 09:38:04 --> Language Class Initialized
INFO - 2018-09-30 09:38:04 --> Loader Class Initialized
INFO - 2018-09-30 09:38:04 --> Helper loaded: url_helper
INFO - 2018-09-30 09:38:04 --> Helper loaded: form_helper
INFO - 2018-09-30 09:38:04 --> Helper loaded: html_helper
INFO - 2018-09-30 09:38:04 --> Database Driver Class Initialized
INFO - 2018-09-30 09:38:04 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:38:04 --> Model "User_model" initialized
INFO - 2018-09-30 09:38:04 --> Model "Project_model" initialized
INFO - 2018-09-30 09:38:04 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:38:04 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:38:04 --> Controller Class Initialized
INFO - 2018-09-30 09:38:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:38:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 09:38:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:38:04 --> Final output sent to browser
DEBUG - 2018-09-30 09:38:04 --> Total execution time: 0.0710
INFO - 2018-09-30 09:38:10 --> Config Class Initialized
INFO - 2018-09-30 09:38:10 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:38:10 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:38:10 --> Utf8 Class Initialized
INFO - 2018-09-30 09:38:10 --> URI Class Initialized
INFO - 2018-09-30 09:38:10 --> Router Class Initialized
INFO - 2018-09-30 09:38:10 --> Output Class Initialized
INFO - 2018-09-30 09:38:10 --> Security Class Initialized
DEBUG - 2018-09-30 09:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:38:10 --> Input Class Initialized
INFO - 2018-09-30 09:38:10 --> Language Class Initialized
INFO - 2018-09-30 09:38:10 --> Loader Class Initialized
INFO - 2018-09-30 09:38:10 --> Helper loaded: url_helper
INFO - 2018-09-30 09:38:10 --> Helper loaded: form_helper
INFO - 2018-09-30 09:38:10 --> Helper loaded: html_helper
INFO - 2018-09-30 09:38:10 --> Database Driver Class Initialized
INFO - 2018-09-30 09:38:10 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:38:10 --> Model "User_model" initialized
INFO - 2018-09-30 09:38:10 --> Model "Project_model" initialized
INFO - 2018-09-30 09:38:10 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:38:10 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:38:10 --> Controller Class Initialized
INFO - 2018-09-30 09:38:10 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:38:10 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 09:38:10 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:38:10 --> Final output sent to browser
DEBUG - 2018-09-30 09:38:10 --> Total execution time: 0.0420
INFO - 2018-09-30 09:38:16 --> Config Class Initialized
INFO - 2018-09-30 09:38:16 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:38:16 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:38:16 --> Utf8 Class Initialized
INFO - 2018-09-30 09:38:16 --> URI Class Initialized
INFO - 2018-09-30 09:38:16 --> Router Class Initialized
INFO - 2018-09-30 09:38:16 --> Output Class Initialized
INFO - 2018-09-30 09:38:16 --> Security Class Initialized
DEBUG - 2018-09-30 09:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:38:16 --> Input Class Initialized
INFO - 2018-09-30 09:38:16 --> Language Class Initialized
INFO - 2018-09-30 09:38:16 --> Loader Class Initialized
INFO - 2018-09-30 09:38:16 --> Helper loaded: url_helper
INFO - 2018-09-30 09:38:16 --> Helper loaded: form_helper
INFO - 2018-09-30 09:38:16 --> Helper loaded: html_helper
INFO - 2018-09-30 09:38:16 --> Database Driver Class Initialized
INFO - 2018-09-30 09:38:16 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:38:16 --> Model "User_model" initialized
INFO - 2018-09-30 09:38:16 --> Model "Project_model" initialized
INFO - 2018-09-30 09:38:16 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:38:16 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:38:16 --> Controller Class Initialized
INFO - 2018-09-30 09:38:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-30 09:38:16 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 3
INFO - 2018-09-30 09:44:55 --> Config Class Initialized
INFO - 2018-09-30 09:44:55 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:44:55 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:44:55 --> Utf8 Class Initialized
INFO - 2018-09-30 09:44:55 --> URI Class Initialized
INFO - 2018-09-30 09:44:55 --> Router Class Initialized
INFO - 2018-09-30 09:44:55 --> Output Class Initialized
INFO - 2018-09-30 09:44:55 --> Security Class Initialized
DEBUG - 2018-09-30 09:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:44:55 --> Input Class Initialized
INFO - 2018-09-30 09:44:55 --> Language Class Initialized
INFO - 2018-09-30 09:44:55 --> Loader Class Initialized
INFO - 2018-09-30 09:44:55 --> Helper loaded: url_helper
INFO - 2018-09-30 09:44:55 --> Helper loaded: form_helper
INFO - 2018-09-30 09:44:55 --> Helper loaded: html_helper
INFO - 2018-09-30 09:44:55 --> Database Driver Class Initialized
INFO - 2018-09-30 09:44:55 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:44:55 --> Model "User_model" initialized
INFO - 2018-09-30 09:44:55 --> Model "Project_model" initialized
INFO - 2018-09-30 09:44:55 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:44:55 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:44:55 --> Controller Class Initialized
INFO - 2018-09-30 09:44:55 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:44:55 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 09:44:55 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:44:55 --> Final output sent to browser
DEBUG - 2018-09-30 09:44:55 --> Total execution time: 0.0500
INFO - 2018-09-30 09:44:57 --> Config Class Initialized
INFO - 2018-09-30 09:44:57 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:44:57 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:44:57 --> Utf8 Class Initialized
INFO - 2018-09-30 09:44:57 --> URI Class Initialized
INFO - 2018-09-30 09:44:57 --> Router Class Initialized
INFO - 2018-09-30 09:44:57 --> Output Class Initialized
INFO - 2018-09-30 09:44:57 --> Security Class Initialized
DEBUG - 2018-09-30 09:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:44:57 --> Input Class Initialized
INFO - 2018-09-30 09:44:57 --> Language Class Initialized
INFO - 2018-09-30 09:44:57 --> Loader Class Initialized
INFO - 2018-09-30 09:44:57 --> Helper loaded: url_helper
INFO - 2018-09-30 09:44:57 --> Helper loaded: form_helper
INFO - 2018-09-30 09:44:57 --> Helper loaded: html_helper
INFO - 2018-09-30 09:44:57 --> Database Driver Class Initialized
INFO - 2018-09-30 09:44:57 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:44:57 --> Model "User_model" initialized
INFO - 2018-09-30 09:44:57 --> Model "Project_model" initialized
INFO - 2018-09-30 09:44:57 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:44:57 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:44:57 --> Controller Class Initialized
INFO - 2018-09-30 09:44:57 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:44:57 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 09:44:57 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:44:57 --> Final output sent to browser
DEBUG - 2018-09-30 09:44:57 --> Total execution time: 0.0640
INFO - 2018-09-30 09:45:31 --> Config Class Initialized
INFO - 2018-09-30 09:45:31 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:45:31 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:45:31 --> Utf8 Class Initialized
INFO - 2018-09-30 09:45:31 --> URI Class Initialized
INFO - 2018-09-30 09:45:31 --> Router Class Initialized
INFO - 2018-09-30 09:45:31 --> Output Class Initialized
INFO - 2018-09-30 09:45:31 --> Security Class Initialized
DEBUG - 2018-09-30 09:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:45:31 --> Input Class Initialized
INFO - 2018-09-30 09:45:31 --> Language Class Initialized
INFO - 2018-09-30 09:45:31 --> Loader Class Initialized
INFO - 2018-09-30 09:45:31 --> Helper loaded: url_helper
INFO - 2018-09-30 09:45:31 --> Helper loaded: form_helper
INFO - 2018-09-30 09:45:31 --> Helper loaded: html_helper
INFO - 2018-09-30 09:45:31 --> Database Driver Class Initialized
INFO - 2018-09-30 09:45:31 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:45:31 --> Model "User_model" initialized
INFO - 2018-09-30 09:45:31 --> Model "Project_model" initialized
INFO - 2018-09-30 09:45:31 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:45:31 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:45:31 --> Controller Class Initialized
INFO - 2018-09-30 09:45:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:45:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 09:45:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:45:31 --> Final output sent to browser
DEBUG - 2018-09-30 09:45:31 --> Total execution time: 0.0560
INFO - 2018-09-30 09:45:46 --> Config Class Initialized
INFO - 2018-09-30 09:45:46 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:45:46 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:45:46 --> Utf8 Class Initialized
INFO - 2018-09-30 09:45:46 --> URI Class Initialized
INFO - 2018-09-30 09:45:46 --> Router Class Initialized
INFO - 2018-09-30 09:45:46 --> Output Class Initialized
INFO - 2018-09-30 09:45:46 --> Security Class Initialized
DEBUG - 2018-09-30 09:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:45:46 --> Input Class Initialized
INFO - 2018-09-30 09:45:46 --> Language Class Initialized
INFO - 2018-09-30 09:45:46 --> Loader Class Initialized
INFO - 2018-09-30 09:45:46 --> Helper loaded: url_helper
INFO - 2018-09-30 09:45:46 --> Helper loaded: form_helper
INFO - 2018-09-30 09:45:46 --> Helper loaded: html_helper
INFO - 2018-09-30 09:45:46 --> Database Driver Class Initialized
INFO - 2018-09-30 09:45:46 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:45:46 --> Model "User_model" initialized
INFO - 2018-09-30 09:45:46 --> Model "Project_model" initialized
INFO - 2018-09-30 09:45:46 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:45:46 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:45:46 --> Controller Class Initialized
INFO - 2018-09-30 09:45:46 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:45:46 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 09:45:46 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:45:46 --> Final output sent to browser
DEBUG - 2018-09-30 09:45:46 --> Total execution time: 0.0610
INFO - 2018-09-30 09:45:47 --> Config Class Initialized
INFO - 2018-09-30 09:45:47 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:45:47 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:45:47 --> Utf8 Class Initialized
INFO - 2018-09-30 09:45:47 --> URI Class Initialized
INFO - 2018-09-30 09:45:47 --> Router Class Initialized
INFO - 2018-09-30 09:45:47 --> Output Class Initialized
INFO - 2018-09-30 09:45:47 --> Security Class Initialized
DEBUG - 2018-09-30 09:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:45:47 --> Input Class Initialized
INFO - 2018-09-30 09:45:47 --> Language Class Initialized
INFO - 2018-09-30 09:45:47 --> Loader Class Initialized
INFO - 2018-09-30 09:45:47 --> Helper loaded: url_helper
INFO - 2018-09-30 09:45:47 --> Helper loaded: form_helper
INFO - 2018-09-30 09:45:47 --> Helper loaded: html_helper
INFO - 2018-09-30 09:45:47 --> Database Driver Class Initialized
INFO - 2018-09-30 09:45:47 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:45:47 --> Model "User_model" initialized
INFO - 2018-09-30 09:45:47 --> Model "Project_model" initialized
INFO - 2018-09-30 09:45:47 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:45:47 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:45:47 --> Controller Class Initialized
INFO - 2018-09-30 09:45:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:45:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 09:45:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:45:47 --> Final output sent to browser
DEBUG - 2018-09-30 09:45:47 --> Total execution time: 0.0610
INFO - 2018-09-30 09:45:48 --> Config Class Initialized
INFO - 2018-09-30 09:45:48 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:45:48 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:45:48 --> Utf8 Class Initialized
INFO - 2018-09-30 09:45:48 --> URI Class Initialized
INFO - 2018-09-30 09:45:48 --> Router Class Initialized
INFO - 2018-09-30 09:45:49 --> Output Class Initialized
INFO - 2018-09-30 09:45:49 --> Security Class Initialized
DEBUG - 2018-09-30 09:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:45:49 --> Input Class Initialized
INFO - 2018-09-30 09:45:49 --> Language Class Initialized
INFO - 2018-09-30 09:45:49 --> Loader Class Initialized
INFO - 2018-09-30 09:45:49 --> Helper loaded: url_helper
INFO - 2018-09-30 09:45:49 --> Helper loaded: form_helper
INFO - 2018-09-30 09:45:49 --> Helper loaded: html_helper
INFO - 2018-09-30 09:45:49 --> Database Driver Class Initialized
INFO - 2018-09-30 09:45:49 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:45:49 --> Model "User_model" initialized
INFO - 2018-09-30 09:45:49 --> Model "Project_model" initialized
INFO - 2018-09-30 09:45:49 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:45:49 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:45:49 --> Controller Class Initialized
INFO - 2018-09-30 09:45:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-30 09:45:49 --> Severity: Notice --> Trying to get property 'project_name' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 3
ERROR - 2018-09-30 09:45:49 --> Severity: Notice --> Trying to get property 'date_created' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 4
ERROR - 2018-09-30 09:45:49 --> Severity: Notice --> Trying to get property 'project_body' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 7
ERROR - 2018-09-30 09:45:49 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 27
ERROR - 2018-09-30 09:45:49 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 53
ERROR - 2018-09-30 09:45:49 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 69
ERROR - 2018-09-30 09:45:49 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 74
ERROR - 2018-09-30 09:45:49 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 79
INFO - 2018-09-30 09:45:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 09:45:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:45:49 --> Final output sent to browser
DEBUG - 2018-09-30 09:45:49 --> Total execution time: 0.0630
INFO - 2018-09-30 09:45:54 --> Config Class Initialized
INFO - 2018-09-30 09:45:54 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:45:54 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:45:54 --> Utf8 Class Initialized
INFO - 2018-09-30 09:45:54 --> URI Class Initialized
INFO - 2018-09-30 09:45:54 --> Router Class Initialized
INFO - 2018-09-30 09:45:54 --> Output Class Initialized
INFO - 2018-09-30 09:45:54 --> Security Class Initialized
DEBUG - 2018-09-30 09:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:45:54 --> Input Class Initialized
INFO - 2018-09-30 09:45:54 --> Language Class Initialized
INFO - 2018-09-30 09:45:54 --> Loader Class Initialized
INFO - 2018-09-30 09:45:54 --> Helper loaded: url_helper
INFO - 2018-09-30 09:45:54 --> Helper loaded: form_helper
INFO - 2018-09-30 09:45:54 --> Helper loaded: html_helper
INFO - 2018-09-30 09:45:54 --> Database Driver Class Initialized
INFO - 2018-09-30 09:45:54 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:45:54 --> Model "User_model" initialized
INFO - 2018-09-30 09:45:54 --> Model "Project_model" initialized
INFO - 2018-09-30 09:45:54 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:45:54 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:45:54 --> Controller Class Initialized
INFO - 2018-09-30 09:45:54 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:45:54 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 09:45:54 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:45:54 --> Final output sent to browser
DEBUG - 2018-09-30 09:45:54 --> Total execution time: 0.0420
INFO - 2018-09-30 09:45:56 --> Config Class Initialized
INFO - 2018-09-30 09:45:56 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:45:56 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:45:56 --> Utf8 Class Initialized
INFO - 2018-09-30 09:45:56 --> URI Class Initialized
INFO - 2018-09-30 09:45:56 --> Router Class Initialized
INFO - 2018-09-30 09:45:56 --> Output Class Initialized
INFO - 2018-09-30 09:45:56 --> Security Class Initialized
DEBUG - 2018-09-30 09:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:45:56 --> Input Class Initialized
INFO - 2018-09-30 09:45:56 --> Language Class Initialized
INFO - 2018-09-30 09:45:56 --> Loader Class Initialized
INFO - 2018-09-30 09:45:56 --> Helper loaded: url_helper
INFO - 2018-09-30 09:45:56 --> Helper loaded: form_helper
INFO - 2018-09-30 09:45:56 --> Helper loaded: html_helper
INFO - 2018-09-30 09:45:56 --> Database Driver Class Initialized
INFO - 2018-09-30 09:45:56 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:45:56 --> Model "User_model" initialized
INFO - 2018-09-30 09:45:56 --> Model "Project_model" initialized
INFO - 2018-09-30 09:45:56 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:45:56 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:45:56 --> Controller Class Initialized
INFO - 2018-09-30 09:45:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:45:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 09:45:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:45:56 --> Final output sent to browser
DEBUG - 2018-09-30 09:45:56 --> Total execution time: 0.0580
INFO - 2018-09-30 09:47:05 --> Config Class Initialized
INFO - 2018-09-30 09:47:05 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:47:05 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:47:05 --> Utf8 Class Initialized
INFO - 2018-09-30 09:47:05 --> URI Class Initialized
INFO - 2018-09-30 09:47:05 --> Router Class Initialized
INFO - 2018-09-30 09:47:05 --> Output Class Initialized
INFO - 2018-09-30 09:47:05 --> Security Class Initialized
DEBUG - 2018-09-30 09:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:47:05 --> Input Class Initialized
INFO - 2018-09-30 09:47:05 --> Language Class Initialized
INFO - 2018-09-30 09:47:05 --> Loader Class Initialized
INFO - 2018-09-30 09:47:05 --> Helper loaded: url_helper
INFO - 2018-09-30 09:47:05 --> Helper loaded: form_helper
INFO - 2018-09-30 09:47:05 --> Helper loaded: html_helper
INFO - 2018-09-30 09:47:05 --> Database Driver Class Initialized
INFO - 2018-09-30 09:47:05 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:47:05 --> Model "User_model" initialized
INFO - 2018-09-30 09:47:05 --> Model "Project_model" initialized
INFO - 2018-09-30 09:47:05 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:47:05 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:47:05 --> Controller Class Initialized
INFO - 2018-09-30 09:47:05 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:47:05 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 09:47:05 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:47:05 --> Final output sent to browser
DEBUG - 2018-09-30 09:47:05 --> Total execution time: 0.0630
INFO - 2018-09-30 09:47:26 --> Config Class Initialized
INFO - 2018-09-30 09:47:26 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:47:26 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:47:26 --> Utf8 Class Initialized
INFO - 2018-09-30 09:47:26 --> URI Class Initialized
INFO - 2018-09-30 09:47:26 --> Router Class Initialized
INFO - 2018-09-30 09:47:26 --> Output Class Initialized
INFO - 2018-09-30 09:47:26 --> Security Class Initialized
DEBUG - 2018-09-30 09:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:47:26 --> Input Class Initialized
INFO - 2018-09-30 09:47:26 --> Language Class Initialized
INFO - 2018-09-30 09:47:26 --> Loader Class Initialized
INFO - 2018-09-30 09:47:26 --> Helper loaded: url_helper
INFO - 2018-09-30 09:47:26 --> Helper loaded: form_helper
INFO - 2018-09-30 09:47:26 --> Helper loaded: html_helper
INFO - 2018-09-30 09:47:26 --> Database Driver Class Initialized
INFO - 2018-09-30 09:47:26 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:47:26 --> Model "User_model" initialized
INFO - 2018-09-30 09:47:26 --> Model "Project_model" initialized
INFO - 2018-09-30 09:47:26 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:47:26 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:47:26 --> Controller Class Initialized
INFO - 2018-09-30 09:47:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-30 09:47:26 --> Severity: Notice --> Trying to get property 'date_created' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 4
ERROR - 2018-09-30 09:47:26 --> Severity: Notice --> Trying to get property 'project_body' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 7
ERROR - 2018-09-30 09:47:26 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 27
ERROR - 2018-09-30 09:47:26 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 53
ERROR - 2018-09-30 09:47:26 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 69
ERROR - 2018-09-30 09:47:26 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 74
ERROR - 2018-09-30 09:47:26 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 79
INFO - 2018-09-30 09:47:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 09:47:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:47:26 --> Final output sent to browser
DEBUG - 2018-09-30 09:47:26 --> Total execution time: 0.0530
INFO - 2018-09-30 09:47:38 --> Config Class Initialized
INFO - 2018-09-30 09:47:38 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:47:38 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:47:38 --> Utf8 Class Initialized
INFO - 2018-09-30 09:47:38 --> URI Class Initialized
INFO - 2018-09-30 09:47:38 --> Router Class Initialized
INFO - 2018-09-30 09:47:38 --> Output Class Initialized
INFO - 2018-09-30 09:47:38 --> Security Class Initialized
DEBUG - 2018-09-30 09:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:47:38 --> Input Class Initialized
INFO - 2018-09-30 09:47:38 --> Language Class Initialized
INFO - 2018-09-30 09:47:38 --> Loader Class Initialized
INFO - 2018-09-30 09:47:38 --> Helper loaded: url_helper
INFO - 2018-09-30 09:47:38 --> Helper loaded: form_helper
INFO - 2018-09-30 09:47:38 --> Helper loaded: html_helper
INFO - 2018-09-30 09:47:38 --> Database Driver Class Initialized
INFO - 2018-09-30 09:47:38 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:47:38 --> Model "User_model" initialized
INFO - 2018-09-30 09:47:38 --> Model "Project_model" initialized
INFO - 2018-09-30 09:47:38 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:47:38 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:47:38 --> Controller Class Initialized
INFO - 2018-09-30 09:47:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-30 09:47:38 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 3
INFO - 2018-09-30 09:48:53 --> Config Class Initialized
INFO - 2018-09-30 09:48:53 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:48:53 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:48:53 --> Utf8 Class Initialized
INFO - 2018-09-30 09:48:53 --> URI Class Initialized
INFO - 2018-09-30 09:48:53 --> Router Class Initialized
INFO - 2018-09-30 09:48:53 --> Output Class Initialized
INFO - 2018-09-30 09:48:53 --> Security Class Initialized
DEBUG - 2018-09-30 09:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:48:53 --> Input Class Initialized
INFO - 2018-09-30 09:48:53 --> Language Class Initialized
INFO - 2018-09-30 09:48:53 --> Loader Class Initialized
INFO - 2018-09-30 09:48:53 --> Helper loaded: url_helper
INFO - 2018-09-30 09:48:53 --> Helper loaded: form_helper
INFO - 2018-09-30 09:48:53 --> Helper loaded: html_helper
INFO - 2018-09-30 09:48:53 --> Database Driver Class Initialized
INFO - 2018-09-30 09:48:53 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:48:53 --> Model "User_model" initialized
INFO - 2018-09-30 09:48:53 --> Model "Project_model" initialized
INFO - 2018-09-30 09:48:53 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:48:53 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:48:53 --> Controller Class Initialized
INFO - 2018-09-30 09:48:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:48:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 09:48:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:48:53 --> Final output sent to browser
DEBUG - 2018-09-30 09:48:53 --> Total execution time: 0.0490
INFO - 2018-09-30 09:52:21 --> Config Class Initialized
INFO - 2018-09-30 09:52:21 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:52:21 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:52:21 --> Utf8 Class Initialized
INFO - 2018-09-30 09:52:21 --> URI Class Initialized
INFO - 2018-09-30 09:52:21 --> Router Class Initialized
INFO - 2018-09-30 09:52:21 --> Output Class Initialized
INFO - 2018-09-30 09:52:21 --> Security Class Initialized
DEBUG - 2018-09-30 09:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:52:21 --> Input Class Initialized
INFO - 2018-09-30 09:52:21 --> Language Class Initialized
INFO - 2018-09-30 09:52:21 --> Loader Class Initialized
INFO - 2018-09-30 09:52:21 --> Helper loaded: url_helper
INFO - 2018-09-30 09:52:21 --> Helper loaded: form_helper
INFO - 2018-09-30 09:52:21 --> Helper loaded: html_helper
INFO - 2018-09-30 09:52:21 --> Database Driver Class Initialized
INFO - 2018-09-30 09:52:21 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:52:21 --> Model "User_model" initialized
INFO - 2018-09-30 09:52:21 --> Model "Project_model" initialized
INFO - 2018-09-30 09:52:21 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:52:21 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:52:21 --> Controller Class Initialized
INFO - 2018-09-30 09:52:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-30 09:52:21 --> Severity: Notice --> Trying to get property 'project_name' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 2
ERROR - 2018-09-30 09:52:21 --> Severity: Notice --> Trying to get property 'date_created' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 3
ERROR - 2018-09-30 09:52:21 --> Severity: Notice --> Trying to get property 'project_body' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 6
ERROR - 2018-09-30 09:52:21 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 26
ERROR - 2018-09-30 09:52:21 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 52
ERROR - 2018-09-30 09:52:21 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 68
ERROR - 2018-09-30 09:52:21 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 73
ERROR - 2018-09-30 09:52:21 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 78
INFO - 2018-09-30 09:52:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 09:52:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:52:21 --> Final output sent to browser
DEBUG - 2018-09-30 09:52:21 --> Total execution time: 0.0660
INFO - 2018-09-30 09:52:37 --> Config Class Initialized
INFO - 2018-09-30 09:52:37 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:52:37 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:52:37 --> Utf8 Class Initialized
INFO - 2018-09-30 09:52:37 --> URI Class Initialized
INFO - 2018-09-30 09:52:37 --> Router Class Initialized
INFO - 2018-09-30 09:52:37 --> Output Class Initialized
INFO - 2018-09-30 09:52:37 --> Security Class Initialized
DEBUG - 2018-09-30 09:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:52:37 --> Input Class Initialized
INFO - 2018-09-30 09:52:37 --> Language Class Initialized
INFO - 2018-09-30 09:52:37 --> Loader Class Initialized
INFO - 2018-09-30 09:52:37 --> Helper loaded: url_helper
INFO - 2018-09-30 09:52:37 --> Helper loaded: form_helper
INFO - 2018-09-30 09:52:37 --> Helper loaded: html_helper
INFO - 2018-09-30 09:52:37 --> Database Driver Class Initialized
INFO - 2018-09-30 09:52:37 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:52:37 --> Model "User_model" initialized
INFO - 2018-09-30 09:52:37 --> Model "Project_model" initialized
INFO - 2018-09-30 09:52:37 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:52:37 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:52:37 --> Controller Class Initialized
INFO - 2018-09-30 09:52:37 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:52:37 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 09:52:37 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:52:37 --> Final output sent to browser
DEBUG - 2018-09-30 09:52:37 --> Total execution time: 0.0460
INFO - 2018-09-30 09:56:27 --> Config Class Initialized
INFO - 2018-09-30 09:56:27 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:56:27 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:56:27 --> Utf8 Class Initialized
INFO - 2018-09-30 09:56:27 --> URI Class Initialized
INFO - 2018-09-30 09:56:27 --> Router Class Initialized
INFO - 2018-09-30 09:56:27 --> Output Class Initialized
INFO - 2018-09-30 09:56:27 --> Security Class Initialized
DEBUG - 2018-09-30 09:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:56:27 --> Input Class Initialized
INFO - 2018-09-30 09:56:27 --> Language Class Initialized
INFO - 2018-09-30 09:56:27 --> Loader Class Initialized
INFO - 2018-09-30 09:56:27 --> Helper loaded: url_helper
INFO - 2018-09-30 09:56:27 --> Helper loaded: form_helper
INFO - 2018-09-30 09:56:27 --> Helper loaded: html_helper
INFO - 2018-09-30 09:56:27 --> Database Driver Class Initialized
INFO - 2018-09-30 09:56:27 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:56:27 --> Model "User_model" initialized
INFO - 2018-09-30 09:56:27 --> Model "Project_model" initialized
INFO - 2018-09-30 09:56:27 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:56:27 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:56:27 --> Controller Class Initialized
ERROR - 2018-09-30 09:56:27 --> Severity: error --> Exception: Too few arguments to function CI_DB_driver::field_exists(), 1 passed in D:\xampp\htdocs\code_igniter\application\models\project_models\project_model.php on line 7 and exactly 2 expected D:\xampp\htdocs\code_igniter\system\database\DB_driver.php 1360
INFO - 2018-09-30 09:57:42 --> Config Class Initialized
INFO - 2018-09-30 09:57:42 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:57:42 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:57:42 --> Utf8 Class Initialized
INFO - 2018-09-30 09:57:42 --> URI Class Initialized
INFO - 2018-09-30 09:57:42 --> Router Class Initialized
INFO - 2018-09-30 09:57:42 --> Output Class Initialized
INFO - 2018-09-30 09:57:42 --> Security Class Initialized
DEBUG - 2018-09-30 09:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:57:42 --> Input Class Initialized
INFO - 2018-09-30 09:57:42 --> Language Class Initialized
INFO - 2018-09-30 09:57:42 --> Loader Class Initialized
INFO - 2018-09-30 09:57:42 --> Helper loaded: url_helper
INFO - 2018-09-30 09:57:42 --> Helper loaded: form_helper
INFO - 2018-09-30 09:57:42 --> Helper loaded: html_helper
INFO - 2018-09-30 09:57:42 --> Database Driver Class Initialized
INFO - 2018-09-30 09:57:42 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:57:42 --> Model "User_model" initialized
INFO - 2018-09-30 09:57:42 --> Model "Project_model" initialized
INFO - 2018-09-30 09:57:42 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:57:42 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:57:42 --> Controller Class Initialized
ERROR - 2018-09-30 09:57:42 --> Severity: error --> Exception: Too few arguments to function CI_DB_driver::field_exists(), 1 passed in D:\xampp\htdocs\code_igniter\application\models\project_models\project_model.php on line 6 and exactly 2 expected D:\xampp\htdocs\code_igniter\system\database\DB_driver.php 1360
INFO - 2018-09-30 09:57:43 --> Config Class Initialized
INFO - 2018-09-30 09:57:43 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:57:43 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:57:43 --> Utf8 Class Initialized
INFO - 2018-09-30 09:57:43 --> URI Class Initialized
INFO - 2018-09-30 09:57:43 --> Router Class Initialized
INFO - 2018-09-30 09:57:43 --> Output Class Initialized
INFO - 2018-09-30 09:57:43 --> Security Class Initialized
DEBUG - 2018-09-30 09:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:57:43 --> Input Class Initialized
INFO - 2018-09-30 09:57:43 --> Language Class Initialized
INFO - 2018-09-30 09:57:43 --> Loader Class Initialized
INFO - 2018-09-30 09:57:43 --> Helper loaded: url_helper
INFO - 2018-09-30 09:57:43 --> Helper loaded: form_helper
INFO - 2018-09-30 09:57:43 --> Helper loaded: html_helper
INFO - 2018-09-30 09:57:43 --> Database Driver Class Initialized
INFO - 2018-09-30 09:57:43 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:57:43 --> Model "User_model" initialized
INFO - 2018-09-30 09:57:43 --> Model "Project_model" initialized
INFO - 2018-09-30 09:57:43 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:57:43 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:57:43 --> Controller Class Initialized
INFO - 2018-09-30 09:57:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:57:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 09:57:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:57:43 --> Final output sent to browser
DEBUG - 2018-09-30 09:57:43 --> Total execution time: 0.0580
INFO - 2018-09-30 09:57:45 --> Config Class Initialized
INFO - 2018-09-30 09:57:45 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:57:45 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:57:45 --> Utf8 Class Initialized
INFO - 2018-09-30 09:57:45 --> URI Class Initialized
INFO - 2018-09-30 09:57:45 --> Router Class Initialized
INFO - 2018-09-30 09:57:45 --> Output Class Initialized
INFO - 2018-09-30 09:57:45 --> Security Class Initialized
DEBUG - 2018-09-30 09:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:57:45 --> Input Class Initialized
INFO - 2018-09-30 09:57:45 --> Language Class Initialized
INFO - 2018-09-30 09:57:45 --> Loader Class Initialized
INFO - 2018-09-30 09:57:45 --> Helper loaded: url_helper
INFO - 2018-09-30 09:57:45 --> Helper loaded: form_helper
INFO - 2018-09-30 09:57:45 --> Helper loaded: html_helper
INFO - 2018-09-30 09:57:45 --> Database Driver Class Initialized
INFO - 2018-09-30 09:57:45 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:57:45 --> Model "User_model" initialized
INFO - 2018-09-30 09:57:45 --> Model "Project_model" initialized
INFO - 2018-09-30 09:57:45 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:57:45 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:57:45 --> Controller Class Initialized
INFO - 2018-09-30 09:57:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:57:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 09:57:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:57:45 --> Final output sent to browser
DEBUG - 2018-09-30 09:57:45 --> Total execution time: 0.0560
INFO - 2018-09-30 09:57:46 --> Config Class Initialized
INFO - 2018-09-30 09:57:46 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:57:46 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:57:46 --> Utf8 Class Initialized
INFO - 2018-09-30 09:57:46 --> URI Class Initialized
INFO - 2018-09-30 09:57:46 --> Router Class Initialized
INFO - 2018-09-30 09:57:46 --> Output Class Initialized
INFO - 2018-09-30 09:57:46 --> Security Class Initialized
DEBUG - 2018-09-30 09:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:57:46 --> Input Class Initialized
INFO - 2018-09-30 09:57:46 --> Language Class Initialized
INFO - 2018-09-30 09:57:46 --> Loader Class Initialized
INFO - 2018-09-30 09:57:46 --> Helper loaded: url_helper
INFO - 2018-09-30 09:57:46 --> Helper loaded: form_helper
INFO - 2018-09-30 09:57:46 --> Helper loaded: html_helper
INFO - 2018-09-30 09:57:46 --> Database Driver Class Initialized
INFO - 2018-09-30 09:57:46 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:57:46 --> Model "User_model" initialized
INFO - 2018-09-30 09:57:46 --> Model "Project_model" initialized
INFO - 2018-09-30 09:57:46 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:57:46 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:57:46 --> Controller Class Initialized
ERROR - 2018-09-30 09:57:46 --> Severity: error --> Exception: Too few arguments to function CI_DB_driver::field_exists(), 1 passed in D:\xampp\htdocs\code_igniter\application\models\project_models\project_model.php on line 6 and exactly 2 expected D:\xampp\htdocs\code_igniter\system\database\DB_driver.php 1360
INFO - 2018-09-30 09:59:09 --> Config Class Initialized
INFO - 2018-09-30 09:59:09 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:59:09 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:59:09 --> Utf8 Class Initialized
INFO - 2018-09-30 09:59:09 --> URI Class Initialized
INFO - 2018-09-30 09:59:09 --> Router Class Initialized
INFO - 2018-09-30 09:59:09 --> Output Class Initialized
INFO - 2018-09-30 09:59:09 --> Security Class Initialized
DEBUG - 2018-09-30 09:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:59:09 --> Input Class Initialized
INFO - 2018-09-30 09:59:09 --> Language Class Initialized
INFO - 2018-09-30 09:59:09 --> Loader Class Initialized
INFO - 2018-09-30 09:59:09 --> Helper loaded: url_helper
INFO - 2018-09-30 09:59:09 --> Helper loaded: form_helper
INFO - 2018-09-30 09:59:09 --> Helper loaded: html_helper
INFO - 2018-09-30 09:59:09 --> Database Driver Class Initialized
INFO - 2018-09-30 09:59:09 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:59:09 --> Model "User_model" initialized
INFO - 2018-09-30 09:59:09 --> Model "Project_model" initialized
INFO - 2018-09-30 09:59:09 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:59:09 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:59:09 --> Controller Class Initialized
INFO - 2018-09-30 09:59:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:59:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 09:59:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:59:09 --> Final output sent to browser
DEBUG - 2018-09-30 09:59:09 --> Total execution time: 0.0600
INFO - 2018-09-30 09:59:11 --> Config Class Initialized
INFO - 2018-09-30 09:59:11 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:59:11 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:59:11 --> Utf8 Class Initialized
INFO - 2018-09-30 09:59:11 --> URI Class Initialized
INFO - 2018-09-30 09:59:11 --> Router Class Initialized
INFO - 2018-09-30 09:59:11 --> Output Class Initialized
INFO - 2018-09-30 09:59:11 --> Security Class Initialized
DEBUG - 2018-09-30 09:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:59:11 --> Input Class Initialized
INFO - 2018-09-30 09:59:11 --> Language Class Initialized
INFO - 2018-09-30 09:59:11 --> Loader Class Initialized
INFO - 2018-09-30 09:59:11 --> Helper loaded: url_helper
INFO - 2018-09-30 09:59:11 --> Helper loaded: form_helper
INFO - 2018-09-30 09:59:11 --> Helper loaded: html_helper
INFO - 2018-09-30 09:59:11 --> Database Driver Class Initialized
INFO - 2018-09-30 09:59:11 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:59:11 --> Model "User_model" initialized
INFO - 2018-09-30 09:59:11 --> Model "Project_model" initialized
INFO - 2018-09-30 09:59:11 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:59:11 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:59:11 --> Controller Class Initialized
INFO - 2018-09-30 09:59:11 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-30 09:59:11 --> Severity: Notice --> Trying to get property 'project_name' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 2
ERROR - 2018-09-30 09:59:11 --> Severity: Notice --> Trying to get property 'date_created' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 3
ERROR - 2018-09-30 09:59:11 --> Severity: Notice --> Trying to get property 'project_body' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 6
ERROR - 2018-09-30 09:59:11 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 26
ERROR - 2018-09-30 09:59:11 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 52
ERROR - 2018-09-30 09:59:11 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 68
ERROR - 2018-09-30 09:59:11 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 73
ERROR - 2018-09-30 09:59:11 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 78
INFO - 2018-09-30 09:59:11 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 09:59:11 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:59:11 --> Final output sent to browser
DEBUG - 2018-09-30 09:59:11 --> Total execution time: 0.0790
INFO - 2018-09-30 09:59:32 --> Config Class Initialized
INFO - 2018-09-30 09:59:32 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:59:32 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:59:32 --> Utf8 Class Initialized
INFO - 2018-09-30 09:59:32 --> URI Class Initialized
INFO - 2018-09-30 09:59:32 --> Router Class Initialized
INFO - 2018-09-30 09:59:32 --> Output Class Initialized
INFO - 2018-09-30 09:59:32 --> Security Class Initialized
DEBUG - 2018-09-30 09:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:59:32 --> Input Class Initialized
INFO - 2018-09-30 09:59:32 --> Language Class Initialized
INFO - 2018-09-30 09:59:32 --> Loader Class Initialized
INFO - 2018-09-30 09:59:32 --> Helper loaded: url_helper
INFO - 2018-09-30 09:59:32 --> Helper loaded: form_helper
INFO - 2018-09-30 09:59:32 --> Helper loaded: html_helper
INFO - 2018-09-30 09:59:32 --> Database Driver Class Initialized
INFO - 2018-09-30 09:59:32 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:59:32 --> Model "User_model" initialized
INFO - 2018-09-30 09:59:32 --> Model "Project_model" initialized
INFO - 2018-09-30 09:59:32 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:59:32 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:59:32 --> Controller Class Initialized
INFO - 2018-09-30 09:59:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:59:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 09:59:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:59:32 --> Final output sent to browser
DEBUG - 2018-09-30 09:59:32 --> Total execution time: 0.0590
INFO - 2018-09-30 09:59:34 --> Config Class Initialized
INFO - 2018-09-30 09:59:34 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:59:34 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:59:34 --> Utf8 Class Initialized
INFO - 2018-09-30 09:59:34 --> URI Class Initialized
INFO - 2018-09-30 09:59:34 --> Router Class Initialized
INFO - 2018-09-30 09:59:34 --> Output Class Initialized
INFO - 2018-09-30 09:59:34 --> Security Class Initialized
DEBUG - 2018-09-30 09:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:59:34 --> Input Class Initialized
INFO - 2018-09-30 09:59:34 --> Language Class Initialized
INFO - 2018-09-30 09:59:34 --> Loader Class Initialized
INFO - 2018-09-30 09:59:34 --> Helper loaded: url_helper
INFO - 2018-09-30 09:59:34 --> Helper loaded: form_helper
INFO - 2018-09-30 09:59:34 --> Helper loaded: html_helper
INFO - 2018-09-30 09:59:34 --> Database Driver Class Initialized
INFO - 2018-09-30 09:59:34 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:59:34 --> Model "User_model" initialized
INFO - 2018-09-30 09:59:34 --> Model "Project_model" initialized
INFO - 2018-09-30 09:59:34 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:59:34 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:59:34 --> Controller Class Initialized
INFO - 2018-09-30 09:59:34 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:59:34 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 09:59:34 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:59:34 --> Final output sent to browser
DEBUG - 2018-09-30 09:59:34 --> Total execution time: 0.0610
INFO - 2018-09-30 09:59:35 --> Config Class Initialized
INFO - 2018-09-30 09:59:35 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:59:35 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:59:35 --> Utf8 Class Initialized
INFO - 2018-09-30 09:59:35 --> URI Class Initialized
INFO - 2018-09-30 09:59:35 --> Router Class Initialized
INFO - 2018-09-30 09:59:35 --> Output Class Initialized
INFO - 2018-09-30 09:59:35 --> Security Class Initialized
DEBUG - 2018-09-30 09:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:59:35 --> Input Class Initialized
INFO - 2018-09-30 09:59:35 --> Language Class Initialized
INFO - 2018-09-30 09:59:35 --> Loader Class Initialized
INFO - 2018-09-30 09:59:35 --> Helper loaded: url_helper
INFO - 2018-09-30 09:59:35 --> Helper loaded: form_helper
INFO - 2018-09-30 09:59:35 --> Helper loaded: html_helper
INFO - 2018-09-30 09:59:35 --> Database Driver Class Initialized
INFO - 2018-09-30 09:59:35 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:59:35 --> Model "User_model" initialized
INFO - 2018-09-30 09:59:35 --> Model "Project_model" initialized
INFO - 2018-09-30 09:59:35 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:59:35 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:59:35 --> Controller Class Initialized
INFO - 2018-09-30 09:59:35 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:59:35 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 09:59:35 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:59:35 --> Final output sent to browser
DEBUG - 2018-09-30 09:59:35 --> Total execution time: 0.0680
INFO - 2018-09-30 09:59:36 --> Config Class Initialized
INFO - 2018-09-30 09:59:36 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:59:36 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:59:36 --> Utf8 Class Initialized
INFO - 2018-09-30 09:59:36 --> URI Class Initialized
INFO - 2018-09-30 09:59:36 --> Router Class Initialized
INFO - 2018-09-30 09:59:36 --> Output Class Initialized
INFO - 2018-09-30 09:59:36 --> Security Class Initialized
DEBUG - 2018-09-30 09:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:59:36 --> Input Class Initialized
INFO - 2018-09-30 09:59:36 --> Language Class Initialized
INFO - 2018-09-30 09:59:36 --> Loader Class Initialized
INFO - 2018-09-30 09:59:36 --> Helper loaded: url_helper
INFO - 2018-09-30 09:59:36 --> Helper loaded: form_helper
INFO - 2018-09-30 09:59:36 --> Helper loaded: html_helper
INFO - 2018-09-30 09:59:36 --> Database Driver Class Initialized
INFO - 2018-09-30 09:59:36 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:59:36 --> Model "User_model" initialized
INFO - 2018-09-30 09:59:36 --> Model "Project_model" initialized
INFO - 2018-09-30 09:59:36 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:59:36 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:59:36 --> Controller Class Initialized
INFO - 2018-09-30 09:59:36 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:59:36 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 09:59:36 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:59:36 --> Final output sent to browser
DEBUG - 2018-09-30 09:59:36 --> Total execution time: 0.0450
INFO - 2018-09-30 09:59:37 --> Config Class Initialized
INFO - 2018-09-30 09:59:37 --> Hooks Class Initialized
DEBUG - 2018-09-30 09:59:37 --> UTF-8 Support Enabled
INFO - 2018-09-30 09:59:37 --> Utf8 Class Initialized
INFO - 2018-09-30 09:59:37 --> URI Class Initialized
INFO - 2018-09-30 09:59:37 --> Router Class Initialized
INFO - 2018-09-30 09:59:37 --> Output Class Initialized
INFO - 2018-09-30 09:59:37 --> Security Class Initialized
DEBUG - 2018-09-30 09:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 09:59:37 --> Input Class Initialized
INFO - 2018-09-30 09:59:37 --> Language Class Initialized
INFO - 2018-09-30 09:59:37 --> Loader Class Initialized
INFO - 2018-09-30 09:59:37 --> Helper loaded: url_helper
INFO - 2018-09-30 09:59:37 --> Helper loaded: form_helper
INFO - 2018-09-30 09:59:37 --> Helper loaded: html_helper
INFO - 2018-09-30 09:59:37 --> Database Driver Class Initialized
INFO - 2018-09-30 09:59:37 --> Form Validation Class Initialized
DEBUG - 2018-09-30 09:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 09:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 09:59:37 --> Model "User_model" initialized
INFO - 2018-09-30 09:59:37 --> Model "Project_model" initialized
INFO - 2018-09-30 09:59:37 --> Model "Tasks_model" initialized
INFO - 2018-09-30 09:59:37 --> Model "Lists_model" initialized
INFO - 2018-09-30 09:59:37 --> Controller Class Initialized
INFO - 2018-09-30 09:59:37 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 09:59:37 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 09:59:37 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 09:59:37 --> Final output sent to browser
DEBUG - 2018-09-30 09:59:37 --> Total execution time: 0.0690
INFO - 2018-09-30 10:00:04 --> Config Class Initialized
INFO - 2018-09-30 10:00:04 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:00:04 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:00:04 --> Utf8 Class Initialized
INFO - 2018-09-30 10:00:04 --> URI Class Initialized
INFO - 2018-09-30 10:00:04 --> Router Class Initialized
INFO - 2018-09-30 10:00:04 --> Output Class Initialized
INFO - 2018-09-30 10:00:04 --> Security Class Initialized
DEBUG - 2018-09-30 10:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:00:04 --> Input Class Initialized
INFO - 2018-09-30 10:00:04 --> Language Class Initialized
INFO - 2018-09-30 10:00:04 --> Loader Class Initialized
INFO - 2018-09-30 10:00:04 --> Helper loaded: url_helper
INFO - 2018-09-30 10:00:04 --> Helper loaded: form_helper
INFO - 2018-09-30 10:00:04 --> Helper loaded: html_helper
INFO - 2018-09-30 10:00:04 --> Database Driver Class Initialized
INFO - 2018-09-30 10:00:04 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:00:04 --> Model "User_model" initialized
INFO - 2018-09-30 10:00:04 --> Model "Project_model" initialized
INFO - 2018-09-30 10:00:04 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:00:04 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:00:04 --> Controller Class Initialized
INFO - 2018-09-30 10:00:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:00:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 10:00:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:00:04 --> Final output sent to browser
DEBUG - 2018-09-30 10:00:04 --> Total execution time: 0.0530
INFO - 2018-09-30 10:00:16 --> Config Class Initialized
INFO - 2018-09-30 10:00:16 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:00:16 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:00:16 --> Utf8 Class Initialized
INFO - 2018-09-30 10:00:16 --> URI Class Initialized
INFO - 2018-09-30 10:00:16 --> Router Class Initialized
INFO - 2018-09-30 10:00:16 --> Output Class Initialized
INFO - 2018-09-30 10:00:16 --> Security Class Initialized
DEBUG - 2018-09-30 10:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:00:16 --> Input Class Initialized
INFO - 2018-09-30 10:00:16 --> Language Class Initialized
INFO - 2018-09-30 10:00:16 --> Loader Class Initialized
INFO - 2018-09-30 10:00:16 --> Helper loaded: url_helper
INFO - 2018-09-30 10:00:16 --> Helper loaded: form_helper
INFO - 2018-09-30 10:00:16 --> Helper loaded: html_helper
INFO - 2018-09-30 10:00:16 --> Database Driver Class Initialized
INFO - 2018-09-30 10:00:16 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:00:16 --> Model "User_model" initialized
INFO - 2018-09-30 10:00:16 --> Model "Project_model" initialized
INFO - 2018-09-30 10:00:16 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:00:16 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:00:16 --> Controller Class Initialized
INFO - 2018-09-30 10:00:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:00:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 10:00:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:00:16 --> Final output sent to browser
DEBUG - 2018-09-30 10:00:16 --> Total execution time: 0.0620
INFO - 2018-09-30 10:00:18 --> Config Class Initialized
INFO - 2018-09-30 10:00:18 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:00:18 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:00:18 --> Utf8 Class Initialized
INFO - 2018-09-30 10:00:18 --> URI Class Initialized
INFO - 2018-09-30 10:00:18 --> Router Class Initialized
INFO - 2018-09-30 10:00:18 --> Output Class Initialized
INFO - 2018-09-30 10:00:18 --> Security Class Initialized
DEBUG - 2018-09-30 10:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:00:18 --> Input Class Initialized
INFO - 2018-09-30 10:00:18 --> Language Class Initialized
INFO - 2018-09-30 10:00:18 --> Loader Class Initialized
INFO - 2018-09-30 10:00:18 --> Helper loaded: url_helper
INFO - 2018-09-30 10:00:18 --> Helper loaded: form_helper
INFO - 2018-09-30 10:00:18 --> Helper loaded: html_helper
INFO - 2018-09-30 10:00:18 --> Database Driver Class Initialized
INFO - 2018-09-30 10:00:18 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:00:18 --> Model "User_model" initialized
INFO - 2018-09-30 10:00:18 --> Model "Project_model" initialized
INFO - 2018-09-30 10:00:18 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:00:18 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:00:18 --> Controller Class Initialized
INFO - 2018-09-30 10:00:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:00:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 10:00:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:00:18 --> Final output sent to browser
DEBUG - 2018-09-30 10:00:18 --> Total execution time: 0.0800
INFO - 2018-09-30 10:00:34 --> Config Class Initialized
INFO - 2018-09-30 10:00:34 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:00:34 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:00:34 --> Utf8 Class Initialized
INFO - 2018-09-30 10:00:34 --> URI Class Initialized
INFO - 2018-09-30 10:00:34 --> Router Class Initialized
INFO - 2018-09-30 10:00:34 --> Output Class Initialized
INFO - 2018-09-30 10:00:34 --> Security Class Initialized
DEBUG - 2018-09-30 10:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:00:34 --> Input Class Initialized
INFO - 2018-09-30 10:00:34 --> Language Class Initialized
INFO - 2018-09-30 10:00:34 --> Loader Class Initialized
INFO - 2018-09-30 10:00:34 --> Helper loaded: url_helper
INFO - 2018-09-30 10:00:34 --> Helper loaded: form_helper
INFO - 2018-09-30 10:00:34 --> Helper loaded: html_helper
INFO - 2018-09-30 10:00:34 --> Database Driver Class Initialized
INFO - 2018-09-30 10:00:34 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:00:34 --> Model "User_model" initialized
INFO - 2018-09-30 10:00:34 --> Model "Project_model" initialized
INFO - 2018-09-30 10:00:34 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:00:34 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:00:34 --> Controller Class Initialized
ERROR - 2018-09-30 10:00:34 --> Query error: Table 'errand_db.project' doesn't exist - Invalid query: SHOW COLUMNS FROM `project`
INFO - 2018-09-30 10:00:34 --> Language file loaded: language/english/db_lang.php
INFO - 2018-09-30 10:01:03 --> Config Class Initialized
INFO - 2018-09-30 10:01:03 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:01:03 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:01:03 --> Utf8 Class Initialized
INFO - 2018-09-30 10:01:03 --> URI Class Initialized
INFO - 2018-09-30 10:01:03 --> Router Class Initialized
INFO - 2018-09-30 10:01:03 --> Output Class Initialized
INFO - 2018-09-30 10:01:03 --> Security Class Initialized
DEBUG - 2018-09-30 10:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:01:03 --> Input Class Initialized
INFO - 2018-09-30 10:01:03 --> Language Class Initialized
INFO - 2018-09-30 10:01:03 --> Loader Class Initialized
INFO - 2018-09-30 10:01:03 --> Helper loaded: url_helper
INFO - 2018-09-30 10:01:03 --> Helper loaded: form_helper
INFO - 2018-09-30 10:01:03 --> Helper loaded: html_helper
INFO - 2018-09-30 10:01:03 --> Database Driver Class Initialized
INFO - 2018-09-30 10:01:03 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:01:03 --> Model "User_model" initialized
INFO - 2018-09-30 10:01:03 --> Model "Project_model" initialized
INFO - 2018-09-30 10:01:03 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:01:03 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:01:03 --> Controller Class Initialized
INFO - 2018-09-30 10:01:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:01:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 10:01:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:01:03 --> Final output sent to browser
DEBUG - 2018-09-30 10:01:03 --> Total execution time: 0.0520
INFO - 2018-09-30 10:01:14 --> Config Class Initialized
INFO - 2018-09-30 10:01:14 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:01:14 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:01:14 --> Utf8 Class Initialized
INFO - 2018-09-30 10:01:14 --> URI Class Initialized
INFO - 2018-09-30 10:01:14 --> Router Class Initialized
INFO - 2018-09-30 10:01:14 --> Output Class Initialized
INFO - 2018-09-30 10:01:14 --> Security Class Initialized
DEBUG - 2018-09-30 10:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:01:14 --> Input Class Initialized
INFO - 2018-09-30 10:01:14 --> Language Class Initialized
INFO - 2018-09-30 10:01:14 --> Loader Class Initialized
INFO - 2018-09-30 10:01:14 --> Helper loaded: url_helper
INFO - 2018-09-30 10:01:14 --> Helper loaded: form_helper
INFO - 2018-09-30 10:01:14 --> Helper loaded: html_helper
INFO - 2018-09-30 10:01:14 --> Database Driver Class Initialized
INFO - 2018-09-30 10:01:14 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:01:14 --> Model "User_model" initialized
INFO - 2018-09-30 10:01:14 --> Model "Project_model" initialized
INFO - 2018-09-30 10:01:14 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:01:14 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:01:14 --> Controller Class Initialized
ERROR - 2018-09-30 10:01:14 --> Query error: Table 'errand_db.project' doesn't exist - Invalid query: SHOW COLUMNS FROM `project`
INFO - 2018-09-30 10:01:14 --> Language file loaded: language/english/db_lang.php
INFO - 2018-09-30 10:01:28 --> Config Class Initialized
INFO - 2018-09-30 10:01:28 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:01:28 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:01:28 --> Utf8 Class Initialized
INFO - 2018-09-30 10:01:28 --> URI Class Initialized
INFO - 2018-09-30 10:01:28 --> Router Class Initialized
INFO - 2018-09-30 10:01:28 --> Output Class Initialized
INFO - 2018-09-30 10:01:28 --> Security Class Initialized
DEBUG - 2018-09-30 10:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:01:28 --> Input Class Initialized
INFO - 2018-09-30 10:01:28 --> Language Class Initialized
INFO - 2018-09-30 10:01:28 --> Loader Class Initialized
INFO - 2018-09-30 10:01:28 --> Helper loaded: url_helper
INFO - 2018-09-30 10:01:28 --> Helper loaded: form_helper
INFO - 2018-09-30 10:01:28 --> Helper loaded: html_helper
INFO - 2018-09-30 10:01:28 --> Database Driver Class Initialized
INFO - 2018-09-30 10:01:28 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:01:28 --> Model "User_model" initialized
INFO - 2018-09-30 10:01:28 --> Model "Project_model" initialized
INFO - 2018-09-30 10:01:28 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:01:28 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:01:28 --> Controller Class Initialized
INFO - 2018-09-30 10:01:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:01:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 10:01:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:01:28 --> Final output sent to browser
DEBUG - 2018-09-30 10:01:28 --> Total execution time: 0.0450
INFO - 2018-09-30 10:01:30 --> Config Class Initialized
INFO - 2018-09-30 10:01:30 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:01:30 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:01:30 --> Utf8 Class Initialized
INFO - 2018-09-30 10:01:30 --> URI Class Initialized
INFO - 2018-09-30 10:01:30 --> Router Class Initialized
INFO - 2018-09-30 10:01:30 --> Output Class Initialized
INFO - 2018-09-30 10:01:30 --> Security Class Initialized
DEBUG - 2018-09-30 10:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:01:30 --> Input Class Initialized
INFO - 2018-09-30 10:01:30 --> Language Class Initialized
INFO - 2018-09-30 10:01:30 --> Loader Class Initialized
INFO - 2018-09-30 10:01:30 --> Helper loaded: url_helper
INFO - 2018-09-30 10:01:30 --> Helper loaded: form_helper
INFO - 2018-09-30 10:01:30 --> Helper loaded: html_helper
INFO - 2018-09-30 10:01:30 --> Database Driver Class Initialized
INFO - 2018-09-30 10:01:30 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:01:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:01:30 --> Model "User_model" initialized
INFO - 2018-09-30 10:01:30 --> Model "Project_model" initialized
INFO - 2018-09-30 10:01:30 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:01:30 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:01:30 --> Controller Class Initialized
INFO - 2018-09-30 10:01:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:01:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 10:01:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:01:30 --> Final output sent to browser
DEBUG - 2018-09-30 10:01:30 --> Total execution time: 0.0680
INFO - 2018-09-30 10:02:46 --> Config Class Initialized
INFO - 2018-09-30 10:02:46 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:02:46 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:02:46 --> Utf8 Class Initialized
INFO - 2018-09-30 10:02:46 --> URI Class Initialized
INFO - 2018-09-30 10:02:46 --> Router Class Initialized
INFO - 2018-09-30 10:02:46 --> Output Class Initialized
INFO - 2018-09-30 10:02:46 --> Security Class Initialized
DEBUG - 2018-09-30 10:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:02:46 --> Input Class Initialized
INFO - 2018-09-30 10:02:46 --> Language Class Initialized
INFO - 2018-09-30 10:02:46 --> Loader Class Initialized
INFO - 2018-09-30 10:02:46 --> Helper loaded: url_helper
INFO - 2018-09-30 10:02:46 --> Helper loaded: form_helper
INFO - 2018-09-30 10:02:46 --> Helper loaded: html_helper
INFO - 2018-09-30 10:02:46 --> Database Driver Class Initialized
INFO - 2018-09-30 10:02:46 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:02:46 --> Model "User_model" initialized
INFO - 2018-09-30 10:02:46 --> Model "Project_model" initialized
INFO - 2018-09-30 10:02:46 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:02:46 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:02:46 --> Controller Class Initialized
INFO - 2018-09-30 10:02:46 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:02:46 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 10:02:46 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:02:46 --> Final output sent to browser
DEBUG - 2018-09-30 10:02:46 --> Total execution time: 0.0440
INFO - 2018-09-30 10:02:51 --> Config Class Initialized
INFO - 2018-09-30 10:02:51 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:02:51 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:02:51 --> Utf8 Class Initialized
INFO - 2018-09-30 10:02:51 --> URI Class Initialized
INFO - 2018-09-30 10:02:51 --> Router Class Initialized
INFO - 2018-09-30 10:02:51 --> Output Class Initialized
INFO - 2018-09-30 10:02:51 --> Security Class Initialized
DEBUG - 2018-09-30 10:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:02:51 --> Input Class Initialized
INFO - 2018-09-30 10:02:51 --> Language Class Initialized
INFO - 2018-09-30 10:02:51 --> Loader Class Initialized
INFO - 2018-09-30 10:02:51 --> Helper loaded: url_helper
INFO - 2018-09-30 10:02:51 --> Helper loaded: form_helper
INFO - 2018-09-30 10:02:51 --> Helper loaded: html_helper
INFO - 2018-09-30 10:02:51 --> Database Driver Class Initialized
INFO - 2018-09-30 10:02:51 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:02:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:02:51 --> Model "User_model" initialized
INFO - 2018-09-30 10:02:51 --> Model "Project_model" initialized
INFO - 2018-09-30 10:02:51 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:02:51 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:02:51 --> Controller Class Initialized
ERROR - 2018-09-30 10:02:51 --> Query error: Table 'errand_db.project' doesn't exist - Invalid query: SHOW COLUMNS FROM `project`
INFO - 2018-09-30 10:02:51 --> Language file loaded: language/english/db_lang.php
INFO - 2018-09-30 10:03:00 --> Config Class Initialized
INFO - 2018-09-30 10:03:00 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:03:00 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:03:00 --> Utf8 Class Initialized
INFO - 2018-09-30 10:03:00 --> URI Class Initialized
INFO - 2018-09-30 10:03:00 --> Router Class Initialized
INFO - 2018-09-30 10:03:00 --> Output Class Initialized
INFO - 2018-09-30 10:03:00 --> Security Class Initialized
DEBUG - 2018-09-30 10:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:03:00 --> Input Class Initialized
INFO - 2018-09-30 10:03:00 --> Language Class Initialized
INFO - 2018-09-30 10:03:00 --> Loader Class Initialized
INFO - 2018-09-30 10:03:00 --> Helper loaded: url_helper
INFO - 2018-09-30 10:03:00 --> Helper loaded: form_helper
INFO - 2018-09-30 10:03:00 --> Helper loaded: html_helper
INFO - 2018-09-30 10:03:00 --> Database Driver Class Initialized
INFO - 2018-09-30 10:03:00 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:03:00 --> Model "User_model" initialized
INFO - 2018-09-30 10:03:00 --> Model "Project_model" initialized
INFO - 2018-09-30 10:03:00 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:03:00 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:03:00 --> Controller Class Initialized
INFO - 2018-09-30 10:03:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:03:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 10:03:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:03:00 --> Final output sent to browser
DEBUG - 2018-09-30 10:03:00 --> Total execution time: 0.0440
INFO - 2018-09-30 10:03:12 --> Config Class Initialized
INFO - 2018-09-30 10:03:12 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:03:12 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:03:12 --> Utf8 Class Initialized
INFO - 2018-09-30 10:03:12 --> URI Class Initialized
INFO - 2018-09-30 10:03:12 --> Router Class Initialized
INFO - 2018-09-30 10:03:12 --> Output Class Initialized
INFO - 2018-09-30 10:03:12 --> Security Class Initialized
DEBUG - 2018-09-30 10:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:03:12 --> Input Class Initialized
INFO - 2018-09-30 10:03:12 --> Language Class Initialized
INFO - 2018-09-30 10:03:12 --> Loader Class Initialized
INFO - 2018-09-30 10:03:12 --> Helper loaded: url_helper
INFO - 2018-09-30 10:03:12 --> Helper loaded: form_helper
INFO - 2018-09-30 10:03:12 --> Helper loaded: html_helper
INFO - 2018-09-30 10:03:12 --> Database Driver Class Initialized
INFO - 2018-09-30 10:03:12 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:03:12 --> Model "User_model" initialized
INFO - 2018-09-30 10:03:12 --> Model "Project_model" initialized
INFO - 2018-09-30 10:03:12 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:03:12 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:03:12 --> Controller Class Initialized
ERROR - 2018-09-30 10:03:12 --> Query error: Table 'errand_db.project' doesn't exist - Invalid query: SHOW COLUMNS FROM `project`
INFO - 2018-09-30 10:03:12 --> Language file loaded: language/english/db_lang.php
INFO - 2018-09-30 10:03:42 --> Config Class Initialized
INFO - 2018-09-30 10:03:42 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:03:42 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:03:42 --> Utf8 Class Initialized
INFO - 2018-09-30 10:03:42 --> URI Class Initialized
INFO - 2018-09-30 10:03:42 --> Router Class Initialized
INFO - 2018-09-30 10:03:42 --> Output Class Initialized
INFO - 2018-09-30 10:03:42 --> Security Class Initialized
DEBUG - 2018-09-30 10:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:03:42 --> Input Class Initialized
INFO - 2018-09-30 10:03:42 --> Language Class Initialized
INFO - 2018-09-30 10:03:42 --> Loader Class Initialized
INFO - 2018-09-30 10:03:42 --> Helper loaded: url_helper
INFO - 2018-09-30 10:03:42 --> Helper loaded: form_helper
INFO - 2018-09-30 10:03:42 --> Helper loaded: html_helper
INFO - 2018-09-30 10:03:42 --> Database Driver Class Initialized
INFO - 2018-09-30 10:03:42 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:03:42 --> Model "User_model" initialized
INFO - 2018-09-30 10:03:42 --> Model "Project_model" initialized
INFO - 2018-09-30 10:03:42 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:03:42 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:03:42 --> Controller Class Initialized
INFO - 2018-09-30 10:03:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-30 10:03:42 --> Severity: Notice --> Trying to get property 'project_name' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 2
ERROR - 2018-09-30 10:03:42 --> Severity: Notice --> Trying to get property 'date_created' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 3
ERROR - 2018-09-30 10:03:42 --> Severity: Notice --> Trying to get property 'project_body' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 6
ERROR - 2018-09-30 10:03:42 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 26
ERROR - 2018-09-30 10:03:42 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 52
ERROR - 2018-09-30 10:03:42 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 68
ERROR - 2018-09-30 10:03:42 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 73
ERROR - 2018-09-30 10:03:42 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 78
INFO - 2018-09-30 10:03:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 10:03:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:03:42 --> Final output sent to browser
DEBUG - 2018-09-30 10:03:42 --> Total execution time: 0.0550
INFO - 2018-09-30 10:04:47 --> Config Class Initialized
INFO - 2018-09-30 10:04:47 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:04:47 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:04:47 --> Utf8 Class Initialized
INFO - 2018-09-30 10:04:47 --> URI Class Initialized
INFO - 2018-09-30 10:04:47 --> Router Class Initialized
INFO - 2018-09-30 10:04:47 --> Output Class Initialized
INFO - 2018-09-30 10:04:47 --> Security Class Initialized
DEBUG - 2018-09-30 10:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:04:47 --> Input Class Initialized
INFO - 2018-09-30 10:04:47 --> Language Class Initialized
INFO - 2018-09-30 10:04:47 --> Loader Class Initialized
INFO - 2018-09-30 10:04:47 --> Helper loaded: url_helper
INFO - 2018-09-30 10:04:47 --> Helper loaded: form_helper
INFO - 2018-09-30 10:04:47 --> Helper loaded: html_helper
INFO - 2018-09-30 10:04:47 --> Database Driver Class Initialized
INFO - 2018-09-30 10:04:47 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:04:47 --> Model "User_model" initialized
INFO - 2018-09-30 10:04:47 --> Model "Project_model" initialized
INFO - 2018-09-30 10:04:47 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:04:47 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:04:47 --> Controller Class Initialized
INFO - 2018-09-30 10:04:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-30 10:04:47 --> Severity: Notice --> Trying to get property 'project_name' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 2
ERROR - 2018-09-30 10:04:47 --> Severity: Notice --> Trying to get property 'date_created' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 3
ERROR - 2018-09-30 10:04:47 --> Severity: Notice --> Trying to get property 'project_body' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 6
ERROR - 2018-09-30 10:04:47 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 26
ERROR - 2018-09-30 10:04:47 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 52
ERROR - 2018-09-30 10:04:47 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 68
ERROR - 2018-09-30 10:04:47 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 73
ERROR - 2018-09-30 10:04:47 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 78
INFO - 2018-09-30 10:04:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 10:04:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:04:47 --> Final output sent to browser
DEBUG - 2018-09-30 10:04:47 --> Total execution time: 0.0740
INFO - 2018-09-30 10:04:49 --> Config Class Initialized
INFO - 2018-09-30 10:04:49 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:04:49 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:04:49 --> Utf8 Class Initialized
INFO - 2018-09-30 10:04:49 --> URI Class Initialized
INFO - 2018-09-30 10:04:49 --> Router Class Initialized
INFO - 2018-09-30 10:04:49 --> Output Class Initialized
INFO - 2018-09-30 10:04:49 --> Security Class Initialized
DEBUG - 2018-09-30 10:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:04:49 --> Input Class Initialized
INFO - 2018-09-30 10:04:49 --> Language Class Initialized
INFO - 2018-09-30 10:04:49 --> Loader Class Initialized
INFO - 2018-09-30 10:04:49 --> Helper loaded: url_helper
INFO - 2018-09-30 10:04:49 --> Helper loaded: form_helper
INFO - 2018-09-30 10:04:49 --> Helper loaded: html_helper
INFO - 2018-09-30 10:04:49 --> Database Driver Class Initialized
INFO - 2018-09-30 10:04:49 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:04:49 --> Model "User_model" initialized
INFO - 2018-09-30 10:04:49 --> Model "Project_model" initialized
INFO - 2018-09-30 10:04:49 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:04:49 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:04:49 --> Controller Class Initialized
INFO - 2018-09-30 10:04:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:04:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 10:04:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:04:49 --> Final output sent to browser
DEBUG - 2018-09-30 10:04:49 --> Total execution time: 0.0660
INFO - 2018-09-30 10:04:58 --> Config Class Initialized
INFO - 2018-09-30 10:04:58 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:04:58 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:04:58 --> Utf8 Class Initialized
INFO - 2018-09-30 10:04:58 --> URI Class Initialized
INFO - 2018-09-30 10:04:58 --> Router Class Initialized
INFO - 2018-09-30 10:04:58 --> Output Class Initialized
INFO - 2018-09-30 10:04:58 --> Security Class Initialized
DEBUG - 2018-09-30 10:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:04:58 --> Input Class Initialized
INFO - 2018-09-30 10:04:58 --> Language Class Initialized
INFO - 2018-09-30 10:04:58 --> Loader Class Initialized
INFO - 2018-09-30 10:04:58 --> Helper loaded: url_helper
INFO - 2018-09-30 10:04:58 --> Helper loaded: form_helper
INFO - 2018-09-30 10:04:58 --> Helper loaded: html_helper
INFO - 2018-09-30 10:04:58 --> Database Driver Class Initialized
INFO - 2018-09-30 10:04:58 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:04:58 --> Model "User_model" initialized
INFO - 2018-09-30 10:04:58 --> Model "Project_model" initialized
INFO - 2018-09-30 10:04:58 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:04:58 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:04:58 --> Controller Class Initialized
INFO - 2018-09-30 10:04:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:04:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 10:04:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:04:58 --> Final output sent to browser
DEBUG - 2018-09-30 10:04:58 --> Total execution time: 0.0540
INFO - 2018-09-30 10:05:01 --> Config Class Initialized
INFO - 2018-09-30 10:05:01 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:05:01 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:05:01 --> Utf8 Class Initialized
INFO - 2018-09-30 10:05:01 --> URI Class Initialized
INFO - 2018-09-30 10:05:01 --> Router Class Initialized
INFO - 2018-09-30 10:05:01 --> Output Class Initialized
INFO - 2018-09-30 10:05:01 --> Security Class Initialized
DEBUG - 2018-09-30 10:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:05:01 --> Input Class Initialized
INFO - 2018-09-30 10:05:01 --> Language Class Initialized
INFO - 2018-09-30 10:05:01 --> Loader Class Initialized
INFO - 2018-09-30 10:05:01 --> Helper loaded: url_helper
INFO - 2018-09-30 10:05:01 --> Helper loaded: form_helper
INFO - 2018-09-30 10:05:01 --> Helper loaded: html_helper
INFO - 2018-09-30 10:05:01 --> Database Driver Class Initialized
INFO - 2018-09-30 10:05:01 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:05:01 --> Model "User_model" initialized
INFO - 2018-09-30 10:05:01 --> Model "Project_model" initialized
INFO - 2018-09-30 10:05:01 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:05:01 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:05:01 --> Controller Class Initialized
INFO - 2018-09-30 10:05:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:05:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 10:05:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:05:01 --> Final output sent to browser
DEBUG - 2018-09-30 10:05:01 --> Total execution time: 0.0660
INFO - 2018-09-30 10:05:06 --> Config Class Initialized
INFO - 2018-09-30 10:05:06 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:05:06 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:05:06 --> Utf8 Class Initialized
INFO - 2018-09-30 10:05:06 --> URI Class Initialized
INFO - 2018-09-30 10:05:06 --> Router Class Initialized
INFO - 2018-09-30 10:05:06 --> Output Class Initialized
INFO - 2018-09-30 10:05:06 --> Security Class Initialized
DEBUG - 2018-09-30 10:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:05:06 --> Input Class Initialized
INFO - 2018-09-30 10:05:06 --> Language Class Initialized
INFO - 2018-09-30 10:05:06 --> Loader Class Initialized
INFO - 2018-09-30 10:05:06 --> Helper loaded: url_helper
INFO - 2018-09-30 10:05:06 --> Helper loaded: form_helper
INFO - 2018-09-30 10:05:06 --> Helper loaded: html_helper
INFO - 2018-09-30 10:05:06 --> Database Driver Class Initialized
INFO - 2018-09-30 10:05:06 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:05:06 --> Model "User_model" initialized
INFO - 2018-09-30 10:05:06 --> Model "Project_model" initialized
INFO - 2018-09-30 10:05:06 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:05:06 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:05:06 --> Controller Class Initialized
ERROR - 2018-09-30 10:05:06 --> Query error: Table 'errand_db.project' doesn't exist - Invalid query: SHOW COLUMNS FROM `project`
INFO - 2018-09-30 10:05:06 --> Language file loaded: language/english/db_lang.php
INFO - 2018-09-30 10:05:35 --> Config Class Initialized
INFO - 2018-09-30 10:05:35 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:05:35 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:05:35 --> Utf8 Class Initialized
INFO - 2018-09-30 10:05:35 --> URI Class Initialized
INFO - 2018-09-30 10:05:35 --> Router Class Initialized
INFO - 2018-09-30 10:05:35 --> Output Class Initialized
INFO - 2018-09-30 10:05:35 --> Security Class Initialized
DEBUG - 2018-09-30 10:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:05:35 --> Input Class Initialized
INFO - 2018-09-30 10:05:35 --> Language Class Initialized
INFO - 2018-09-30 10:05:35 --> Loader Class Initialized
INFO - 2018-09-30 10:05:35 --> Helper loaded: url_helper
INFO - 2018-09-30 10:05:35 --> Helper loaded: form_helper
INFO - 2018-09-30 10:05:35 --> Helper loaded: html_helper
INFO - 2018-09-30 10:05:35 --> Database Driver Class Initialized
INFO - 2018-09-30 10:05:35 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:05:35 --> Model "User_model" initialized
INFO - 2018-09-30 10:05:35 --> Model "Project_model" initialized
INFO - 2018-09-30 10:05:35 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:05:35 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:05:35 --> Controller Class Initialized
INFO - 2018-09-30 10:05:35 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:05:35 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 10:05:35 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:05:35 --> Final output sent to browser
DEBUG - 2018-09-30 10:05:35 --> Total execution time: 0.0540
INFO - 2018-09-30 10:06:15 --> Config Class Initialized
INFO - 2018-09-30 10:06:15 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:06:15 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:06:15 --> Utf8 Class Initialized
INFO - 2018-09-30 10:06:15 --> URI Class Initialized
INFO - 2018-09-30 10:06:15 --> Router Class Initialized
INFO - 2018-09-30 10:06:15 --> Output Class Initialized
INFO - 2018-09-30 10:06:15 --> Security Class Initialized
DEBUG - 2018-09-30 10:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:06:15 --> Input Class Initialized
INFO - 2018-09-30 10:06:15 --> Language Class Initialized
INFO - 2018-09-30 10:06:15 --> Loader Class Initialized
INFO - 2018-09-30 10:06:15 --> Helper loaded: url_helper
INFO - 2018-09-30 10:06:15 --> Helper loaded: form_helper
INFO - 2018-09-30 10:06:15 --> Helper loaded: html_helper
INFO - 2018-09-30 10:06:15 --> Database Driver Class Initialized
INFO - 2018-09-30 10:06:15 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:06:15 --> Model "User_model" initialized
INFO - 2018-09-30 10:06:15 --> Model "Project_model" initialized
INFO - 2018-09-30 10:06:15 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:06:15 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:06:15 --> Controller Class Initialized
INFO - 2018-09-30 10:06:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:06:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 10:06:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:06:15 --> Final output sent to browser
DEBUG - 2018-09-30 10:06:15 --> Total execution time: 0.0540
INFO - 2018-09-30 10:06:24 --> Config Class Initialized
INFO - 2018-09-30 10:06:24 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:06:24 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:06:24 --> Utf8 Class Initialized
INFO - 2018-09-30 10:06:24 --> URI Class Initialized
INFO - 2018-09-30 10:06:24 --> Router Class Initialized
INFO - 2018-09-30 10:06:24 --> Output Class Initialized
INFO - 2018-09-30 10:06:24 --> Security Class Initialized
DEBUG - 2018-09-30 10:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:06:24 --> Input Class Initialized
INFO - 2018-09-30 10:06:24 --> Language Class Initialized
INFO - 2018-09-30 10:06:24 --> Loader Class Initialized
INFO - 2018-09-30 10:06:24 --> Helper loaded: url_helper
INFO - 2018-09-30 10:06:24 --> Helper loaded: form_helper
INFO - 2018-09-30 10:06:24 --> Helper loaded: html_helper
INFO - 2018-09-30 10:06:24 --> Database Driver Class Initialized
INFO - 2018-09-30 10:06:24 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:06:24 --> Model "User_model" initialized
INFO - 2018-09-30 10:06:24 --> Model "Project_model" initialized
INFO - 2018-09-30 10:06:24 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:06:24 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:06:24 --> Controller Class Initialized
INFO - 2018-09-30 10:06:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:06:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 10:06:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:06:24 --> Final output sent to browser
DEBUG - 2018-09-30 10:06:24 --> Total execution time: 0.0490
INFO - 2018-09-30 10:06:24 --> Config Class Initialized
INFO - 2018-09-30 10:06:24 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:06:24 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:06:24 --> Utf8 Class Initialized
INFO - 2018-09-30 10:06:24 --> URI Class Initialized
INFO - 2018-09-30 10:06:24 --> Router Class Initialized
INFO - 2018-09-30 10:06:24 --> Output Class Initialized
INFO - 2018-09-30 10:06:24 --> Security Class Initialized
DEBUG - 2018-09-30 10:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:06:24 --> Input Class Initialized
INFO - 2018-09-30 10:06:24 --> Language Class Initialized
INFO - 2018-09-30 10:06:24 --> Loader Class Initialized
INFO - 2018-09-30 10:06:24 --> Helper loaded: url_helper
INFO - 2018-09-30 10:06:24 --> Helper loaded: form_helper
INFO - 2018-09-30 10:06:24 --> Helper loaded: html_helper
INFO - 2018-09-30 10:06:24 --> Database Driver Class Initialized
INFO - 2018-09-30 10:06:24 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:06:24 --> Model "User_model" initialized
INFO - 2018-09-30 10:06:24 --> Model "Project_model" initialized
INFO - 2018-09-30 10:06:24 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:06:24 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:06:24 --> Controller Class Initialized
INFO - 2018-09-30 10:06:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:06:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 10:06:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:06:24 --> Final output sent to browser
DEBUG - 2018-09-30 10:06:24 --> Total execution time: 0.0590
INFO - 2018-09-30 10:06:26 --> Config Class Initialized
INFO - 2018-09-30 10:06:26 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:06:26 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:06:26 --> Utf8 Class Initialized
INFO - 2018-09-30 10:06:26 --> URI Class Initialized
INFO - 2018-09-30 10:06:26 --> Router Class Initialized
INFO - 2018-09-30 10:06:26 --> Output Class Initialized
INFO - 2018-09-30 10:06:26 --> Security Class Initialized
DEBUG - 2018-09-30 10:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:06:26 --> Input Class Initialized
INFO - 2018-09-30 10:06:26 --> Language Class Initialized
INFO - 2018-09-30 10:06:26 --> Loader Class Initialized
INFO - 2018-09-30 10:06:26 --> Helper loaded: url_helper
INFO - 2018-09-30 10:06:26 --> Helper loaded: form_helper
INFO - 2018-09-30 10:06:26 --> Helper loaded: html_helper
INFO - 2018-09-30 10:06:26 --> Database Driver Class Initialized
INFO - 2018-09-30 10:06:26 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:06:26 --> Model "User_model" initialized
INFO - 2018-09-30 10:06:26 --> Model "Project_model" initialized
INFO - 2018-09-30 10:06:26 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:06:26 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:06:26 --> Controller Class Initialized
INFO - 2018-09-30 10:06:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:06:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 10:06:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:06:26 --> Final output sent to browser
DEBUG - 2018-09-30 10:06:26 --> Total execution time: 0.0510
INFO - 2018-09-30 10:08:00 --> Config Class Initialized
INFO - 2018-09-30 10:08:00 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:08:00 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:08:00 --> Utf8 Class Initialized
INFO - 2018-09-30 10:08:00 --> URI Class Initialized
INFO - 2018-09-30 10:08:00 --> Router Class Initialized
INFO - 2018-09-30 10:08:00 --> Output Class Initialized
INFO - 2018-09-30 10:08:00 --> Security Class Initialized
DEBUG - 2018-09-30 10:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:08:00 --> Input Class Initialized
INFO - 2018-09-30 10:08:00 --> Language Class Initialized
INFO - 2018-09-30 10:08:00 --> Loader Class Initialized
INFO - 2018-09-30 10:08:00 --> Helper loaded: url_helper
INFO - 2018-09-30 10:08:00 --> Helper loaded: form_helper
INFO - 2018-09-30 10:08:00 --> Helper loaded: html_helper
INFO - 2018-09-30 10:08:00 --> Database Driver Class Initialized
INFO - 2018-09-30 10:08:00 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:08:00 --> Model "User_model" initialized
INFO - 2018-09-30 10:08:00 --> Model "Project_model" initialized
INFO - 2018-09-30 10:08:00 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:08:00 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:08:00 --> Controller Class Initialized
INFO - 2018-09-30 10:08:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:08:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 10:08:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:08:00 --> Final output sent to browser
DEBUG - 2018-09-30 10:08:00 --> Total execution time: 0.0510
INFO - 2018-09-30 10:08:39 --> Config Class Initialized
INFO - 2018-09-30 10:08:39 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:08:39 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:08:39 --> Utf8 Class Initialized
INFO - 2018-09-30 10:08:39 --> URI Class Initialized
INFO - 2018-09-30 10:08:39 --> Router Class Initialized
INFO - 2018-09-30 10:08:39 --> Output Class Initialized
INFO - 2018-09-30 10:08:39 --> Security Class Initialized
DEBUG - 2018-09-30 10:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:08:39 --> Input Class Initialized
INFO - 2018-09-30 10:08:39 --> Language Class Initialized
INFO - 2018-09-30 10:08:39 --> Loader Class Initialized
INFO - 2018-09-30 10:08:39 --> Helper loaded: url_helper
INFO - 2018-09-30 10:08:39 --> Helper loaded: form_helper
INFO - 2018-09-30 10:08:39 --> Helper loaded: html_helper
INFO - 2018-09-30 10:08:39 --> Database Driver Class Initialized
INFO - 2018-09-30 10:08:39 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:08:39 --> Model "User_model" initialized
INFO - 2018-09-30 10:08:39 --> Model "Project_model" initialized
INFO - 2018-09-30 10:08:39 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:08:39 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:08:39 --> Controller Class Initialized
INFO - 2018-09-30 10:08:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-30 10:08:39 --> Severity: Notice --> Trying to get property 'project_name' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 2
ERROR - 2018-09-30 10:08:39 --> Severity: Notice --> Trying to get property 'date_created' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 3
ERROR - 2018-09-30 10:08:39 --> Severity: Notice --> Trying to get property 'project_body' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 6
ERROR - 2018-09-30 10:08:39 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 26
ERROR - 2018-09-30 10:08:39 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 52
ERROR - 2018-09-30 10:08:39 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 68
ERROR - 2018-09-30 10:08:39 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 73
ERROR - 2018-09-30 10:08:39 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 78
INFO - 2018-09-30 10:08:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 10:08:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:08:39 --> Final output sent to browser
DEBUG - 2018-09-30 10:08:39 --> Total execution time: 0.0520
INFO - 2018-09-30 10:20:22 --> Config Class Initialized
INFO - 2018-09-30 10:20:22 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:20:22 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:20:22 --> Utf8 Class Initialized
INFO - 2018-09-30 10:20:22 --> URI Class Initialized
INFO - 2018-09-30 10:20:22 --> Router Class Initialized
INFO - 2018-09-30 10:20:22 --> Output Class Initialized
INFO - 2018-09-30 10:20:22 --> Security Class Initialized
DEBUG - 2018-09-30 10:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:20:22 --> Input Class Initialized
INFO - 2018-09-30 10:20:22 --> Language Class Initialized
INFO - 2018-09-30 10:20:22 --> Loader Class Initialized
INFO - 2018-09-30 10:20:22 --> Helper loaded: url_helper
INFO - 2018-09-30 10:20:22 --> Helper loaded: form_helper
INFO - 2018-09-30 10:20:22 --> Helper loaded: html_helper
INFO - 2018-09-30 10:20:22 --> Database Driver Class Initialized
INFO - 2018-09-30 10:20:22 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:20:22 --> Model "User_model" initialized
INFO - 2018-09-30 10:20:22 --> Model "Project_model" initialized
INFO - 2018-09-30 10:20:22 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:20:22 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:20:22 --> Controller Class Initialized
INFO - 2018-09-30 10:20:22 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-30 10:20:22 --> Severity: Notice --> Trying to get property 'project_name' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 2
ERROR - 2018-09-30 10:20:22 --> Severity: Notice --> Trying to get property 'date_created' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 3
ERROR - 2018-09-30 10:20:22 --> Severity: Notice --> Trying to get property 'project_body' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 6
ERROR - 2018-09-30 10:20:22 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 26
ERROR - 2018-09-30 10:20:22 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 52
ERROR - 2018-09-30 10:20:22 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 68
ERROR - 2018-09-30 10:20:22 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 73
ERROR - 2018-09-30 10:20:22 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 78
INFO - 2018-09-30 10:20:22 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 10:20:22 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:20:22 --> Final output sent to browser
DEBUG - 2018-09-30 10:20:22 --> Total execution time: 0.0630
INFO - 2018-09-30 10:20:39 --> Config Class Initialized
INFO - 2018-09-30 10:20:39 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:20:39 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:20:39 --> Utf8 Class Initialized
INFO - 2018-09-30 10:20:39 --> URI Class Initialized
INFO - 2018-09-30 10:20:39 --> Router Class Initialized
INFO - 2018-09-30 10:20:39 --> Output Class Initialized
INFO - 2018-09-30 10:20:39 --> Security Class Initialized
DEBUG - 2018-09-30 10:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:20:39 --> Input Class Initialized
INFO - 2018-09-30 10:20:39 --> Language Class Initialized
INFO - 2018-09-30 10:20:39 --> Loader Class Initialized
INFO - 2018-09-30 10:20:39 --> Helper loaded: url_helper
INFO - 2018-09-30 10:20:39 --> Helper loaded: form_helper
INFO - 2018-09-30 10:20:39 --> Helper loaded: html_helper
INFO - 2018-09-30 10:20:39 --> Database Driver Class Initialized
INFO - 2018-09-30 10:20:39 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:20:39 --> Model "User_model" initialized
INFO - 2018-09-30 10:20:39 --> Model "Project_model" initialized
INFO - 2018-09-30 10:20:39 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:20:39 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:20:39 --> Controller Class Initialized
INFO - 2018-09-30 10:20:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:20:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 10:20:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:20:39 --> Final output sent to browser
DEBUG - 2018-09-30 10:20:39 --> Total execution time: 0.0480
INFO - 2018-09-30 10:27:31 --> Config Class Initialized
INFO - 2018-09-30 10:27:31 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:27:31 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:27:31 --> Utf8 Class Initialized
INFO - 2018-09-30 10:27:31 --> URI Class Initialized
INFO - 2018-09-30 10:27:31 --> Router Class Initialized
INFO - 2018-09-30 10:27:31 --> Output Class Initialized
INFO - 2018-09-30 10:27:31 --> Security Class Initialized
DEBUG - 2018-09-30 10:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:27:31 --> Input Class Initialized
INFO - 2018-09-30 10:27:31 --> Language Class Initialized
INFO - 2018-09-30 10:27:31 --> Loader Class Initialized
INFO - 2018-09-30 10:27:31 --> Helper loaded: url_helper
INFO - 2018-09-30 10:27:31 --> Helper loaded: form_helper
INFO - 2018-09-30 10:27:31 --> Helper loaded: html_helper
INFO - 2018-09-30 10:27:31 --> Database Driver Class Initialized
INFO - 2018-09-30 10:27:31 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:27:31 --> Model "User_model" initialized
INFO - 2018-09-30 10:27:31 --> Model "Project_model" initialized
INFO - 2018-09-30 10:27:31 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:27:31 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:27:31 --> Controller Class Initialized
INFO - 2018-09-30 10:27:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:27:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 10:27:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:27:31 --> Final output sent to browser
DEBUG - 2018-09-30 10:27:31 --> Total execution time: 0.0530
INFO - 2018-09-30 10:27:33 --> Config Class Initialized
INFO - 2018-09-30 10:27:33 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:27:33 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:27:33 --> Utf8 Class Initialized
INFO - 2018-09-30 10:27:33 --> URI Class Initialized
INFO - 2018-09-30 10:27:33 --> Router Class Initialized
INFO - 2018-09-30 10:27:33 --> Output Class Initialized
INFO - 2018-09-30 10:27:33 --> Security Class Initialized
DEBUG - 2018-09-30 10:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:27:33 --> Input Class Initialized
INFO - 2018-09-30 10:27:33 --> Language Class Initialized
INFO - 2018-09-30 10:27:33 --> Loader Class Initialized
INFO - 2018-09-30 10:27:33 --> Helper loaded: url_helper
INFO - 2018-09-30 10:27:33 --> Helper loaded: form_helper
INFO - 2018-09-30 10:27:33 --> Helper loaded: html_helper
INFO - 2018-09-30 10:27:33 --> Database Driver Class Initialized
INFO - 2018-09-30 10:27:33 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:27:33 --> Model "User_model" initialized
INFO - 2018-09-30 10:27:33 --> Model "Project_model" initialized
INFO - 2018-09-30 10:27:33 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:27:33 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:27:33 --> Controller Class Initialized
ERROR - 2018-09-30 10:27:33 --> Query error: Table 'errand_db.project' doesn't exist - Invalid query: SHOW COLUMNS FROM `project`
INFO - 2018-09-30 10:27:33 --> Language file loaded: language/english/db_lang.php
INFO - 2018-09-30 10:27:59 --> Config Class Initialized
INFO - 2018-09-30 10:27:59 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:27:59 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:27:59 --> Utf8 Class Initialized
INFO - 2018-09-30 10:27:59 --> URI Class Initialized
INFO - 2018-09-30 10:27:59 --> Router Class Initialized
INFO - 2018-09-30 10:27:59 --> Output Class Initialized
INFO - 2018-09-30 10:27:59 --> Security Class Initialized
DEBUG - 2018-09-30 10:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:27:59 --> Input Class Initialized
INFO - 2018-09-30 10:27:59 --> Language Class Initialized
INFO - 2018-09-30 10:27:59 --> Loader Class Initialized
INFO - 2018-09-30 10:27:59 --> Helper loaded: url_helper
INFO - 2018-09-30 10:27:59 --> Helper loaded: form_helper
INFO - 2018-09-30 10:27:59 --> Helper loaded: html_helper
INFO - 2018-09-30 10:27:59 --> Database Driver Class Initialized
INFO - 2018-09-30 10:27:59 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:27:59 --> Model "User_model" initialized
INFO - 2018-09-30 10:27:59 --> Model "Project_model" initialized
INFO - 2018-09-30 10:27:59 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:27:59 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:27:59 --> Controller Class Initialized
ERROR - 2018-09-30 10:27:59 --> Query error: Table 'errand_db.project' doesn't exist - Invalid query: SHOW COLUMNS FROM `project`
INFO - 2018-09-30 10:27:59 --> Language file loaded: language/english/db_lang.php
INFO - 2018-09-30 10:28:03 --> Config Class Initialized
INFO - 2018-09-30 10:28:03 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:28:03 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:28:03 --> Utf8 Class Initialized
INFO - 2018-09-30 10:28:03 --> URI Class Initialized
INFO - 2018-09-30 10:28:03 --> Router Class Initialized
INFO - 2018-09-30 10:28:03 --> Output Class Initialized
INFO - 2018-09-30 10:28:03 --> Security Class Initialized
DEBUG - 2018-09-30 10:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:28:03 --> Input Class Initialized
INFO - 2018-09-30 10:28:03 --> Language Class Initialized
INFO - 2018-09-30 10:28:03 --> Loader Class Initialized
INFO - 2018-09-30 10:28:03 --> Helper loaded: url_helper
INFO - 2018-09-30 10:28:03 --> Helper loaded: form_helper
INFO - 2018-09-30 10:28:03 --> Helper loaded: html_helper
INFO - 2018-09-30 10:28:03 --> Database Driver Class Initialized
INFO - 2018-09-30 10:28:03 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:28:03 --> Model "User_model" initialized
INFO - 2018-09-30 10:28:03 --> Model "Project_model" initialized
INFO - 2018-09-30 10:28:03 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:28:03 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:28:03 --> Controller Class Initialized
INFO - 2018-09-30 10:28:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:28:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 10:28:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:28:03 --> Final output sent to browser
DEBUG - 2018-09-30 10:28:03 --> Total execution time: 0.0610
INFO - 2018-09-30 10:28:04 --> Config Class Initialized
INFO - 2018-09-30 10:28:04 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:28:04 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:28:04 --> Utf8 Class Initialized
INFO - 2018-09-30 10:28:04 --> URI Class Initialized
INFO - 2018-09-30 10:28:04 --> Router Class Initialized
INFO - 2018-09-30 10:28:04 --> Output Class Initialized
INFO - 2018-09-30 10:28:04 --> Security Class Initialized
DEBUG - 2018-09-30 10:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:28:04 --> Input Class Initialized
INFO - 2018-09-30 10:28:04 --> Language Class Initialized
INFO - 2018-09-30 10:28:04 --> Loader Class Initialized
INFO - 2018-09-30 10:28:04 --> Helper loaded: url_helper
INFO - 2018-09-30 10:28:04 --> Helper loaded: form_helper
INFO - 2018-09-30 10:28:04 --> Helper loaded: html_helper
INFO - 2018-09-30 10:28:04 --> Database Driver Class Initialized
INFO - 2018-09-30 10:28:04 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:28:04 --> Model "User_model" initialized
INFO - 2018-09-30 10:28:04 --> Model "Project_model" initialized
INFO - 2018-09-30 10:28:04 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:28:04 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:28:04 --> Controller Class Initialized
ERROR - 2018-09-30 10:28:04 --> Query error: Table 'errand_db.project' doesn't exist - Invalid query: SHOW COLUMNS FROM `project`
INFO - 2018-09-30 10:28:04 --> Language file loaded: language/english/db_lang.php
INFO - 2018-09-30 10:28:10 --> Config Class Initialized
INFO - 2018-09-30 10:28:10 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:28:10 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:28:10 --> Utf8 Class Initialized
INFO - 2018-09-30 10:28:10 --> URI Class Initialized
INFO - 2018-09-30 10:28:10 --> Router Class Initialized
INFO - 2018-09-30 10:28:10 --> Output Class Initialized
INFO - 2018-09-30 10:28:10 --> Security Class Initialized
DEBUG - 2018-09-30 10:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:28:10 --> Input Class Initialized
INFO - 2018-09-30 10:28:10 --> Language Class Initialized
INFO - 2018-09-30 10:28:10 --> Loader Class Initialized
INFO - 2018-09-30 10:28:10 --> Helper loaded: url_helper
INFO - 2018-09-30 10:28:10 --> Helper loaded: form_helper
INFO - 2018-09-30 10:28:10 --> Helper loaded: html_helper
INFO - 2018-09-30 10:28:10 --> Database Driver Class Initialized
INFO - 2018-09-30 10:28:10 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:28:10 --> Model "User_model" initialized
INFO - 2018-09-30 10:28:10 --> Model "Project_model" initialized
INFO - 2018-09-30 10:28:10 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:28:10 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:28:10 --> Controller Class Initialized
ERROR - 2018-09-30 10:28:10 --> Query error: Table 'errand_db.project' doesn't exist - Invalid query: SHOW COLUMNS FROM `project`
INFO - 2018-09-30 10:28:10 --> Language file loaded: language/english/db_lang.php
INFO - 2018-09-30 10:30:44 --> Config Class Initialized
INFO - 2018-09-30 10:30:44 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:30:44 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:30:44 --> Utf8 Class Initialized
INFO - 2018-09-30 10:30:44 --> URI Class Initialized
INFO - 2018-09-30 10:30:44 --> Router Class Initialized
INFO - 2018-09-30 10:30:44 --> Output Class Initialized
INFO - 2018-09-30 10:30:44 --> Security Class Initialized
DEBUG - 2018-09-30 10:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:30:44 --> Input Class Initialized
INFO - 2018-09-30 10:30:44 --> Language Class Initialized
INFO - 2018-09-30 10:30:44 --> Loader Class Initialized
INFO - 2018-09-30 10:30:44 --> Helper loaded: url_helper
INFO - 2018-09-30 10:30:44 --> Helper loaded: form_helper
INFO - 2018-09-30 10:30:44 --> Helper loaded: html_helper
INFO - 2018-09-30 10:30:44 --> Database Driver Class Initialized
INFO - 2018-09-30 10:30:44 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:30:44 --> Model "User_model" initialized
INFO - 2018-09-30 10:30:44 --> Model "Project_model" initialized
INFO - 2018-09-30 10:30:44 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:30:44 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:30:44 --> Controller Class Initialized
INFO - 2018-09-30 10:30:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:30:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 10:30:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:30:44 --> Final output sent to browser
DEBUG - 2018-09-30 10:30:44 --> Total execution time: 0.0440
INFO - 2018-09-30 10:31:50 --> Config Class Initialized
INFO - 2018-09-30 10:31:50 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:31:50 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:31:50 --> Utf8 Class Initialized
INFO - 2018-09-30 10:31:50 --> URI Class Initialized
INFO - 2018-09-30 10:31:50 --> Router Class Initialized
INFO - 2018-09-30 10:31:50 --> Output Class Initialized
INFO - 2018-09-30 10:31:50 --> Security Class Initialized
DEBUG - 2018-09-30 10:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:31:50 --> Input Class Initialized
INFO - 2018-09-30 10:31:50 --> Language Class Initialized
INFO - 2018-09-30 10:31:50 --> Loader Class Initialized
INFO - 2018-09-30 10:31:50 --> Helper loaded: url_helper
INFO - 2018-09-30 10:31:50 --> Helper loaded: form_helper
INFO - 2018-09-30 10:31:50 --> Helper loaded: html_helper
INFO - 2018-09-30 10:31:50 --> Database Driver Class Initialized
INFO - 2018-09-30 10:31:50 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:31:50 --> Model "User_model" initialized
INFO - 2018-09-30 10:31:50 --> Model "Project_model" initialized
INFO - 2018-09-30 10:31:50 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:31:50 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:31:50 --> Controller Class Initialized
ERROR - 2018-09-30 10:31:50 --> Query error: Table 'errand_db.project' doesn't exist - Invalid query: SHOW COLUMNS FROM `project`
INFO - 2018-09-30 10:31:50 --> Language file loaded: language/english/db_lang.php
INFO - 2018-09-30 10:31:56 --> Config Class Initialized
INFO - 2018-09-30 10:31:56 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:31:56 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:31:56 --> Utf8 Class Initialized
INFO - 2018-09-30 10:31:56 --> URI Class Initialized
INFO - 2018-09-30 10:31:56 --> Router Class Initialized
INFO - 2018-09-30 10:31:56 --> Output Class Initialized
INFO - 2018-09-30 10:31:56 --> Security Class Initialized
DEBUG - 2018-09-30 10:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:31:56 --> Input Class Initialized
INFO - 2018-09-30 10:31:56 --> Language Class Initialized
INFO - 2018-09-30 10:31:56 --> Loader Class Initialized
INFO - 2018-09-30 10:31:56 --> Helper loaded: url_helper
INFO - 2018-09-30 10:31:56 --> Helper loaded: form_helper
INFO - 2018-09-30 10:31:56 --> Helper loaded: html_helper
INFO - 2018-09-30 10:31:56 --> Database Driver Class Initialized
INFO - 2018-09-30 10:31:56 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:31:56 --> Model "User_model" initialized
INFO - 2018-09-30 10:31:56 --> Model "Project_model" initialized
INFO - 2018-09-30 10:31:56 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:31:56 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:31:56 --> Controller Class Initialized
INFO - 2018-09-30 10:31:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:31:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 10:31:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:31:56 --> Final output sent to browser
DEBUG - 2018-09-30 10:31:56 --> Total execution time: 0.0470
INFO - 2018-09-30 10:37:06 --> Config Class Initialized
INFO - 2018-09-30 10:37:06 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:37:06 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:37:06 --> Utf8 Class Initialized
INFO - 2018-09-30 10:37:06 --> URI Class Initialized
INFO - 2018-09-30 10:37:06 --> Router Class Initialized
INFO - 2018-09-30 10:37:06 --> Output Class Initialized
INFO - 2018-09-30 10:37:06 --> Security Class Initialized
DEBUG - 2018-09-30 10:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:37:06 --> Input Class Initialized
INFO - 2018-09-30 10:37:06 --> Language Class Initialized
INFO - 2018-09-30 10:37:06 --> Loader Class Initialized
INFO - 2018-09-30 10:37:06 --> Helper loaded: url_helper
INFO - 2018-09-30 10:37:06 --> Helper loaded: form_helper
INFO - 2018-09-30 10:37:06 --> Helper loaded: html_helper
INFO - 2018-09-30 10:37:06 --> Database Driver Class Initialized
INFO - 2018-09-30 10:37:06 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:37:06 --> Model "User_model" initialized
INFO - 2018-09-30 10:37:06 --> Model "Project_model" initialized
INFO - 2018-09-30 10:37:06 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:37:06 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:37:06 --> Controller Class Initialized
ERROR - 2018-09-30 10:37:06 --> Query error: Table 'errand_db.project' doesn't exist - Invalid query: SHOW COLUMNS FROM `project`
INFO - 2018-09-30 10:37:06 --> Language file loaded: language/english/db_lang.php
INFO - 2018-09-30 10:37:11 --> Config Class Initialized
INFO - 2018-09-30 10:37:11 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:37:11 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:37:11 --> Utf8 Class Initialized
INFO - 2018-09-30 10:37:11 --> URI Class Initialized
INFO - 2018-09-30 10:37:11 --> Router Class Initialized
INFO - 2018-09-30 10:37:11 --> Output Class Initialized
INFO - 2018-09-30 10:37:11 --> Security Class Initialized
DEBUG - 2018-09-30 10:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:37:11 --> Input Class Initialized
INFO - 2018-09-30 10:37:11 --> Language Class Initialized
INFO - 2018-09-30 10:37:11 --> Loader Class Initialized
INFO - 2018-09-30 10:37:11 --> Helper loaded: url_helper
INFO - 2018-09-30 10:37:11 --> Helper loaded: form_helper
INFO - 2018-09-30 10:37:11 --> Helper loaded: html_helper
INFO - 2018-09-30 10:37:11 --> Database Driver Class Initialized
INFO - 2018-09-30 10:37:11 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:37:11 --> Model "User_model" initialized
INFO - 2018-09-30 10:37:11 --> Model "Project_model" initialized
INFO - 2018-09-30 10:37:11 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:37:11 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:37:11 --> Controller Class Initialized
INFO - 2018-09-30 10:37:11 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-30 10:37:11 --> Severity: Notice --> Trying to get property 'project_name' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 2
ERROR - 2018-09-30 10:37:11 --> Severity: Notice --> Trying to get property 'date_created' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 3
ERROR - 2018-09-30 10:37:11 --> Severity: Notice --> Trying to get property 'project_body' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 6
ERROR - 2018-09-30 10:37:11 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 26
ERROR - 2018-09-30 10:37:11 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 52
ERROR - 2018-09-30 10:37:11 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 68
ERROR - 2018-09-30 10:37:11 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 73
ERROR - 2018-09-30 10:37:11 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 78
INFO - 2018-09-30 10:37:11 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 10:37:11 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:37:11 --> Final output sent to browser
DEBUG - 2018-09-30 10:37:11 --> Total execution time: 0.0610
INFO - 2018-09-30 10:37:35 --> Config Class Initialized
INFO - 2018-09-30 10:37:35 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:37:35 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:37:35 --> Utf8 Class Initialized
INFO - 2018-09-30 10:37:35 --> URI Class Initialized
INFO - 2018-09-30 10:37:35 --> Router Class Initialized
INFO - 2018-09-30 10:37:35 --> Output Class Initialized
INFO - 2018-09-30 10:37:35 --> Security Class Initialized
DEBUG - 2018-09-30 10:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:37:35 --> Input Class Initialized
INFO - 2018-09-30 10:37:35 --> Language Class Initialized
INFO - 2018-09-30 10:37:35 --> Loader Class Initialized
INFO - 2018-09-30 10:37:35 --> Helper loaded: url_helper
INFO - 2018-09-30 10:37:35 --> Helper loaded: form_helper
INFO - 2018-09-30 10:37:35 --> Helper loaded: html_helper
INFO - 2018-09-30 10:37:35 --> Database Driver Class Initialized
INFO - 2018-09-30 10:37:35 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:37:35 --> Model "User_model" initialized
INFO - 2018-09-30 10:37:35 --> Model "Project_model" initialized
INFO - 2018-09-30 10:37:35 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:37:35 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:37:35 --> Controller Class Initialized
INFO - 2018-09-30 10:37:35 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:37:35 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 10:37:35 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:37:35 --> Final output sent to browser
DEBUG - 2018-09-30 10:37:35 --> Total execution time: 0.0530
INFO - 2018-09-30 10:37:47 --> Config Class Initialized
INFO - 2018-09-30 10:37:47 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:37:47 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:37:47 --> Utf8 Class Initialized
INFO - 2018-09-30 10:37:47 --> URI Class Initialized
INFO - 2018-09-30 10:37:47 --> Router Class Initialized
INFO - 2018-09-30 10:37:47 --> Output Class Initialized
INFO - 2018-09-30 10:37:47 --> Security Class Initialized
DEBUG - 2018-09-30 10:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:37:47 --> Input Class Initialized
INFO - 2018-09-30 10:37:47 --> Language Class Initialized
INFO - 2018-09-30 10:37:47 --> Loader Class Initialized
INFO - 2018-09-30 10:37:47 --> Helper loaded: url_helper
INFO - 2018-09-30 10:37:47 --> Helper loaded: form_helper
INFO - 2018-09-30 10:37:47 --> Helper loaded: html_helper
INFO - 2018-09-30 10:37:47 --> Database Driver Class Initialized
INFO - 2018-09-30 10:37:47 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:37:47 --> Model "User_model" initialized
INFO - 2018-09-30 10:37:47 --> Model "Project_model" initialized
INFO - 2018-09-30 10:37:47 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:37:47 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:37:47 --> Controller Class Initialized
ERROR - 2018-09-30 10:37:47 --> Query error: Table 'errand_db.project' doesn't exist - Invalid query: SHOW COLUMNS FROM `project`
INFO - 2018-09-30 10:37:47 --> Language file loaded: language/english/db_lang.php
INFO - 2018-09-30 10:37:55 --> Config Class Initialized
INFO - 2018-09-30 10:37:55 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:37:55 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:37:55 --> Utf8 Class Initialized
INFO - 2018-09-30 10:37:55 --> URI Class Initialized
INFO - 2018-09-30 10:37:55 --> Router Class Initialized
INFO - 2018-09-30 10:37:55 --> Output Class Initialized
INFO - 2018-09-30 10:37:55 --> Security Class Initialized
DEBUG - 2018-09-30 10:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:37:55 --> Input Class Initialized
INFO - 2018-09-30 10:37:55 --> Language Class Initialized
INFO - 2018-09-30 10:37:55 --> Loader Class Initialized
INFO - 2018-09-30 10:37:55 --> Helper loaded: url_helper
INFO - 2018-09-30 10:37:55 --> Helper loaded: form_helper
INFO - 2018-09-30 10:37:55 --> Helper loaded: html_helper
INFO - 2018-09-30 10:37:55 --> Database Driver Class Initialized
INFO - 2018-09-30 10:37:55 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:37:55 --> Model "User_model" initialized
INFO - 2018-09-30 10:37:55 --> Model "Project_model" initialized
INFO - 2018-09-30 10:37:55 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:37:55 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:37:55 --> Controller Class Initialized
ERROR - 2018-09-30 10:37:55 --> Query error: Table 'errand_db.project' doesn't exist - Invalid query: SHOW COLUMNS FROM `project`
INFO - 2018-09-30 10:37:55 --> Language file loaded: language/english/db_lang.php
INFO - 2018-09-30 10:38:05 --> Config Class Initialized
INFO - 2018-09-30 10:38:05 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:38:05 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:38:05 --> Utf8 Class Initialized
INFO - 2018-09-30 10:38:05 --> URI Class Initialized
INFO - 2018-09-30 10:38:05 --> Router Class Initialized
INFO - 2018-09-30 10:38:05 --> Output Class Initialized
INFO - 2018-09-30 10:38:05 --> Security Class Initialized
DEBUG - 2018-09-30 10:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:38:05 --> Input Class Initialized
INFO - 2018-09-30 10:38:05 --> Language Class Initialized
INFO - 2018-09-30 10:38:05 --> Loader Class Initialized
INFO - 2018-09-30 10:38:05 --> Helper loaded: url_helper
INFO - 2018-09-30 10:38:05 --> Helper loaded: form_helper
INFO - 2018-09-30 10:38:05 --> Helper loaded: html_helper
INFO - 2018-09-30 10:38:05 --> Database Driver Class Initialized
INFO - 2018-09-30 10:38:06 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:38:06 --> Model "User_model" initialized
INFO - 2018-09-30 10:38:06 --> Model "Project_model" initialized
INFO - 2018-09-30 10:38:06 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:38:06 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:38:06 --> Controller Class Initialized
INFO - 2018-09-30 10:38:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-30 10:38:06 --> Severity: Notice --> Trying to get property 'project_name' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 2
ERROR - 2018-09-30 10:38:06 --> Severity: Notice --> Trying to get property 'date_created' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 3
ERROR - 2018-09-30 10:38:06 --> Severity: Notice --> Trying to get property 'project_body' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 6
ERROR - 2018-09-30 10:38:06 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 26
ERROR - 2018-09-30 10:38:06 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 52
ERROR - 2018-09-30 10:38:06 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 68
ERROR - 2018-09-30 10:38:06 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 73
ERROR - 2018-09-30 10:38:06 --> Severity: Notice --> Trying to get property 'id' of non-object D:\xampp\htdocs\code_igniter\application\views\project_views\projects\display.php 78
INFO - 2018-09-30 10:38:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 10:38:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:38:06 --> Final output sent to browser
DEBUG - 2018-09-30 10:38:06 --> Total execution time: 0.0660
INFO - 2018-09-30 10:38:14 --> Config Class Initialized
INFO - 2018-09-30 10:38:14 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:38:14 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:38:14 --> Utf8 Class Initialized
INFO - 2018-09-30 10:38:14 --> URI Class Initialized
INFO - 2018-09-30 10:38:14 --> Router Class Initialized
INFO - 2018-09-30 10:38:14 --> Output Class Initialized
INFO - 2018-09-30 10:38:14 --> Security Class Initialized
DEBUG - 2018-09-30 10:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:38:14 --> Input Class Initialized
INFO - 2018-09-30 10:38:14 --> Language Class Initialized
INFO - 2018-09-30 10:38:14 --> Loader Class Initialized
INFO - 2018-09-30 10:38:14 --> Helper loaded: url_helper
INFO - 2018-09-30 10:38:14 --> Helper loaded: form_helper
INFO - 2018-09-30 10:38:14 --> Helper loaded: html_helper
INFO - 2018-09-30 10:38:14 --> Database Driver Class Initialized
INFO - 2018-09-30 10:38:14 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:38:14 --> Model "User_model" initialized
INFO - 2018-09-30 10:38:14 --> Model "Project_model" initialized
INFO - 2018-09-30 10:38:14 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:38:14 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:38:14 --> Controller Class Initialized
INFO - 2018-09-30 10:38:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:38:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 10:38:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:38:14 --> Final output sent to browser
DEBUG - 2018-09-30 10:38:14 --> Total execution time: 0.0650
INFO - 2018-09-30 10:40:00 --> Config Class Initialized
INFO - 2018-09-30 10:40:00 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:40:00 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:40:00 --> Utf8 Class Initialized
INFO - 2018-09-30 10:40:00 --> URI Class Initialized
INFO - 2018-09-30 10:40:00 --> Router Class Initialized
INFO - 2018-09-30 10:40:00 --> Output Class Initialized
INFO - 2018-09-30 10:40:00 --> Security Class Initialized
DEBUG - 2018-09-30 10:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:40:00 --> Input Class Initialized
INFO - 2018-09-30 10:40:00 --> Language Class Initialized
INFO - 2018-09-30 10:40:00 --> Loader Class Initialized
INFO - 2018-09-30 10:40:00 --> Helper loaded: url_helper
INFO - 2018-09-30 10:40:00 --> Helper loaded: form_helper
INFO - 2018-09-30 10:40:00 --> Helper loaded: html_helper
INFO - 2018-09-30 10:40:00 --> Database Driver Class Initialized
INFO - 2018-09-30 10:40:00 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:40:00 --> Model "User_model" initialized
INFO - 2018-09-30 10:40:00 --> Model "Project_model" initialized
INFO - 2018-09-30 10:40:00 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:40:00 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:40:00 --> Controller Class Initialized
ERROR - 2018-09-30 10:40:00 --> Query error: Table 'errand_db.project' doesn't exist - Invalid query: SHOW COLUMNS FROM `project`
INFO - 2018-09-30 10:40:00 --> Language file loaded: language/english/db_lang.php
INFO - 2018-09-30 10:52:36 --> Config Class Initialized
INFO - 2018-09-30 10:52:36 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:52:36 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:52:36 --> Utf8 Class Initialized
INFO - 2018-09-30 10:52:36 --> URI Class Initialized
INFO - 2018-09-30 10:52:36 --> Router Class Initialized
INFO - 2018-09-30 10:52:36 --> Output Class Initialized
INFO - 2018-09-30 10:52:36 --> Security Class Initialized
DEBUG - 2018-09-30 10:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:52:36 --> Input Class Initialized
INFO - 2018-09-30 10:52:36 --> Language Class Initialized
INFO - 2018-09-30 10:52:36 --> Loader Class Initialized
INFO - 2018-09-30 10:52:36 --> Helper loaded: url_helper
INFO - 2018-09-30 10:52:36 --> Helper loaded: form_helper
INFO - 2018-09-30 10:52:36 --> Helper loaded: html_helper
INFO - 2018-09-30 10:52:36 --> Database Driver Class Initialized
INFO - 2018-09-30 10:52:36 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:52:36 --> Model "User_model" initialized
INFO - 2018-09-30 10:52:36 --> Model "Project_model" initialized
INFO - 2018-09-30 10:52:36 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:52:36 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:52:36 --> Controller Class Initialized
INFO - 2018-09-30 10:52:36 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:52:36 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 10:52:36 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:52:36 --> Final output sent to browser
DEBUG - 2018-09-30 10:52:36 --> Total execution time: 0.0830
INFO - 2018-09-30 10:52:39 --> Config Class Initialized
INFO - 2018-09-30 10:52:39 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:52:39 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:52:39 --> Utf8 Class Initialized
INFO - 2018-09-30 10:52:39 --> URI Class Initialized
INFO - 2018-09-30 10:52:39 --> Router Class Initialized
INFO - 2018-09-30 10:52:39 --> Output Class Initialized
INFO - 2018-09-30 10:52:39 --> Security Class Initialized
DEBUG - 2018-09-30 10:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:52:39 --> Input Class Initialized
INFO - 2018-09-30 10:52:39 --> Language Class Initialized
INFO - 2018-09-30 10:52:39 --> Loader Class Initialized
INFO - 2018-09-30 10:52:39 --> Helper loaded: url_helper
INFO - 2018-09-30 10:52:39 --> Helper loaded: form_helper
INFO - 2018-09-30 10:52:39 --> Helper loaded: html_helper
INFO - 2018-09-30 10:52:39 --> Database Driver Class Initialized
INFO - 2018-09-30 10:52:39 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:52:39 --> Model "User_model" initialized
INFO - 2018-09-30 10:52:39 --> Model "Project_model" initialized
INFO - 2018-09-30 10:52:39 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:52:39 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:52:39 --> Controller Class Initialized
INFO - 2018-09-30 10:52:39 --> Config Class Initialized
INFO - 2018-09-30 10:52:39 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:52:39 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:52:39 --> Utf8 Class Initialized
INFO - 2018-09-30 10:52:39 --> URI Class Initialized
INFO - 2018-09-30 10:52:39 --> Router Class Initialized
INFO - 2018-09-30 10:52:39 --> Output Class Initialized
INFO - 2018-09-30 10:52:39 --> Security Class Initialized
DEBUG - 2018-09-30 10:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:52:39 --> Input Class Initialized
INFO - 2018-09-30 10:52:39 --> Language Class Initialized
INFO - 2018-09-30 10:52:39 --> Loader Class Initialized
INFO - 2018-09-30 10:52:39 --> Helper loaded: url_helper
INFO - 2018-09-30 10:52:39 --> Helper loaded: form_helper
INFO - 2018-09-30 10:52:39 --> Helper loaded: html_helper
INFO - 2018-09-30 10:52:39 --> Database Driver Class Initialized
INFO - 2018-09-30 10:52:39 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:52:39 --> Model "User_model" initialized
INFO - 2018-09-30 10:52:39 --> Model "Project_model" initialized
INFO - 2018-09-30 10:52:39 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:52:39 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:52:39 --> Controller Class Initialized
INFO - 2018-09-30 10:52:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:52:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 10:52:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:52:39 --> Final output sent to browser
DEBUG - 2018-09-30 10:52:39 --> Total execution time: 0.0480
INFO - 2018-09-30 10:53:34 --> Config Class Initialized
INFO - 2018-09-30 10:53:34 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:53:34 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:53:34 --> Utf8 Class Initialized
INFO - 2018-09-30 10:53:34 --> URI Class Initialized
INFO - 2018-09-30 10:53:34 --> Router Class Initialized
INFO - 2018-09-30 10:53:34 --> Output Class Initialized
INFO - 2018-09-30 10:53:34 --> Security Class Initialized
DEBUG - 2018-09-30 10:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:53:34 --> Input Class Initialized
INFO - 2018-09-30 10:53:34 --> Language Class Initialized
INFO - 2018-09-30 10:53:34 --> Loader Class Initialized
INFO - 2018-09-30 10:53:34 --> Helper loaded: url_helper
INFO - 2018-09-30 10:53:34 --> Helper loaded: form_helper
INFO - 2018-09-30 10:53:34 --> Helper loaded: html_helper
INFO - 2018-09-30 10:53:34 --> Database Driver Class Initialized
INFO - 2018-09-30 10:53:34 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:53:34 --> Model "User_model" initialized
INFO - 2018-09-30 10:53:34 --> Model "Project_model" initialized
INFO - 2018-09-30 10:53:34 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:53:34 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:53:34 --> Controller Class Initialized
INFO - 2018-09-30 10:53:34 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:53:34 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 10:53:34 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:53:34 --> Final output sent to browser
DEBUG - 2018-09-30 10:53:34 --> Total execution time: 0.0530
INFO - 2018-09-30 10:53:40 --> Config Class Initialized
INFO - 2018-09-30 10:53:40 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:53:40 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:53:40 --> Utf8 Class Initialized
INFO - 2018-09-30 10:53:40 --> URI Class Initialized
INFO - 2018-09-30 10:53:40 --> Router Class Initialized
INFO - 2018-09-30 10:53:40 --> Output Class Initialized
INFO - 2018-09-30 10:53:40 --> Security Class Initialized
DEBUG - 2018-09-30 10:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:53:40 --> Input Class Initialized
INFO - 2018-09-30 10:53:40 --> Language Class Initialized
INFO - 2018-09-30 10:53:40 --> Loader Class Initialized
INFO - 2018-09-30 10:53:40 --> Helper loaded: url_helper
INFO - 2018-09-30 10:53:40 --> Helper loaded: form_helper
INFO - 2018-09-30 10:53:40 --> Helper loaded: html_helper
INFO - 2018-09-30 10:53:40 --> Database Driver Class Initialized
INFO - 2018-09-30 10:53:40 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:53:40 --> Model "User_model" initialized
INFO - 2018-09-30 10:53:40 --> Model "Project_model" initialized
INFO - 2018-09-30 10:53:40 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:53:40 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:53:40 --> Controller Class Initialized
INFO - 2018-09-30 10:53:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-30 10:53:41 --> Config Class Initialized
INFO - 2018-09-30 10:53:41 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:53:41 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:53:41 --> Utf8 Class Initialized
INFO - 2018-09-30 10:53:41 --> URI Class Initialized
INFO - 2018-09-30 10:53:41 --> Router Class Initialized
INFO - 2018-09-30 10:53:41 --> Output Class Initialized
INFO - 2018-09-30 10:53:41 --> Security Class Initialized
DEBUG - 2018-09-30 10:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:53:41 --> Input Class Initialized
INFO - 2018-09-30 10:53:41 --> Language Class Initialized
INFO - 2018-09-30 10:53:41 --> Loader Class Initialized
INFO - 2018-09-30 10:53:41 --> Helper loaded: url_helper
INFO - 2018-09-30 10:53:41 --> Helper loaded: form_helper
INFO - 2018-09-30 10:53:41 --> Helper loaded: html_helper
INFO - 2018-09-30 10:53:41 --> Database Driver Class Initialized
INFO - 2018-09-30 10:53:41 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:53:41 --> Model "User_model" initialized
INFO - 2018-09-30 10:53:41 --> Model "Project_model" initialized
INFO - 2018-09-30 10:53:41 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:53:41 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:53:41 --> Controller Class Initialized
INFO - 2018-09-30 10:53:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:53:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 10:53:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:53:41 --> Final output sent to browser
DEBUG - 2018-09-30 10:53:41 --> Total execution time: 0.0360
INFO - 2018-09-30 10:53:42 --> Config Class Initialized
INFO - 2018-09-30 10:53:42 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:53:42 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:53:42 --> Utf8 Class Initialized
INFO - 2018-09-30 10:53:42 --> URI Class Initialized
INFO - 2018-09-30 10:53:42 --> Router Class Initialized
INFO - 2018-09-30 10:53:42 --> Output Class Initialized
INFO - 2018-09-30 10:53:42 --> Security Class Initialized
DEBUG - 2018-09-30 10:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:53:42 --> Input Class Initialized
INFO - 2018-09-30 10:53:42 --> Language Class Initialized
INFO - 2018-09-30 10:53:42 --> Loader Class Initialized
INFO - 2018-09-30 10:53:42 --> Helper loaded: url_helper
INFO - 2018-09-30 10:53:42 --> Helper loaded: form_helper
INFO - 2018-09-30 10:53:42 --> Helper loaded: html_helper
INFO - 2018-09-30 10:53:42 --> Database Driver Class Initialized
INFO - 2018-09-30 10:53:42 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:53:42 --> Model "User_model" initialized
INFO - 2018-09-30 10:53:42 --> Model "Project_model" initialized
INFO - 2018-09-30 10:53:42 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:53:42 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:53:42 --> Controller Class Initialized
INFO - 2018-09-30 10:53:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:53:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 10:53:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:53:42 --> Final output sent to browser
DEBUG - 2018-09-30 10:53:42 --> Total execution time: 0.0650
INFO - 2018-09-30 10:54:12 --> Config Class Initialized
INFO - 2018-09-30 10:54:12 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:54:12 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:54:12 --> Utf8 Class Initialized
INFO - 2018-09-30 10:54:12 --> URI Class Initialized
INFO - 2018-09-30 10:54:12 --> Router Class Initialized
INFO - 2018-09-30 10:54:12 --> Output Class Initialized
INFO - 2018-09-30 10:54:12 --> Security Class Initialized
DEBUG - 2018-09-30 10:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:54:12 --> Input Class Initialized
INFO - 2018-09-30 10:54:12 --> Language Class Initialized
INFO - 2018-09-30 10:54:12 --> Loader Class Initialized
INFO - 2018-09-30 10:54:12 --> Helper loaded: url_helper
INFO - 2018-09-30 10:54:12 --> Helper loaded: form_helper
INFO - 2018-09-30 10:54:12 --> Helper loaded: html_helper
INFO - 2018-09-30 10:54:12 --> Database Driver Class Initialized
INFO - 2018-09-30 10:54:12 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:54:12 --> Model "User_model" initialized
INFO - 2018-09-30 10:54:12 --> Model "Project_model" initialized
INFO - 2018-09-30 10:54:12 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:54:12 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:54:12 --> Controller Class Initialized
INFO - 2018-09-30 10:54:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:54:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 10:54:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:54:12 --> Final output sent to browser
DEBUG - 2018-09-30 10:54:12 --> Total execution time: 0.0470
INFO - 2018-09-30 10:54:33 --> Config Class Initialized
INFO - 2018-09-30 10:54:33 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:54:33 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:54:33 --> Utf8 Class Initialized
INFO - 2018-09-30 10:54:33 --> URI Class Initialized
INFO - 2018-09-30 10:54:33 --> Router Class Initialized
INFO - 2018-09-30 10:54:33 --> Output Class Initialized
INFO - 2018-09-30 10:54:33 --> Security Class Initialized
DEBUG - 2018-09-30 10:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:54:33 --> Input Class Initialized
INFO - 2018-09-30 10:54:33 --> Language Class Initialized
INFO - 2018-09-30 10:54:33 --> Loader Class Initialized
INFO - 2018-09-30 10:54:33 --> Helper loaded: url_helper
INFO - 2018-09-30 10:54:33 --> Helper loaded: form_helper
INFO - 2018-09-30 10:54:33 --> Helper loaded: html_helper
INFO - 2018-09-30 10:54:33 --> Database Driver Class Initialized
INFO - 2018-09-30 10:54:33 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:54:33 --> Model "User_model" initialized
INFO - 2018-09-30 10:54:33 --> Model "Project_model" initialized
INFO - 2018-09-30 10:54:33 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:54:33 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:54:33 --> Controller Class Initialized
INFO - 2018-09-30 10:54:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:54:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 10:54:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:54:33 --> Final output sent to browser
DEBUG - 2018-09-30 10:54:33 --> Total execution time: 0.0510
INFO - 2018-09-30 10:54:45 --> Config Class Initialized
INFO - 2018-09-30 10:54:45 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:54:45 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:54:45 --> Utf8 Class Initialized
INFO - 2018-09-30 10:54:45 --> URI Class Initialized
INFO - 2018-09-30 10:54:45 --> Router Class Initialized
INFO - 2018-09-30 10:54:45 --> Output Class Initialized
INFO - 2018-09-30 10:54:45 --> Security Class Initialized
DEBUG - 2018-09-30 10:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:54:45 --> Input Class Initialized
INFO - 2018-09-30 10:54:45 --> Language Class Initialized
INFO - 2018-09-30 10:54:45 --> Loader Class Initialized
INFO - 2018-09-30 10:54:45 --> Helper loaded: url_helper
INFO - 2018-09-30 10:54:45 --> Helper loaded: form_helper
INFO - 2018-09-30 10:54:45 --> Helper loaded: html_helper
INFO - 2018-09-30 10:54:45 --> Database Driver Class Initialized
INFO - 2018-09-30 10:54:46 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:54:46 --> Model "User_model" initialized
INFO - 2018-09-30 10:54:46 --> Model "Project_model" initialized
INFO - 2018-09-30 10:54:46 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:54:46 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:54:46 --> Controller Class Initialized
INFO - 2018-09-30 10:54:46 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:54:46 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 10:54:46 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:54:46 --> Final output sent to browser
DEBUG - 2018-09-30 10:54:46 --> Total execution time: 0.0600
INFO - 2018-09-30 10:55:01 --> Config Class Initialized
INFO - 2018-09-30 10:55:01 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:55:01 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:55:01 --> Utf8 Class Initialized
INFO - 2018-09-30 10:55:01 --> URI Class Initialized
INFO - 2018-09-30 10:55:01 --> Router Class Initialized
INFO - 2018-09-30 10:55:01 --> Output Class Initialized
INFO - 2018-09-30 10:55:01 --> Security Class Initialized
DEBUG - 2018-09-30 10:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:55:01 --> Input Class Initialized
INFO - 2018-09-30 10:55:01 --> Language Class Initialized
INFO - 2018-09-30 10:55:01 --> Loader Class Initialized
INFO - 2018-09-30 10:55:01 --> Helper loaded: url_helper
INFO - 2018-09-30 10:55:01 --> Helper loaded: form_helper
INFO - 2018-09-30 10:55:01 --> Helper loaded: html_helper
INFO - 2018-09-30 10:55:01 --> Database Driver Class Initialized
INFO - 2018-09-30 10:55:01 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:55:01 --> Model "User_model" initialized
INFO - 2018-09-30 10:55:01 --> Model "Project_model" initialized
INFO - 2018-09-30 10:55:01 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:55:01 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:55:01 --> Controller Class Initialized
INFO - 2018-09-30 10:55:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:55:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 10:55:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:55:01 --> Final output sent to browser
DEBUG - 2018-09-30 10:55:01 --> Total execution time: 0.0620
INFO - 2018-09-30 10:55:02 --> Config Class Initialized
INFO - 2018-09-30 10:55:02 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:55:02 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:55:02 --> Utf8 Class Initialized
INFO - 2018-09-30 10:55:02 --> URI Class Initialized
INFO - 2018-09-30 10:55:02 --> Router Class Initialized
INFO - 2018-09-30 10:55:02 --> Output Class Initialized
INFO - 2018-09-30 10:55:02 --> Security Class Initialized
DEBUG - 2018-09-30 10:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:55:02 --> Input Class Initialized
INFO - 2018-09-30 10:55:02 --> Language Class Initialized
INFO - 2018-09-30 10:55:02 --> Loader Class Initialized
INFO - 2018-09-30 10:55:02 --> Helper loaded: url_helper
INFO - 2018-09-30 10:55:02 --> Helper loaded: form_helper
INFO - 2018-09-30 10:55:02 --> Helper loaded: html_helper
INFO - 2018-09-30 10:55:02 --> Database Driver Class Initialized
INFO - 2018-09-30 10:55:02 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:55:02 --> Model "User_model" initialized
INFO - 2018-09-30 10:55:02 --> Model "Project_model" initialized
INFO - 2018-09-30 10:55:02 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:55:02 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:55:02 --> Controller Class Initialized
INFO - 2018-09-30 10:55:02 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:55:02 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 10:55:02 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:55:02 --> Final output sent to browser
DEBUG - 2018-09-30 10:55:02 --> Total execution time: 0.0700
INFO - 2018-09-30 10:59:52 --> Config Class Initialized
INFO - 2018-09-30 10:59:52 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:59:52 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:59:52 --> Utf8 Class Initialized
INFO - 2018-09-30 10:59:52 --> URI Class Initialized
INFO - 2018-09-30 10:59:52 --> Router Class Initialized
INFO - 2018-09-30 10:59:52 --> Output Class Initialized
INFO - 2018-09-30 10:59:52 --> Security Class Initialized
DEBUG - 2018-09-30 10:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:59:52 --> Input Class Initialized
INFO - 2018-09-30 10:59:52 --> Language Class Initialized
INFO - 2018-09-30 10:59:52 --> Loader Class Initialized
INFO - 2018-09-30 10:59:52 --> Helper loaded: url_helper
INFO - 2018-09-30 10:59:52 --> Helper loaded: form_helper
INFO - 2018-09-30 10:59:52 --> Helper loaded: html_helper
INFO - 2018-09-30 10:59:52 --> Database Driver Class Initialized
INFO - 2018-09-30 10:59:52 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:59:52 --> Model "User_model" initialized
INFO - 2018-09-30 10:59:52 --> Model "Project_model" initialized
INFO - 2018-09-30 10:59:52 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:59:52 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:59:52 --> Controller Class Initialized
INFO - 2018-09-30 10:59:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 10:59:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 10:59:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 10:59:52 --> Final output sent to browser
DEBUG - 2018-09-30 10:59:52 --> Total execution time: 0.0560
INFO - 2018-09-30 10:59:56 --> Config Class Initialized
INFO - 2018-09-30 10:59:56 --> Hooks Class Initialized
DEBUG - 2018-09-30 10:59:56 --> UTF-8 Support Enabled
INFO - 2018-09-30 10:59:56 --> Utf8 Class Initialized
INFO - 2018-09-30 10:59:56 --> URI Class Initialized
INFO - 2018-09-30 10:59:56 --> Router Class Initialized
INFO - 2018-09-30 10:59:56 --> Output Class Initialized
INFO - 2018-09-30 10:59:56 --> Security Class Initialized
DEBUG - 2018-09-30 10:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 10:59:56 --> Input Class Initialized
INFO - 2018-09-30 10:59:56 --> Language Class Initialized
INFO - 2018-09-30 10:59:56 --> Loader Class Initialized
INFO - 2018-09-30 10:59:56 --> Helper loaded: url_helper
INFO - 2018-09-30 10:59:56 --> Helper loaded: form_helper
INFO - 2018-09-30 10:59:56 --> Helper loaded: html_helper
INFO - 2018-09-30 10:59:56 --> Database Driver Class Initialized
INFO - 2018-09-30 10:59:56 --> Form Validation Class Initialized
DEBUG - 2018-09-30 10:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 10:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 10:59:56 --> Model "User_model" initialized
INFO - 2018-09-30 10:59:56 --> Model "Project_model" initialized
INFO - 2018-09-30 10:59:56 --> Model "Tasks_model" initialized
INFO - 2018-09-30 10:59:56 --> Model "Lists_model" initialized
INFO - 2018-09-30 10:59:56 --> Controller Class Initialized
ERROR - 2018-09-30 10:59:56 --> Query error: Table 'errand_db.id' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows` FROM `id`
INFO - 2018-09-30 10:59:56 --> Language file loaded: language/english/db_lang.php
INFO - 2018-09-30 11:00:12 --> Config Class Initialized
INFO - 2018-09-30 11:00:12 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:00:12 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:00:12 --> Utf8 Class Initialized
INFO - 2018-09-30 11:00:12 --> URI Class Initialized
INFO - 2018-09-30 11:00:12 --> Router Class Initialized
INFO - 2018-09-30 11:00:12 --> Output Class Initialized
INFO - 2018-09-30 11:00:12 --> Security Class Initialized
DEBUG - 2018-09-30 11:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:00:12 --> Input Class Initialized
INFO - 2018-09-30 11:00:12 --> Language Class Initialized
INFO - 2018-09-30 11:00:12 --> Loader Class Initialized
INFO - 2018-09-30 11:00:12 --> Helper loaded: url_helper
INFO - 2018-09-30 11:00:12 --> Helper loaded: form_helper
INFO - 2018-09-30 11:00:12 --> Helper loaded: html_helper
INFO - 2018-09-30 11:00:12 --> Database Driver Class Initialized
INFO - 2018-09-30 11:00:12 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:00:12 --> Model "User_model" initialized
INFO - 2018-09-30 11:00:12 --> Model "Project_model" initialized
INFO - 2018-09-30 11:00:12 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:00:12 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:00:12 --> Controller Class Initialized
INFO - 2018-09-30 11:00:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:00:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 11:00:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:00:12 --> Final output sent to browser
DEBUG - 2018-09-30 11:00:12 --> Total execution time: 0.0480
INFO - 2018-09-30 11:01:10 --> Config Class Initialized
INFO - 2018-09-30 11:01:10 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:01:10 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:01:10 --> Utf8 Class Initialized
INFO - 2018-09-30 11:01:10 --> URI Class Initialized
INFO - 2018-09-30 11:01:10 --> Router Class Initialized
INFO - 2018-09-30 11:01:10 --> Output Class Initialized
INFO - 2018-09-30 11:01:10 --> Security Class Initialized
DEBUG - 2018-09-30 11:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:01:10 --> Input Class Initialized
INFO - 2018-09-30 11:01:10 --> Language Class Initialized
INFO - 2018-09-30 11:01:10 --> Loader Class Initialized
INFO - 2018-09-30 11:01:10 --> Helper loaded: url_helper
INFO - 2018-09-30 11:01:10 --> Helper loaded: form_helper
INFO - 2018-09-30 11:01:10 --> Helper loaded: html_helper
INFO - 2018-09-30 11:01:10 --> Database Driver Class Initialized
INFO - 2018-09-30 11:01:10 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:01:10 --> Model "User_model" initialized
INFO - 2018-09-30 11:01:10 --> Model "Project_model" initialized
INFO - 2018-09-30 11:01:10 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:01:10 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:01:10 --> Controller Class Initialized
INFO - 2018-09-30 11:01:10 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:01:10 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 11:01:10 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:01:10 --> Final output sent to browser
DEBUG - 2018-09-30 11:01:10 --> Total execution time: 0.0470
INFO - 2018-09-30 11:01:31 --> Config Class Initialized
INFO - 2018-09-30 11:01:31 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:01:31 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:01:31 --> Utf8 Class Initialized
INFO - 2018-09-30 11:01:31 --> URI Class Initialized
INFO - 2018-09-30 11:01:31 --> Router Class Initialized
INFO - 2018-09-30 11:01:31 --> Output Class Initialized
INFO - 2018-09-30 11:01:31 --> Security Class Initialized
DEBUG - 2018-09-30 11:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:01:31 --> Input Class Initialized
INFO - 2018-09-30 11:01:31 --> Language Class Initialized
INFO - 2018-09-30 11:01:31 --> Loader Class Initialized
INFO - 2018-09-30 11:01:31 --> Helper loaded: url_helper
INFO - 2018-09-30 11:01:31 --> Helper loaded: form_helper
INFO - 2018-09-30 11:01:31 --> Helper loaded: html_helper
INFO - 2018-09-30 11:01:31 --> Database Driver Class Initialized
INFO - 2018-09-30 11:01:31 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:01:31 --> Model "User_model" initialized
INFO - 2018-09-30 11:01:31 --> Model "Project_model" initialized
INFO - 2018-09-30 11:01:31 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:01:31 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:01:31 --> Controller Class Initialized
INFO - 2018-09-30 11:01:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:01:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 11:01:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:01:31 --> Final output sent to browser
DEBUG - 2018-09-30 11:01:31 --> Total execution time: 0.0480
INFO - 2018-09-30 11:01:32 --> Config Class Initialized
INFO - 2018-09-30 11:01:32 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:01:32 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:01:32 --> Utf8 Class Initialized
INFO - 2018-09-30 11:01:32 --> URI Class Initialized
INFO - 2018-09-30 11:01:32 --> Router Class Initialized
INFO - 2018-09-30 11:01:32 --> Output Class Initialized
INFO - 2018-09-30 11:01:32 --> Security Class Initialized
DEBUG - 2018-09-30 11:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:01:32 --> Input Class Initialized
INFO - 2018-09-30 11:01:32 --> Language Class Initialized
INFO - 2018-09-30 11:01:32 --> Loader Class Initialized
INFO - 2018-09-30 11:01:32 --> Helper loaded: url_helper
INFO - 2018-09-30 11:01:32 --> Helper loaded: form_helper
INFO - 2018-09-30 11:01:32 --> Helper loaded: html_helper
INFO - 2018-09-30 11:01:32 --> Database Driver Class Initialized
INFO - 2018-09-30 11:01:32 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:01:32 --> Model "User_model" initialized
INFO - 2018-09-30 11:01:32 --> Model "Project_model" initialized
INFO - 2018-09-30 11:01:32 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:01:32 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:01:32 --> Controller Class Initialized
INFO - 2018-09-30 11:01:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:01:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 11:01:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:01:32 --> Final output sent to browser
DEBUG - 2018-09-30 11:01:32 --> Total execution time: 0.0480
INFO - 2018-09-30 11:01:33 --> Config Class Initialized
INFO - 2018-09-30 11:01:33 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:01:33 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:01:33 --> Utf8 Class Initialized
INFO - 2018-09-30 11:01:33 --> URI Class Initialized
INFO - 2018-09-30 11:01:33 --> Router Class Initialized
INFO - 2018-09-30 11:01:33 --> Output Class Initialized
INFO - 2018-09-30 11:01:33 --> Security Class Initialized
DEBUG - 2018-09-30 11:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:01:33 --> Input Class Initialized
INFO - 2018-09-30 11:01:33 --> Language Class Initialized
INFO - 2018-09-30 11:01:33 --> Loader Class Initialized
INFO - 2018-09-30 11:01:33 --> Helper loaded: url_helper
INFO - 2018-09-30 11:01:33 --> Helper loaded: form_helper
INFO - 2018-09-30 11:01:33 --> Helper loaded: html_helper
INFO - 2018-09-30 11:01:33 --> Database Driver Class Initialized
INFO - 2018-09-30 11:01:33 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:01:33 --> Model "User_model" initialized
INFO - 2018-09-30 11:01:33 --> Model "Project_model" initialized
INFO - 2018-09-30 11:01:33 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:01:33 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:01:33 --> Controller Class Initialized
INFO - 2018-09-30 11:01:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:01:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 11:01:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:01:33 --> Final output sent to browser
DEBUG - 2018-09-30 11:01:33 --> Total execution time: 0.0600
INFO - 2018-09-30 11:01:52 --> Config Class Initialized
INFO - 2018-09-30 11:01:52 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:01:52 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:01:52 --> Utf8 Class Initialized
INFO - 2018-09-30 11:01:52 --> URI Class Initialized
INFO - 2018-09-30 11:01:52 --> Router Class Initialized
INFO - 2018-09-30 11:01:52 --> Output Class Initialized
INFO - 2018-09-30 11:01:52 --> Security Class Initialized
DEBUG - 2018-09-30 11:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:01:52 --> Input Class Initialized
INFO - 2018-09-30 11:01:52 --> Language Class Initialized
INFO - 2018-09-30 11:01:52 --> Loader Class Initialized
INFO - 2018-09-30 11:01:52 --> Helper loaded: url_helper
INFO - 2018-09-30 11:01:52 --> Helper loaded: form_helper
INFO - 2018-09-30 11:01:52 --> Helper loaded: html_helper
INFO - 2018-09-30 11:01:52 --> Database Driver Class Initialized
INFO - 2018-09-30 11:01:52 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:01:52 --> Model "User_model" initialized
INFO - 2018-09-30 11:01:52 --> Model "Project_model" initialized
INFO - 2018-09-30 11:01:52 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:01:52 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:01:52 --> Controller Class Initialized
INFO - 2018-09-30 11:01:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:01:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 11:01:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:01:52 --> Final output sent to browser
DEBUG - 2018-09-30 11:01:52 --> Total execution time: 0.0490
INFO - 2018-09-30 11:02:05 --> Config Class Initialized
INFO - 2018-09-30 11:02:05 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:02:05 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:02:05 --> Utf8 Class Initialized
INFO - 2018-09-30 11:02:05 --> URI Class Initialized
INFO - 2018-09-30 11:02:05 --> Router Class Initialized
INFO - 2018-09-30 11:02:05 --> Output Class Initialized
INFO - 2018-09-30 11:02:05 --> Security Class Initialized
DEBUG - 2018-09-30 11:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:02:05 --> Input Class Initialized
INFO - 2018-09-30 11:02:05 --> Language Class Initialized
INFO - 2018-09-30 11:02:05 --> Loader Class Initialized
INFO - 2018-09-30 11:02:05 --> Helper loaded: url_helper
INFO - 2018-09-30 11:02:05 --> Helper loaded: form_helper
INFO - 2018-09-30 11:02:05 --> Helper loaded: html_helper
INFO - 2018-09-30 11:02:05 --> Database Driver Class Initialized
INFO - 2018-09-30 11:02:05 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:02:05 --> Model "User_model" initialized
INFO - 2018-09-30 11:02:05 --> Model "Project_model" initialized
INFO - 2018-09-30 11:02:05 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:02:05 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:02:05 --> Controller Class Initialized
ERROR - 2018-09-30 11:02:05 --> Severity: error --> Exception: Call to a member function num_rows() on integer D:\xampp\htdocs\code_igniter\application\models\project_models\project_model.php 99
INFO - 2018-09-30 11:02:19 --> Config Class Initialized
INFO - 2018-09-30 11:02:19 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:02:19 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:02:19 --> Utf8 Class Initialized
INFO - 2018-09-30 11:02:19 --> URI Class Initialized
INFO - 2018-09-30 11:02:19 --> Router Class Initialized
INFO - 2018-09-30 11:02:19 --> Output Class Initialized
INFO - 2018-09-30 11:02:19 --> Security Class Initialized
DEBUG - 2018-09-30 11:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:02:19 --> Input Class Initialized
INFO - 2018-09-30 11:02:19 --> Language Class Initialized
INFO - 2018-09-30 11:02:19 --> Loader Class Initialized
INFO - 2018-09-30 11:02:19 --> Helper loaded: url_helper
INFO - 2018-09-30 11:02:19 --> Helper loaded: form_helper
INFO - 2018-09-30 11:02:19 --> Helper loaded: html_helper
INFO - 2018-09-30 11:02:19 --> Database Driver Class Initialized
INFO - 2018-09-30 11:02:19 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:02:19 --> Model "User_model" initialized
INFO - 2018-09-30 11:02:19 --> Model "Project_model" initialized
INFO - 2018-09-30 11:02:19 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:02:19 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:02:19 --> Controller Class Initialized
INFO - 2018-09-30 11:02:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:02:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 11:02:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:02:19 --> Final output sent to browser
DEBUG - 2018-09-30 11:02:19 --> Total execution time: 0.0440
INFO - 2018-09-30 11:04:03 --> Config Class Initialized
INFO - 2018-09-30 11:04:03 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:04:03 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:04:03 --> Utf8 Class Initialized
INFO - 2018-09-30 11:04:03 --> URI Class Initialized
INFO - 2018-09-30 11:04:03 --> Router Class Initialized
INFO - 2018-09-30 11:04:03 --> Output Class Initialized
INFO - 2018-09-30 11:04:03 --> Security Class Initialized
DEBUG - 2018-09-30 11:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:04:03 --> Input Class Initialized
INFO - 2018-09-30 11:04:03 --> Language Class Initialized
INFO - 2018-09-30 11:04:03 --> Loader Class Initialized
INFO - 2018-09-30 11:04:03 --> Helper loaded: url_helper
INFO - 2018-09-30 11:04:03 --> Helper loaded: form_helper
INFO - 2018-09-30 11:04:03 --> Helper loaded: html_helper
INFO - 2018-09-30 11:04:03 --> Database Driver Class Initialized
INFO - 2018-09-30 11:04:03 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:04:03 --> Model "User_model" initialized
INFO - 2018-09-30 11:04:03 --> Model "Project_model" initialized
INFO - 2018-09-30 11:04:03 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:04:03 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:04:03 --> Controller Class Initialized
INFO - 2018-09-30 11:04:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:04:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 11:04:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:04:03 --> Final output sent to browser
DEBUG - 2018-09-30 11:04:03 --> Total execution time: 0.0810
INFO - 2018-09-30 11:10:45 --> Config Class Initialized
INFO - 2018-09-30 11:10:45 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:10:45 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:10:45 --> Utf8 Class Initialized
INFO - 2018-09-30 11:10:45 --> URI Class Initialized
INFO - 2018-09-30 11:10:45 --> Router Class Initialized
INFO - 2018-09-30 11:10:45 --> Output Class Initialized
INFO - 2018-09-30 11:10:45 --> Security Class Initialized
DEBUG - 2018-09-30 11:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:10:45 --> Input Class Initialized
INFO - 2018-09-30 11:10:45 --> Language Class Initialized
INFO - 2018-09-30 11:10:45 --> Loader Class Initialized
INFO - 2018-09-30 11:10:45 --> Helper loaded: url_helper
INFO - 2018-09-30 11:10:45 --> Helper loaded: form_helper
INFO - 2018-09-30 11:10:45 --> Helper loaded: html_helper
INFO - 2018-09-30 11:10:45 --> Database Driver Class Initialized
INFO - 2018-09-30 11:10:45 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:10:45 --> Model "User_model" initialized
INFO - 2018-09-30 11:10:45 --> Model "Project_model" initialized
INFO - 2018-09-30 11:10:45 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:10:45 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:10:45 --> Controller Class Initialized
INFO - 2018-09-30 11:10:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:10:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/edit_project.php
INFO - 2018-09-30 11:10:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:10:45 --> Final output sent to browser
DEBUG - 2018-09-30 11:10:45 --> Total execution time: 0.0590
INFO - 2018-09-30 11:10:51 --> Config Class Initialized
INFO - 2018-09-30 11:10:51 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:10:51 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:10:51 --> Utf8 Class Initialized
INFO - 2018-09-30 11:10:51 --> URI Class Initialized
INFO - 2018-09-30 11:10:51 --> Router Class Initialized
INFO - 2018-09-30 11:10:51 --> Output Class Initialized
INFO - 2018-09-30 11:10:51 --> Security Class Initialized
DEBUG - 2018-09-30 11:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:10:51 --> Input Class Initialized
INFO - 2018-09-30 11:10:51 --> Language Class Initialized
INFO - 2018-09-30 11:10:51 --> Loader Class Initialized
INFO - 2018-09-30 11:10:51 --> Helper loaded: url_helper
INFO - 2018-09-30 11:10:51 --> Helper loaded: form_helper
INFO - 2018-09-30 11:10:51 --> Helper loaded: html_helper
INFO - 2018-09-30 11:10:51 --> Database Driver Class Initialized
INFO - 2018-09-30 11:10:51 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:10:51 --> Model "User_model" initialized
INFO - 2018-09-30 11:10:51 --> Model "Project_model" initialized
INFO - 2018-09-30 11:10:51 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:10:51 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:10:51 --> Controller Class Initialized
INFO - 2018-09-30 11:10:51 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-09-30 11:10:51 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\code_igniter\system\database\DB_driver.php 1525
ERROR - 2018-09-30 11:10:51 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\code_igniter\system\database\DB_driver.php 1525
ERROR - 2018-09-30 11:10:51 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: UPDATE `projects` SET `project_name` = Array, `project_body` = Array
WHERE `id` = '2'
INFO - 2018-09-30 11:10:51 --> Language file loaded: language/english/db_lang.php
INFO - 2018-09-30 11:11:59 --> Config Class Initialized
INFO - 2018-09-30 11:11:59 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:11:59 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:11:59 --> Utf8 Class Initialized
INFO - 2018-09-30 11:11:59 --> URI Class Initialized
INFO - 2018-09-30 11:11:59 --> Router Class Initialized
INFO - 2018-09-30 11:11:59 --> Output Class Initialized
INFO - 2018-09-30 11:11:59 --> Security Class Initialized
DEBUG - 2018-09-30 11:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:11:59 --> Input Class Initialized
INFO - 2018-09-30 11:11:59 --> Language Class Initialized
INFO - 2018-09-30 11:11:59 --> Loader Class Initialized
INFO - 2018-09-30 11:11:59 --> Helper loaded: url_helper
INFO - 2018-09-30 11:11:59 --> Helper loaded: form_helper
INFO - 2018-09-30 11:11:59 --> Helper loaded: html_helper
INFO - 2018-09-30 11:11:59 --> Database Driver Class Initialized
INFO - 2018-09-30 11:11:59 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:11:59 --> Model "User_model" initialized
INFO - 2018-09-30 11:11:59 --> Model "Project_model" initialized
INFO - 2018-09-30 11:11:59 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:11:59 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:11:59 --> Controller Class Initialized
INFO - 2018-09-30 11:11:59 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-09-30 11:11:59 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\code_igniter\application\models\project_models\project_model.php 47
ERROR - 2018-09-30 11:11:59 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$Array D:\xampp\htdocs\code_igniter\application\models\project_models\project_model.php 47
ERROR - 2018-09-30 11:11:59 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\code_igniter\application\models\project_models\project_model.php 47
ERROR - 2018-09-30 11:11:59 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$Array D:\xampp\htdocs\code_igniter\application\models\project_models\project_model.php 47
INFO - 2018-09-30 11:11:59 --> Config Class Initialized
INFO - 2018-09-30 11:11:59 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:11:59 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:11:59 --> Utf8 Class Initialized
INFO - 2018-09-30 11:11:59 --> URI Class Initialized
INFO - 2018-09-30 11:11:59 --> Router Class Initialized
INFO - 2018-09-30 11:11:59 --> Output Class Initialized
INFO - 2018-09-30 11:11:59 --> Security Class Initialized
DEBUG - 2018-09-30 11:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:11:59 --> Input Class Initialized
INFO - 2018-09-30 11:11:59 --> Language Class Initialized
INFO - 2018-09-30 11:11:59 --> Loader Class Initialized
INFO - 2018-09-30 11:11:59 --> Helper loaded: url_helper
INFO - 2018-09-30 11:11:59 --> Helper loaded: form_helper
INFO - 2018-09-30 11:11:59 --> Helper loaded: html_helper
INFO - 2018-09-30 11:11:59 --> Database Driver Class Initialized
INFO - 2018-09-30 11:11:59 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:11:59 --> Model "User_model" initialized
INFO - 2018-09-30 11:11:59 --> Model "Project_model" initialized
INFO - 2018-09-30 11:11:59 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:11:59 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:11:59 --> Controller Class Initialized
INFO - 2018-09-30 11:11:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:11:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 11:11:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:11:59 --> Final output sent to browser
DEBUG - 2018-09-30 11:11:59 --> Total execution time: 0.0520
INFO - 2018-09-30 11:12:18 --> Config Class Initialized
INFO - 2018-09-30 11:12:18 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:12:18 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:12:18 --> Utf8 Class Initialized
INFO - 2018-09-30 11:12:18 --> URI Class Initialized
INFO - 2018-09-30 11:12:18 --> Router Class Initialized
INFO - 2018-09-30 11:12:18 --> Output Class Initialized
INFO - 2018-09-30 11:12:18 --> Security Class Initialized
DEBUG - 2018-09-30 11:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:12:18 --> Input Class Initialized
INFO - 2018-09-30 11:12:18 --> Language Class Initialized
INFO - 2018-09-30 11:12:18 --> Loader Class Initialized
INFO - 2018-09-30 11:12:18 --> Helper loaded: url_helper
INFO - 2018-09-30 11:12:18 --> Helper loaded: form_helper
INFO - 2018-09-30 11:12:18 --> Helper loaded: html_helper
INFO - 2018-09-30 11:12:18 --> Database Driver Class Initialized
INFO - 2018-09-30 11:12:18 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:12:18 --> Model "User_model" initialized
INFO - 2018-09-30 11:12:18 --> Model "Project_model" initialized
INFO - 2018-09-30 11:12:18 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:12:18 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:12:18 --> Controller Class Initialized
INFO - 2018-09-30 11:12:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:12:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 11:12:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:12:18 --> Final output sent to browser
DEBUG - 2018-09-30 11:12:18 --> Total execution time: 0.0660
INFO - 2018-09-30 11:12:19 --> Config Class Initialized
INFO - 2018-09-30 11:12:19 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:12:19 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:12:19 --> Utf8 Class Initialized
INFO - 2018-09-30 11:12:19 --> URI Class Initialized
INFO - 2018-09-30 11:12:19 --> Router Class Initialized
INFO - 2018-09-30 11:12:19 --> Output Class Initialized
INFO - 2018-09-30 11:12:19 --> Security Class Initialized
DEBUG - 2018-09-30 11:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:12:19 --> Input Class Initialized
INFO - 2018-09-30 11:12:19 --> Language Class Initialized
INFO - 2018-09-30 11:12:19 --> Loader Class Initialized
INFO - 2018-09-30 11:12:19 --> Helper loaded: url_helper
INFO - 2018-09-30 11:12:19 --> Helper loaded: form_helper
INFO - 2018-09-30 11:12:19 --> Helper loaded: html_helper
INFO - 2018-09-30 11:12:19 --> Database Driver Class Initialized
INFO - 2018-09-30 11:12:19 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:12:19 --> Model "User_model" initialized
INFO - 2018-09-30 11:12:19 --> Model "Project_model" initialized
INFO - 2018-09-30 11:12:19 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:12:19 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:12:19 --> Controller Class Initialized
INFO - 2018-09-30 11:12:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:12:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 11:12:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:12:19 --> Final output sent to browser
DEBUG - 2018-09-30 11:12:19 --> Total execution time: 0.0380
INFO - 2018-09-30 11:12:21 --> Config Class Initialized
INFO - 2018-09-30 11:12:21 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:12:21 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:12:21 --> Utf8 Class Initialized
INFO - 2018-09-30 11:12:21 --> URI Class Initialized
INFO - 2018-09-30 11:12:21 --> Router Class Initialized
INFO - 2018-09-30 11:12:21 --> Output Class Initialized
INFO - 2018-09-30 11:12:21 --> Security Class Initialized
DEBUG - 2018-09-30 11:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:12:21 --> Input Class Initialized
INFO - 2018-09-30 11:12:21 --> Language Class Initialized
INFO - 2018-09-30 11:12:21 --> Loader Class Initialized
INFO - 2018-09-30 11:12:21 --> Helper loaded: url_helper
INFO - 2018-09-30 11:12:21 --> Helper loaded: form_helper
INFO - 2018-09-30 11:12:21 --> Helper loaded: html_helper
INFO - 2018-09-30 11:12:21 --> Database Driver Class Initialized
INFO - 2018-09-30 11:12:21 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:12:21 --> Model "User_model" initialized
INFO - 2018-09-30 11:12:21 --> Model "Project_model" initialized
INFO - 2018-09-30 11:12:21 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:12:21 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:12:21 --> Controller Class Initialized
INFO - 2018-09-30 11:12:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:12:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/edit_project.php
INFO - 2018-09-30 11:12:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:12:21 --> Final output sent to browser
DEBUG - 2018-09-30 11:12:21 --> Total execution time: 0.0720
INFO - 2018-09-30 11:12:25 --> Config Class Initialized
INFO - 2018-09-30 11:12:25 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:12:25 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:12:25 --> Utf8 Class Initialized
INFO - 2018-09-30 11:12:25 --> URI Class Initialized
INFO - 2018-09-30 11:12:25 --> Router Class Initialized
INFO - 2018-09-30 11:12:25 --> Output Class Initialized
INFO - 2018-09-30 11:12:25 --> Security Class Initialized
DEBUG - 2018-09-30 11:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:12:25 --> Input Class Initialized
INFO - 2018-09-30 11:12:25 --> Language Class Initialized
INFO - 2018-09-30 11:12:25 --> Loader Class Initialized
INFO - 2018-09-30 11:12:25 --> Helper loaded: url_helper
INFO - 2018-09-30 11:12:25 --> Helper loaded: form_helper
INFO - 2018-09-30 11:12:25 --> Helper loaded: html_helper
INFO - 2018-09-30 11:12:25 --> Database Driver Class Initialized
INFO - 2018-09-30 11:12:25 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:12:25 --> Model "User_model" initialized
INFO - 2018-09-30 11:12:25 --> Model "Project_model" initialized
INFO - 2018-09-30 11:12:25 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:12:25 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:12:25 --> Controller Class Initialized
INFO - 2018-09-30 11:12:25 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-09-30 11:12:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\code_igniter\application\models\project_models\project_model.php 47
ERROR - 2018-09-30 11:12:25 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$Array D:\xampp\htdocs\code_igniter\application\models\project_models\project_model.php 47
ERROR - 2018-09-30 11:12:25 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\code_igniter\application\models\project_models\project_model.php 47
ERROR - 2018-09-30 11:12:25 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$Array D:\xampp\htdocs\code_igniter\application\models\project_models\project_model.php 47
INFO - 2018-09-30 11:12:25 --> Config Class Initialized
INFO - 2018-09-30 11:12:25 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:12:25 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:12:25 --> Utf8 Class Initialized
INFO - 2018-09-30 11:12:25 --> URI Class Initialized
INFO - 2018-09-30 11:12:25 --> Router Class Initialized
INFO - 2018-09-30 11:12:25 --> Output Class Initialized
INFO - 2018-09-30 11:12:25 --> Security Class Initialized
DEBUG - 2018-09-30 11:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:12:25 --> Input Class Initialized
INFO - 2018-09-30 11:12:25 --> Language Class Initialized
INFO - 2018-09-30 11:12:25 --> Loader Class Initialized
INFO - 2018-09-30 11:12:25 --> Helper loaded: url_helper
INFO - 2018-09-30 11:12:25 --> Helper loaded: form_helper
INFO - 2018-09-30 11:12:25 --> Helper loaded: html_helper
INFO - 2018-09-30 11:12:25 --> Database Driver Class Initialized
INFO - 2018-09-30 11:12:25 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:12:25 --> Model "User_model" initialized
INFO - 2018-09-30 11:12:25 --> Model "Project_model" initialized
INFO - 2018-09-30 11:12:25 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:12:25 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:12:25 --> Controller Class Initialized
INFO - 2018-09-30 11:12:25 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:12:25 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 11:12:25 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:12:25 --> Final output sent to browser
DEBUG - 2018-09-30 11:12:25 --> Total execution time: 0.0450
INFO - 2018-09-30 11:12:38 --> Config Class Initialized
INFO - 2018-09-30 11:12:38 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:12:38 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:12:38 --> Utf8 Class Initialized
INFO - 2018-09-30 11:12:38 --> URI Class Initialized
INFO - 2018-09-30 11:12:38 --> Router Class Initialized
INFO - 2018-09-30 11:12:38 --> Output Class Initialized
INFO - 2018-09-30 11:12:38 --> Security Class Initialized
DEBUG - 2018-09-30 11:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:12:38 --> Input Class Initialized
INFO - 2018-09-30 11:12:38 --> Language Class Initialized
INFO - 2018-09-30 11:12:38 --> Loader Class Initialized
INFO - 2018-09-30 11:12:38 --> Helper loaded: url_helper
INFO - 2018-09-30 11:12:38 --> Helper loaded: form_helper
INFO - 2018-09-30 11:12:38 --> Helper loaded: html_helper
INFO - 2018-09-30 11:12:38 --> Database Driver Class Initialized
INFO - 2018-09-30 11:12:38 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:12:38 --> Model "User_model" initialized
INFO - 2018-09-30 11:12:38 --> Model "Project_model" initialized
INFO - 2018-09-30 11:12:38 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:12:38 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:12:38 --> Controller Class Initialized
INFO - 2018-09-30 11:12:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:12:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 11:12:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:12:38 --> Final output sent to browser
DEBUG - 2018-09-30 11:12:38 --> Total execution time: 0.0640
INFO - 2018-09-30 11:13:56 --> Config Class Initialized
INFO - 2018-09-30 11:13:56 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:13:56 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:13:56 --> Utf8 Class Initialized
INFO - 2018-09-30 11:13:56 --> URI Class Initialized
INFO - 2018-09-30 11:13:56 --> Router Class Initialized
INFO - 2018-09-30 11:13:56 --> Output Class Initialized
INFO - 2018-09-30 11:13:56 --> Security Class Initialized
DEBUG - 2018-09-30 11:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:13:56 --> Input Class Initialized
INFO - 2018-09-30 11:13:56 --> Language Class Initialized
INFO - 2018-09-30 11:13:56 --> Loader Class Initialized
INFO - 2018-09-30 11:13:56 --> Helper loaded: url_helper
INFO - 2018-09-30 11:13:56 --> Helper loaded: form_helper
INFO - 2018-09-30 11:13:56 --> Helper loaded: html_helper
INFO - 2018-09-30 11:13:56 --> Database Driver Class Initialized
INFO - 2018-09-30 11:13:56 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:13:56 --> Model "User_model" initialized
INFO - 2018-09-30 11:13:56 --> Model "Project_model" initialized
INFO - 2018-09-30 11:13:56 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:13:56 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:13:56 --> Controller Class Initialized
INFO - 2018-09-30 11:13:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:13:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 11:13:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:13:56 --> Final output sent to browser
DEBUG - 2018-09-30 11:13:56 --> Total execution time: 0.0750
INFO - 2018-09-30 11:13:58 --> Config Class Initialized
INFO - 2018-09-30 11:13:58 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:13:58 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:13:58 --> Utf8 Class Initialized
INFO - 2018-09-30 11:13:58 --> URI Class Initialized
INFO - 2018-09-30 11:13:58 --> Router Class Initialized
INFO - 2018-09-30 11:13:58 --> Output Class Initialized
INFO - 2018-09-30 11:13:58 --> Security Class Initialized
DEBUG - 2018-09-30 11:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:13:58 --> Input Class Initialized
INFO - 2018-09-30 11:13:58 --> Language Class Initialized
INFO - 2018-09-30 11:13:58 --> Loader Class Initialized
INFO - 2018-09-30 11:13:58 --> Helper loaded: url_helper
INFO - 2018-09-30 11:13:58 --> Helper loaded: form_helper
INFO - 2018-09-30 11:13:58 --> Helper loaded: html_helper
INFO - 2018-09-30 11:13:58 --> Database Driver Class Initialized
INFO - 2018-09-30 11:13:58 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:13:58 --> Model "User_model" initialized
INFO - 2018-09-30 11:13:58 --> Model "Project_model" initialized
INFO - 2018-09-30 11:13:58 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:13:58 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:13:58 --> Controller Class Initialized
INFO - 2018-09-30 11:13:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:13:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/edit_project.php
INFO - 2018-09-30 11:13:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:13:58 --> Final output sent to browser
DEBUG - 2018-09-30 11:13:58 --> Total execution time: 0.0620
INFO - 2018-09-30 11:14:01 --> Config Class Initialized
INFO - 2018-09-30 11:14:01 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:14:01 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:14:01 --> Utf8 Class Initialized
INFO - 2018-09-30 11:14:01 --> URI Class Initialized
INFO - 2018-09-30 11:14:01 --> Router Class Initialized
INFO - 2018-09-30 11:14:01 --> Output Class Initialized
INFO - 2018-09-30 11:14:01 --> Security Class Initialized
DEBUG - 2018-09-30 11:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:14:01 --> Input Class Initialized
INFO - 2018-09-30 11:14:01 --> Language Class Initialized
INFO - 2018-09-30 11:14:01 --> Loader Class Initialized
INFO - 2018-09-30 11:14:01 --> Helper loaded: url_helper
INFO - 2018-09-30 11:14:01 --> Helper loaded: form_helper
INFO - 2018-09-30 11:14:01 --> Helper loaded: html_helper
INFO - 2018-09-30 11:14:01 --> Database Driver Class Initialized
INFO - 2018-09-30 11:14:01 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:14:01 --> Model "User_model" initialized
INFO - 2018-09-30 11:14:01 --> Model "Project_model" initialized
INFO - 2018-09-30 11:14:01 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:14:01 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:14:01 --> Controller Class Initialized
INFO - 2018-09-30 11:14:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-30 11:14:01 --> Config Class Initialized
INFO - 2018-09-30 11:14:01 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:14:01 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:14:01 --> Utf8 Class Initialized
INFO - 2018-09-30 11:14:01 --> URI Class Initialized
INFO - 2018-09-30 11:14:01 --> Router Class Initialized
INFO - 2018-09-30 11:14:01 --> Output Class Initialized
INFO - 2018-09-30 11:14:01 --> Security Class Initialized
DEBUG - 2018-09-30 11:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:14:01 --> Input Class Initialized
INFO - 2018-09-30 11:14:01 --> Language Class Initialized
INFO - 2018-09-30 11:14:01 --> Loader Class Initialized
INFO - 2018-09-30 11:14:01 --> Helper loaded: url_helper
INFO - 2018-09-30 11:14:01 --> Helper loaded: form_helper
INFO - 2018-09-30 11:14:01 --> Helper loaded: html_helper
INFO - 2018-09-30 11:14:01 --> Database Driver Class Initialized
INFO - 2018-09-30 11:14:01 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:14:01 --> Model "User_model" initialized
INFO - 2018-09-30 11:14:01 --> Model "Project_model" initialized
INFO - 2018-09-30 11:14:01 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:14:01 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:14:01 --> Controller Class Initialized
INFO - 2018-09-30 11:14:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:14:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 11:14:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:14:01 --> Final output sent to browser
DEBUG - 2018-09-30 11:14:01 --> Total execution time: 0.0340
INFO - 2018-09-30 11:22:00 --> Config Class Initialized
INFO - 2018-09-30 11:22:00 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:22:00 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:22:00 --> Utf8 Class Initialized
INFO - 2018-09-30 11:22:00 --> URI Class Initialized
INFO - 2018-09-30 11:22:00 --> Router Class Initialized
INFO - 2018-09-30 11:22:00 --> Output Class Initialized
INFO - 2018-09-30 11:22:00 --> Security Class Initialized
DEBUG - 2018-09-30 11:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:22:00 --> Input Class Initialized
INFO - 2018-09-30 11:22:00 --> Language Class Initialized
INFO - 2018-09-30 11:22:00 --> Loader Class Initialized
INFO - 2018-09-30 11:22:00 --> Helper loaded: url_helper
INFO - 2018-09-30 11:22:00 --> Helper loaded: form_helper
INFO - 2018-09-30 11:22:00 --> Helper loaded: html_helper
INFO - 2018-09-30 11:22:00 --> Database Driver Class Initialized
INFO - 2018-09-30 11:22:00 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:22:00 --> Model "User_model" initialized
INFO - 2018-09-30 11:22:00 --> Model "Project_model" initialized
INFO - 2018-09-30 11:22:00 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:22:00 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:22:00 --> Controller Class Initialized
INFO - 2018-09-30 11:22:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:22:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 11:22:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:22:00 --> Final output sent to browser
DEBUG - 2018-09-30 11:22:00 --> Total execution time: 0.0950
INFO - 2018-09-30 11:22:01 --> Config Class Initialized
INFO - 2018-09-30 11:22:01 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:22:01 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:22:01 --> Utf8 Class Initialized
INFO - 2018-09-30 11:22:01 --> URI Class Initialized
INFO - 2018-09-30 11:22:01 --> Router Class Initialized
INFO - 2018-09-30 11:22:01 --> Output Class Initialized
INFO - 2018-09-30 11:22:01 --> Security Class Initialized
DEBUG - 2018-09-30 11:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:22:01 --> Input Class Initialized
INFO - 2018-09-30 11:22:01 --> Language Class Initialized
INFO - 2018-09-30 11:22:01 --> Loader Class Initialized
INFO - 2018-09-30 11:22:01 --> Helper loaded: url_helper
INFO - 2018-09-30 11:22:01 --> Helper loaded: form_helper
INFO - 2018-09-30 11:22:01 --> Helper loaded: html_helper
INFO - 2018-09-30 11:22:01 --> Database Driver Class Initialized
INFO - 2018-09-30 11:22:01 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:22:01 --> Model "User_model" initialized
INFO - 2018-09-30 11:22:01 --> Model "Project_model" initialized
INFO - 2018-09-30 11:22:01 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:22:01 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:22:01 --> Controller Class Initialized
INFO - 2018-09-30 11:22:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:22:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/edit_project.php
INFO - 2018-09-30 11:22:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:22:01 --> Final output sent to browser
DEBUG - 2018-09-30 11:22:01 --> Total execution time: 0.1040
INFO - 2018-09-30 11:22:08 --> Config Class Initialized
INFO - 2018-09-30 11:22:08 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:22:08 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:22:08 --> Utf8 Class Initialized
INFO - 2018-09-30 11:22:08 --> URI Class Initialized
INFO - 2018-09-30 11:22:08 --> Router Class Initialized
INFO - 2018-09-30 11:22:08 --> Output Class Initialized
INFO - 2018-09-30 11:22:08 --> Security Class Initialized
DEBUG - 2018-09-30 11:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:22:08 --> Input Class Initialized
INFO - 2018-09-30 11:22:08 --> Language Class Initialized
INFO - 2018-09-30 11:22:08 --> Loader Class Initialized
INFO - 2018-09-30 11:22:08 --> Helper loaded: url_helper
INFO - 2018-09-30 11:22:08 --> Helper loaded: form_helper
INFO - 2018-09-30 11:22:08 --> Helper loaded: html_helper
INFO - 2018-09-30 11:22:08 --> Database Driver Class Initialized
INFO - 2018-09-30 11:22:08 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:22:08 --> Model "User_model" initialized
INFO - 2018-09-30 11:22:08 --> Model "Project_model" initialized
INFO - 2018-09-30 11:22:08 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:22:08 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:22:08 --> Controller Class Initialized
INFO - 2018-09-30 11:22:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-30 11:22:08 --> Language file loaded: language/english/db_lang.php
INFO - 2018-09-30 11:22:58 --> Config Class Initialized
INFO - 2018-09-30 11:22:58 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:22:58 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:22:58 --> Utf8 Class Initialized
INFO - 2018-09-30 11:22:58 --> URI Class Initialized
INFO - 2018-09-30 11:22:58 --> Router Class Initialized
INFO - 2018-09-30 11:22:58 --> Output Class Initialized
INFO - 2018-09-30 11:22:58 --> Security Class Initialized
DEBUG - 2018-09-30 11:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:22:58 --> Input Class Initialized
INFO - 2018-09-30 11:22:58 --> Language Class Initialized
INFO - 2018-09-30 11:22:58 --> Loader Class Initialized
INFO - 2018-09-30 11:22:58 --> Helper loaded: url_helper
INFO - 2018-09-30 11:22:58 --> Helper loaded: form_helper
INFO - 2018-09-30 11:22:58 --> Helper loaded: html_helper
INFO - 2018-09-30 11:22:58 --> Database Driver Class Initialized
INFO - 2018-09-30 11:22:58 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:22:58 --> Model "User_model" initialized
INFO - 2018-09-30 11:22:58 --> Model "Project_model" initialized
INFO - 2018-09-30 11:22:58 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:22:58 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:22:58 --> Controller Class Initialized
INFO - 2018-09-30 11:22:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:22:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/edit_project.php
INFO - 2018-09-30 11:22:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:22:58 --> Final output sent to browser
DEBUG - 2018-09-30 11:22:58 --> Total execution time: 0.0500
INFO - 2018-09-30 11:23:01 --> Config Class Initialized
INFO - 2018-09-30 11:23:01 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:23:01 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:23:01 --> Utf8 Class Initialized
INFO - 2018-09-30 11:23:01 --> URI Class Initialized
INFO - 2018-09-30 11:23:01 --> Router Class Initialized
INFO - 2018-09-30 11:23:01 --> Output Class Initialized
INFO - 2018-09-30 11:23:01 --> Security Class Initialized
DEBUG - 2018-09-30 11:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:23:01 --> Input Class Initialized
INFO - 2018-09-30 11:23:01 --> Language Class Initialized
INFO - 2018-09-30 11:23:01 --> Loader Class Initialized
INFO - 2018-09-30 11:23:01 --> Helper loaded: url_helper
INFO - 2018-09-30 11:23:01 --> Helper loaded: form_helper
INFO - 2018-09-30 11:23:01 --> Helper loaded: html_helper
INFO - 2018-09-30 11:23:01 --> Database Driver Class Initialized
INFO - 2018-09-30 11:23:01 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:23:01 --> Model "User_model" initialized
INFO - 2018-09-30 11:23:01 --> Model "Project_model" initialized
INFO - 2018-09-30 11:23:01 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:23:01 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:23:01 --> Controller Class Initialized
INFO - 2018-09-30 11:23:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-30 11:23:01 --> Language file loaded: language/english/db_lang.php
INFO - 2018-09-30 11:23:15 --> Config Class Initialized
INFO - 2018-09-30 11:23:15 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:23:15 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:23:15 --> Utf8 Class Initialized
INFO - 2018-09-30 11:23:15 --> URI Class Initialized
INFO - 2018-09-30 11:23:15 --> Router Class Initialized
INFO - 2018-09-30 11:23:15 --> Output Class Initialized
INFO - 2018-09-30 11:23:15 --> Security Class Initialized
DEBUG - 2018-09-30 11:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:23:15 --> Input Class Initialized
INFO - 2018-09-30 11:23:15 --> Language Class Initialized
INFO - 2018-09-30 11:23:15 --> Loader Class Initialized
INFO - 2018-09-30 11:23:15 --> Helper loaded: url_helper
INFO - 2018-09-30 11:23:15 --> Helper loaded: form_helper
INFO - 2018-09-30 11:23:15 --> Helper loaded: html_helper
INFO - 2018-09-30 11:23:15 --> Database Driver Class Initialized
INFO - 2018-09-30 11:23:15 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:23:15 --> Model "User_model" initialized
INFO - 2018-09-30 11:23:15 --> Model "Project_model" initialized
INFO - 2018-09-30 11:23:15 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:23:15 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:23:15 --> Controller Class Initialized
INFO - 2018-09-30 11:23:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:23:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/edit_project.php
INFO - 2018-09-30 11:23:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:23:15 --> Final output sent to browser
DEBUG - 2018-09-30 11:23:15 --> Total execution time: 0.0460
INFO - 2018-09-30 11:23:16 --> Config Class Initialized
INFO - 2018-09-30 11:23:16 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:23:16 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:23:16 --> Utf8 Class Initialized
INFO - 2018-09-30 11:23:16 --> URI Class Initialized
INFO - 2018-09-30 11:23:16 --> Router Class Initialized
INFO - 2018-09-30 11:23:16 --> Output Class Initialized
INFO - 2018-09-30 11:23:16 --> Security Class Initialized
DEBUG - 2018-09-30 11:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:23:16 --> Input Class Initialized
INFO - 2018-09-30 11:23:16 --> Language Class Initialized
INFO - 2018-09-30 11:23:16 --> Loader Class Initialized
INFO - 2018-09-30 11:23:16 --> Helper loaded: url_helper
INFO - 2018-09-30 11:23:16 --> Helper loaded: form_helper
INFO - 2018-09-30 11:23:16 --> Helper loaded: html_helper
INFO - 2018-09-30 11:23:16 --> Database Driver Class Initialized
INFO - 2018-09-30 11:23:16 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:23:16 --> Model "User_model" initialized
INFO - 2018-09-30 11:23:16 --> Model "Project_model" initialized
INFO - 2018-09-30 11:23:16 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:23:16 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:23:16 --> Controller Class Initialized
INFO - 2018-09-30 11:23:16 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-09-30 11:23:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\code_igniter\system\database\DB_query_builder.php 2009
INFO - 2018-09-30 11:23:16 --> Final output sent to browser
DEBUG - 2018-09-30 11:23:16 --> Total execution time: 0.0360
INFO - 2018-09-30 11:23:48 --> Config Class Initialized
INFO - 2018-09-30 11:23:48 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:23:48 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:23:48 --> Utf8 Class Initialized
INFO - 2018-09-30 11:23:48 --> URI Class Initialized
INFO - 2018-09-30 11:23:48 --> Router Class Initialized
INFO - 2018-09-30 11:23:48 --> Output Class Initialized
INFO - 2018-09-30 11:23:48 --> Security Class Initialized
DEBUG - 2018-09-30 11:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:23:48 --> Input Class Initialized
INFO - 2018-09-30 11:23:48 --> Language Class Initialized
INFO - 2018-09-30 11:23:48 --> Loader Class Initialized
INFO - 2018-09-30 11:23:48 --> Helper loaded: url_helper
INFO - 2018-09-30 11:23:48 --> Helper loaded: form_helper
INFO - 2018-09-30 11:23:48 --> Helper loaded: html_helper
INFO - 2018-09-30 11:23:48 --> Database Driver Class Initialized
INFO - 2018-09-30 11:23:48 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:23:48 --> Model "User_model" initialized
INFO - 2018-09-30 11:23:48 --> Model "Project_model" initialized
INFO - 2018-09-30 11:23:48 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:23:48 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:23:48 --> Controller Class Initialized
INFO - 2018-09-30 11:23:48 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:23:48 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/edit_project.php
INFO - 2018-09-30 11:23:48 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:23:48 --> Final output sent to browser
DEBUG - 2018-09-30 11:23:48 --> Total execution time: 0.0440
INFO - 2018-09-30 11:24:09 --> Config Class Initialized
INFO - 2018-09-30 11:24:09 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:24:09 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:24:09 --> Utf8 Class Initialized
INFO - 2018-09-30 11:24:09 --> URI Class Initialized
INFO - 2018-09-30 11:24:09 --> Router Class Initialized
INFO - 2018-09-30 11:24:09 --> Output Class Initialized
INFO - 2018-09-30 11:24:09 --> Security Class Initialized
DEBUG - 2018-09-30 11:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:24:09 --> Input Class Initialized
INFO - 2018-09-30 11:24:09 --> Language Class Initialized
INFO - 2018-09-30 11:24:09 --> Loader Class Initialized
INFO - 2018-09-30 11:24:09 --> Helper loaded: url_helper
INFO - 2018-09-30 11:24:09 --> Helper loaded: form_helper
INFO - 2018-09-30 11:24:09 --> Helper loaded: html_helper
INFO - 2018-09-30 11:24:09 --> Database Driver Class Initialized
INFO - 2018-09-30 11:24:09 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:24:09 --> Model "User_model" initialized
INFO - 2018-09-30 11:24:09 --> Model "Project_model" initialized
INFO - 2018-09-30 11:24:09 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:24:09 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:24:09 --> Controller Class Initialized
INFO - 2018-09-30 11:24:09 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-09-30 11:24:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\code_igniter\system\database\DB_query_builder.php 2009
INFO - 2018-09-30 11:24:09 --> Final output sent to browser
DEBUG - 2018-09-30 11:24:09 --> Total execution time: 0.0610
INFO - 2018-09-30 11:24:12 --> Config Class Initialized
INFO - 2018-09-30 11:24:12 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:24:12 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:24:12 --> Utf8 Class Initialized
INFO - 2018-09-30 11:24:12 --> URI Class Initialized
INFO - 2018-09-30 11:24:12 --> Router Class Initialized
INFO - 2018-09-30 11:24:12 --> Output Class Initialized
INFO - 2018-09-30 11:24:12 --> Security Class Initialized
DEBUG - 2018-09-30 11:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:24:12 --> Input Class Initialized
INFO - 2018-09-30 11:24:12 --> Language Class Initialized
INFO - 2018-09-30 11:24:12 --> Loader Class Initialized
INFO - 2018-09-30 11:24:12 --> Helper loaded: url_helper
INFO - 2018-09-30 11:24:12 --> Helper loaded: form_helper
INFO - 2018-09-30 11:24:12 --> Helper loaded: html_helper
INFO - 2018-09-30 11:24:12 --> Database Driver Class Initialized
INFO - 2018-09-30 11:24:12 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:24:12 --> Model "User_model" initialized
INFO - 2018-09-30 11:24:12 --> Model "Project_model" initialized
INFO - 2018-09-30 11:24:12 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:24:12 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:24:12 --> Controller Class Initialized
INFO - 2018-09-30 11:24:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:24:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/edit_project.php
INFO - 2018-09-30 11:24:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:24:12 --> Final output sent to browser
DEBUG - 2018-09-30 11:24:12 --> Total execution time: 0.0500
INFO - 2018-09-30 11:24:47 --> Config Class Initialized
INFO - 2018-09-30 11:24:47 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:24:47 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:24:47 --> Utf8 Class Initialized
INFO - 2018-09-30 11:24:47 --> URI Class Initialized
INFO - 2018-09-30 11:24:47 --> Router Class Initialized
INFO - 2018-09-30 11:24:47 --> Output Class Initialized
INFO - 2018-09-30 11:24:47 --> Security Class Initialized
DEBUG - 2018-09-30 11:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:24:47 --> Input Class Initialized
INFO - 2018-09-30 11:24:47 --> Language Class Initialized
INFO - 2018-09-30 11:24:47 --> Loader Class Initialized
INFO - 2018-09-30 11:24:47 --> Helper loaded: url_helper
INFO - 2018-09-30 11:24:47 --> Helper loaded: form_helper
INFO - 2018-09-30 11:24:47 --> Helper loaded: html_helper
INFO - 2018-09-30 11:24:47 --> Database Driver Class Initialized
INFO - 2018-09-30 11:24:47 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:24:47 --> Model "User_model" initialized
INFO - 2018-09-30 11:24:47 --> Model "Project_model" initialized
INFO - 2018-09-30 11:24:47 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:24:47 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:24:47 --> Controller Class Initialized
INFO - 2018-09-30 11:24:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:24:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 11:24:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:24:47 --> Final output sent to browser
DEBUG - 2018-09-30 11:24:47 --> Total execution time: 0.0410
INFO - 2018-09-30 11:24:49 --> Config Class Initialized
INFO - 2018-09-30 11:24:49 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:24:49 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:24:49 --> Utf8 Class Initialized
INFO - 2018-09-30 11:24:49 --> URI Class Initialized
INFO - 2018-09-30 11:24:49 --> Router Class Initialized
INFO - 2018-09-30 11:24:49 --> Output Class Initialized
INFO - 2018-09-30 11:24:49 --> Security Class Initialized
DEBUG - 2018-09-30 11:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:24:49 --> Input Class Initialized
INFO - 2018-09-30 11:24:49 --> Language Class Initialized
INFO - 2018-09-30 11:24:49 --> Loader Class Initialized
INFO - 2018-09-30 11:24:49 --> Helper loaded: url_helper
INFO - 2018-09-30 11:24:49 --> Helper loaded: form_helper
INFO - 2018-09-30 11:24:49 --> Helper loaded: html_helper
INFO - 2018-09-30 11:24:49 --> Database Driver Class Initialized
INFO - 2018-09-30 11:24:49 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:24:49 --> Model "User_model" initialized
INFO - 2018-09-30 11:24:49 --> Model "Project_model" initialized
INFO - 2018-09-30 11:24:49 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:24:49 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:24:49 --> Controller Class Initialized
INFO - 2018-09-30 11:24:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:24:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 11:24:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:24:49 --> Final output sent to browser
DEBUG - 2018-09-30 11:24:49 --> Total execution time: 0.0800
INFO - 2018-09-30 11:24:51 --> Config Class Initialized
INFO - 2018-09-30 11:24:51 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:24:51 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:24:51 --> Utf8 Class Initialized
INFO - 2018-09-30 11:24:51 --> URI Class Initialized
INFO - 2018-09-30 11:24:51 --> Router Class Initialized
INFO - 2018-09-30 11:24:51 --> Output Class Initialized
INFO - 2018-09-30 11:24:51 --> Security Class Initialized
DEBUG - 2018-09-30 11:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:24:51 --> Input Class Initialized
INFO - 2018-09-30 11:24:51 --> Language Class Initialized
INFO - 2018-09-30 11:24:51 --> Loader Class Initialized
INFO - 2018-09-30 11:24:51 --> Helper loaded: url_helper
INFO - 2018-09-30 11:24:51 --> Helper loaded: form_helper
INFO - 2018-09-30 11:24:51 --> Helper loaded: html_helper
INFO - 2018-09-30 11:24:51 --> Database Driver Class Initialized
INFO - 2018-09-30 11:24:51 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:24:51 --> Model "User_model" initialized
INFO - 2018-09-30 11:24:51 --> Model "Project_model" initialized
INFO - 2018-09-30 11:24:51 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:24:51 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:24:51 --> Controller Class Initialized
INFO - 2018-09-30 11:24:51 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:24:51 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/edit_project.php
INFO - 2018-09-30 11:24:51 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:24:51 --> Final output sent to browser
DEBUG - 2018-09-30 11:24:51 --> Total execution time: 0.0590
INFO - 2018-09-30 11:24:57 --> Config Class Initialized
INFO - 2018-09-30 11:24:57 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:24:57 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:24:57 --> Utf8 Class Initialized
INFO - 2018-09-30 11:24:57 --> URI Class Initialized
INFO - 2018-09-30 11:24:57 --> Router Class Initialized
INFO - 2018-09-30 11:24:57 --> Output Class Initialized
INFO - 2018-09-30 11:24:57 --> Security Class Initialized
DEBUG - 2018-09-30 11:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:24:57 --> Input Class Initialized
INFO - 2018-09-30 11:24:57 --> Language Class Initialized
INFO - 2018-09-30 11:24:57 --> Loader Class Initialized
INFO - 2018-09-30 11:24:57 --> Helper loaded: url_helper
INFO - 2018-09-30 11:24:57 --> Helper loaded: form_helper
INFO - 2018-09-30 11:24:57 --> Helper loaded: html_helper
INFO - 2018-09-30 11:24:57 --> Database Driver Class Initialized
INFO - 2018-09-30 11:24:57 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:24:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:24:57 --> Model "User_model" initialized
INFO - 2018-09-30 11:24:57 --> Model "Project_model" initialized
INFO - 2018-09-30 11:24:57 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:24:57 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:24:57 --> Controller Class Initialized
INFO - 2018-09-30 11:24:57 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-09-30 11:24:57 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\code_igniter\system\database\DB_query_builder.php 2009
INFO - 2018-09-30 11:24:57 --> Final output sent to browser
DEBUG - 2018-09-30 11:24:57 --> Total execution time: 0.0520
INFO - 2018-09-30 11:25:33 --> Config Class Initialized
INFO - 2018-09-30 11:25:33 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:25:33 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:25:33 --> Utf8 Class Initialized
INFO - 2018-09-30 11:25:33 --> URI Class Initialized
INFO - 2018-09-30 11:25:33 --> Router Class Initialized
INFO - 2018-09-30 11:25:33 --> Output Class Initialized
INFO - 2018-09-30 11:25:33 --> Security Class Initialized
DEBUG - 2018-09-30 11:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:25:33 --> Input Class Initialized
INFO - 2018-09-30 11:25:33 --> Language Class Initialized
INFO - 2018-09-30 11:25:33 --> Loader Class Initialized
INFO - 2018-09-30 11:25:33 --> Helper loaded: url_helper
INFO - 2018-09-30 11:25:33 --> Helper loaded: form_helper
INFO - 2018-09-30 11:25:33 --> Helper loaded: html_helper
INFO - 2018-09-30 11:25:33 --> Database Driver Class Initialized
INFO - 2018-09-30 11:25:33 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:25:33 --> Model "User_model" initialized
INFO - 2018-09-30 11:25:33 --> Model "Project_model" initialized
INFO - 2018-09-30 11:25:33 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:25:33 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:25:33 --> Controller Class Initialized
INFO - 2018-09-30 11:25:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:25:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/edit_project.php
INFO - 2018-09-30 11:25:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:25:33 --> Final output sent to browser
DEBUG - 2018-09-30 11:25:33 --> Total execution time: 0.0510
INFO - 2018-09-30 11:25:36 --> Config Class Initialized
INFO - 2018-09-30 11:25:36 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:25:36 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:25:36 --> Utf8 Class Initialized
INFO - 2018-09-30 11:25:36 --> URI Class Initialized
INFO - 2018-09-30 11:25:36 --> Router Class Initialized
INFO - 2018-09-30 11:25:36 --> Output Class Initialized
INFO - 2018-09-30 11:25:36 --> Security Class Initialized
DEBUG - 2018-09-30 11:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:25:36 --> Input Class Initialized
INFO - 2018-09-30 11:25:36 --> Language Class Initialized
INFO - 2018-09-30 11:25:36 --> Loader Class Initialized
INFO - 2018-09-30 11:25:36 --> Helper loaded: url_helper
INFO - 2018-09-30 11:25:36 --> Helper loaded: form_helper
INFO - 2018-09-30 11:25:36 --> Helper loaded: html_helper
INFO - 2018-09-30 11:25:36 --> Database Driver Class Initialized
INFO - 2018-09-30 11:25:36 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:25:36 --> Model "User_model" initialized
INFO - 2018-09-30 11:25:36 --> Model "Project_model" initialized
INFO - 2018-09-30 11:25:36 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:25:36 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:25:36 --> Controller Class Initialized
INFO - 2018-09-30 11:25:36 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-09-30 11:25:36 --> Severity: error --> Exception: Call to undefined method Project_model::edit_project() D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\projects.php 84
INFO - 2018-09-30 11:25:50 --> Config Class Initialized
INFO - 2018-09-30 11:25:50 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:25:50 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:25:50 --> Utf8 Class Initialized
INFO - 2018-09-30 11:25:50 --> URI Class Initialized
INFO - 2018-09-30 11:25:50 --> Router Class Initialized
INFO - 2018-09-30 11:25:50 --> Output Class Initialized
INFO - 2018-09-30 11:25:50 --> Security Class Initialized
DEBUG - 2018-09-30 11:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:25:50 --> Input Class Initialized
INFO - 2018-09-30 11:25:50 --> Language Class Initialized
INFO - 2018-09-30 11:25:50 --> Loader Class Initialized
INFO - 2018-09-30 11:25:50 --> Helper loaded: url_helper
INFO - 2018-09-30 11:25:50 --> Helper loaded: form_helper
INFO - 2018-09-30 11:25:50 --> Helper loaded: html_helper
INFO - 2018-09-30 11:25:50 --> Database Driver Class Initialized
INFO - 2018-09-30 11:25:50 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:25:50 --> Model "User_model" initialized
INFO - 2018-09-30 11:25:50 --> Model "Project_model" initialized
INFO - 2018-09-30 11:25:50 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:25:50 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:25:50 --> Controller Class Initialized
INFO - 2018-09-30 11:25:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-30 11:25:50 --> Config Class Initialized
INFO - 2018-09-30 11:25:50 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:25:50 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:25:50 --> Utf8 Class Initialized
INFO - 2018-09-30 11:25:50 --> URI Class Initialized
INFO - 2018-09-30 11:25:50 --> Router Class Initialized
INFO - 2018-09-30 11:25:50 --> Output Class Initialized
INFO - 2018-09-30 11:25:50 --> Security Class Initialized
DEBUG - 2018-09-30 11:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:25:50 --> Input Class Initialized
INFO - 2018-09-30 11:25:50 --> Language Class Initialized
INFO - 2018-09-30 11:25:50 --> Loader Class Initialized
INFO - 2018-09-30 11:25:50 --> Helper loaded: url_helper
INFO - 2018-09-30 11:25:50 --> Helper loaded: form_helper
INFO - 2018-09-30 11:25:50 --> Helper loaded: html_helper
INFO - 2018-09-30 11:25:50 --> Database Driver Class Initialized
INFO - 2018-09-30 11:25:50 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:25:50 --> Model "User_model" initialized
INFO - 2018-09-30 11:25:50 --> Model "Project_model" initialized
INFO - 2018-09-30 11:25:50 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:25:50 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:25:50 --> Controller Class Initialized
INFO - 2018-09-30 11:25:50 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:25:50 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 11:25:50 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:25:50 --> Final output sent to browser
DEBUG - 2018-09-30 11:25:50 --> Total execution time: 0.0510
INFO - 2018-09-30 11:30:44 --> Config Class Initialized
INFO - 2018-09-30 11:30:44 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:30:44 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:30:44 --> Utf8 Class Initialized
INFO - 2018-09-30 11:30:44 --> URI Class Initialized
INFO - 2018-09-30 11:30:44 --> Router Class Initialized
INFO - 2018-09-30 11:30:44 --> Output Class Initialized
INFO - 2018-09-30 11:30:44 --> Security Class Initialized
DEBUG - 2018-09-30 11:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:30:44 --> Input Class Initialized
INFO - 2018-09-30 11:30:44 --> Language Class Initialized
INFO - 2018-09-30 11:30:44 --> Loader Class Initialized
INFO - 2018-09-30 11:30:44 --> Helper loaded: url_helper
INFO - 2018-09-30 11:30:44 --> Helper loaded: form_helper
INFO - 2018-09-30 11:30:44 --> Helper loaded: html_helper
INFO - 2018-09-30 11:30:44 --> Database Driver Class Initialized
INFO - 2018-09-30 11:30:44 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:30:44 --> Model "User_model" initialized
INFO - 2018-09-30 11:30:44 --> Model "Project_model" initialized
INFO - 2018-09-30 11:30:44 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:30:44 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:30:44 --> Controller Class Initialized
INFO - 2018-09-30 11:30:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:30:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 11:30:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:30:44 --> Final output sent to browser
DEBUG - 2018-09-30 11:30:44 --> Total execution time: 0.0540
INFO - 2018-09-30 11:30:46 --> Config Class Initialized
INFO - 2018-09-30 11:30:46 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:30:46 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:30:46 --> Utf8 Class Initialized
INFO - 2018-09-30 11:30:46 --> URI Class Initialized
INFO - 2018-09-30 11:30:46 --> Router Class Initialized
INFO - 2018-09-30 11:30:46 --> Output Class Initialized
INFO - 2018-09-30 11:30:46 --> Security Class Initialized
DEBUG - 2018-09-30 11:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:30:46 --> Input Class Initialized
INFO - 2018-09-30 11:30:46 --> Language Class Initialized
INFO - 2018-09-30 11:30:46 --> Loader Class Initialized
INFO - 2018-09-30 11:30:46 --> Helper loaded: url_helper
INFO - 2018-09-30 11:30:46 --> Helper loaded: form_helper
INFO - 2018-09-30 11:30:46 --> Helper loaded: html_helper
INFO - 2018-09-30 11:30:46 --> Database Driver Class Initialized
INFO - 2018-09-30 11:30:46 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:30:46 --> Model "User_model" initialized
INFO - 2018-09-30 11:30:46 --> Model "Project_model" initialized
INFO - 2018-09-30 11:30:46 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:30:46 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:30:46 --> Controller Class Initialized
INFO - 2018-09-30 11:30:46 --> Config Class Initialized
INFO - 2018-09-30 11:30:46 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:30:46 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:30:46 --> Utf8 Class Initialized
INFO - 2018-09-30 11:30:46 --> URI Class Initialized
INFO - 2018-09-30 11:30:46 --> Router Class Initialized
INFO - 2018-09-30 11:30:46 --> Output Class Initialized
INFO - 2018-09-30 11:30:46 --> Security Class Initialized
DEBUG - 2018-09-30 11:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:30:46 --> Input Class Initialized
INFO - 2018-09-30 11:30:46 --> Language Class Initialized
INFO - 2018-09-30 11:30:46 --> Loader Class Initialized
INFO - 2018-09-30 11:30:46 --> Helper loaded: url_helper
INFO - 2018-09-30 11:30:46 --> Helper loaded: form_helper
INFO - 2018-09-30 11:30:46 --> Helper loaded: html_helper
INFO - 2018-09-30 11:30:46 --> Database Driver Class Initialized
INFO - 2018-09-30 11:30:46 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:30:46 --> Model "User_model" initialized
INFO - 2018-09-30 11:30:46 --> Model "Project_model" initialized
INFO - 2018-09-30 11:30:46 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:30:46 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:30:46 --> Controller Class Initialized
INFO - 2018-09-30 11:30:46 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:30:46 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 11:30:46 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:30:46 --> Final output sent to browser
DEBUG - 2018-09-30 11:30:46 --> Total execution time: 0.0660
INFO - 2018-09-30 11:30:50 --> Config Class Initialized
INFO - 2018-09-30 11:30:50 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:30:50 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:30:50 --> Utf8 Class Initialized
INFO - 2018-09-30 11:30:50 --> URI Class Initialized
INFO - 2018-09-30 11:30:51 --> Router Class Initialized
INFO - 2018-09-30 11:30:51 --> Output Class Initialized
INFO - 2018-09-30 11:30:51 --> Security Class Initialized
DEBUG - 2018-09-30 11:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:30:51 --> Input Class Initialized
INFO - 2018-09-30 11:30:51 --> Language Class Initialized
INFO - 2018-09-30 11:30:51 --> Loader Class Initialized
INFO - 2018-09-30 11:30:51 --> Helper loaded: url_helper
INFO - 2018-09-30 11:30:51 --> Helper loaded: form_helper
INFO - 2018-09-30 11:30:51 --> Helper loaded: html_helper
INFO - 2018-09-30 11:30:51 --> Database Driver Class Initialized
INFO - 2018-09-30 11:30:51 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:30:51 --> Model "User_model" initialized
INFO - 2018-09-30 11:30:51 --> Model "Project_model" initialized
INFO - 2018-09-30 11:30:51 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:30:51 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:30:51 --> Controller Class Initialized
INFO - 2018-09-30 11:30:51 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:30:51 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 11:30:51 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:30:51 --> Final output sent to browser
DEBUG - 2018-09-30 11:30:51 --> Total execution time: 0.0670
INFO - 2018-09-30 11:30:52 --> Config Class Initialized
INFO - 2018-09-30 11:30:52 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:30:52 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:30:52 --> Utf8 Class Initialized
INFO - 2018-09-30 11:30:52 --> URI Class Initialized
INFO - 2018-09-30 11:30:52 --> Router Class Initialized
INFO - 2018-09-30 11:30:52 --> Output Class Initialized
INFO - 2018-09-30 11:30:52 --> Security Class Initialized
DEBUG - 2018-09-30 11:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:30:52 --> Input Class Initialized
INFO - 2018-09-30 11:30:52 --> Language Class Initialized
INFO - 2018-09-30 11:30:52 --> Loader Class Initialized
INFO - 2018-09-30 11:30:52 --> Helper loaded: url_helper
INFO - 2018-09-30 11:30:52 --> Helper loaded: form_helper
INFO - 2018-09-30 11:30:52 --> Helper loaded: html_helper
INFO - 2018-09-30 11:30:52 --> Database Driver Class Initialized
INFO - 2018-09-30 11:30:52 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:30:52 --> Model "User_model" initialized
INFO - 2018-09-30 11:30:52 --> Model "Project_model" initialized
INFO - 2018-09-30 11:30:52 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:30:52 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:30:52 --> Controller Class Initialized
INFO - 2018-09-30 11:30:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:30:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 11:30:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:30:52 --> Final output sent to browser
DEBUG - 2018-09-30 11:30:52 --> Total execution time: 0.0690
INFO - 2018-09-30 11:30:53 --> Config Class Initialized
INFO - 2018-09-30 11:30:53 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:30:53 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:30:53 --> Utf8 Class Initialized
INFO - 2018-09-30 11:30:53 --> URI Class Initialized
INFO - 2018-09-30 11:30:53 --> Router Class Initialized
INFO - 2018-09-30 11:30:53 --> Output Class Initialized
INFO - 2018-09-30 11:30:53 --> Security Class Initialized
DEBUG - 2018-09-30 11:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:30:53 --> Input Class Initialized
INFO - 2018-09-30 11:30:53 --> Language Class Initialized
INFO - 2018-09-30 11:30:53 --> Loader Class Initialized
INFO - 2018-09-30 11:30:53 --> Helper loaded: url_helper
INFO - 2018-09-30 11:30:53 --> Helper loaded: form_helper
INFO - 2018-09-30 11:30:53 --> Helper loaded: html_helper
INFO - 2018-09-30 11:30:53 --> Database Driver Class Initialized
INFO - 2018-09-30 11:30:53 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:30:53 --> Model "User_model" initialized
INFO - 2018-09-30 11:30:53 --> Model "Project_model" initialized
INFO - 2018-09-30 11:30:53 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:30:53 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:30:53 --> Controller Class Initialized
INFO - 2018-09-30 11:30:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:30:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 11:30:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:30:53 --> Final output sent to browser
DEBUG - 2018-09-30 11:30:53 --> Total execution time: 0.0450
INFO - 2018-09-30 11:30:56 --> Config Class Initialized
INFO - 2018-09-30 11:30:56 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:30:56 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:30:56 --> Utf8 Class Initialized
INFO - 2018-09-30 11:30:56 --> URI Class Initialized
INFO - 2018-09-30 11:30:56 --> Router Class Initialized
INFO - 2018-09-30 11:30:56 --> Output Class Initialized
INFO - 2018-09-30 11:30:56 --> Security Class Initialized
DEBUG - 2018-09-30 11:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:30:56 --> Input Class Initialized
INFO - 2018-09-30 11:30:56 --> Language Class Initialized
INFO - 2018-09-30 11:30:56 --> Loader Class Initialized
INFO - 2018-09-30 11:30:56 --> Helper loaded: url_helper
INFO - 2018-09-30 11:30:56 --> Helper loaded: form_helper
INFO - 2018-09-30 11:30:56 --> Helper loaded: html_helper
INFO - 2018-09-30 11:30:56 --> Database Driver Class Initialized
INFO - 2018-09-30 11:30:56 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:30:56 --> Model "User_model" initialized
INFO - 2018-09-30 11:30:56 --> Model "Project_model" initialized
INFO - 2018-09-30 11:30:56 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:30:56 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:30:56 --> Controller Class Initialized
INFO - 2018-09-30 11:30:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:30:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/create_project.php
INFO - 2018-09-30 11:30:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:30:56 --> Final output sent to browser
DEBUG - 2018-09-30 11:30:56 --> Total execution time: 0.0450
INFO - 2018-09-30 11:30:59 --> Config Class Initialized
INFO - 2018-09-30 11:30:59 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:30:59 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:30:59 --> Utf8 Class Initialized
INFO - 2018-09-30 11:30:59 --> URI Class Initialized
INFO - 2018-09-30 11:30:59 --> Router Class Initialized
INFO - 2018-09-30 11:30:59 --> Output Class Initialized
INFO - 2018-09-30 11:30:59 --> Security Class Initialized
DEBUG - 2018-09-30 11:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:30:59 --> Input Class Initialized
INFO - 2018-09-30 11:30:59 --> Language Class Initialized
INFO - 2018-09-30 11:30:59 --> Loader Class Initialized
INFO - 2018-09-30 11:30:59 --> Helper loaded: url_helper
INFO - 2018-09-30 11:30:59 --> Helper loaded: form_helper
INFO - 2018-09-30 11:30:59 --> Helper loaded: html_helper
INFO - 2018-09-30 11:30:59 --> Database Driver Class Initialized
INFO - 2018-09-30 11:30:59 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:30:59 --> Model "User_model" initialized
INFO - 2018-09-30 11:30:59 --> Model "Project_model" initialized
INFO - 2018-09-30 11:30:59 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:30:59 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:30:59 --> Controller Class Initialized
INFO - 2018-09-30 11:30:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-30 11:31:00 --> Config Class Initialized
INFO - 2018-09-30 11:31:00 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:31:00 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:31:00 --> Utf8 Class Initialized
INFO - 2018-09-30 11:31:00 --> URI Class Initialized
INFO - 2018-09-30 11:31:00 --> Router Class Initialized
INFO - 2018-09-30 11:31:00 --> Output Class Initialized
INFO - 2018-09-30 11:31:00 --> Security Class Initialized
DEBUG - 2018-09-30 11:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:31:00 --> Input Class Initialized
INFO - 2018-09-30 11:31:00 --> Language Class Initialized
INFO - 2018-09-30 11:31:00 --> Loader Class Initialized
INFO - 2018-09-30 11:31:00 --> Helper loaded: url_helper
INFO - 2018-09-30 11:31:00 --> Helper loaded: form_helper
INFO - 2018-09-30 11:31:00 --> Helper loaded: html_helper
INFO - 2018-09-30 11:31:00 --> Database Driver Class Initialized
INFO - 2018-09-30 11:31:00 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:31:00 --> Model "User_model" initialized
INFO - 2018-09-30 11:31:00 --> Model "Project_model" initialized
INFO - 2018-09-30 11:31:00 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:31:00 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:31:00 --> Controller Class Initialized
INFO - 2018-09-30 11:31:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:31:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 11:31:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:31:00 --> Final output sent to browser
DEBUG - 2018-09-30 11:31:00 --> Total execution time: 0.0550
INFO - 2018-09-30 11:31:17 --> Config Class Initialized
INFO - 2018-09-30 11:31:17 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:31:17 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:31:17 --> Utf8 Class Initialized
INFO - 2018-09-30 11:31:17 --> URI Class Initialized
INFO - 2018-09-30 11:31:17 --> Router Class Initialized
INFO - 2018-09-30 11:31:17 --> Output Class Initialized
INFO - 2018-09-30 11:31:17 --> Security Class Initialized
DEBUG - 2018-09-30 11:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:31:17 --> Input Class Initialized
INFO - 2018-09-30 11:31:17 --> Language Class Initialized
INFO - 2018-09-30 11:31:17 --> Loader Class Initialized
INFO - 2018-09-30 11:31:17 --> Helper loaded: url_helper
INFO - 2018-09-30 11:31:17 --> Helper loaded: form_helper
INFO - 2018-09-30 11:31:17 --> Helper loaded: html_helper
INFO - 2018-09-30 11:31:17 --> Database Driver Class Initialized
INFO - 2018-09-30 11:31:17 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:31:17 --> Model "User_model" initialized
INFO - 2018-09-30 11:31:17 --> Model "Project_model" initialized
INFO - 2018-09-30 11:31:17 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:31:17 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:31:17 --> Controller Class Initialized
INFO - 2018-09-30 11:31:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:31:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 11:31:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:31:17 --> Final output sent to browser
DEBUG - 2018-09-30 11:31:17 --> Total execution time: 0.0540
INFO - 2018-09-30 11:44:54 --> Config Class Initialized
INFO - 2018-09-30 11:44:54 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:44:54 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:44:54 --> Utf8 Class Initialized
INFO - 2018-09-30 11:44:54 --> URI Class Initialized
INFO - 2018-09-30 11:44:54 --> Router Class Initialized
INFO - 2018-09-30 11:44:54 --> Output Class Initialized
INFO - 2018-09-30 11:44:54 --> Security Class Initialized
DEBUG - 2018-09-30 11:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:44:54 --> Input Class Initialized
INFO - 2018-09-30 11:44:54 --> Language Class Initialized
INFO - 2018-09-30 11:44:54 --> Loader Class Initialized
INFO - 2018-09-30 11:44:54 --> Helper loaded: url_helper
INFO - 2018-09-30 11:44:54 --> Helper loaded: form_helper
INFO - 2018-09-30 11:44:54 --> Helper loaded: html_helper
INFO - 2018-09-30 11:44:54 --> Database Driver Class Initialized
INFO - 2018-09-30 11:44:54 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:44:54 --> Model "User_model" initialized
INFO - 2018-09-30 11:44:54 --> Model "Project_model" initialized
INFO - 2018-09-30 11:44:54 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:44:54 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:44:54 --> Controller Class Initialized
INFO - 2018-09-30 11:44:54 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:44:54 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 11:44:54 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:44:54 --> Final output sent to browser
DEBUG - 2018-09-30 11:44:54 --> Total execution time: 0.0820
INFO - 2018-09-30 11:44:56 --> Config Class Initialized
INFO - 2018-09-30 11:44:56 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:44:56 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:44:56 --> Utf8 Class Initialized
INFO - 2018-09-30 11:44:56 --> URI Class Initialized
INFO - 2018-09-30 11:44:56 --> Router Class Initialized
INFO - 2018-09-30 11:44:56 --> Output Class Initialized
INFO - 2018-09-30 11:44:56 --> Security Class Initialized
DEBUG - 2018-09-30 11:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:44:56 --> Input Class Initialized
INFO - 2018-09-30 11:44:56 --> Language Class Initialized
INFO - 2018-09-30 11:44:56 --> Loader Class Initialized
INFO - 2018-09-30 11:44:56 --> Helper loaded: url_helper
INFO - 2018-09-30 11:44:56 --> Helper loaded: form_helper
INFO - 2018-09-30 11:44:56 --> Helper loaded: html_helper
INFO - 2018-09-30 11:44:56 --> Database Driver Class Initialized
INFO - 2018-09-30 11:44:56 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:44:56 --> Model "User_model" initialized
INFO - 2018-09-30 11:44:56 --> Model "Project_model" initialized
INFO - 2018-09-30 11:44:56 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:44:56 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:44:56 --> Controller Class Initialized
ERROR - 2018-09-30 11:44:56 --> Severity: Notice --> Undefined variable: id D:\xampp\htdocs\code_igniter\application\models\project_models\project_model.php 63
INFO - 2018-09-30 11:44:56 --> Config Class Initialized
INFO - 2018-09-30 11:44:56 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:44:56 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:44:56 --> Utf8 Class Initialized
INFO - 2018-09-30 11:44:56 --> URI Class Initialized
INFO - 2018-09-30 11:44:56 --> Router Class Initialized
INFO - 2018-09-30 11:44:56 --> Output Class Initialized
INFO - 2018-09-30 11:44:56 --> Security Class Initialized
DEBUG - 2018-09-30 11:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:44:56 --> Input Class Initialized
INFO - 2018-09-30 11:44:56 --> Language Class Initialized
INFO - 2018-09-30 11:44:56 --> Loader Class Initialized
INFO - 2018-09-30 11:44:56 --> Helper loaded: url_helper
INFO - 2018-09-30 11:44:56 --> Helper loaded: form_helper
INFO - 2018-09-30 11:44:56 --> Helper loaded: html_helper
INFO - 2018-09-30 11:44:56 --> Database Driver Class Initialized
INFO - 2018-09-30 11:44:56 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:44:56 --> Model "User_model" initialized
INFO - 2018-09-30 11:44:56 --> Model "Project_model" initialized
INFO - 2018-09-30 11:44:56 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:44:56 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:44:56 --> Controller Class Initialized
INFO - 2018-09-30 11:44:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:44:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 11:44:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:44:56 --> Final output sent to browser
DEBUG - 2018-09-30 11:44:56 --> Total execution time: 0.0430
INFO - 2018-09-30 11:45:00 --> Config Class Initialized
INFO - 2018-09-30 11:45:00 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:45:00 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:45:00 --> Utf8 Class Initialized
INFO - 2018-09-30 11:45:00 --> URI Class Initialized
INFO - 2018-09-30 11:45:00 --> Router Class Initialized
INFO - 2018-09-30 11:45:00 --> Output Class Initialized
INFO - 2018-09-30 11:45:00 --> Security Class Initialized
DEBUG - 2018-09-30 11:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:45:00 --> Input Class Initialized
INFO - 2018-09-30 11:45:00 --> Language Class Initialized
INFO - 2018-09-30 11:45:00 --> Loader Class Initialized
INFO - 2018-09-30 11:45:00 --> Helper loaded: url_helper
INFO - 2018-09-30 11:45:00 --> Helper loaded: form_helper
INFO - 2018-09-30 11:45:00 --> Helper loaded: html_helper
INFO - 2018-09-30 11:45:00 --> Database Driver Class Initialized
INFO - 2018-09-30 11:45:00 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:45:00 --> Model "User_model" initialized
INFO - 2018-09-30 11:45:00 --> Model "Project_model" initialized
INFO - 2018-09-30 11:45:00 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:45:00 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:45:00 --> Controller Class Initialized
INFO - 2018-09-30 11:45:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:45:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 11:45:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:45:00 --> Final output sent to browser
DEBUG - 2018-09-30 11:45:00 --> Total execution time: 0.0700
INFO - 2018-09-30 11:45:07 --> Config Class Initialized
INFO - 2018-09-30 11:45:07 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:45:07 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:45:07 --> Utf8 Class Initialized
INFO - 2018-09-30 11:45:07 --> URI Class Initialized
INFO - 2018-09-30 11:45:07 --> Router Class Initialized
INFO - 2018-09-30 11:45:07 --> Output Class Initialized
INFO - 2018-09-30 11:45:07 --> Security Class Initialized
DEBUG - 2018-09-30 11:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:45:07 --> Input Class Initialized
INFO - 2018-09-30 11:45:07 --> Language Class Initialized
INFO - 2018-09-30 11:45:07 --> Loader Class Initialized
INFO - 2018-09-30 11:45:07 --> Helper loaded: url_helper
INFO - 2018-09-30 11:45:07 --> Helper loaded: form_helper
INFO - 2018-09-30 11:45:07 --> Helper loaded: html_helper
INFO - 2018-09-30 11:45:07 --> Database Driver Class Initialized
INFO - 2018-09-30 11:45:07 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:45:07 --> Model "User_model" initialized
INFO - 2018-09-30 11:45:07 --> Model "Project_model" initialized
INFO - 2018-09-30 11:45:07 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:45:07 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:45:07 --> Controller Class Initialized
INFO - 2018-09-30 11:45:07 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:45:07 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 11:45:07 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:45:07 --> Final output sent to browser
DEBUG - 2018-09-30 11:45:07 --> Total execution time: 0.0610
INFO - 2018-09-30 11:45:08 --> Config Class Initialized
INFO - 2018-09-30 11:45:08 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:45:08 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:45:08 --> Utf8 Class Initialized
INFO - 2018-09-30 11:45:08 --> URI Class Initialized
INFO - 2018-09-30 11:45:08 --> Router Class Initialized
INFO - 2018-09-30 11:45:08 --> Output Class Initialized
INFO - 2018-09-30 11:45:08 --> Security Class Initialized
DEBUG - 2018-09-30 11:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:45:08 --> Input Class Initialized
INFO - 2018-09-30 11:45:08 --> Language Class Initialized
INFO - 2018-09-30 11:45:08 --> Loader Class Initialized
INFO - 2018-09-30 11:45:08 --> Helper loaded: url_helper
INFO - 2018-09-30 11:45:08 --> Helper loaded: form_helper
INFO - 2018-09-30 11:45:08 --> Helper loaded: html_helper
INFO - 2018-09-30 11:45:08 --> Database Driver Class Initialized
INFO - 2018-09-30 11:45:08 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:45:08 --> Model "User_model" initialized
INFO - 2018-09-30 11:45:08 --> Model "Project_model" initialized
INFO - 2018-09-30 11:45:08 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:45:08 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:45:08 --> Controller Class Initialized
ERROR - 2018-09-30 11:45:08 --> Severity: Notice --> Undefined variable: id D:\xampp\htdocs\code_igniter\application\models\project_models\project_model.php 63
INFO - 2018-09-30 11:45:08 --> Config Class Initialized
INFO - 2018-09-30 11:45:08 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:45:08 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:45:08 --> Utf8 Class Initialized
INFO - 2018-09-30 11:45:08 --> URI Class Initialized
INFO - 2018-09-30 11:45:08 --> Router Class Initialized
INFO - 2018-09-30 11:45:08 --> Output Class Initialized
INFO - 2018-09-30 11:45:08 --> Security Class Initialized
DEBUG - 2018-09-30 11:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:45:08 --> Input Class Initialized
INFO - 2018-09-30 11:45:08 --> Language Class Initialized
INFO - 2018-09-30 11:45:08 --> Loader Class Initialized
INFO - 2018-09-30 11:45:08 --> Helper loaded: url_helper
INFO - 2018-09-30 11:45:08 --> Helper loaded: form_helper
INFO - 2018-09-30 11:45:08 --> Helper loaded: html_helper
INFO - 2018-09-30 11:45:08 --> Database Driver Class Initialized
INFO - 2018-09-30 11:45:08 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:45:08 --> Model "User_model" initialized
INFO - 2018-09-30 11:45:08 --> Model "Project_model" initialized
INFO - 2018-09-30 11:45:08 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:45:08 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:45:08 --> Controller Class Initialized
INFO - 2018-09-30 11:45:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:45:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 11:45:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:45:08 --> Final output sent to browser
DEBUG - 2018-09-30 11:45:08 --> Total execution time: 0.0360
INFO - 2018-09-30 11:45:23 --> Config Class Initialized
INFO - 2018-09-30 11:45:23 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:45:23 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:45:23 --> Utf8 Class Initialized
INFO - 2018-09-30 11:45:23 --> URI Class Initialized
INFO - 2018-09-30 11:45:23 --> Router Class Initialized
INFO - 2018-09-30 11:45:23 --> Output Class Initialized
INFO - 2018-09-30 11:45:23 --> Security Class Initialized
DEBUG - 2018-09-30 11:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:45:23 --> Input Class Initialized
INFO - 2018-09-30 11:45:23 --> Language Class Initialized
INFO - 2018-09-30 11:45:23 --> Loader Class Initialized
INFO - 2018-09-30 11:45:23 --> Helper loaded: url_helper
INFO - 2018-09-30 11:45:23 --> Helper loaded: form_helper
INFO - 2018-09-30 11:45:24 --> Helper loaded: html_helper
INFO - 2018-09-30 11:45:24 --> Database Driver Class Initialized
INFO - 2018-09-30 11:45:24 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:45:24 --> Model "User_model" initialized
INFO - 2018-09-30 11:45:24 --> Model "Project_model" initialized
INFO - 2018-09-30 11:45:24 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:45:24 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:45:24 --> Controller Class Initialized
INFO - 2018-09-30 11:45:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:45:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 11:45:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:45:24 --> Final output sent to browser
DEBUG - 2018-09-30 11:45:24 --> Total execution time: 0.0490
INFO - 2018-09-30 11:45:26 --> Config Class Initialized
INFO - 2018-09-30 11:45:26 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:45:26 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:45:26 --> Utf8 Class Initialized
INFO - 2018-09-30 11:45:26 --> URI Class Initialized
INFO - 2018-09-30 11:45:26 --> Router Class Initialized
INFO - 2018-09-30 11:45:26 --> Output Class Initialized
INFO - 2018-09-30 11:45:26 --> Security Class Initialized
DEBUG - 2018-09-30 11:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:45:26 --> Input Class Initialized
INFO - 2018-09-30 11:45:26 --> Language Class Initialized
INFO - 2018-09-30 11:45:26 --> Loader Class Initialized
INFO - 2018-09-30 11:45:26 --> Helper loaded: url_helper
INFO - 2018-09-30 11:45:26 --> Helper loaded: form_helper
INFO - 2018-09-30 11:45:26 --> Helper loaded: html_helper
INFO - 2018-09-30 11:45:26 --> Database Driver Class Initialized
INFO - 2018-09-30 11:45:26 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:45:26 --> Model "User_model" initialized
INFO - 2018-09-30 11:45:26 --> Model "Project_model" initialized
INFO - 2018-09-30 11:45:26 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:45:26 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:45:26 --> Controller Class Initialized
ERROR - 2018-09-30 11:45:26 --> Severity: Notice --> Undefined variable: id D:\xampp\htdocs\code_igniter\application\models\project_models\project_model.php 63
INFO - 2018-09-30 11:45:26 --> Config Class Initialized
INFO - 2018-09-30 11:45:26 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:45:26 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:45:26 --> Utf8 Class Initialized
INFO - 2018-09-30 11:45:26 --> URI Class Initialized
INFO - 2018-09-30 11:45:26 --> Router Class Initialized
INFO - 2018-09-30 11:45:26 --> Output Class Initialized
INFO - 2018-09-30 11:45:26 --> Security Class Initialized
DEBUG - 2018-09-30 11:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:45:26 --> Input Class Initialized
INFO - 2018-09-30 11:45:26 --> Language Class Initialized
INFO - 2018-09-30 11:45:26 --> Loader Class Initialized
INFO - 2018-09-30 11:45:26 --> Helper loaded: url_helper
INFO - 2018-09-30 11:45:26 --> Helper loaded: form_helper
INFO - 2018-09-30 11:45:26 --> Helper loaded: html_helper
INFO - 2018-09-30 11:45:26 --> Database Driver Class Initialized
INFO - 2018-09-30 11:45:26 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:45:26 --> Model "User_model" initialized
INFO - 2018-09-30 11:45:26 --> Model "Project_model" initialized
INFO - 2018-09-30 11:45:26 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:45:26 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:45:26 --> Controller Class Initialized
INFO - 2018-09-30 11:45:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:45:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 11:45:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:45:26 --> Final output sent to browser
DEBUG - 2018-09-30 11:45:26 --> Total execution time: 0.0410
INFO - 2018-09-30 11:45:57 --> Config Class Initialized
INFO - 2018-09-30 11:45:57 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:45:57 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:45:57 --> Utf8 Class Initialized
INFO - 2018-09-30 11:45:57 --> URI Class Initialized
INFO - 2018-09-30 11:45:57 --> Router Class Initialized
INFO - 2018-09-30 11:45:57 --> Output Class Initialized
INFO - 2018-09-30 11:45:57 --> Security Class Initialized
DEBUG - 2018-09-30 11:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:45:57 --> Input Class Initialized
INFO - 2018-09-30 11:45:57 --> Language Class Initialized
INFO - 2018-09-30 11:45:57 --> Loader Class Initialized
INFO - 2018-09-30 11:45:57 --> Helper loaded: url_helper
INFO - 2018-09-30 11:45:57 --> Helper loaded: form_helper
INFO - 2018-09-30 11:45:57 --> Helper loaded: html_helper
INFO - 2018-09-30 11:45:57 --> Database Driver Class Initialized
INFO - 2018-09-30 11:45:57 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:45:57 --> Model "User_model" initialized
INFO - 2018-09-30 11:45:57 --> Model "Project_model" initialized
INFO - 2018-09-30 11:45:57 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:45:57 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:45:57 --> Controller Class Initialized
INFO - 2018-09-30 11:45:57 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:45:57 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 11:45:57 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:45:57 --> Final output sent to browser
DEBUG - 2018-09-30 11:45:57 --> Total execution time: 0.0680
INFO - 2018-09-30 11:45:58 --> Config Class Initialized
INFO - 2018-09-30 11:45:58 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:45:58 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:45:58 --> Utf8 Class Initialized
INFO - 2018-09-30 11:45:58 --> URI Class Initialized
INFO - 2018-09-30 11:45:58 --> Router Class Initialized
INFO - 2018-09-30 11:45:58 --> Output Class Initialized
INFO - 2018-09-30 11:45:58 --> Security Class Initialized
DEBUG - 2018-09-30 11:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:45:58 --> Input Class Initialized
INFO - 2018-09-30 11:45:58 --> Language Class Initialized
INFO - 2018-09-30 11:45:58 --> Loader Class Initialized
INFO - 2018-09-30 11:45:58 --> Helper loaded: url_helper
INFO - 2018-09-30 11:45:58 --> Helper loaded: form_helper
INFO - 2018-09-30 11:45:58 --> Helper loaded: html_helper
INFO - 2018-09-30 11:45:58 --> Database Driver Class Initialized
INFO - 2018-09-30 11:45:58 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:45:58 --> Model "User_model" initialized
INFO - 2018-09-30 11:45:58 --> Model "Project_model" initialized
INFO - 2018-09-30 11:45:58 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:45:58 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:45:58 --> Controller Class Initialized
INFO - 2018-09-30 11:45:58 --> Config Class Initialized
INFO - 2018-09-30 11:45:58 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:45:58 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:45:58 --> Utf8 Class Initialized
INFO - 2018-09-30 11:45:58 --> URI Class Initialized
INFO - 2018-09-30 11:45:58 --> Router Class Initialized
INFO - 2018-09-30 11:45:58 --> Output Class Initialized
INFO - 2018-09-30 11:45:58 --> Security Class Initialized
DEBUG - 2018-09-30 11:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:45:58 --> Input Class Initialized
INFO - 2018-09-30 11:45:58 --> Language Class Initialized
INFO - 2018-09-30 11:45:58 --> Loader Class Initialized
INFO - 2018-09-30 11:45:58 --> Helper loaded: url_helper
INFO - 2018-09-30 11:45:58 --> Helper loaded: form_helper
INFO - 2018-09-30 11:45:58 --> Helper loaded: html_helper
INFO - 2018-09-30 11:45:58 --> Database Driver Class Initialized
INFO - 2018-09-30 11:45:58 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:45:58 --> Model "User_model" initialized
INFO - 2018-09-30 11:45:58 --> Model "Project_model" initialized
INFO - 2018-09-30 11:45:58 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:45:58 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:45:58 --> Controller Class Initialized
INFO - 2018-09-30 11:45:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:45:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 11:45:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:45:58 --> Final output sent to browser
DEBUG - 2018-09-30 11:45:58 --> Total execution time: 0.0610
INFO - 2018-09-30 11:46:00 --> Config Class Initialized
INFO - 2018-09-30 11:46:00 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:46:00 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:46:00 --> Utf8 Class Initialized
INFO - 2018-09-30 11:46:00 --> URI Class Initialized
INFO - 2018-09-30 11:46:00 --> Router Class Initialized
INFO - 2018-09-30 11:46:00 --> Output Class Initialized
INFO - 2018-09-30 11:46:00 --> Security Class Initialized
DEBUG - 2018-09-30 11:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:46:00 --> Input Class Initialized
INFO - 2018-09-30 11:46:00 --> Language Class Initialized
INFO - 2018-09-30 11:46:00 --> Loader Class Initialized
INFO - 2018-09-30 11:46:00 --> Helper loaded: url_helper
INFO - 2018-09-30 11:46:00 --> Helper loaded: form_helper
INFO - 2018-09-30 11:46:00 --> Helper loaded: html_helper
INFO - 2018-09-30 11:46:00 --> Database Driver Class Initialized
INFO - 2018-09-30 11:46:00 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:46:00 --> Model "User_model" initialized
INFO - 2018-09-30 11:46:00 --> Model "Project_model" initialized
INFO - 2018-09-30 11:46:00 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:46:00 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:46:00 --> Controller Class Initialized
INFO - 2018-09-30 11:46:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:46:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 11:46:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:46:00 --> Final output sent to browser
DEBUG - 2018-09-30 11:46:00 --> Total execution time: 0.0510
INFO - 2018-09-30 11:47:54 --> Config Class Initialized
INFO - 2018-09-30 11:47:54 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:47:54 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:47:54 --> Utf8 Class Initialized
INFO - 2018-09-30 11:47:54 --> URI Class Initialized
INFO - 2018-09-30 11:47:54 --> Router Class Initialized
INFO - 2018-09-30 11:47:54 --> Output Class Initialized
INFO - 2018-09-30 11:47:54 --> Security Class Initialized
DEBUG - 2018-09-30 11:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:47:54 --> Input Class Initialized
INFO - 2018-09-30 11:47:54 --> Language Class Initialized
INFO - 2018-09-30 11:47:54 --> Loader Class Initialized
INFO - 2018-09-30 11:47:54 --> Helper loaded: url_helper
INFO - 2018-09-30 11:47:54 --> Helper loaded: form_helper
INFO - 2018-09-30 11:47:54 --> Helper loaded: html_helper
INFO - 2018-09-30 11:47:54 --> Database Driver Class Initialized
INFO - 2018-09-30 11:47:54 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:47:54 --> Model "User_model" initialized
INFO - 2018-09-30 11:47:54 --> Model "Project_model" initialized
INFO - 2018-09-30 11:47:54 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:47:54 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:47:54 --> Controller Class Initialized
INFO - 2018-09-30 11:47:54 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:47:54 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 11:47:54 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:47:54 --> Final output sent to browser
DEBUG - 2018-09-30 11:47:54 --> Total execution time: 0.0540
INFO - 2018-09-30 11:52:37 --> Config Class Initialized
INFO - 2018-09-30 11:52:37 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:52:37 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:52:37 --> Utf8 Class Initialized
INFO - 2018-09-30 11:52:37 --> URI Class Initialized
INFO - 2018-09-30 11:52:37 --> Router Class Initialized
INFO - 2018-09-30 11:52:37 --> Output Class Initialized
INFO - 2018-09-30 11:52:37 --> Security Class Initialized
DEBUG - 2018-09-30 11:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:52:37 --> Input Class Initialized
INFO - 2018-09-30 11:52:37 --> Language Class Initialized
INFO - 2018-09-30 11:52:37 --> Loader Class Initialized
INFO - 2018-09-30 11:52:37 --> Helper loaded: url_helper
INFO - 2018-09-30 11:52:37 --> Helper loaded: form_helper
INFO - 2018-09-30 11:52:37 --> Helper loaded: html_helper
INFO - 2018-09-30 11:52:37 --> Database Driver Class Initialized
INFO - 2018-09-30 11:52:37 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:52:37 --> Model "User_model" initialized
INFO - 2018-09-30 11:52:37 --> Model "Project_model" initialized
INFO - 2018-09-30 11:52:37 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:52:37 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:52:37 --> Controller Class Initialized
INFO - 2018-09-30 11:52:37 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:52:37 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/create_project.php
INFO - 2018-09-30 11:52:37 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:52:37 --> Final output sent to browser
DEBUG - 2018-09-30 11:52:37 --> Total execution time: 0.2190
INFO - 2018-09-30 11:53:20 --> Config Class Initialized
INFO - 2018-09-30 11:53:20 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:53:20 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:53:20 --> Utf8 Class Initialized
INFO - 2018-09-30 11:53:20 --> URI Class Initialized
INFO - 2018-09-30 11:53:20 --> Router Class Initialized
INFO - 2018-09-30 11:53:20 --> Output Class Initialized
INFO - 2018-09-30 11:53:20 --> Security Class Initialized
DEBUG - 2018-09-30 11:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:53:20 --> Input Class Initialized
INFO - 2018-09-30 11:53:20 --> Language Class Initialized
INFO - 2018-09-30 11:53:20 --> Loader Class Initialized
INFO - 2018-09-30 11:53:20 --> Helper loaded: url_helper
INFO - 2018-09-30 11:53:20 --> Helper loaded: form_helper
INFO - 2018-09-30 11:53:20 --> Helper loaded: html_helper
INFO - 2018-09-30 11:53:20 --> Database Driver Class Initialized
INFO - 2018-09-30 11:53:20 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:53:20 --> Model "User_model" initialized
INFO - 2018-09-30 11:53:20 --> Model "Project_model" initialized
INFO - 2018-09-30 11:53:20 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:53:20 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:53:20 --> Controller Class Initialized
INFO - 2018-09-30 11:53:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-30 11:53:21 --> Config Class Initialized
INFO - 2018-09-30 11:53:21 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:53:21 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:53:21 --> Utf8 Class Initialized
INFO - 2018-09-30 11:53:21 --> URI Class Initialized
INFO - 2018-09-30 11:53:21 --> Router Class Initialized
INFO - 2018-09-30 11:53:21 --> Output Class Initialized
INFO - 2018-09-30 11:53:21 --> Security Class Initialized
DEBUG - 2018-09-30 11:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:53:21 --> Input Class Initialized
INFO - 2018-09-30 11:53:21 --> Language Class Initialized
INFO - 2018-09-30 11:53:21 --> Loader Class Initialized
INFO - 2018-09-30 11:53:21 --> Helper loaded: url_helper
INFO - 2018-09-30 11:53:21 --> Helper loaded: form_helper
INFO - 2018-09-30 11:53:21 --> Helper loaded: html_helper
INFO - 2018-09-30 11:53:21 --> Database Driver Class Initialized
INFO - 2018-09-30 11:53:21 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:53:21 --> Model "User_model" initialized
INFO - 2018-09-30 11:53:21 --> Model "Project_model" initialized
INFO - 2018-09-30 11:53:21 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:53:21 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:53:21 --> Controller Class Initialized
INFO - 2018-09-30 11:53:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:53:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 11:53:21 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:53:21 --> Final output sent to browser
DEBUG - 2018-09-30 11:53:21 --> Total execution time: 0.0660
INFO - 2018-09-30 11:53:31 --> Config Class Initialized
INFO - 2018-09-30 11:53:31 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:53:31 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:53:31 --> Utf8 Class Initialized
INFO - 2018-09-30 11:53:31 --> URI Class Initialized
INFO - 2018-09-30 11:53:31 --> Router Class Initialized
INFO - 2018-09-30 11:53:31 --> Output Class Initialized
INFO - 2018-09-30 11:53:31 --> Security Class Initialized
DEBUG - 2018-09-30 11:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:53:31 --> Input Class Initialized
INFO - 2018-09-30 11:53:31 --> Language Class Initialized
INFO - 2018-09-30 11:53:31 --> Loader Class Initialized
INFO - 2018-09-30 11:53:31 --> Helper loaded: url_helper
INFO - 2018-09-30 11:53:31 --> Helper loaded: form_helper
INFO - 2018-09-30 11:53:31 --> Helper loaded: html_helper
INFO - 2018-09-30 11:53:31 --> Database Driver Class Initialized
INFO - 2018-09-30 11:53:31 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:53:31 --> Model "User_model" initialized
INFO - 2018-09-30 11:53:31 --> Model "Project_model" initialized
INFO - 2018-09-30 11:53:31 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:53:31 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:53:31 --> Controller Class Initialized
INFO - 2018-09-30 11:53:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:53:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/create_project.php
INFO - 2018-09-30 11:53:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:53:31 --> Final output sent to browser
DEBUG - 2018-09-30 11:53:31 --> Total execution time: 0.0390
INFO - 2018-09-30 11:53:46 --> Config Class Initialized
INFO - 2018-09-30 11:53:46 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:53:46 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:53:46 --> Utf8 Class Initialized
INFO - 2018-09-30 11:53:46 --> URI Class Initialized
INFO - 2018-09-30 11:53:46 --> Router Class Initialized
INFO - 2018-09-30 11:53:46 --> Output Class Initialized
INFO - 2018-09-30 11:53:46 --> Security Class Initialized
DEBUG - 2018-09-30 11:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:53:46 --> Input Class Initialized
INFO - 2018-09-30 11:53:46 --> Language Class Initialized
INFO - 2018-09-30 11:53:46 --> Loader Class Initialized
INFO - 2018-09-30 11:53:46 --> Helper loaded: url_helper
INFO - 2018-09-30 11:53:46 --> Helper loaded: form_helper
INFO - 2018-09-30 11:53:46 --> Helper loaded: html_helper
INFO - 2018-09-30 11:53:46 --> Database Driver Class Initialized
INFO - 2018-09-30 11:53:46 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:53:46 --> Model "User_model" initialized
INFO - 2018-09-30 11:53:46 --> Model "Project_model" initialized
INFO - 2018-09-30 11:53:46 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:53:46 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:53:46 --> Controller Class Initialized
INFO - 2018-09-30 11:53:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-30 11:53:46 --> Config Class Initialized
INFO - 2018-09-30 11:53:46 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:53:46 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:53:46 --> Utf8 Class Initialized
INFO - 2018-09-30 11:53:46 --> URI Class Initialized
INFO - 2018-09-30 11:53:46 --> Router Class Initialized
INFO - 2018-09-30 11:53:46 --> Output Class Initialized
INFO - 2018-09-30 11:53:46 --> Security Class Initialized
DEBUG - 2018-09-30 11:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:53:46 --> Input Class Initialized
INFO - 2018-09-30 11:53:46 --> Language Class Initialized
INFO - 2018-09-30 11:53:46 --> Loader Class Initialized
INFO - 2018-09-30 11:53:46 --> Helper loaded: url_helper
INFO - 2018-09-30 11:53:46 --> Helper loaded: form_helper
INFO - 2018-09-30 11:53:46 --> Helper loaded: html_helper
INFO - 2018-09-30 11:53:46 --> Database Driver Class Initialized
INFO - 2018-09-30 11:53:46 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:53:46 --> Model "User_model" initialized
INFO - 2018-09-30 11:53:46 --> Model "Project_model" initialized
INFO - 2018-09-30 11:53:46 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:53:46 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:53:46 --> Controller Class Initialized
INFO - 2018-09-30 11:53:46 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:53:46 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 11:53:46 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:53:46 --> Final output sent to browser
DEBUG - 2018-09-30 11:53:46 --> Total execution time: 0.0380
INFO - 2018-09-30 11:53:49 --> Config Class Initialized
INFO - 2018-09-30 11:53:49 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:53:49 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:53:49 --> Utf8 Class Initialized
INFO - 2018-09-30 11:53:49 --> URI Class Initialized
INFO - 2018-09-30 11:53:49 --> Router Class Initialized
INFO - 2018-09-30 11:53:49 --> Output Class Initialized
INFO - 2018-09-30 11:53:49 --> Security Class Initialized
DEBUG - 2018-09-30 11:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:53:49 --> Input Class Initialized
INFO - 2018-09-30 11:53:49 --> Language Class Initialized
INFO - 2018-09-30 11:53:49 --> Loader Class Initialized
INFO - 2018-09-30 11:53:49 --> Helper loaded: url_helper
INFO - 2018-09-30 11:53:49 --> Helper loaded: form_helper
INFO - 2018-09-30 11:53:49 --> Helper loaded: html_helper
INFO - 2018-09-30 11:53:49 --> Database Driver Class Initialized
INFO - 2018-09-30 11:53:49 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:53:49 --> Model "User_model" initialized
INFO - 2018-09-30 11:53:49 --> Model "Project_model" initialized
INFO - 2018-09-30 11:53:49 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:53:49 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:53:49 --> Controller Class Initialized
INFO - 2018-09-30 11:53:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:53:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 11:53:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:53:49 --> Final output sent to browser
DEBUG - 2018-09-30 11:53:49 --> Total execution time: 0.0720
INFO - 2018-09-30 11:55:32 --> Config Class Initialized
INFO - 2018-09-30 11:55:32 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:55:32 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:55:32 --> Utf8 Class Initialized
INFO - 2018-09-30 11:55:32 --> URI Class Initialized
INFO - 2018-09-30 11:55:32 --> Router Class Initialized
INFO - 2018-09-30 11:55:32 --> Output Class Initialized
INFO - 2018-09-30 11:55:32 --> Security Class Initialized
DEBUG - 2018-09-30 11:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:55:32 --> Input Class Initialized
INFO - 2018-09-30 11:55:32 --> Language Class Initialized
INFO - 2018-09-30 11:55:32 --> Loader Class Initialized
INFO - 2018-09-30 11:55:32 --> Helper loaded: url_helper
INFO - 2018-09-30 11:55:32 --> Helper loaded: form_helper
INFO - 2018-09-30 11:55:32 --> Helper loaded: html_helper
INFO - 2018-09-30 11:55:32 --> Database Driver Class Initialized
INFO - 2018-09-30 11:55:32 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:55:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:55:32 --> Model "User_model" initialized
INFO - 2018-09-30 11:55:32 --> Model "Project_model" initialized
INFO - 2018-09-30 11:55:32 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:55:32 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:55:32 --> Controller Class Initialized
INFO - 2018-09-30 11:55:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:55:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 11:55:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:55:32 --> Final output sent to browser
DEBUG - 2018-09-30 11:55:32 --> Total execution time: 0.0400
INFO - 2018-09-30 11:55:34 --> Config Class Initialized
INFO - 2018-09-30 11:55:34 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:55:34 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:55:34 --> Utf8 Class Initialized
INFO - 2018-09-30 11:55:34 --> URI Class Initialized
INFO - 2018-09-30 11:55:34 --> Router Class Initialized
INFO - 2018-09-30 11:55:34 --> Output Class Initialized
INFO - 2018-09-30 11:55:34 --> Security Class Initialized
DEBUG - 2018-09-30 11:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:55:34 --> Input Class Initialized
INFO - 2018-09-30 11:55:34 --> Language Class Initialized
INFO - 2018-09-30 11:55:34 --> Loader Class Initialized
INFO - 2018-09-30 11:55:34 --> Helper loaded: url_helper
INFO - 2018-09-30 11:55:34 --> Helper loaded: form_helper
INFO - 2018-09-30 11:55:34 --> Helper loaded: html_helper
INFO - 2018-09-30 11:55:34 --> Database Driver Class Initialized
INFO - 2018-09-30 11:55:34 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:55:34 --> Model "User_model" initialized
INFO - 2018-09-30 11:55:34 --> Model "Project_model" initialized
INFO - 2018-09-30 11:55:34 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:55:34 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:55:34 --> Controller Class Initialized
INFO - 2018-09-30 11:55:34 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:55:34 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 11:55:34 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:55:34 --> Final output sent to browser
DEBUG - 2018-09-30 11:55:34 --> Total execution time: 0.0680
INFO - 2018-09-30 11:55:39 --> Config Class Initialized
INFO - 2018-09-30 11:55:39 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:55:39 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:55:39 --> Utf8 Class Initialized
INFO - 2018-09-30 11:55:39 --> URI Class Initialized
INFO - 2018-09-30 11:55:39 --> Router Class Initialized
INFO - 2018-09-30 11:55:39 --> Output Class Initialized
INFO - 2018-09-30 11:55:39 --> Security Class Initialized
DEBUG - 2018-09-30 11:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:55:39 --> Input Class Initialized
INFO - 2018-09-30 11:55:39 --> Language Class Initialized
INFO - 2018-09-30 11:55:39 --> Loader Class Initialized
INFO - 2018-09-30 11:55:39 --> Helper loaded: url_helper
INFO - 2018-09-30 11:55:39 --> Helper loaded: form_helper
INFO - 2018-09-30 11:55:39 --> Helper loaded: html_helper
INFO - 2018-09-30 11:55:39 --> Database Driver Class Initialized
INFO - 2018-09-30 11:55:39 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:55:39 --> Model "User_model" initialized
INFO - 2018-09-30 11:55:39 --> Model "Project_model" initialized
INFO - 2018-09-30 11:55:39 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:55:39 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:55:39 --> Controller Class Initialized
INFO - 2018-09-30 11:55:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:55:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 11:55:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:55:39 --> Final output sent to browser
DEBUG - 2018-09-30 11:55:39 --> Total execution time: 0.0470
INFO - 2018-09-30 11:55:42 --> Config Class Initialized
INFO - 2018-09-30 11:55:42 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:55:42 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:55:42 --> Utf8 Class Initialized
INFO - 2018-09-30 11:55:42 --> URI Class Initialized
INFO - 2018-09-30 11:55:42 --> Router Class Initialized
INFO - 2018-09-30 11:55:42 --> Output Class Initialized
INFO - 2018-09-30 11:55:42 --> Security Class Initialized
DEBUG - 2018-09-30 11:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:55:42 --> Input Class Initialized
INFO - 2018-09-30 11:55:42 --> Language Class Initialized
INFO - 2018-09-30 11:55:42 --> Loader Class Initialized
INFO - 2018-09-30 11:55:42 --> Helper loaded: url_helper
INFO - 2018-09-30 11:55:42 --> Helper loaded: form_helper
INFO - 2018-09-30 11:55:42 --> Helper loaded: html_helper
INFO - 2018-09-30 11:55:42 --> Database Driver Class Initialized
INFO - 2018-09-30 11:55:42 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:55:42 --> Model "User_model" initialized
INFO - 2018-09-30 11:55:42 --> Model "Project_model" initialized
INFO - 2018-09-30 11:55:42 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:55:42 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:55:42 --> Controller Class Initialized
INFO - 2018-09-30 11:55:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:55:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 11:55:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:55:42 --> Final output sent to browser
DEBUG - 2018-09-30 11:55:42 --> Total execution time: 0.0540
INFO - 2018-09-30 11:55:49 --> Config Class Initialized
INFO - 2018-09-30 11:55:49 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:55:49 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:55:49 --> Utf8 Class Initialized
INFO - 2018-09-30 11:55:49 --> URI Class Initialized
INFO - 2018-09-30 11:55:49 --> Router Class Initialized
INFO - 2018-09-30 11:55:49 --> Output Class Initialized
INFO - 2018-09-30 11:55:49 --> Security Class Initialized
DEBUG - 2018-09-30 11:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:55:49 --> Input Class Initialized
INFO - 2018-09-30 11:55:49 --> Language Class Initialized
INFO - 2018-09-30 11:55:49 --> Loader Class Initialized
INFO - 2018-09-30 11:55:49 --> Helper loaded: url_helper
INFO - 2018-09-30 11:55:49 --> Helper loaded: form_helper
INFO - 2018-09-30 11:55:49 --> Helper loaded: html_helper
INFO - 2018-09-30 11:55:49 --> Database Driver Class Initialized
INFO - 2018-09-30 11:55:49 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:55:49 --> Model "User_model" initialized
INFO - 2018-09-30 11:55:49 --> Model "Project_model" initialized
INFO - 2018-09-30 11:55:49 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:55:49 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:55:49 --> Controller Class Initialized
INFO - 2018-09-30 11:55:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:55:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 11:55:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:55:49 --> Final output sent to browser
DEBUG - 2018-09-30 11:55:49 --> Total execution time: 0.0630
INFO - 2018-09-30 11:55:52 --> Config Class Initialized
INFO - 2018-09-30 11:55:52 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:55:52 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:55:52 --> Utf8 Class Initialized
INFO - 2018-09-30 11:55:52 --> URI Class Initialized
INFO - 2018-09-30 11:55:52 --> Router Class Initialized
INFO - 2018-09-30 11:55:52 --> Output Class Initialized
INFO - 2018-09-30 11:55:52 --> Security Class Initialized
DEBUG - 2018-09-30 11:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:55:52 --> Input Class Initialized
INFO - 2018-09-30 11:55:52 --> Language Class Initialized
INFO - 2018-09-30 11:55:52 --> Loader Class Initialized
INFO - 2018-09-30 11:55:52 --> Helper loaded: url_helper
INFO - 2018-09-30 11:55:52 --> Helper loaded: form_helper
INFO - 2018-09-30 11:55:52 --> Helper loaded: html_helper
INFO - 2018-09-30 11:55:52 --> Database Driver Class Initialized
INFO - 2018-09-30 11:55:52 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:55:52 --> Model "User_model" initialized
INFO - 2018-09-30 11:55:52 --> Model "Project_model" initialized
INFO - 2018-09-30 11:55:52 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:55:52 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:55:52 --> Controller Class Initialized
INFO - 2018-09-30 11:55:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:55:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 11:55:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:55:52 --> Final output sent to browser
DEBUG - 2018-09-30 11:55:52 --> Total execution time: 0.0690
INFO - 2018-09-30 11:56:02 --> Config Class Initialized
INFO - 2018-09-30 11:56:02 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:56:02 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:56:02 --> Utf8 Class Initialized
INFO - 2018-09-30 11:56:02 --> URI Class Initialized
INFO - 2018-09-30 11:56:02 --> Router Class Initialized
INFO - 2018-09-30 11:56:02 --> Output Class Initialized
INFO - 2018-09-30 11:56:02 --> Security Class Initialized
DEBUG - 2018-09-30 11:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:56:02 --> Input Class Initialized
INFO - 2018-09-30 11:56:02 --> Language Class Initialized
INFO - 2018-09-30 11:56:02 --> Loader Class Initialized
INFO - 2018-09-30 11:56:02 --> Helper loaded: url_helper
INFO - 2018-09-30 11:56:02 --> Helper loaded: form_helper
INFO - 2018-09-30 11:56:02 --> Helper loaded: html_helper
INFO - 2018-09-30 11:56:02 --> Database Driver Class Initialized
INFO - 2018-09-30 11:56:02 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:56:02 --> Model "User_model" initialized
INFO - 2018-09-30 11:56:02 --> Model "Project_model" initialized
INFO - 2018-09-30 11:56:02 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:56:02 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:56:02 --> Controller Class Initialized
INFO - 2018-09-30 11:56:02 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:56:02 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 11:56:02 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:56:02 --> Final output sent to browser
DEBUG - 2018-09-30 11:56:02 --> Total execution time: 0.0460
INFO - 2018-09-30 11:56:03 --> Config Class Initialized
INFO - 2018-09-30 11:56:03 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:56:03 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:56:03 --> Utf8 Class Initialized
INFO - 2018-09-30 11:56:03 --> URI Class Initialized
INFO - 2018-09-30 11:56:03 --> Router Class Initialized
INFO - 2018-09-30 11:56:03 --> Output Class Initialized
INFO - 2018-09-30 11:56:03 --> Security Class Initialized
DEBUG - 2018-09-30 11:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:56:03 --> Input Class Initialized
INFO - 2018-09-30 11:56:03 --> Language Class Initialized
INFO - 2018-09-30 11:56:03 --> Loader Class Initialized
INFO - 2018-09-30 11:56:03 --> Helper loaded: url_helper
INFO - 2018-09-30 11:56:03 --> Helper loaded: form_helper
INFO - 2018-09-30 11:56:03 --> Helper loaded: html_helper
INFO - 2018-09-30 11:56:03 --> Database Driver Class Initialized
INFO - 2018-09-30 11:56:03 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:56:03 --> Model "User_model" initialized
INFO - 2018-09-30 11:56:03 --> Model "Project_model" initialized
INFO - 2018-09-30 11:56:03 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:56:03 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:56:03 --> Controller Class Initialized
INFO - 2018-09-30 11:56:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:56:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 11:56:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:56:03 --> Final output sent to browser
DEBUG - 2018-09-30 11:56:03 --> Total execution time: 0.0620
INFO - 2018-09-30 11:56:09 --> Config Class Initialized
INFO - 2018-09-30 11:56:09 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:56:09 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:56:09 --> Utf8 Class Initialized
INFO - 2018-09-30 11:56:09 --> URI Class Initialized
INFO - 2018-09-30 11:56:09 --> Router Class Initialized
INFO - 2018-09-30 11:56:09 --> Output Class Initialized
INFO - 2018-09-30 11:56:09 --> Security Class Initialized
DEBUG - 2018-09-30 11:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:56:09 --> Input Class Initialized
INFO - 2018-09-30 11:56:09 --> Language Class Initialized
INFO - 2018-09-30 11:56:09 --> Loader Class Initialized
INFO - 2018-09-30 11:56:09 --> Helper loaded: url_helper
INFO - 2018-09-30 11:56:09 --> Helper loaded: form_helper
INFO - 2018-09-30 11:56:09 --> Helper loaded: html_helper
INFO - 2018-09-30 11:56:09 --> Database Driver Class Initialized
INFO - 2018-09-30 11:56:09 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:56:09 --> Model "User_model" initialized
INFO - 2018-09-30 11:56:09 --> Model "Project_model" initialized
INFO - 2018-09-30 11:56:09 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:56:09 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:56:09 --> Controller Class Initialized
INFO - 2018-09-30 11:56:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:56:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 11:56:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:56:09 --> Final output sent to browser
DEBUG - 2018-09-30 11:56:09 --> Total execution time: 0.0660
INFO - 2018-09-30 11:56:10 --> Config Class Initialized
INFO - 2018-09-30 11:56:10 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:56:10 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:56:10 --> Utf8 Class Initialized
INFO - 2018-09-30 11:56:10 --> URI Class Initialized
INFO - 2018-09-30 11:56:10 --> Router Class Initialized
INFO - 2018-09-30 11:56:10 --> Output Class Initialized
INFO - 2018-09-30 11:56:10 --> Security Class Initialized
DEBUG - 2018-09-30 11:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:56:10 --> Input Class Initialized
INFO - 2018-09-30 11:56:10 --> Language Class Initialized
INFO - 2018-09-30 11:56:10 --> Loader Class Initialized
INFO - 2018-09-30 11:56:10 --> Helper loaded: url_helper
INFO - 2018-09-30 11:56:10 --> Helper loaded: form_helper
INFO - 2018-09-30 11:56:10 --> Helper loaded: html_helper
INFO - 2018-09-30 11:56:10 --> Database Driver Class Initialized
INFO - 2018-09-30 11:56:10 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:56:10 --> Model "User_model" initialized
INFO - 2018-09-30 11:56:10 --> Model "Project_model" initialized
INFO - 2018-09-30 11:56:10 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:56:10 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:56:10 --> Controller Class Initialized
INFO - 2018-09-30 11:56:10 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:56:10 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 11:56:10 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:56:10 --> Final output sent to browser
DEBUG - 2018-09-30 11:56:10 --> Total execution time: 0.0550
INFO - 2018-09-30 11:56:12 --> Config Class Initialized
INFO - 2018-09-30 11:56:12 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:56:12 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:56:12 --> Utf8 Class Initialized
INFO - 2018-09-30 11:56:12 --> URI Class Initialized
INFO - 2018-09-30 11:56:12 --> Router Class Initialized
INFO - 2018-09-30 11:56:12 --> Output Class Initialized
INFO - 2018-09-30 11:56:12 --> Security Class Initialized
DEBUG - 2018-09-30 11:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:56:12 --> Input Class Initialized
INFO - 2018-09-30 11:56:12 --> Language Class Initialized
INFO - 2018-09-30 11:56:12 --> Loader Class Initialized
INFO - 2018-09-30 11:56:12 --> Helper loaded: url_helper
INFO - 2018-09-30 11:56:12 --> Helper loaded: form_helper
INFO - 2018-09-30 11:56:12 --> Helper loaded: html_helper
INFO - 2018-09-30 11:56:12 --> Database Driver Class Initialized
INFO - 2018-09-30 11:56:12 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:56:12 --> Model "User_model" initialized
INFO - 2018-09-30 11:56:12 --> Model "Project_model" initialized
INFO - 2018-09-30 11:56:12 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:56:12 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:56:12 --> Controller Class Initialized
INFO - 2018-09-30 11:56:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:56:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 11:56:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:56:12 --> Final output sent to browser
DEBUG - 2018-09-30 11:56:12 --> Total execution time: 0.0680
INFO - 2018-09-30 11:56:13 --> Config Class Initialized
INFO - 2018-09-30 11:56:13 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:56:13 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:56:13 --> Utf8 Class Initialized
INFO - 2018-09-30 11:56:13 --> URI Class Initialized
INFO - 2018-09-30 11:56:13 --> Router Class Initialized
INFO - 2018-09-30 11:56:13 --> Output Class Initialized
INFO - 2018-09-30 11:56:13 --> Security Class Initialized
DEBUG - 2018-09-30 11:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:56:13 --> Input Class Initialized
INFO - 2018-09-30 11:56:13 --> Language Class Initialized
INFO - 2018-09-30 11:56:13 --> Loader Class Initialized
INFO - 2018-09-30 11:56:13 --> Helper loaded: url_helper
INFO - 2018-09-30 11:56:13 --> Helper loaded: form_helper
INFO - 2018-09-30 11:56:13 --> Helper loaded: html_helper
INFO - 2018-09-30 11:56:13 --> Database Driver Class Initialized
INFO - 2018-09-30 11:56:13 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:56:13 --> Model "User_model" initialized
INFO - 2018-09-30 11:56:13 --> Model "Project_model" initialized
INFO - 2018-09-30 11:56:13 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:56:13 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:56:13 --> Controller Class Initialized
INFO - 2018-09-30 11:56:13 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:56:13 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-30 11:56:13 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:56:13 --> Final output sent to browser
DEBUG - 2018-09-30 11:56:13 --> Total execution time: 0.0640
INFO - 2018-09-30 11:56:14 --> Config Class Initialized
INFO - 2018-09-30 11:56:14 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:56:14 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:56:14 --> Utf8 Class Initialized
INFO - 2018-09-30 11:56:14 --> URI Class Initialized
INFO - 2018-09-30 11:56:14 --> Router Class Initialized
INFO - 2018-09-30 11:56:14 --> Output Class Initialized
INFO - 2018-09-30 11:56:14 --> Security Class Initialized
DEBUG - 2018-09-30 11:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:56:14 --> Input Class Initialized
INFO - 2018-09-30 11:56:14 --> Language Class Initialized
INFO - 2018-09-30 11:56:14 --> Loader Class Initialized
INFO - 2018-09-30 11:56:14 --> Helper loaded: url_helper
INFO - 2018-09-30 11:56:14 --> Helper loaded: form_helper
INFO - 2018-09-30 11:56:14 --> Helper loaded: html_helper
INFO - 2018-09-30 11:56:14 --> Database Driver Class Initialized
INFO - 2018-09-30 11:56:14 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:56:14 --> Model "User_model" initialized
INFO - 2018-09-30 11:56:14 --> Model "Project_model" initialized
INFO - 2018-09-30 11:56:14 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:56:14 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:56:14 --> Controller Class Initialized
INFO - 2018-09-30 11:56:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:56:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 11:56:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:56:14 --> Final output sent to browser
DEBUG - 2018-09-30 11:56:14 --> Total execution time: 0.0790
INFO - 2018-09-30 11:56:15 --> Config Class Initialized
INFO - 2018-09-30 11:56:15 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:56:15 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:56:15 --> Utf8 Class Initialized
INFO - 2018-09-30 11:56:15 --> URI Class Initialized
INFO - 2018-09-30 11:56:15 --> Router Class Initialized
INFO - 2018-09-30 11:56:15 --> Output Class Initialized
INFO - 2018-09-30 11:56:15 --> Security Class Initialized
DEBUG - 2018-09-30 11:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:56:15 --> Input Class Initialized
INFO - 2018-09-30 11:56:15 --> Language Class Initialized
INFO - 2018-09-30 11:56:15 --> Loader Class Initialized
INFO - 2018-09-30 11:56:15 --> Helper loaded: url_helper
INFO - 2018-09-30 11:56:15 --> Helper loaded: form_helper
INFO - 2018-09-30 11:56:15 --> Helper loaded: html_helper
INFO - 2018-09-30 11:56:15 --> Database Driver Class Initialized
INFO - 2018-09-30 11:56:15 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:56:15 --> Model "User_model" initialized
INFO - 2018-09-30 11:56:15 --> Model "Project_model" initialized
INFO - 2018-09-30 11:56:15 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:56:15 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:56:15 --> Controller Class Initialized
INFO - 2018-09-30 11:56:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:56:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 11:56:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:56:15 --> Final output sent to browser
DEBUG - 2018-09-30 11:56:15 --> Total execution time: 0.0610
INFO - 2018-09-30 11:56:16 --> Config Class Initialized
INFO - 2018-09-30 11:56:16 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:56:16 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:56:16 --> Utf8 Class Initialized
INFO - 2018-09-30 11:56:16 --> URI Class Initialized
INFO - 2018-09-30 11:56:16 --> Router Class Initialized
INFO - 2018-09-30 11:56:16 --> Output Class Initialized
INFO - 2018-09-30 11:56:16 --> Security Class Initialized
DEBUG - 2018-09-30 11:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:56:16 --> Input Class Initialized
INFO - 2018-09-30 11:56:16 --> Language Class Initialized
INFO - 2018-09-30 11:56:16 --> Loader Class Initialized
INFO - 2018-09-30 11:56:16 --> Helper loaded: url_helper
INFO - 2018-09-30 11:56:16 --> Helper loaded: form_helper
INFO - 2018-09-30 11:56:16 --> Helper loaded: html_helper
INFO - 2018-09-30 11:56:16 --> Database Driver Class Initialized
INFO - 2018-09-30 11:56:16 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:56:16 --> Model "User_model" initialized
INFO - 2018-09-30 11:56:16 --> Model "Project_model" initialized
INFO - 2018-09-30 11:56:16 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:56:16 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:56:16 --> Controller Class Initialized
INFO - 2018-09-30 11:56:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:56:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 11:56:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:56:16 --> Final output sent to browser
DEBUG - 2018-09-30 11:56:16 --> Total execution time: 0.0500
INFO - 2018-09-30 11:56:30 --> Config Class Initialized
INFO - 2018-09-30 11:56:30 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:56:30 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:56:30 --> Utf8 Class Initialized
INFO - 2018-09-30 11:56:30 --> URI Class Initialized
INFO - 2018-09-30 11:56:30 --> Router Class Initialized
INFO - 2018-09-30 11:56:30 --> Output Class Initialized
INFO - 2018-09-30 11:56:30 --> Security Class Initialized
DEBUG - 2018-09-30 11:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:56:30 --> Input Class Initialized
INFO - 2018-09-30 11:56:30 --> Language Class Initialized
INFO - 2018-09-30 11:56:30 --> Loader Class Initialized
INFO - 2018-09-30 11:56:30 --> Helper loaded: url_helper
INFO - 2018-09-30 11:56:30 --> Helper loaded: form_helper
INFO - 2018-09-30 11:56:30 --> Helper loaded: html_helper
INFO - 2018-09-30 11:56:30 --> Database Driver Class Initialized
INFO - 2018-09-30 11:56:30 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:56:30 --> Model "User_model" initialized
INFO - 2018-09-30 11:56:30 --> Model "Project_model" initialized
INFO - 2018-09-30 11:56:30 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:56:30 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:56:30 --> Controller Class Initialized
INFO - 2018-09-30 11:56:30 --> Config Class Initialized
INFO - 2018-09-30 11:56:30 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:56:30 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:56:30 --> Utf8 Class Initialized
INFO - 2018-09-30 11:56:30 --> URI Class Initialized
INFO - 2018-09-30 11:56:30 --> Router Class Initialized
INFO - 2018-09-30 11:56:30 --> Output Class Initialized
INFO - 2018-09-30 11:56:30 --> Security Class Initialized
DEBUG - 2018-09-30 11:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:56:30 --> Input Class Initialized
INFO - 2018-09-30 11:56:30 --> Language Class Initialized
INFO - 2018-09-30 11:56:30 --> Loader Class Initialized
INFO - 2018-09-30 11:56:30 --> Helper loaded: url_helper
INFO - 2018-09-30 11:56:30 --> Helper loaded: form_helper
INFO - 2018-09-30 11:56:30 --> Helper loaded: html_helper
INFO - 2018-09-30 11:56:30 --> Database Driver Class Initialized
INFO - 2018-09-30 11:56:30 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:56:30 --> Model "User_model" initialized
INFO - 2018-09-30 11:56:30 --> Model "Project_model" initialized
INFO - 2018-09-30 11:56:30 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:56:30 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:56:30 --> Controller Class Initialized
INFO - 2018-09-30 11:56:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:56:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 11:56:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:56:30 --> Final output sent to browser
DEBUG - 2018-09-30 11:56:30 --> Total execution time: 0.0410
INFO - 2018-09-30 11:56:42 --> Config Class Initialized
INFO - 2018-09-30 11:56:42 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:56:42 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:56:42 --> Utf8 Class Initialized
INFO - 2018-09-30 11:56:42 --> URI Class Initialized
INFO - 2018-09-30 11:56:42 --> Router Class Initialized
INFO - 2018-09-30 11:56:42 --> Output Class Initialized
INFO - 2018-09-30 11:56:42 --> Security Class Initialized
DEBUG - 2018-09-30 11:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:56:42 --> Input Class Initialized
INFO - 2018-09-30 11:56:42 --> Language Class Initialized
INFO - 2018-09-30 11:56:42 --> Loader Class Initialized
INFO - 2018-09-30 11:56:42 --> Helper loaded: url_helper
INFO - 2018-09-30 11:56:42 --> Helper loaded: form_helper
INFO - 2018-09-30 11:56:42 --> Helper loaded: html_helper
INFO - 2018-09-30 11:56:42 --> Database Driver Class Initialized
INFO - 2018-09-30 11:56:42 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:56:42 --> Model "User_model" initialized
INFO - 2018-09-30 11:56:42 --> Model "Project_model" initialized
INFO - 2018-09-30 11:56:42 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:56:42 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:56:42 --> Controller Class Initialized
INFO - 2018-09-30 11:56:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-30 11:56:43 --> Config Class Initialized
INFO - 2018-09-30 11:56:43 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:56:43 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:56:43 --> Utf8 Class Initialized
INFO - 2018-09-30 11:56:43 --> URI Class Initialized
INFO - 2018-09-30 11:56:43 --> Router Class Initialized
INFO - 2018-09-30 11:56:43 --> Output Class Initialized
INFO - 2018-09-30 11:56:43 --> Security Class Initialized
DEBUG - 2018-09-30 11:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:56:43 --> Input Class Initialized
INFO - 2018-09-30 11:56:43 --> Language Class Initialized
INFO - 2018-09-30 11:56:43 --> Loader Class Initialized
INFO - 2018-09-30 11:56:43 --> Helper loaded: url_helper
INFO - 2018-09-30 11:56:43 --> Helper loaded: form_helper
INFO - 2018-09-30 11:56:43 --> Helper loaded: html_helper
INFO - 2018-09-30 11:56:43 --> Database Driver Class Initialized
INFO - 2018-09-30 11:56:43 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:56:43 --> Model "User_model" initialized
INFO - 2018-09-30 11:56:43 --> Model "Project_model" initialized
INFO - 2018-09-30 11:56:43 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:56:43 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:56:43 --> Controller Class Initialized
INFO - 2018-09-30 11:56:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:56:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 11:56:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:56:43 --> Final output sent to browser
DEBUG - 2018-09-30 11:56:43 --> Total execution time: 0.0460
INFO - 2018-09-30 11:56:45 --> Config Class Initialized
INFO - 2018-09-30 11:56:45 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:56:45 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:56:45 --> Utf8 Class Initialized
INFO - 2018-09-30 11:56:45 --> URI Class Initialized
INFO - 2018-09-30 11:56:45 --> Router Class Initialized
INFO - 2018-09-30 11:56:45 --> Output Class Initialized
INFO - 2018-09-30 11:56:45 --> Security Class Initialized
DEBUG - 2018-09-30 11:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:56:45 --> Input Class Initialized
INFO - 2018-09-30 11:56:45 --> Language Class Initialized
INFO - 2018-09-30 11:56:45 --> Loader Class Initialized
INFO - 2018-09-30 11:56:45 --> Helper loaded: url_helper
INFO - 2018-09-30 11:56:45 --> Helper loaded: form_helper
INFO - 2018-09-30 11:56:45 --> Helper loaded: html_helper
INFO - 2018-09-30 11:56:45 --> Database Driver Class Initialized
INFO - 2018-09-30 11:56:45 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:56:45 --> Model "User_model" initialized
INFO - 2018-09-30 11:56:45 --> Model "Project_model" initialized
INFO - 2018-09-30 11:56:45 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:56:45 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:56:45 --> Controller Class Initialized
INFO - 2018-09-30 11:56:45 --> Config Class Initialized
INFO - 2018-09-30 11:56:45 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:56:45 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:56:45 --> Utf8 Class Initialized
INFO - 2018-09-30 11:56:45 --> URI Class Initialized
INFO - 2018-09-30 11:56:45 --> Router Class Initialized
INFO - 2018-09-30 11:56:45 --> Output Class Initialized
INFO - 2018-09-30 11:56:45 --> Security Class Initialized
DEBUG - 2018-09-30 11:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:56:45 --> Input Class Initialized
INFO - 2018-09-30 11:56:45 --> Language Class Initialized
INFO - 2018-09-30 11:56:45 --> Loader Class Initialized
INFO - 2018-09-30 11:56:45 --> Helper loaded: url_helper
INFO - 2018-09-30 11:56:45 --> Helper loaded: form_helper
INFO - 2018-09-30 11:56:45 --> Helper loaded: html_helper
INFO - 2018-09-30 11:56:45 --> Database Driver Class Initialized
INFO - 2018-09-30 11:56:45 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:56:45 --> Model "User_model" initialized
INFO - 2018-09-30 11:56:45 --> Model "Project_model" initialized
INFO - 2018-09-30 11:56:45 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:56:45 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:56:45 --> Controller Class Initialized
INFO - 2018-09-30 11:56:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:56:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 11:56:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:56:45 --> Final output sent to browser
DEBUG - 2018-09-30 11:56:45 --> Total execution time: 0.0350
INFO - 2018-09-30 11:56:52 --> Config Class Initialized
INFO - 2018-09-30 11:56:52 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:56:52 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:56:52 --> Utf8 Class Initialized
INFO - 2018-09-30 11:56:52 --> URI Class Initialized
INFO - 2018-09-30 11:56:52 --> Router Class Initialized
INFO - 2018-09-30 11:56:52 --> Output Class Initialized
INFO - 2018-09-30 11:56:52 --> Security Class Initialized
DEBUG - 2018-09-30 11:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:56:52 --> Input Class Initialized
INFO - 2018-09-30 11:56:52 --> Language Class Initialized
INFO - 2018-09-30 11:56:52 --> Loader Class Initialized
INFO - 2018-09-30 11:56:52 --> Helper loaded: url_helper
INFO - 2018-09-30 11:56:52 --> Helper loaded: form_helper
INFO - 2018-09-30 11:56:52 --> Helper loaded: html_helper
INFO - 2018-09-30 11:56:52 --> Database Driver Class Initialized
INFO - 2018-09-30 11:56:52 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:56:52 --> Model "User_model" initialized
INFO - 2018-09-30 11:56:52 --> Model "Project_model" initialized
INFO - 2018-09-30 11:56:52 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:56:52 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:56:52 --> Controller Class Initialized
INFO - 2018-09-30 11:56:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-30 11:56:52 --> Config Class Initialized
INFO - 2018-09-30 11:56:52 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:56:52 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:56:52 --> Utf8 Class Initialized
INFO - 2018-09-30 11:56:52 --> URI Class Initialized
INFO - 2018-09-30 11:56:52 --> Router Class Initialized
INFO - 2018-09-30 11:56:52 --> Output Class Initialized
INFO - 2018-09-30 11:56:52 --> Security Class Initialized
DEBUG - 2018-09-30 11:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:56:52 --> Input Class Initialized
INFO - 2018-09-30 11:56:52 --> Language Class Initialized
INFO - 2018-09-30 11:56:52 --> Loader Class Initialized
INFO - 2018-09-30 11:56:52 --> Helper loaded: url_helper
INFO - 2018-09-30 11:56:52 --> Helper loaded: form_helper
INFO - 2018-09-30 11:56:52 --> Helper loaded: html_helper
INFO - 2018-09-30 11:56:52 --> Database Driver Class Initialized
INFO - 2018-09-30 11:56:52 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:56:52 --> Model "User_model" initialized
INFO - 2018-09-30 11:56:52 --> Model "Project_model" initialized
INFO - 2018-09-30 11:56:52 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:56:52 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:56:52 --> Controller Class Initialized
INFO - 2018-09-30 11:56:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 11:56:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 11:56:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:56:52 --> Final output sent to browser
DEBUG - 2018-09-30 11:56:52 --> Total execution time: 0.0430
INFO - 2018-09-30 11:58:35 --> Config Class Initialized
INFO - 2018-09-30 11:58:35 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:58:35 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:58:35 --> Utf8 Class Initialized
INFO - 2018-09-30 11:58:35 --> URI Class Initialized
INFO - 2018-09-30 11:58:35 --> Router Class Initialized
INFO - 2018-09-30 11:58:35 --> Output Class Initialized
INFO - 2018-09-30 11:58:35 --> Security Class Initialized
DEBUG - 2018-09-30 11:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:58:35 --> Input Class Initialized
INFO - 2018-09-30 11:58:35 --> Language Class Initialized
INFO - 2018-09-30 11:58:35 --> Loader Class Initialized
INFO - 2018-09-30 11:58:35 --> Helper loaded: url_helper
INFO - 2018-09-30 11:58:35 --> Helper loaded: form_helper
INFO - 2018-09-30 11:58:35 --> Helper loaded: html_helper
INFO - 2018-09-30 11:58:35 --> Database Driver Class Initialized
INFO - 2018-09-30 11:58:35 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:58:35 --> Model "User_model" initialized
INFO - 2018-09-30 11:58:35 --> Model "Project_model" initialized
INFO - 2018-09-30 11:58:35 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:58:35 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:58:35 --> Controller Class Initialized
INFO - 2018-09-30 11:58:35 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-30 11:58:35 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\code_igniter\application\views\project_views\projects\index.php 36
ERROR - 2018-09-30 11:58:35 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\code_igniter\application\views\project_views\projects\index.php 36
INFO - 2018-09-30 11:58:35 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 11:58:35 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:58:35 --> Final output sent to browser
DEBUG - 2018-09-30 11:58:35 --> Total execution time: 0.0590
INFO - 2018-09-30 11:58:42 --> Config Class Initialized
INFO - 2018-09-30 11:58:42 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:58:42 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:58:42 --> Utf8 Class Initialized
INFO - 2018-09-30 11:58:42 --> URI Class Initialized
INFO - 2018-09-30 11:58:42 --> Router Class Initialized
INFO - 2018-09-30 11:58:42 --> Output Class Initialized
INFO - 2018-09-30 11:58:42 --> Security Class Initialized
DEBUG - 2018-09-30 11:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:58:42 --> Input Class Initialized
INFO - 2018-09-30 11:58:42 --> Language Class Initialized
INFO - 2018-09-30 11:58:42 --> Loader Class Initialized
INFO - 2018-09-30 11:58:42 --> Helper loaded: url_helper
INFO - 2018-09-30 11:58:42 --> Helper loaded: form_helper
INFO - 2018-09-30 11:58:42 --> Helper loaded: html_helper
INFO - 2018-09-30 11:58:42 --> Database Driver Class Initialized
INFO - 2018-09-30 11:58:42 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:58:42 --> Model "User_model" initialized
INFO - 2018-09-30 11:58:42 --> Model "Project_model" initialized
INFO - 2018-09-30 11:58:42 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:58:42 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:58:42 --> Controller Class Initialized
INFO - 2018-09-30 11:58:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-30 11:58:42 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\code_igniter\application\views\project_views\projects\index.php 36
ERROR - 2018-09-30 11:58:42 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\code_igniter\application\views\project_views\projects\index.php 36
INFO - 2018-09-30 11:58:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-30 11:58:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:58:42 --> Final output sent to browser
DEBUG - 2018-09-30 11:58:42 --> Total execution time: 0.0510
INFO - 2018-09-30 11:58:43 --> Config Class Initialized
INFO - 2018-09-30 11:58:43 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:58:43 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:58:43 --> Utf8 Class Initialized
INFO - 2018-09-30 11:58:43 --> URI Class Initialized
INFO - 2018-09-30 11:58:43 --> Router Class Initialized
INFO - 2018-09-30 11:58:43 --> Output Class Initialized
INFO - 2018-09-30 11:58:43 --> Security Class Initialized
DEBUG - 2018-09-30 11:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:58:43 --> Input Class Initialized
INFO - 2018-09-30 11:58:43 --> Language Class Initialized
INFO - 2018-09-30 11:58:43 --> Loader Class Initialized
INFO - 2018-09-30 11:58:43 --> Helper loaded: url_helper
INFO - 2018-09-30 11:58:43 --> Helper loaded: form_helper
INFO - 2018-09-30 11:58:43 --> Helper loaded: html_helper
INFO - 2018-09-30 11:58:43 --> Database Driver Class Initialized
INFO - 2018-09-30 11:58:43 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:58:43 --> Model "User_model" initialized
INFO - 2018-09-30 11:58:43 --> Model "Project_model" initialized
INFO - 2018-09-30 11:58:43 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:58:43 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:58:43 --> Controller Class Initialized
INFO - 2018-09-30 11:58:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-30 11:58:43 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\code_igniter\application\views\project_views\users\home_view.php 52
ERROR - 2018-09-30 11:58:43 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\code_igniter\application\views\project_views\users\home_view.php 55
ERROR - 2018-09-30 11:58:43 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\code_igniter\application\views\project_views\users\home_view.php 52
ERROR - 2018-09-30 11:58:43 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\code_igniter\application\views\project_views\users\home_view.php 55
INFO - 2018-09-30 11:58:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 11:58:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:58:43 --> Final output sent to browser
DEBUG - 2018-09-30 11:58:43 --> Total execution time: 0.0740
INFO - 2018-09-30 11:59:29 --> Config Class Initialized
INFO - 2018-09-30 11:59:29 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:59:29 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:59:29 --> Utf8 Class Initialized
INFO - 2018-09-30 11:59:29 --> URI Class Initialized
INFO - 2018-09-30 11:59:29 --> Router Class Initialized
INFO - 2018-09-30 11:59:29 --> Output Class Initialized
INFO - 2018-09-30 11:59:29 --> Security Class Initialized
DEBUG - 2018-09-30 11:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:59:29 --> Input Class Initialized
INFO - 2018-09-30 11:59:29 --> Language Class Initialized
INFO - 2018-09-30 11:59:29 --> Loader Class Initialized
INFO - 2018-09-30 11:59:29 --> Helper loaded: url_helper
INFO - 2018-09-30 11:59:30 --> Helper loaded: form_helper
INFO - 2018-09-30 11:59:30 --> Helper loaded: html_helper
INFO - 2018-09-30 11:59:30 --> Database Driver Class Initialized
INFO - 2018-09-30 11:59:30 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:59:30 --> Model "User_model" initialized
INFO - 2018-09-30 11:59:30 --> Model "Project_model" initialized
INFO - 2018-09-30 11:59:30 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:59:30 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:59:30 --> Controller Class Initialized
ERROR - 2018-09-30 11:59:30 --> Query error: Not unique table/alias: 'projects' - Invalid query: SELECT `project_name`
FROM `projects`, `projects`
WHERE `project_user_id` = '2'
INFO - 2018-09-30 11:59:30 --> Language file loaded: language/english/db_lang.php
INFO - 2018-09-30 11:59:49 --> Config Class Initialized
INFO - 2018-09-30 11:59:49 --> Hooks Class Initialized
DEBUG - 2018-09-30 11:59:49 --> UTF-8 Support Enabled
INFO - 2018-09-30 11:59:49 --> Utf8 Class Initialized
INFO - 2018-09-30 11:59:49 --> URI Class Initialized
INFO - 2018-09-30 11:59:49 --> Router Class Initialized
INFO - 2018-09-30 11:59:49 --> Output Class Initialized
INFO - 2018-09-30 11:59:49 --> Security Class Initialized
DEBUG - 2018-09-30 11:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 11:59:49 --> Input Class Initialized
INFO - 2018-09-30 11:59:49 --> Language Class Initialized
INFO - 2018-09-30 11:59:49 --> Loader Class Initialized
INFO - 2018-09-30 11:59:49 --> Helper loaded: url_helper
INFO - 2018-09-30 11:59:49 --> Helper loaded: form_helper
INFO - 2018-09-30 11:59:49 --> Helper loaded: html_helper
INFO - 2018-09-30 11:59:49 --> Database Driver Class Initialized
INFO - 2018-09-30 11:59:49 --> Form Validation Class Initialized
DEBUG - 2018-09-30 11:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 11:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 11:59:49 --> Model "User_model" initialized
INFO - 2018-09-30 11:59:49 --> Model "Project_model" initialized
INFO - 2018-09-30 11:59:49 --> Model "Tasks_model" initialized
INFO - 2018-09-30 11:59:49 --> Model "Lists_model" initialized
INFO - 2018-09-30 11:59:49 --> Controller Class Initialized
INFO - 2018-09-30 11:59:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-09-30 11:59:49 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\code_igniter\application\views\project_views\users\home_view.php 52
ERROR - 2018-09-30 11:59:49 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\code_igniter\application\views\project_views\users\home_view.php 55
ERROR - 2018-09-30 11:59:49 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\code_igniter\application\views\project_views\users\home_view.php 52
ERROR - 2018-09-30 11:59:49 --> Severity: Notice --> Undefined property: stdClass::$id D:\xampp\htdocs\code_igniter\application\views\project_views\users\home_view.php 55
INFO - 2018-09-30 11:59:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 11:59:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 11:59:49 --> Final output sent to browser
DEBUG - 2018-09-30 11:59:49 --> Total execution time: 0.0580
INFO - 2018-09-30 12:12:34 --> Config Class Initialized
INFO - 2018-09-30 12:12:34 --> Hooks Class Initialized
DEBUG - 2018-09-30 12:12:34 --> UTF-8 Support Enabled
INFO - 2018-09-30 12:12:34 --> Utf8 Class Initialized
INFO - 2018-09-30 12:12:34 --> URI Class Initialized
INFO - 2018-09-30 12:12:34 --> Router Class Initialized
INFO - 2018-09-30 12:12:34 --> Output Class Initialized
INFO - 2018-09-30 12:12:34 --> Security Class Initialized
DEBUG - 2018-09-30 12:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-30 12:12:34 --> Input Class Initialized
INFO - 2018-09-30 12:12:34 --> Language Class Initialized
INFO - 2018-09-30 12:12:34 --> Loader Class Initialized
INFO - 2018-09-30 12:12:34 --> Helper loaded: url_helper
INFO - 2018-09-30 12:12:34 --> Helper loaded: form_helper
INFO - 2018-09-30 12:12:34 --> Helper loaded: html_helper
INFO - 2018-09-30 12:12:34 --> Database Driver Class Initialized
INFO - 2018-09-30 12:12:34 --> Form Validation Class Initialized
DEBUG - 2018-09-30 12:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-30 12:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-30 12:12:34 --> Model "User_model" initialized
INFO - 2018-09-30 12:12:34 --> Model "Project_model" initialized
INFO - 2018-09-30 12:12:34 --> Model "Tasks_model" initialized
INFO - 2018-09-30 12:12:34 --> Model "Lists_model" initialized
INFO - 2018-09-30 12:12:34 --> Controller Class Initialized
INFO - 2018-09-30 12:12:34 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-30 12:12:34 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-30 12:12:34 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-30 12:12:34 --> Final output sent to browser
DEBUG - 2018-09-30 12:12:34 --> Total execution time: 0.1490
