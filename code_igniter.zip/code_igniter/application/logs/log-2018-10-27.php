<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-27 05:26:07 --> Config Class Initialized
INFO - 2018-10-27 05:26:07 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:26:07 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:26:07 --> Utf8 Class Initialized
INFO - 2018-10-27 05:26:07 --> URI Class Initialized
INFO - 2018-10-27 05:26:07 --> Router Class Initialized
INFO - 2018-10-27 05:26:07 --> Output Class Initialized
INFO - 2018-10-27 05:26:07 --> Security Class Initialized
DEBUG - 2018-10-27 05:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:26:07 --> Input Class Initialized
INFO - 2018-10-27 05:26:07 --> Language Class Initialized
INFO - 2018-10-27 05:26:07 --> Loader Class Initialized
INFO - 2018-10-27 05:26:07 --> Helper loaded: url_helper
INFO - 2018-10-27 05:26:07 --> Helper loaded: form_helper
INFO - 2018-10-27 05:26:07 --> Helper loaded: html_helper
INFO - 2018-10-27 05:26:07 --> Database Driver Class Initialized
INFO - 2018-10-27 05:26:07 --> Form Validation Class Initialized
DEBUG - 2018-10-27 05:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 05:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 05:26:07 --> Model "User_model" initialized
INFO - 2018-10-27 05:26:07 --> Controller Class Initialized
INFO - 2018-10-27 05:26:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-27 05:26:07 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 05:26:07 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 05:26:07 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 05:26:07 --> Final output sent to browser
DEBUG - 2018-10-27 05:26:07 --> Total execution time: 0.2510
INFO - 2018-10-27 05:26:17 --> Config Class Initialized
INFO - 2018-10-27 05:26:17 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:26:17 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:26:17 --> Utf8 Class Initialized
INFO - 2018-10-27 05:26:17 --> URI Class Initialized
INFO - 2018-10-27 05:26:17 --> Router Class Initialized
INFO - 2018-10-27 05:26:17 --> Output Class Initialized
INFO - 2018-10-27 05:26:17 --> Security Class Initialized
DEBUG - 2018-10-27 05:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:26:17 --> Input Class Initialized
INFO - 2018-10-27 05:26:17 --> Language Class Initialized
INFO - 2018-10-27 05:26:17 --> Loader Class Initialized
INFO - 2018-10-27 05:26:17 --> Helper loaded: url_helper
INFO - 2018-10-27 05:26:17 --> Helper loaded: form_helper
INFO - 2018-10-27 05:26:17 --> Helper loaded: html_helper
INFO - 2018-10-27 05:26:17 --> Database Driver Class Initialized
INFO - 2018-10-27 05:26:17 --> Form Validation Class Initialized
DEBUG - 2018-10-27 05:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 05:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 05:26:17 --> Model "User_model" initialized
INFO - 2018-10-27 05:26:17 --> Controller Class Initialized
INFO - 2018-10-27 05:26:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-27 05:26:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 05:26:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 05:26:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 05:26:17 --> Final output sent to browser
DEBUG - 2018-10-27 05:26:17 --> Total execution time: 0.0440
INFO - 2018-10-27 05:26:53 --> Config Class Initialized
INFO - 2018-10-27 05:26:53 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:26:53 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:26:53 --> Utf8 Class Initialized
INFO - 2018-10-27 05:26:53 --> URI Class Initialized
INFO - 2018-10-27 05:26:53 --> Router Class Initialized
INFO - 2018-10-27 05:26:53 --> Output Class Initialized
INFO - 2018-10-27 05:26:53 --> Security Class Initialized
DEBUG - 2018-10-27 05:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:26:53 --> Input Class Initialized
INFO - 2018-10-27 05:26:53 --> Language Class Initialized
INFO - 2018-10-27 05:26:53 --> Loader Class Initialized
INFO - 2018-10-27 05:26:53 --> Helper loaded: url_helper
INFO - 2018-10-27 05:26:53 --> Helper loaded: form_helper
INFO - 2018-10-27 05:26:53 --> Helper loaded: html_helper
INFO - 2018-10-27 05:26:53 --> Database Driver Class Initialized
INFO - 2018-10-27 05:26:53 --> Form Validation Class Initialized
DEBUG - 2018-10-27 05:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 05:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 05:26:53 --> Model "User_model" initialized
INFO - 2018-10-27 05:26:53 --> Controller Class Initialized
INFO - 2018-10-27 05:26:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-27 05:26:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 05:26:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 05:26:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 05:26:53 --> Final output sent to browser
DEBUG - 2018-10-27 05:26:53 --> Total execution time: 0.0550
INFO - 2018-10-27 05:27:02 --> Config Class Initialized
INFO - 2018-10-27 05:27:02 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:27:02 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:27:02 --> Utf8 Class Initialized
INFO - 2018-10-27 05:27:02 --> URI Class Initialized
INFO - 2018-10-27 05:27:02 --> Router Class Initialized
INFO - 2018-10-27 05:27:02 --> Output Class Initialized
INFO - 2018-10-27 05:27:02 --> Security Class Initialized
DEBUG - 2018-10-27 05:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:27:02 --> Input Class Initialized
INFO - 2018-10-27 05:27:02 --> Language Class Initialized
INFO - 2018-10-27 05:27:02 --> Loader Class Initialized
INFO - 2018-10-27 05:27:02 --> Helper loaded: url_helper
INFO - 2018-10-27 05:27:02 --> Helper loaded: form_helper
INFO - 2018-10-27 05:27:02 --> Helper loaded: html_helper
INFO - 2018-10-27 05:27:02 --> Database Driver Class Initialized
INFO - 2018-10-27 05:27:02 --> Form Validation Class Initialized
DEBUG - 2018-10-27 05:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 05:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 05:27:02 --> Model "User_model" initialized
INFO - 2018-10-27 05:27:02 --> Controller Class Initialized
INFO - 2018-10-27 05:27:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-27 05:27:02 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 05:27:02 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 05:27:02 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 05:27:02 --> Final output sent to browser
DEBUG - 2018-10-27 05:27:02 --> Total execution time: 0.0440
INFO - 2018-10-27 05:29:17 --> Config Class Initialized
INFO - 2018-10-27 05:29:17 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:29:17 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:29:17 --> Utf8 Class Initialized
INFO - 2018-10-27 05:29:17 --> URI Class Initialized
INFO - 2018-10-27 05:29:17 --> Router Class Initialized
INFO - 2018-10-27 05:29:17 --> Output Class Initialized
INFO - 2018-10-27 05:29:17 --> Security Class Initialized
DEBUG - 2018-10-27 05:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:29:17 --> Input Class Initialized
INFO - 2018-10-27 05:29:17 --> Language Class Initialized
INFO - 2018-10-27 05:29:17 --> Loader Class Initialized
INFO - 2018-10-27 05:29:17 --> Helper loaded: url_helper
INFO - 2018-10-27 05:29:17 --> Helper loaded: form_helper
INFO - 2018-10-27 05:29:17 --> Helper loaded: html_helper
INFO - 2018-10-27 05:29:17 --> Database Driver Class Initialized
INFO - 2018-10-27 05:29:17 --> Form Validation Class Initialized
DEBUG - 2018-10-27 05:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 05:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 05:29:17 --> Form Validation Class Initialized
INFO - 2018-10-27 05:29:17 --> Model "User_model" initialized
INFO - 2018-10-27 05:29:17 --> Controller Class Initialized
INFO - 2018-10-27 05:29:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-27 05:29:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 05:29:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 05:29:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 05:29:17 --> Final output sent to browser
DEBUG - 2018-10-27 05:29:17 --> Total execution time: 0.0630
INFO - 2018-10-27 05:29:23 --> Config Class Initialized
INFO - 2018-10-27 05:29:23 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:29:23 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:29:23 --> Utf8 Class Initialized
INFO - 2018-10-27 05:29:23 --> URI Class Initialized
INFO - 2018-10-27 05:29:23 --> Router Class Initialized
INFO - 2018-10-27 05:29:23 --> Output Class Initialized
INFO - 2018-10-27 05:29:23 --> Security Class Initialized
DEBUG - 2018-10-27 05:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:29:23 --> Input Class Initialized
INFO - 2018-10-27 05:29:23 --> Language Class Initialized
INFO - 2018-10-27 05:29:23 --> Loader Class Initialized
INFO - 2018-10-27 05:29:23 --> Helper loaded: url_helper
INFO - 2018-10-27 05:29:23 --> Helper loaded: form_helper
INFO - 2018-10-27 05:29:23 --> Helper loaded: html_helper
INFO - 2018-10-27 05:29:23 --> Database Driver Class Initialized
INFO - 2018-10-27 05:29:23 --> Form Validation Class Initialized
DEBUG - 2018-10-27 05:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 05:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 05:29:23 --> Form Validation Class Initialized
INFO - 2018-10-27 05:29:23 --> Model "User_model" initialized
INFO - 2018-10-27 05:29:23 --> Controller Class Initialized
INFO - 2018-10-27 05:29:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-27 05:29:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 05:29:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 05:29:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 05:29:23 --> Final output sent to browser
DEBUG - 2018-10-27 05:29:23 --> Total execution time: 0.0500
INFO - 2018-10-27 05:29:33 --> Config Class Initialized
INFO - 2018-10-27 05:29:33 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:29:33 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:29:33 --> Utf8 Class Initialized
INFO - 2018-10-27 05:29:33 --> URI Class Initialized
INFO - 2018-10-27 05:29:33 --> Router Class Initialized
INFO - 2018-10-27 05:29:33 --> Output Class Initialized
INFO - 2018-10-27 05:29:33 --> Security Class Initialized
DEBUG - 2018-10-27 05:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:29:33 --> Input Class Initialized
INFO - 2018-10-27 05:29:33 --> Language Class Initialized
INFO - 2018-10-27 05:29:33 --> Loader Class Initialized
INFO - 2018-10-27 05:29:33 --> Helper loaded: url_helper
INFO - 2018-10-27 05:29:33 --> Helper loaded: form_helper
INFO - 2018-10-27 05:29:33 --> Helper loaded: html_helper
INFO - 2018-10-27 05:29:33 --> Database Driver Class Initialized
INFO - 2018-10-27 05:29:33 --> Form Validation Class Initialized
DEBUG - 2018-10-27 05:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 05:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 05:29:33 --> Form Validation Class Initialized
INFO - 2018-10-27 05:29:33 --> Model "User_model" initialized
INFO - 2018-10-27 05:29:33 --> Controller Class Initialized
INFO - 2018-10-27 05:29:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-27 05:29:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 05:29:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 05:29:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 05:29:33 --> Final output sent to browser
DEBUG - 2018-10-27 05:29:33 --> Total execution time: 0.0520
INFO - 2018-10-27 05:31:59 --> Config Class Initialized
INFO - 2018-10-27 05:31:59 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:31:59 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:31:59 --> Utf8 Class Initialized
INFO - 2018-10-27 05:32:00 --> URI Class Initialized
INFO - 2018-10-27 05:32:00 --> Router Class Initialized
INFO - 2018-10-27 05:32:00 --> Output Class Initialized
INFO - 2018-10-27 05:32:00 --> Security Class Initialized
DEBUG - 2018-10-27 05:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:32:00 --> Input Class Initialized
INFO - 2018-10-27 05:32:00 --> Language Class Initialized
INFO - 2018-10-27 05:32:00 --> Loader Class Initialized
INFO - 2018-10-27 05:32:00 --> Helper loaded: url_helper
INFO - 2018-10-27 05:32:00 --> Helper loaded: form_helper
INFO - 2018-10-27 05:32:00 --> Helper loaded: html_helper
INFO - 2018-10-27 05:32:00 --> Database Driver Class Initialized
INFO - 2018-10-27 05:32:00 --> Form Validation Class Initialized
DEBUG - 2018-10-27 05:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 05:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 05:32:00 --> Form Validation Class Initialized
INFO - 2018-10-27 05:32:00 --> Model "User_model" initialized
INFO - 2018-10-27 05:32:00 --> Controller Class Initialized
INFO - 2018-10-27 05:32:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-27 05:32:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 05:32:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 05:32:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 05:32:00 --> Final output sent to browser
DEBUG - 2018-10-27 05:32:00 --> Total execution time: 0.0470
INFO - 2018-10-27 05:32:19 --> Config Class Initialized
INFO - 2018-10-27 05:32:19 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:32:19 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:32:19 --> Utf8 Class Initialized
INFO - 2018-10-27 05:32:19 --> URI Class Initialized
INFO - 2018-10-27 05:32:19 --> Router Class Initialized
INFO - 2018-10-27 05:32:19 --> Output Class Initialized
INFO - 2018-10-27 05:32:19 --> Security Class Initialized
DEBUG - 2018-10-27 05:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:32:19 --> Input Class Initialized
INFO - 2018-10-27 05:32:19 --> Language Class Initialized
INFO - 2018-10-27 05:32:19 --> Loader Class Initialized
INFO - 2018-10-27 05:32:19 --> Helper loaded: url_helper
INFO - 2018-10-27 05:32:19 --> Helper loaded: form_helper
INFO - 2018-10-27 05:32:19 --> Helper loaded: html_helper
INFO - 2018-10-27 05:32:19 --> Database Driver Class Initialized
INFO - 2018-10-27 05:32:19 --> Form Validation Class Initialized
DEBUG - 2018-10-27 05:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 05:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 05:32:19 --> Form Validation Class Initialized
INFO - 2018-10-27 05:32:19 --> Model "User_model" initialized
INFO - 2018-10-27 05:32:19 --> Controller Class Initialized
INFO - 2018-10-27 05:32:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-27 05:32:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 05:32:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 05:32:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 05:32:19 --> Final output sent to browser
DEBUG - 2018-10-27 05:32:19 --> Total execution time: 0.0650
INFO - 2018-10-27 05:38:53 --> Config Class Initialized
INFO - 2018-10-27 05:38:53 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:38:53 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:38:53 --> Utf8 Class Initialized
INFO - 2018-10-27 05:38:53 --> URI Class Initialized
INFO - 2018-10-27 05:38:53 --> Router Class Initialized
INFO - 2018-10-27 05:38:53 --> Output Class Initialized
INFO - 2018-10-27 05:38:53 --> Security Class Initialized
DEBUG - 2018-10-27 05:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:38:53 --> Input Class Initialized
INFO - 2018-10-27 05:38:53 --> Language Class Initialized
INFO - 2018-10-27 05:38:53 --> Loader Class Initialized
INFO - 2018-10-27 05:38:53 --> Helper loaded: url_helper
INFO - 2018-10-27 05:38:53 --> Helper loaded: form_helper
INFO - 2018-10-27 05:38:53 --> Helper loaded: html_helper
INFO - 2018-10-27 05:38:53 --> Database Driver Class Initialized
INFO - 2018-10-27 05:38:53 --> Form Validation Class Initialized
DEBUG - 2018-10-27 05:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 05:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 05:38:53 --> Model "User_model" initialized
INFO - 2018-10-27 05:38:53 --> Controller Class Initialized
INFO - 2018-10-27 05:38:53 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-10-27 05:38:53 --> Unable to find validation rule: 
ERROR - 2018-10-27 05:38:53 --> Could not find the language line "form_validation_"
INFO - 2018-10-27 05:38:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 05:38:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 05:38:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 05:38:53 --> Final output sent to browser
DEBUG - 2018-10-27 05:38:53 --> Total execution time: 0.0610
INFO - 2018-10-27 05:40:42 --> Config Class Initialized
INFO - 2018-10-27 05:40:42 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:40:42 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:40:42 --> Utf8 Class Initialized
INFO - 2018-10-27 05:40:42 --> URI Class Initialized
INFO - 2018-10-27 05:40:42 --> Router Class Initialized
INFO - 2018-10-27 05:40:42 --> Output Class Initialized
INFO - 2018-10-27 05:40:42 --> Security Class Initialized
DEBUG - 2018-10-27 05:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:40:42 --> Input Class Initialized
INFO - 2018-10-27 05:40:42 --> Language Class Initialized
INFO - 2018-10-27 05:40:42 --> Loader Class Initialized
INFO - 2018-10-27 05:40:42 --> Helper loaded: url_helper
INFO - 2018-10-27 05:40:42 --> Helper loaded: form_helper
INFO - 2018-10-27 05:40:42 --> Helper loaded: html_helper
INFO - 2018-10-27 05:40:42 --> Database Driver Class Initialized
INFO - 2018-10-27 05:40:42 --> Form Validation Class Initialized
DEBUG - 2018-10-27 05:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 05:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 05:40:42 --> Model "User_model" initialized
INFO - 2018-10-27 05:40:42 --> Controller Class Initialized
INFO - 2018-10-27 05:40:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-10-27 05:40:42 --> Unable to find validation rule: 
ERROR - 2018-10-27 05:40:42 --> Could not find the language line "form_validation_"
INFO - 2018-10-27 05:40:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 05:40:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 05:40:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 05:40:42 --> Final output sent to browser
DEBUG - 2018-10-27 05:40:42 --> Total execution time: 0.0640
INFO - 2018-10-27 05:41:15 --> Config Class Initialized
INFO - 2018-10-27 05:41:15 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:41:15 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:41:15 --> Utf8 Class Initialized
INFO - 2018-10-27 05:41:15 --> URI Class Initialized
INFO - 2018-10-27 05:41:15 --> Router Class Initialized
INFO - 2018-10-27 05:41:15 --> Output Class Initialized
INFO - 2018-10-27 05:41:15 --> Security Class Initialized
DEBUG - 2018-10-27 05:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:41:15 --> Input Class Initialized
INFO - 2018-10-27 05:41:15 --> Language Class Initialized
INFO - 2018-10-27 05:41:15 --> Loader Class Initialized
INFO - 2018-10-27 05:41:15 --> Helper loaded: url_helper
INFO - 2018-10-27 05:41:15 --> Helper loaded: form_helper
INFO - 2018-10-27 05:41:15 --> Helper loaded: html_helper
INFO - 2018-10-27 05:41:15 --> Database Driver Class Initialized
INFO - 2018-10-27 05:41:15 --> Form Validation Class Initialized
DEBUG - 2018-10-27 05:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 05:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 05:41:15 --> Model "User_model" initialized
INFO - 2018-10-27 05:41:15 --> Controller Class Initialized
INFO - 2018-10-27 05:41:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-27 05:41:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 05:41:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 05:41:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 05:41:15 --> Final output sent to browser
DEBUG - 2018-10-27 05:41:15 --> Total execution time: 0.0530
INFO - 2018-10-27 05:41:31 --> Config Class Initialized
INFO - 2018-10-27 05:41:31 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:41:31 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:41:31 --> Utf8 Class Initialized
INFO - 2018-10-27 05:41:31 --> URI Class Initialized
INFO - 2018-10-27 05:41:31 --> Router Class Initialized
INFO - 2018-10-27 05:41:31 --> Output Class Initialized
INFO - 2018-10-27 05:41:31 --> Security Class Initialized
DEBUG - 2018-10-27 05:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:41:31 --> Input Class Initialized
INFO - 2018-10-27 05:41:31 --> Language Class Initialized
INFO - 2018-10-27 05:41:31 --> Loader Class Initialized
INFO - 2018-10-27 05:41:31 --> Helper loaded: url_helper
INFO - 2018-10-27 05:41:31 --> Helper loaded: form_helper
INFO - 2018-10-27 05:41:31 --> Helper loaded: html_helper
INFO - 2018-10-27 05:41:31 --> Database Driver Class Initialized
INFO - 2018-10-27 05:41:31 --> Form Validation Class Initialized
DEBUG - 2018-10-27 05:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 05:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 05:41:31 --> Model "User_model" initialized
INFO - 2018-10-27 05:41:31 --> Controller Class Initialized
INFO - 2018-10-27 05:41:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-27 05:41:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 05:41:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 05:41:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 05:41:31 --> Final output sent to browser
DEBUG - 2018-10-27 05:41:31 --> Total execution time: 0.0610
INFO - 2018-10-27 05:41:40 --> Config Class Initialized
INFO - 2018-10-27 05:41:40 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:41:40 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:41:40 --> Utf8 Class Initialized
INFO - 2018-10-27 05:41:40 --> URI Class Initialized
INFO - 2018-10-27 05:41:40 --> Router Class Initialized
INFO - 2018-10-27 05:41:40 --> Output Class Initialized
INFO - 2018-10-27 05:41:40 --> Security Class Initialized
DEBUG - 2018-10-27 05:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:41:40 --> Input Class Initialized
INFO - 2018-10-27 05:41:40 --> Language Class Initialized
INFO - 2018-10-27 05:41:40 --> Loader Class Initialized
INFO - 2018-10-27 05:41:40 --> Helper loaded: url_helper
INFO - 2018-10-27 05:41:40 --> Helper loaded: form_helper
INFO - 2018-10-27 05:41:40 --> Helper loaded: html_helper
INFO - 2018-10-27 05:41:40 --> Database Driver Class Initialized
INFO - 2018-10-27 05:41:40 --> Form Validation Class Initialized
DEBUG - 2018-10-27 05:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 05:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 05:41:40 --> Model "User_model" initialized
INFO - 2018-10-27 05:41:40 --> Controller Class Initialized
INFO - 2018-10-27 05:41:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-27 05:41:41 --> Config Class Initialized
INFO - 2018-10-27 05:41:41 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:41:41 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:41:41 --> Utf8 Class Initialized
INFO - 2018-10-27 05:41:41 --> URI Class Initialized
INFO - 2018-10-27 05:41:41 --> Router Class Initialized
INFO - 2018-10-27 05:41:41 --> Output Class Initialized
INFO - 2018-10-27 05:41:41 --> Security Class Initialized
DEBUG - 2018-10-27 05:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:41:41 --> Input Class Initialized
INFO - 2018-10-27 05:41:41 --> Language Class Initialized
INFO - 2018-10-27 05:41:41 --> Loader Class Initialized
INFO - 2018-10-27 05:41:41 --> Helper loaded: url_helper
INFO - 2018-10-27 05:41:41 --> Helper loaded: form_helper
INFO - 2018-10-27 05:41:41 --> Helper loaded: html_helper
INFO - 2018-10-27 05:41:41 --> Database Driver Class Initialized
INFO - 2018-10-27 05:41:41 --> Form Validation Class Initialized
DEBUG - 2018-10-27 05:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 05:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 05:41:41 --> Model "User_model" initialized
INFO - 2018-10-27 05:41:41 --> Controller Class Initialized
INFO - 2018-10-27 05:41:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 05:41:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-27 05:41:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 05:41:41 --> Final output sent to browser
DEBUG - 2018-10-27 05:41:41 --> Total execution time: 0.0810
INFO - 2018-10-27 05:41:43 --> Config Class Initialized
INFO - 2018-10-27 05:41:43 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:41:43 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:41:43 --> Utf8 Class Initialized
INFO - 2018-10-27 05:41:43 --> URI Class Initialized
INFO - 2018-10-27 05:41:43 --> Router Class Initialized
INFO - 2018-10-27 05:41:43 --> Output Class Initialized
INFO - 2018-10-27 05:41:43 --> Security Class Initialized
DEBUG - 2018-10-27 05:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:41:43 --> Input Class Initialized
INFO - 2018-10-27 05:41:43 --> Language Class Initialized
INFO - 2018-10-27 05:41:43 --> Loader Class Initialized
INFO - 2018-10-27 05:41:43 --> Helper loaded: url_helper
INFO - 2018-10-27 05:41:43 --> Helper loaded: form_helper
INFO - 2018-10-27 05:41:43 --> Helper loaded: html_helper
INFO - 2018-10-27 05:41:43 --> Database Driver Class Initialized
INFO - 2018-10-27 05:41:43 --> Form Validation Class Initialized
DEBUG - 2018-10-27 05:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 05:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 05:41:43 --> Model "User_model" initialized
INFO - 2018-10-27 05:41:43 --> Controller Class Initialized
INFO - 2018-10-27 05:41:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 05:41:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 05:41:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 05:41:43 --> Final output sent to browser
DEBUG - 2018-10-27 05:41:43 --> Total execution time: 0.0630
INFO - 2018-10-27 05:42:20 --> Config Class Initialized
INFO - 2018-10-27 05:42:20 --> Hooks Class Initialized
DEBUG - 2018-10-27 05:42:20 --> UTF-8 Support Enabled
INFO - 2018-10-27 05:42:20 --> Utf8 Class Initialized
INFO - 2018-10-27 05:42:20 --> URI Class Initialized
INFO - 2018-10-27 05:42:20 --> Router Class Initialized
INFO - 2018-10-27 05:42:20 --> Output Class Initialized
INFO - 2018-10-27 05:42:20 --> Security Class Initialized
DEBUG - 2018-10-27 05:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 05:42:20 --> Input Class Initialized
INFO - 2018-10-27 05:42:20 --> Language Class Initialized
INFO - 2018-10-27 05:42:20 --> Loader Class Initialized
INFO - 2018-10-27 05:42:20 --> Helper loaded: url_helper
INFO - 2018-10-27 05:42:20 --> Helper loaded: form_helper
INFO - 2018-10-27 05:42:20 --> Helper loaded: html_helper
INFO - 2018-10-27 05:42:20 --> Database Driver Class Initialized
INFO - 2018-10-27 05:42:20 --> Form Validation Class Initialized
DEBUG - 2018-10-27 05:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 05:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 05:42:20 --> Model "User_model" initialized
INFO - 2018-10-27 05:42:20 --> Controller Class Initialized
INFO - 2018-10-27 05:42:20 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-27 05:42:21 --> Query error: Duplicate entry 'renzo@sample.com' for key 'email' - Invalid query: INSERT INTO `users` (`first_name`, `last_name`, `email`, `password`) VALUES ('Rolly', 'Abrazaldo', 'renzo@sample.com', '$2y$12$eUKQ8yvZzgRfyrkRGuTureC3B9lGhxJfHm30.WaBrRBvFRRHsUk06')
INFO - 2018-10-27 05:42:21 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-27 06:00:58 --> Config Class Initialized
INFO - 2018-10-27 06:00:58 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:00:58 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:00:58 --> Utf8 Class Initialized
INFO - 2018-10-27 06:00:58 --> URI Class Initialized
INFO - 2018-10-27 06:00:58 --> Router Class Initialized
INFO - 2018-10-27 06:00:58 --> Output Class Initialized
INFO - 2018-10-27 06:00:58 --> Security Class Initialized
DEBUG - 2018-10-27 06:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:00:58 --> Input Class Initialized
INFO - 2018-10-27 06:00:58 --> Language Class Initialized
INFO - 2018-10-27 06:00:58 --> Loader Class Initialized
INFO - 2018-10-27 06:00:58 --> Helper loaded: url_helper
INFO - 2018-10-27 06:00:58 --> Helper loaded: form_helper
INFO - 2018-10-27 06:00:58 --> Helper loaded: html_helper
INFO - 2018-10-27 06:00:58 --> Database Driver Class Initialized
INFO - 2018-10-27 06:00:58 --> Form Validation Class Initialized
DEBUG - 2018-10-27 06:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:00:58 --> Model "User_model" initialized
INFO - 2018-10-27 06:00:58 --> Controller Class Initialized
INFO - 2018-10-27 06:00:58 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-27 06:00:58 --> Query error: Duplicate entry 'renzo@sample.com' for key 'email' - Invalid query: INSERT INTO `users` (`first_name`, `last_name`, `email`, `password`) VALUES ('Rolly', 'Abrazaldo', 'renzo@sample.com', '$2y$12$UE8OmOP.7zhpzsa0X8XnwuqrmLwmxqCrX42zU9BP9j0WB3GPJ/DCy')
INFO - 2018-10-27 06:00:58 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-27 06:01:04 --> Config Class Initialized
INFO - 2018-10-27 06:01:04 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:01:04 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:01:04 --> Utf8 Class Initialized
INFO - 2018-10-27 06:01:04 --> URI Class Initialized
INFO - 2018-10-27 06:01:04 --> Router Class Initialized
INFO - 2018-10-27 06:01:04 --> Output Class Initialized
INFO - 2018-10-27 06:01:04 --> Security Class Initialized
DEBUG - 2018-10-27 06:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:01:04 --> Input Class Initialized
INFO - 2018-10-27 06:01:04 --> Language Class Initialized
INFO - 2018-10-27 06:01:04 --> Loader Class Initialized
INFO - 2018-10-27 06:01:04 --> Helper loaded: url_helper
INFO - 2018-10-27 06:01:04 --> Helper loaded: form_helper
INFO - 2018-10-27 06:01:04 --> Helper loaded: html_helper
INFO - 2018-10-27 06:01:04 --> Database Driver Class Initialized
INFO - 2018-10-27 06:01:04 --> Form Validation Class Initialized
DEBUG - 2018-10-27 06:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:01:04 --> Model "User_model" initialized
INFO - 2018-10-27 06:01:04 --> Controller Class Initialized
INFO - 2018-10-27 06:01:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 06:01:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 06:01:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 06:01:04 --> Final output sent to browser
DEBUG - 2018-10-27 06:01:04 --> Total execution time: 0.0720
INFO - 2018-10-27 06:01:14 --> Config Class Initialized
INFO - 2018-10-27 06:01:14 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:01:14 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:01:14 --> Utf8 Class Initialized
INFO - 2018-10-27 06:01:14 --> URI Class Initialized
INFO - 2018-10-27 06:01:14 --> Router Class Initialized
INFO - 2018-10-27 06:01:14 --> Output Class Initialized
INFO - 2018-10-27 06:01:14 --> Security Class Initialized
DEBUG - 2018-10-27 06:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:01:14 --> Input Class Initialized
INFO - 2018-10-27 06:01:14 --> Language Class Initialized
INFO - 2018-10-27 06:01:14 --> Loader Class Initialized
INFO - 2018-10-27 06:01:14 --> Helper loaded: url_helper
INFO - 2018-10-27 06:01:14 --> Helper loaded: form_helper
INFO - 2018-10-27 06:01:14 --> Helper loaded: html_helper
INFO - 2018-10-27 06:01:14 --> Database Driver Class Initialized
INFO - 2018-10-27 06:01:14 --> Form Validation Class Initialized
DEBUG - 2018-10-27 06:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:01:15 --> Model "User_model" initialized
INFO - 2018-10-27 06:01:15 --> Controller Class Initialized
INFO - 2018-10-27 06:01:15 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-27 06:01:15 --> Query error: Duplicate entry 'renzo@sample.com' for key 'email' - Invalid query: INSERT INTO `users` (`first_name`, `last_name`, `email`, `password`) VALUES ('Rolly', 'Abrazaldo', 'renzo@sample.com', '$2y$12$onqKr6IrrKhtuyP6BhKGs.79ddNWlgLH7FXo9.f226PzjYoT78AVS')
INFO - 2018-10-27 06:01:15 --> Language file loaded: language/english/db_lang.php
INFO - 2018-10-27 06:02:03 --> Config Class Initialized
INFO - 2018-10-27 06:02:03 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:02:03 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:02:03 --> Utf8 Class Initialized
INFO - 2018-10-27 06:02:03 --> URI Class Initialized
INFO - 2018-10-27 06:02:03 --> Router Class Initialized
INFO - 2018-10-27 06:02:03 --> Output Class Initialized
INFO - 2018-10-27 06:02:03 --> Security Class Initialized
DEBUG - 2018-10-27 06:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:02:03 --> Input Class Initialized
INFO - 2018-10-27 06:02:03 --> Language Class Initialized
INFO - 2018-10-27 06:02:03 --> Loader Class Initialized
INFO - 2018-10-27 06:02:03 --> Helper loaded: url_helper
INFO - 2018-10-27 06:02:03 --> Helper loaded: form_helper
INFO - 2018-10-27 06:02:03 --> Helper loaded: html_helper
INFO - 2018-10-27 06:02:03 --> Database Driver Class Initialized
INFO - 2018-10-27 06:02:03 --> Form Validation Class Initialized
DEBUG - 2018-10-27 06:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:02:03 --> Model "User_model" initialized
INFO - 2018-10-27 06:02:03 --> Controller Class Initialized
INFO - 2018-10-27 06:02:03 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-27 06:02:03 --> Could not find the language line "form_validation_isEmailExist"
INFO - 2018-10-27 06:02:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 06:02:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 06:02:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 06:02:03 --> Final output sent to browser
DEBUG - 2018-10-27 06:02:03 --> Total execution time: 0.0720
INFO - 2018-10-27 06:03:22 --> Config Class Initialized
INFO - 2018-10-27 06:03:22 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:03:22 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:03:22 --> Utf8 Class Initialized
INFO - 2018-10-27 06:03:22 --> URI Class Initialized
INFO - 2018-10-27 06:03:22 --> Router Class Initialized
INFO - 2018-10-27 06:03:22 --> Output Class Initialized
INFO - 2018-10-27 06:03:22 --> Security Class Initialized
DEBUG - 2018-10-27 06:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:03:22 --> Input Class Initialized
INFO - 2018-10-27 06:03:22 --> Language Class Initialized
INFO - 2018-10-27 06:03:22 --> Loader Class Initialized
INFO - 2018-10-27 06:03:22 --> Helper loaded: url_helper
INFO - 2018-10-27 06:03:22 --> Helper loaded: form_helper
INFO - 2018-10-27 06:03:22 --> Helper loaded: html_helper
INFO - 2018-10-27 06:03:22 --> Database Driver Class Initialized
INFO - 2018-10-27 06:03:22 --> Form Validation Class Initialized
DEBUG - 2018-10-27 06:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:03:22 --> Model "User_model" initialized
INFO - 2018-10-27 06:03:22 --> Controller Class Initialized
INFO - 2018-10-27 06:03:22 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-10-27 06:03:22 --> Unable to find validation rule: isEmailExist
ERROR - 2018-10-27 06:03:22 --> Could not find the language line "form_validation_isEmailExist"
INFO - 2018-10-27 06:03:22 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 06:03:22 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 06:03:22 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 06:03:22 --> Final output sent to browser
DEBUG - 2018-10-27 06:03:22 --> Total execution time: 0.0540
INFO - 2018-10-27 06:03:29 --> Config Class Initialized
INFO - 2018-10-27 06:03:29 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:03:29 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:03:29 --> Utf8 Class Initialized
INFO - 2018-10-27 06:03:29 --> URI Class Initialized
INFO - 2018-10-27 06:03:29 --> Router Class Initialized
INFO - 2018-10-27 06:03:29 --> Output Class Initialized
INFO - 2018-10-27 06:03:29 --> Security Class Initialized
DEBUG - 2018-10-27 06:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:03:29 --> Input Class Initialized
INFO - 2018-10-27 06:03:29 --> Language Class Initialized
INFO - 2018-10-27 06:03:29 --> Loader Class Initialized
INFO - 2018-10-27 06:03:29 --> Helper loaded: url_helper
INFO - 2018-10-27 06:03:29 --> Helper loaded: form_helper
INFO - 2018-10-27 06:03:29 --> Helper loaded: html_helper
INFO - 2018-10-27 06:03:29 --> Database Driver Class Initialized
INFO - 2018-10-27 06:03:29 --> Form Validation Class Initialized
DEBUG - 2018-10-27 06:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:03:29 --> Model "User_model" initialized
INFO - 2018-10-27 06:03:29 --> Controller Class Initialized
INFO - 2018-10-27 06:03:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-10-27 06:03:29 --> Unable to find validation rule: isEmailExist
ERROR - 2018-10-27 06:03:29 --> Could not find the language line "form_validation_isEmailExist"
INFO - 2018-10-27 06:03:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 06:03:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 06:03:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 06:03:29 --> Final output sent to browser
DEBUG - 2018-10-27 06:03:29 --> Total execution time: 0.0450
INFO - 2018-10-27 06:03:37 --> Config Class Initialized
INFO - 2018-10-27 06:03:37 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:03:37 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:03:37 --> Utf8 Class Initialized
INFO - 2018-10-27 06:03:37 --> URI Class Initialized
INFO - 2018-10-27 06:03:37 --> Router Class Initialized
INFO - 2018-10-27 06:03:37 --> Output Class Initialized
INFO - 2018-10-27 06:03:37 --> Security Class Initialized
DEBUG - 2018-10-27 06:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:03:37 --> Input Class Initialized
INFO - 2018-10-27 06:03:37 --> Language Class Initialized
INFO - 2018-10-27 06:03:37 --> Loader Class Initialized
INFO - 2018-10-27 06:03:37 --> Helper loaded: url_helper
INFO - 2018-10-27 06:03:37 --> Helper loaded: form_helper
INFO - 2018-10-27 06:03:37 --> Helper loaded: html_helper
INFO - 2018-10-27 06:03:37 --> Database Driver Class Initialized
INFO - 2018-10-27 06:03:37 --> Form Validation Class Initialized
DEBUG - 2018-10-27 06:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:03:37 --> Model "User_model" initialized
INFO - 2018-10-27 06:03:37 --> Controller Class Initialized
INFO - 2018-10-27 06:03:37 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-10-27 06:03:37 --> Unable to find validation rule: isEmailExist
ERROR - 2018-10-27 06:03:37 --> Could not find the language line "form_validation_isEmailExist"
INFO - 2018-10-27 06:03:37 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 06:03:37 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 06:03:37 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 06:03:37 --> Final output sent to browser
DEBUG - 2018-10-27 06:03:37 --> Total execution time: 0.0480
INFO - 2018-10-27 06:06:26 --> Config Class Initialized
INFO - 2018-10-27 06:06:26 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:06:26 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:06:26 --> Utf8 Class Initialized
INFO - 2018-10-27 06:06:26 --> URI Class Initialized
INFO - 2018-10-27 06:06:26 --> Router Class Initialized
INFO - 2018-10-27 06:06:26 --> Output Class Initialized
INFO - 2018-10-27 06:06:26 --> Security Class Initialized
DEBUG - 2018-10-27 06:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:06:26 --> Input Class Initialized
INFO - 2018-10-27 06:06:26 --> Language Class Initialized
INFO - 2018-10-27 06:06:26 --> Loader Class Initialized
INFO - 2018-10-27 06:06:26 --> Helper loaded: url_helper
INFO - 2018-10-27 06:06:26 --> Helper loaded: form_helper
INFO - 2018-10-27 06:06:26 --> Helper loaded: html_helper
INFO - 2018-10-27 06:06:26 --> Database Driver Class Initialized
INFO - 2018-10-27 06:06:26 --> Form Validation Class Initialized
DEBUG - 2018-10-27 06:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:06:26 --> Model "User_model" initialized
INFO - 2018-10-27 06:06:26 --> Controller Class Initialized
INFO - 2018-10-27 06:06:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-10-27 06:06:26 --> Unable to find validation rule: isEmailExist
ERROR - 2018-10-27 06:06:26 --> Could not find the language line "form_validation_isEmailExist"
INFO - 2018-10-27 06:06:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 06:06:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 06:06:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 06:06:26 --> Final output sent to browser
DEBUG - 2018-10-27 06:06:26 --> Total execution time: 0.0510
INFO - 2018-10-27 06:06:28 --> Config Class Initialized
INFO - 2018-10-27 06:06:28 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:06:28 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:06:28 --> Utf8 Class Initialized
INFO - 2018-10-27 06:06:28 --> URI Class Initialized
INFO - 2018-10-27 06:06:28 --> Router Class Initialized
INFO - 2018-10-27 06:06:28 --> Output Class Initialized
INFO - 2018-10-27 06:06:28 --> Security Class Initialized
DEBUG - 2018-10-27 06:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:06:28 --> Input Class Initialized
INFO - 2018-10-27 06:06:28 --> Language Class Initialized
INFO - 2018-10-27 06:06:28 --> Loader Class Initialized
INFO - 2018-10-27 06:06:28 --> Helper loaded: url_helper
INFO - 2018-10-27 06:06:28 --> Helper loaded: form_helper
INFO - 2018-10-27 06:06:28 --> Helper loaded: html_helper
INFO - 2018-10-27 06:06:28 --> Database Driver Class Initialized
INFO - 2018-10-27 06:06:28 --> Form Validation Class Initialized
DEBUG - 2018-10-27 06:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:06:28 --> Model "User_model" initialized
INFO - 2018-10-27 06:06:28 --> Controller Class Initialized
INFO - 2018-10-27 06:06:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-10-27 06:06:28 --> Unable to find validation rule: isEmailExist
ERROR - 2018-10-27 06:06:28 --> Could not find the language line "form_validation_isEmailExist"
INFO - 2018-10-27 06:06:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 06:06:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 06:06:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 06:06:28 --> Final output sent to browser
DEBUG - 2018-10-27 06:06:28 --> Total execution time: 0.0550
INFO - 2018-10-27 06:06:28 --> Config Class Initialized
INFO - 2018-10-27 06:06:28 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:06:28 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:06:28 --> Utf8 Class Initialized
INFO - 2018-10-27 06:06:28 --> URI Class Initialized
INFO - 2018-10-27 06:06:28 --> Router Class Initialized
INFO - 2018-10-27 06:06:28 --> Output Class Initialized
INFO - 2018-10-27 06:06:28 --> Security Class Initialized
DEBUG - 2018-10-27 06:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:06:28 --> Input Class Initialized
INFO - 2018-10-27 06:06:28 --> Language Class Initialized
INFO - 2018-10-27 06:06:28 --> Loader Class Initialized
INFO - 2018-10-27 06:06:28 --> Helper loaded: url_helper
INFO - 2018-10-27 06:06:28 --> Helper loaded: form_helper
INFO - 2018-10-27 06:06:28 --> Helper loaded: html_helper
INFO - 2018-10-27 06:06:28 --> Database Driver Class Initialized
INFO - 2018-10-27 06:06:29 --> Form Validation Class Initialized
DEBUG - 2018-10-27 06:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:06:29 --> Model "User_model" initialized
INFO - 2018-10-27 06:06:29 --> Controller Class Initialized
INFO - 2018-10-27 06:06:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-10-27 06:06:29 --> Unable to find validation rule: isEmailExist
ERROR - 2018-10-27 06:06:29 --> Could not find the language line "form_validation_isEmailExist"
INFO - 2018-10-27 06:06:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 06:06:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 06:06:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 06:06:29 --> Final output sent to browser
DEBUG - 2018-10-27 06:06:29 --> Total execution time: 0.0510
INFO - 2018-10-27 06:06:29 --> Config Class Initialized
INFO - 2018-10-27 06:06:29 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:06:29 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:06:29 --> Utf8 Class Initialized
INFO - 2018-10-27 06:06:29 --> URI Class Initialized
INFO - 2018-10-27 06:06:29 --> Router Class Initialized
INFO - 2018-10-27 06:06:29 --> Output Class Initialized
INFO - 2018-10-27 06:06:29 --> Security Class Initialized
DEBUG - 2018-10-27 06:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:06:29 --> Input Class Initialized
INFO - 2018-10-27 06:06:29 --> Language Class Initialized
INFO - 2018-10-27 06:06:29 --> Loader Class Initialized
INFO - 2018-10-27 06:06:29 --> Helper loaded: url_helper
INFO - 2018-10-27 06:06:29 --> Helper loaded: form_helper
INFO - 2018-10-27 06:06:29 --> Helper loaded: html_helper
INFO - 2018-10-27 06:06:29 --> Database Driver Class Initialized
INFO - 2018-10-27 06:06:29 --> Form Validation Class Initialized
DEBUG - 2018-10-27 06:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:06:29 --> Model "User_model" initialized
INFO - 2018-10-27 06:06:29 --> Controller Class Initialized
INFO - 2018-10-27 06:06:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-10-27 06:06:29 --> Unable to find validation rule: isEmailExist
ERROR - 2018-10-27 06:06:29 --> Could not find the language line "form_validation_isEmailExist"
INFO - 2018-10-27 06:06:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 06:06:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 06:06:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 06:06:29 --> Final output sent to browser
DEBUG - 2018-10-27 06:06:29 --> Total execution time: 0.0570
INFO - 2018-10-27 06:06:29 --> Config Class Initialized
INFO - 2018-10-27 06:06:29 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:06:29 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:06:29 --> Utf8 Class Initialized
INFO - 2018-10-27 06:06:29 --> URI Class Initialized
INFO - 2018-10-27 06:06:29 --> Router Class Initialized
INFO - 2018-10-27 06:06:29 --> Output Class Initialized
INFO - 2018-10-27 06:06:29 --> Security Class Initialized
DEBUG - 2018-10-27 06:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:06:29 --> Input Class Initialized
INFO - 2018-10-27 06:06:29 --> Language Class Initialized
INFO - 2018-10-27 06:06:29 --> Loader Class Initialized
INFO - 2018-10-27 06:06:29 --> Helper loaded: url_helper
INFO - 2018-10-27 06:06:29 --> Helper loaded: form_helper
INFO - 2018-10-27 06:06:29 --> Helper loaded: html_helper
INFO - 2018-10-27 06:06:29 --> Database Driver Class Initialized
INFO - 2018-10-27 06:06:29 --> Form Validation Class Initialized
DEBUG - 2018-10-27 06:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:06:29 --> Model "User_model" initialized
INFO - 2018-10-27 06:06:29 --> Controller Class Initialized
INFO - 2018-10-27 06:06:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-10-27 06:06:29 --> Unable to find validation rule: isEmailExist
ERROR - 2018-10-27 06:06:29 --> Could not find the language line "form_validation_isEmailExist"
INFO - 2018-10-27 06:06:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 06:06:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 06:06:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 06:06:29 --> Final output sent to browser
DEBUG - 2018-10-27 06:06:29 --> Total execution time: 0.0560
INFO - 2018-10-27 06:06:29 --> Config Class Initialized
INFO - 2018-10-27 06:06:29 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:06:29 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:06:29 --> Utf8 Class Initialized
INFO - 2018-10-27 06:06:29 --> URI Class Initialized
INFO - 2018-10-27 06:06:29 --> Router Class Initialized
INFO - 2018-10-27 06:06:29 --> Output Class Initialized
INFO - 2018-10-27 06:06:29 --> Security Class Initialized
DEBUG - 2018-10-27 06:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:06:29 --> Input Class Initialized
INFO - 2018-10-27 06:06:29 --> Language Class Initialized
INFO - 2018-10-27 06:06:29 --> Loader Class Initialized
INFO - 2018-10-27 06:06:29 --> Helper loaded: url_helper
INFO - 2018-10-27 06:06:29 --> Helper loaded: form_helper
INFO - 2018-10-27 06:06:29 --> Helper loaded: html_helper
INFO - 2018-10-27 06:06:29 --> Database Driver Class Initialized
INFO - 2018-10-27 06:06:29 --> Form Validation Class Initialized
DEBUG - 2018-10-27 06:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:06:29 --> Model "User_model" initialized
INFO - 2018-10-27 06:06:29 --> Controller Class Initialized
INFO - 2018-10-27 06:06:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-10-27 06:06:29 --> Unable to find validation rule: isEmailExist
ERROR - 2018-10-27 06:06:29 --> Could not find the language line "form_validation_isEmailExist"
INFO - 2018-10-27 06:06:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 06:06:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 06:06:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 06:06:29 --> Final output sent to browser
DEBUG - 2018-10-27 06:06:29 --> Total execution time: 0.0560
INFO - 2018-10-27 06:07:28 --> Config Class Initialized
INFO - 2018-10-27 06:07:28 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:07:28 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:07:28 --> Utf8 Class Initialized
INFO - 2018-10-27 06:07:28 --> URI Class Initialized
INFO - 2018-10-27 06:07:28 --> Router Class Initialized
INFO - 2018-10-27 06:07:28 --> Output Class Initialized
INFO - 2018-10-27 06:07:28 --> Security Class Initialized
DEBUG - 2018-10-27 06:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:07:28 --> Input Class Initialized
INFO - 2018-10-27 06:07:28 --> Language Class Initialized
INFO - 2018-10-27 06:07:28 --> Loader Class Initialized
INFO - 2018-10-27 06:07:28 --> Helper loaded: url_helper
INFO - 2018-10-27 06:07:28 --> Helper loaded: form_helper
INFO - 2018-10-27 06:07:28 --> Helper loaded: html_helper
INFO - 2018-10-27 06:07:28 --> Database Driver Class Initialized
INFO - 2018-10-27 06:07:28 --> Form Validation Class Initialized
DEBUG - 2018-10-27 06:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:07:28 --> Model "User_model" initialized
INFO - 2018-10-27 06:07:28 --> Controller Class Initialized
INFO - 2018-10-27 06:07:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-27 06:07:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 06:07:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 06:07:28 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 06:07:28 --> Final output sent to browser
DEBUG - 2018-10-27 06:07:28 --> Total execution time: 0.0590
INFO - 2018-10-27 06:07:58 --> Config Class Initialized
INFO - 2018-10-27 06:07:58 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:07:58 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:07:58 --> Utf8 Class Initialized
INFO - 2018-10-27 06:07:58 --> URI Class Initialized
INFO - 2018-10-27 06:07:58 --> Router Class Initialized
INFO - 2018-10-27 06:07:58 --> Output Class Initialized
INFO - 2018-10-27 06:07:58 --> Security Class Initialized
DEBUG - 2018-10-27 06:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:07:58 --> Input Class Initialized
INFO - 2018-10-27 06:07:58 --> Language Class Initialized
INFO - 2018-10-27 06:07:58 --> Loader Class Initialized
INFO - 2018-10-27 06:07:58 --> Helper loaded: url_helper
INFO - 2018-10-27 06:07:58 --> Helper loaded: form_helper
INFO - 2018-10-27 06:07:58 --> Helper loaded: html_helper
INFO - 2018-10-27 06:07:58 --> Database Driver Class Initialized
INFO - 2018-10-27 06:07:58 --> Form Validation Class Initialized
DEBUG - 2018-10-27 06:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:07:58 --> Model "User_model" initialized
INFO - 2018-10-27 06:07:58 --> Controller Class Initialized
INFO - 2018-10-27 06:07:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-27 06:07:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 06:07:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 06:07:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 06:07:58 --> Final output sent to browser
DEBUG - 2018-10-27 06:07:58 --> Total execution time: 0.0530
INFO - 2018-10-27 06:08:06 --> Config Class Initialized
INFO - 2018-10-27 06:08:06 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:08:06 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:08:06 --> Utf8 Class Initialized
INFO - 2018-10-27 06:08:06 --> URI Class Initialized
INFO - 2018-10-27 06:08:06 --> Router Class Initialized
INFO - 2018-10-27 06:08:06 --> Output Class Initialized
INFO - 2018-10-27 06:08:06 --> Security Class Initialized
DEBUG - 2018-10-27 06:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:08:06 --> Input Class Initialized
INFO - 2018-10-27 06:08:06 --> Language Class Initialized
INFO - 2018-10-27 06:08:06 --> Loader Class Initialized
INFO - 2018-10-27 06:08:06 --> Helper loaded: url_helper
INFO - 2018-10-27 06:08:06 --> Helper loaded: form_helper
INFO - 2018-10-27 06:08:06 --> Helper loaded: html_helper
INFO - 2018-10-27 06:08:06 --> Database Driver Class Initialized
INFO - 2018-10-27 06:08:06 --> Form Validation Class Initialized
DEBUG - 2018-10-27 06:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:08:06 --> Model "User_model" initialized
INFO - 2018-10-27 06:08:06 --> Controller Class Initialized
INFO - 2018-10-27 06:08:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-27 06:08:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 06:08:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 06:08:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 06:08:06 --> Final output sent to browser
DEBUG - 2018-10-27 06:08:06 --> Total execution time: 0.0480
INFO - 2018-10-27 06:08:12 --> Config Class Initialized
INFO - 2018-10-27 06:08:12 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:08:12 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:08:12 --> Utf8 Class Initialized
INFO - 2018-10-27 06:08:12 --> URI Class Initialized
INFO - 2018-10-27 06:08:12 --> Router Class Initialized
INFO - 2018-10-27 06:08:12 --> Output Class Initialized
INFO - 2018-10-27 06:08:12 --> Security Class Initialized
DEBUG - 2018-10-27 06:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:08:12 --> Input Class Initialized
INFO - 2018-10-27 06:08:12 --> Language Class Initialized
INFO - 2018-10-27 06:08:12 --> Loader Class Initialized
INFO - 2018-10-27 06:08:12 --> Helper loaded: url_helper
INFO - 2018-10-27 06:08:12 --> Helper loaded: form_helper
INFO - 2018-10-27 06:08:12 --> Helper loaded: html_helper
INFO - 2018-10-27 06:08:12 --> Database Driver Class Initialized
INFO - 2018-10-27 06:08:12 --> Form Validation Class Initialized
DEBUG - 2018-10-27 06:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:08:12 --> Model "User_model" initialized
INFO - 2018-10-27 06:08:12 --> Controller Class Initialized
INFO - 2018-10-27 06:08:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-27 06:08:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 06:08:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 06:08:12 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 06:08:12 --> Final output sent to browser
DEBUG - 2018-10-27 06:08:12 --> Total execution time: 0.0510
INFO - 2018-10-27 06:45:22 --> Config Class Initialized
INFO - 2018-10-27 06:45:22 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:45:22 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:45:22 --> Utf8 Class Initialized
INFO - 2018-10-27 06:45:22 --> URI Class Initialized
INFO - 2018-10-27 06:45:22 --> Router Class Initialized
INFO - 2018-10-27 06:45:22 --> Output Class Initialized
INFO - 2018-10-27 06:45:22 --> Security Class Initialized
DEBUG - 2018-10-27 06:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:45:22 --> Input Class Initialized
INFO - 2018-10-27 06:45:22 --> Language Class Initialized
INFO - 2018-10-27 06:45:22 --> Loader Class Initialized
INFO - 2018-10-27 06:45:22 --> Helper loaded: url_helper
INFO - 2018-10-27 06:45:22 --> Helper loaded: form_helper
INFO - 2018-10-27 06:45:22 --> Helper loaded: html_helper
INFO - 2018-10-27 06:45:22 --> Database Driver Class Initialized
INFO - 2018-10-27 06:45:22 --> Form Validation Class Initialized
DEBUG - 2018-10-27 06:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:45:22 --> Model "User_model" initialized
INFO - 2018-10-27 06:45:22 --> Controller Class Initialized
INFO - 2018-10-27 06:45:22 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 06:45:22 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 06:45:22 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 06:45:22 --> Final output sent to browser
DEBUG - 2018-10-27 06:45:22 --> Total execution time: 0.1700
INFO - 2018-10-27 06:46:14 --> Config Class Initialized
INFO - 2018-10-27 06:46:14 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:46:14 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:46:14 --> Utf8 Class Initialized
INFO - 2018-10-27 06:46:14 --> URI Class Initialized
INFO - 2018-10-27 06:46:15 --> Router Class Initialized
INFO - 2018-10-27 06:46:15 --> Output Class Initialized
INFO - 2018-10-27 06:46:15 --> Security Class Initialized
DEBUG - 2018-10-27 06:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:46:15 --> Input Class Initialized
INFO - 2018-10-27 06:46:15 --> Language Class Initialized
INFO - 2018-10-27 06:46:15 --> Loader Class Initialized
INFO - 2018-10-27 06:46:15 --> Helper loaded: url_helper
INFO - 2018-10-27 06:46:15 --> Helper loaded: form_helper
INFO - 2018-10-27 06:46:15 --> Helper loaded: html_helper
INFO - 2018-10-27 06:46:15 --> Database Driver Class Initialized
INFO - 2018-10-27 06:46:15 --> Form Validation Class Initialized
DEBUG - 2018-10-27 06:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:46:15 --> Model "User_model" initialized
INFO - 2018-10-27 06:46:15 --> Controller Class Initialized
INFO - 2018-10-27 06:46:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 06:46:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 06:46:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 06:46:15 --> Final output sent to browser
DEBUG - 2018-10-27 06:46:15 --> Total execution time: 0.0540
INFO - 2018-10-27 06:46:33 --> Config Class Initialized
INFO - 2018-10-27 06:46:33 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:46:33 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:46:33 --> Utf8 Class Initialized
INFO - 2018-10-27 06:46:33 --> URI Class Initialized
INFO - 2018-10-27 06:46:33 --> Router Class Initialized
INFO - 2018-10-27 06:46:33 --> Output Class Initialized
INFO - 2018-10-27 06:46:33 --> Security Class Initialized
DEBUG - 2018-10-27 06:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:46:33 --> Input Class Initialized
INFO - 2018-10-27 06:46:33 --> Language Class Initialized
INFO - 2018-10-27 06:46:33 --> Loader Class Initialized
INFO - 2018-10-27 06:46:33 --> Helper loaded: url_helper
INFO - 2018-10-27 06:46:33 --> Helper loaded: form_helper
INFO - 2018-10-27 06:46:33 --> Helper loaded: html_helper
INFO - 2018-10-27 06:46:33 --> Database Driver Class Initialized
INFO - 2018-10-27 06:46:33 --> Form Validation Class Initialized
DEBUG - 2018-10-27 06:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:46:33 --> Model "User_model" initialized
INFO - 2018-10-27 06:46:33 --> Controller Class Initialized
INFO - 2018-10-27 06:46:33 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-27 06:46:33 --> Severity: Notice --> Trying to get property 'password' of non-object D:\xampp\htdocs\code_igniter\application\models\project_models\user_model.php 53
INFO - 2018-10-27 06:46:33 --> Config Class Initialized
INFO - 2018-10-27 06:46:33 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:46:33 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:46:33 --> Utf8 Class Initialized
INFO - 2018-10-27 06:46:33 --> URI Class Initialized
INFO - 2018-10-27 06:46:33 --> Router Class Initialized
INFO - 2018-10-27 06:46:33 --> Output Class Initialized
INFO - 2018-10-27 06:46:33 --> Security Class Initialized
DEBUG - 2018-10-27 06:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:46:33 --> Input Class Initialized
INFO - 2018-10-27 06:46:33 --> Language Class Initialized
INFO - 2018-10-27 06:46:33 --> Loader Class Initialized
INFO - 2018-10-27 06:46:33 --> Helper loaded: url_helper
INFO - 2018-10-27 06:46:33 --> Helper loaded: form_helper
INFO - 2018-10-27 06:46:33 --> Helper loaded: html_helper
INFO - 2018-10-27 06:46:33 --> Database Driver Class Initialized
INFO - 2018-10-27 06:46:33 --> Form Validation Class Initialized
DEBUG - 2018-10-27 06:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:46:33 --> Model "User_model" initialized
INFO - 2018-10-27 06:46:33 --> Controller Class Initialized
INFO - 2018-10-27 06:46:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 06:46:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-27 06:46:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 06:46:33 --> Final output sent to browser
DEBUG - 2018-10-27 06:46:33 --> Total execution time: 0.0440
INFO - 2018-10-27 06:53:52 --> Config Class Initialized
INFO - 2018-10-27 06:53:52 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:53:52 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:53:52 --> Utf8 Class Initialized
INFO - 2018-10-27 06:53:52 --> URI Class Initialized
INFO - 2018-10-27 06:53:52 --> Router Class Initialized
INFO - 2018-10-27 06:53:52 --> Output Class Initialized
INFO - 2018-10-27 06:53:52 --> Security Class Initialized
DEBUG - 2018-10-27 06:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:53:52 --> Input Class Initialized
INFO - 2018-10-27 06:53:52 --> Language Class Initialized
INFO - 2018-10-27 06:53:52 --> Loader Class Initialized
INFO - 2018-10-27 06:53:52 --> Helper loaded: url_helper
INFO - 2018-10-27 06:53:52 --> Helper loaded: form_helper
INFO - 2018-10-27 06:53:52 --> Helper loaded: html_helper
INFO - 2018-10-27 06:53:52 --> Database Driver Class Initialized
INFO - 2018-10-27 06:53:52 --> Form Validation Class Initialized
DEBUG - 2018-10-27 06:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:53:52 --> Model "User_model" initialized
INFO - 2018-10-27 06:53:52 --> Controller Class Initialized
INFO - 2018-10-27 06:53:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 06:53:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-27 06:53:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 06:53:52 --> Final output sent to browser
DEBUG - 2018-10-27 06:53:52 --> Total execution time: 0.0490
INFO - 2018-10-27 06:57:01 --> Config Class Initialized
INFO - 2018-10-27 06:57:01 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:57:01 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:57:01 --> Utf8 Class Initialized
INFO - 2018-10-27 06:57:01 --> URI Class Initialized
INFO - 2018-10-27 06:57:01 --> Router Class Initialized
INFO - 2018-10-27 06:57:01 --> Output Class Initialized
INFO - 2018-10-27 06:57:01 --> Security Class Initialized
DEBUG - 2018-10-27 06:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:57:01 --> Input Class Initialized
INFO - 2018-10-27 06:57:01 --> Language Class Initialized
INFO - 2018-10-27 06:57:01 --> Loader Class Initialized
INFO - 2018-10-27 06:57:01 --> Helper loaded: url_helper
INFO - 2018-10-27 06:57:01 --> Helper loaded: form_helper
INFO - 2018-10-27 06:57:01 --> Helper loaded: html_helper
INFO - 2018-10-27 06:57:01 --> Database Driver Class Initialized
INFO - 2018-10-27 06:57:01 --> Form Validation Class Initialized
DEBUG - 2018-10-27 06:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:57:01 --> Model "User_model" initialized
INFO - 2018-10-27 06:57:01 --> Controller Class Initialized
INFO - 2018-10-27 06:57:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 06:57:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-27 06:57:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 06:57:01 --> Final output sent to browser
DEBUG - 2018-10-27 06:57:01 --> Total execution time: 0.0590
INFO - 2018-10-27 06:57:19 --> Config Class Initialized
INFO - 2018-10-27 06:57:19 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:57:19 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:57:19 --> Utf8 Class Initialized
INFO - 2018-10-27 06:57:19 --> URI Class Initialized
INFO - 2018-10-27 06:57:19 --> Router Class Initialized
INFO - 2018-10-27 06:57:19 --> Output Class Initialized
INFO - 2018-10-27 06:57:19 --> Security Class Initialized
DEBUG - 2018-10-27 06:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:57:19 --> Input Class Initialized
INFO - 2018-10-27 06:57:19 --> Language Class Initialized
INFO - 2018-10-27 06:57:19 --> Loader Class Initialized
INFO - 2018-10-27 06:57:19 --> Helper loaded: url_helper
INFO - 2018-10-27 06:57:19 --> Helper loaded: form_helper
INFO - 2018-10-27 06:57:19 --> Helper loaded: html_helper
INFO - 2018-10-27 06:57:19 --> Database Driver Class Initialized
INFO - 2018-10-27 06:57:19 --> Form Validation Class Initialized
DEBUG - 2018-10-27 06:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:57:19 --> Model "User_model" initialized
INFO - 2018-10-27 06:57:19 --> Controller Class Initialized
INFO - 2018-10-27 06:57:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 06:57:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-27 06:57:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 06:57:19 --> Final output sent to browser
DEBUG - 2018-10-27 06:57:19 --> Total execution time: 0.0600
INFO - 2018-10-27 06:57:23 --> Config Class Initialized
INFO - 2018-10-27 06:57:23 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:57:23 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:57:23 --> Utf8 Class Initialized
INFO - 2018-10-27 06:57:23 --> URI Class Initialized
INFO - 2018-10-27 06:57:23 --> Router Class Initialized
INFO - 2018-10-27 06:57:23 --> Output Class Initialized
INFO - 2018-10-27 06:57:23 --> Security Class Initialized
DEBUG - 2018-10-27 06:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:57:23 --> Input Class Initialized
INFO - 2018-10-27 06:57:23 --> Language Class Initialized
ERROR - 2018-10-27 06:57:23 --> 404 Page Not Found: project_controllers/%3C/index
INFO - 2018-10-27 06:57:25 --> Config Class Initialized
INFO - 2018-10-27 06:57:25 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:57:25 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:57:25 --> Utf8 Class Initialized
INFO - 2018-10-27 06:57:25 --> URI Class Initialized
INFO - 2018-10-27 06:57:25 --> Router Class Initialized
INFO - 2018-10-27 06:57:25 --> Output Class Initialized
INFO - 2018-10-27 06:57:25 --> Security Class Initialized
DEBUG - 2018-10-27 06:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:57:25 --> Input Class Initialized
INFO - 2018-10-27 06:57:25 --> Language Class Initialized
INFO - 2018-10-27 06:57:25 --> Loader Class Initialized
INFO - 2018-10-27 06:57:25 --> Helper loaded: url_helper
INFO - 2018-10-27 06:57:25 --> Helper loaded: form_helper
INFO - 2018-10-27 06:57:25 --> Helper loaded: html_helper
INFO - 2018-10-27 06:57:25 --> Database Driver Class Initialized
INFO - 2018-10-27 06:57:25 --> Form Validation Class Initialized
DEBUG - 2018-10-27 06:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:57:25 --> Model "User_model" initialized
INFO - 2018-10-27 06:57:25 --> Controller Class Initialized
INFO - 2018-10-27 06:57:25 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 06:57:25 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-27 06:57:25 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 06:57:25 --> Final output sent to browser
DEBUG - 2018-10-27 06:57:25 --> Total execution time: 0.0410
INFO - 2018-10-27 06:57:46 --> Config Class Initialized
INFO - 2018-10-27 06:57:46 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:57:46 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:57:46 --> Utf8 Class Initialized
INFO - 2018-10-27 06:57:46 --> URI Class Initialized
INFO - 2018-10-27 06:57:46 --> Router Class Initialized
INFO - 2018-10-27 06:57:46 --> Output Class Initialized
INFO - 2018-10-27 06:57:46 --> Security Class Initialized
DEBUG - 2018-10-27 06:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:57:46 --> Input Class Initialized
INFO - 2018-10-27 06:57:46 --> Language Class Initialized
INFO - 2018-10-27 06:57:46 --> Loader Class Initialized
INFO - 2018-10-27 06:57:46 --> Helper loaded: url_helper
INFO - 2018-10-27 06:57:46 --> Helper loaded: form_helper
INFO - 2018-10-27 06:57:46 --> Helper loaded: html_helper
INFO - 2018-10-27 06:57:46 --> Database Driver Class Initialized
INFO - 2018-10-27 06:57:46 --> Form Validation Class Initialized
DEBUG - 2018-10-27 06:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:57:46 --> Model "User_model" initialized
INFO - 2018-10-27 06:57:46 --> Controller Class Initialized
INFO - 2018-10-27 06:57:46 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 06:57:46 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 06:57:46 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 06:57:46 --> Final output sent to browser
DEBUG - 2018-10-27 06:57:46 --> Total execution time: 0.0640
INFO - 2018-10-27 06:57:47 --> Config Class Initialized
INFO - 2018-10-27 06:57:47 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:57:47 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:57:47 --> Utf8 Class Initialized
INFO - 2018-10-27 06:57:47 --> URI Class Initialized
INFO - 2018-10-27 06:57:47 --> Router Class Initialized
INFO - 2018-10-27 06:57:47 --> Output Class Initialized
INFO - 2018-10-27 06:57:47 --> Security Class Initialized
DEBUG - 2018-10-27 06:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:57:47 --> Input Class Initialized
INFO - 2018-10-27 06:57:47 --> Language Class Initialized
INFO - 2018-10-27 06:57:47 --> Loader Class Initialized
INFO - 2018-10-27 06:57:47 --> Helper loaded: url_helper
INFO - 2018-10-27 06:57:47 --> Helper loaded: form_helper
INFO - 2018-10-27 06:57:47 --> Helper loaded: html_helper
INFO - 2018-10-27 06:57:47 --> Database Driver Class Initialized
INFO - 2018-10-27 06:57:47 --> Form Validation Class Initialized
DEBUG - 2018-10-27 06:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:57:47 --> Model "User_model" initialized
INFO - 2018-10-27 06:57:47 --> Controller Class Initialized
INFO - 2018-10-27 06:57:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 06:57:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-27 06:57:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 06:57:47 --> Final output sent to browser
DEBUG - 2018-10-27 06:57:47 --> Total execution time: 0.0550
INFO - 2018-10-27 06:58:06 --> Config Class Initialized
INFO - 2018-10-27 06:58:06 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:58:06 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:58:06 --> Utf8 Class Initialized
INFO - 2018-10-27 06:58:06 --> URI Class Initialized
INFO - 2018-10-27 06:58:06 --> Router Class Initialized
INFO - 2018-10-27 06:58:06 --> Output Class Initialized
INFO - 2018-10-27 06:58:06 --> Security Class Initialized
DEBUG - 2018-10-27 06:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:58:06 --> Input Class Initialized
INFO - 2018-10-27 06:58:06 --> Language Class Initialized
ERROR - 2018-10-27 06:58:06 --> 404 Page Not Found: project_controllers/%3C/index
INFO - 2018-10-27 06:58:07 --> Config Class Initialized
INFO - 2018-10-27 06:58:07 --> Hooks Class Initialized
DEBUG - 2018-10-27 06:58:07 --> UTF-8 Support Enabled
INFO - 2018-10-27 06:58:07 --> Utf8 Class Initialized
INFO - 2018-10-27 06:58:07 --> URI Class Initialized
INFO - 2018-10-27 06:58:07 --> Router Class Initialized
INFO - 2018-10-27 06:58:07 --> Output Class Initialized
INFO - 2018-10-27 06:58:07 --> Security Class Initialized
DEBUG - 2018-10-27 06:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 06:58:07 --> Input Class Initialized
INFO - 2018-10-27 06:58:07 --> Language Class Initialized
INFO - 2018-10-27 06:58:07 --> Loader Class Initialized
INFO - 2018-10-27 06:58:07 --> Helper loaded: url_helper
INFO - 2018-10-27 06:58:07 --> Helper loaded: form_helper
INFO - 2018-10-27 06:58:07 --> Helper loaded: html_helper
INFO - 2018-10-27 06:58:07 --> Database Driver Class Initialized
INFO - 2018-10-27 06:58:07 --> Form Validation Class Initialized
DEBUG - 2018-10-27 06:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 06:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 06:58:07 --> Model "User_model" initialized
INFO - 2018-10-27 06:58:07 --> Controller Class Initialized
INFO - 2018-10-27 06:58:07 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 06:58:07 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-27 06:58:07 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 06:58:07 --> Final output sent to browser
DEBUG - 2018-10-27 06:58:07 --> Total execution time: 0.0680
INFO - 2018-10-27 07:11:32 --> Config Class Initialized
INFO - 2018-10-27 07:11:32 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:11:32 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:11:32 --> Utf8 Class Initialized
INFO - 2018-10-27 07:11:32 --> URI Class Initialized
INFO - 2018-10-27 07:11:32 --> Router Class Initialized
INFO - 2018-10-27 07:11:32 --> Output Class Initialized
INFO - 2018-10-27 07:11:32 --> Security Class Initialized
DEBUG - 2018-10-27 07:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:11:32 --> Input Class Initialized
INFO - 2018-10-27 07:11:32 --> Language Class Initialized
INFO - 2018-10-27 07:11:32 --> Loader Class Initialized
INFO - 2018-10-27 07:11:32 --> Helper loaded: url_helper
INFO - 2018-10-27 07:11:32 --> Helper loaded: form_helper
INFO - 2018-10-27 07:11:32 --> Helper loaded: html_helper
INFO - 2018-10-27 07:11:32 --> Database Driver Class Initialized
INFO - 2018-10-27 07:11:32 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:11:32 --> Model "User_model" initialized
INFO - 2018-10-27 07:11:32 --> Controller Class Initialized
INFO - 2018-10-27 07:11:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:11:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-27 07:11:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:11:32 --> Final output sent to browser
DEBUG - 2018-10-27 07:11:32 --> Total execution time: 0.0530
INFO - 2018-10-27 07:11:34 --> Config Class Initialized
INFO - 2018-10-27 07:11:34 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:11:34 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:11:34 --> Utf8 Class Initialized
INFO - 2018-10-27 07:11:34 --> URI Class Initialized
INFO - 2018-10-27 07:11:34 --> Router Class Initialized
INFO - 2018-10-27 07:11:34 --> Output Class Initialized
INFO - 2018-10-27 07:11:34 --> Security Class Initialized
DEBUG - 2018-10-27 07:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:11:34 --> Input Class Initialized
INFO - 2018-10-27 07:11:34 --> Language Class Initialized
ERROR - 2018-10-27 07:11:34 --> 404 Page Not Found: Reset_password_email/index
INFO - 2018-10-27 07:11:35 --> Config Class Initialized
INFO - 2018-10-27 07:11:35 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:11:35 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:11:35 --> Utf8 Class Initialized
INFO - 2018-10-27 07:11:35 --> URI Class Initialized
INFO - 2018-10-27 07:11:35 --> Router Class Initialized
INFO - 2018-10-27 07:11:35 --> Output Class Initialized
INFO - 2018-10-27 07:11:35 --> Security Class Initialized
DEBUG - 2018-10-27 07:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:11:35 --> Input Class Initialized
INFO - 2018-10-27 07:11:35 --> Language Class Initialized
INFO - 2018-10-27 07:11:35 --> Loader Class Initialized
INFO - 2018-10-27 07:11:35 --> Helper loaded: url_helper
INFO - 2018-10-27 07:11:35 --> Helper loaded: form_helper
INFO - 2018-10-27 07:11:35 --> Helper loaded: html_helper
INFO - 2018-10-27 07:11:35 --> Database Driver Class Initialized
INFO - 2018-10-27 07:11:35 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:11:35 --> Model "User_model" initialized
INFO - 2018-10-27 07:11:35 --> Controller Class Initialized
INFO - 2018-10-27 07:11:35 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:11:35 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-27 07:11:35 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:11:35 --> Final output sent to browser
DEBUG - 2018-10-27 07:11:35 --> Total execution time: 0.0570
INFO - 2018-10-27 07:11:37 --> Config Class Initialized
INFO - 2018-10-27 07:11:37 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:11:37 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:11:37 --> Utf8 Class Initialized
INFO - 2018-10-27 07:11:37 --> URI Class Initialized
INFO - 2018-10-27 07:11:37 --> Router Class Initialized
INFO - 2018-10-27 07:11:37 --> Output Class Initialized
INFO - 2018-10-27 07:11:37 --> Security Class Initialized
DEBUG - 2018-10-27 07:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:11:37 --> Input Class Initialized
INFO - 2018-10-27 07:11:37 --> Language Class Initialized
ERROR - 2018-10-27 07:11:37 --> 404 Page Not Found: Reset_password_email/index
INFO - 2018-10-27 07:11:38 --> Config Class Initialized
INFO - 2018-10-27 07:11:38 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:11:38 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:11:38 --> Utf8 Class Initialized
INFO - 2018-10-27 07:11:38 --> URI Class Initialized
INFO - 2018-10-27 07:11:38 --> Router Class Initialized
INFO - 2018-10-27 07:11:38 --> Output Class Initialized
INFO - 2018-10-27 07:11:38 --> Security Class Initialized
DEBUG - 2018-10-27 07:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:11:38 --> Input Class Initialized
INFO - 2018-10-27 07:11:38 --> Language Class Initialized
INFO - 2018-10-27 07:11:38 --> Loader Class Initialized
INFO - 2018-10-27 07:11:38 --> Helper loaded: url_helper
INFO - 2018-10-27 07:11:38 --> Helper loaded: form_helper
INFO - 2018-10-27 07:11:38 --> Helper loaded: html_helper
INFO - 2018-10-27 07:11:38 --> Database Driver Class Initialized
INFO - 2018-10-27 07:11:38 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:11:38 --> Model "User_model" initialized
INFO - 2018-10-27 07:11:38 --> Controller Class Initialized
INFO - 2018-10-27 07:11:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:11:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-27 07:11:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:11:38 --> Final output sent to browser
DEBUG - 2018-10-27 07:11:38 --> Total execution time: 0.0610
INFO - 2018-10-27 07:11:40 --> Config Class Initialized
INFO - 2018-10-27 07:11:40 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:11:40 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:11:40 --> Utf8 Class Initialized
INFO - 2018-10-27 07:11:40 --> URI Class Initialized
INFO - 2018-10-27 07:11:40 --> Router Class Initialized
INFO - 2018-10-27 07:11:40 --> Output Class Initialized
INFO - 2018-10-27 07:11:40 --> Security Class Initialized
DEBUG - 2018-10-27 07:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:11:40 --> Input Class Initialized
INFO - 2018-10-27 07:11:40 --> Language Class Initialized
ERROR - 2018-10-27 07:11:40 --> 404 Page Not Found: Reset_password_email/index
INFO - 2018-10-27 07:11:41 --> Config Class Initialized
INFO - 2018-10-27 07:11:41 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:11:41 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:11:41 --> Utf8 Class Initialized
INFO - 2018-10-27 07:11:41 --> URI Class Initialized
INFO - 2018-10-27 07:11:41 --> Router Class Initialized
INFO - 2018-10-27 07:11:41 --> Output Class Initialized
INFO - 2018-10-27 07:11:41 --> Security Class Initialized
DEBUG - 2018-10-27 07:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:11:41 --> Input Class Initialized
INFO - 2018-10-27 07:11:41 --> Language Class Initialized
INFO - 2018-10-27 07:11:41 --> Loader Class Initialized
INFO - 2018-10-27 07:11:41 --> Helper loaded: url_helper
INFO - 2018-10-27 07:11:41 --> Helper loaded: form_helper
INFO - 2018-10-27 07:11:41 --> Helper loaded: html_helper
INFO - 2018-10-27 07:11:41 --> Database Driver Class Initialized
INFO - 2018-10-27 07:11:41 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:11:41 --> Model "User_model" initialized
INFO - 2018-10-27 07:11:41 --> Controller Class Initialized
INFO - 2018-10-27 07:11:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:11:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-27 07:11:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:11:41 --> Final output sent to browser
DEBUG - 2018-10-27 07:11:41 --> Total execution time: 0.0690
INFO - 2018-10-27 07:13:38 --> Config Class Initialized
INFO - 2018-10-27 07:13:38 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:13:38 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:13:38 --> Utf8 Class Initialized
INFO - 2018-10-27 07:13:38 --> URI Class Initialized
INFO - 2018-10-27 07:13:38 --> Router Class Initialized
INFO - 2018-10-27 07:13:38 --> Output Class Initialized
INFO - 2018-10-27 07:13:38 --> Security Class Initialized
DEBUG - 2018-10-27 07:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:13:38 --> Input Class Initialized
INFO - 2018-10-27 07:13:38 --> Language Class Initialized
INFO - 2018-10-27 07:13:38 --> Loader Class Initialized
INFO - 2018-10-27 07:13:38 --> Helper loaded: url_helper
INFO - 2018-10-27 07:13:38 --> Helper loaded: form_helper
INFO - 2018-10-27 07:13:38 --> Helper loaded: html_helper
INFO - 2018-10-27 07:13:38 --> Database Driver Class Initialized
INFO - 2018-10-27 07:13:38 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:13:38 --> Model "User_model" initialized
INFO - 2018-10-27 07:13:38 --> Controller Class Initialized
INFO - 2018-10-27 07:13:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:13:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-27 07:13:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:13:38 --> Final output sent to browser
DEBUG - 2018-10-27 07:13:38 --> Total execution time: 0.0590
INFO - 2018-10-27 07:13:39 --> Config Class Initialized
INFO - 2018-10-27 07:13:39 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:13:39 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:13:39 --> Utf8 Class Initialized
INFO - 2018-10-27 07:13:39 --> URI Class Initialized
INFO - 2018-10-27 07:13:39 --> Router Class Initialized
INFO - 2018-10-27 07:13:39 --> Output Class Initialized
INFO - 2018-10-27 07:13:39 --> Security Class Initialized
DEBUG - 2018-10-27 07:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:13:39 --> Input Class Initialized
INFO - 2018-10-27 07:13:39 --> Language Class Initialized
ERROR - 2018-10-27 07:13:39 --> 404 Page Not Found: Forgot_password/index
INFO - 2018-10-27 07:13:41 --> Config Class Initialized
INFO - 2018-10-27 07:13:41 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:13:41 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:13:41 --> Utf8 Class Initialized
INFO - 2018-10-27 07:13:41 --> URI Class Initialized
INFO - 2018-10-27 07:13:41 --> Router Class Initialized
INFO - 2018-10-27 07:13:41 --> Output Class Initialized
INFO - 2018-10-27 07:13:41 --> Security Class Initialized
DEBUG - 2018-10-27 07:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:13:41 --> Input Class Initialized
INFO - 2018-10-27 07:13:41 --> Language Class Initialized
INFO - 2018-10-27 07:13:41 --> Loader Class Initialized
INFO - 2018-10-27 07:13:41 --> Helper loaded: url_helper
INFO - 2018-10-27 07:13:41 --> Helper loaded: form_helper
INFO - 2018-10-27 07:13:41 --> Helper loaded: html_helper
INFO - 2018-10-27 07:13:41 --> Database Driver Class Initialized
INFO - 2018-10-27 07:13:41 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:13:41 --> Model "User_model" initialized
INFO - 2018-10-27 07:13:41 --> Controller Class Initialized
INFO - 2018-10-27 07:13:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:13:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-27 07:13:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:13:41 --> Final output sent to browser
DEBUG - 2018-10-27 07:13:41 --> Total execution time: 0.0640
INFO - 2018-10-27 07:13:43 --> Config Class Initialized
INFO - 2018-10-27 07:13:43 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:13:43 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:13:43 --> Utf8 Class Initialized
INFO - 2018-10-27 07:13:43 --> URI Class Initialized
INFO - 2018-10-27 07:13:43 --> Router Class Initialized
INFO - 2018-10-27 07:13:43 --> Output Class Initialized
INFO - 2018-10-27 07:13:43 --> Security Class Initialized
DEBUG - 2018-10-27 07:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:13:43 --> Input Class Initialized
INFO - 2018-10-27 07:13:43 --> Language Class Initialized
ERROR - 2018-10-27 07:13:43 --> 404 Page Not Found: Forgot_password/index
INFO - 2018-10-27 07:13:45 --> Config Class Initialized
INFO - 2018-10-27 07:13:45 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:13:45 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:13:45 --> Utf8 Class Initialized
INFO - 2018-10-27 07:13:45 --> URI Class Initialized
INFO - 2018-10-27 07:13:45 --> Router Class Initialized
INFO - 2018-10-27 07:13:45 --> Output Class Initialized
INFO - 2018-10-27 07:13:45 --> Security Class Initialized
DEBUG - 2018-10-27 07:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:13:45 --> Input Class Initialized
INFO - 2018-10-27 07:13:45 --> Language Class Initialized
INFO - 2018-10-27 07:13:45 --> Loader Class Initialized
INFO - 2018-10-27 07:13:45 --> Helper loaded: url_helper
INFO - 2018-10-27 07:13:45 --> Helper loaded: form_helper
INFO - 2018-10-27 07:13:45 --> Helper loaded: html_helper
INFO - 2018-10-27 07:13:45 --> Database Driver Class Initialized
INFO - 2018-10-27 07:13:45 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:13:45 --> Model "User_model" initialized
INFO - 2018-10-27 07:13:45 --> Controller Class Initialized
INFO - 2018-10-27 07:13:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:13:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-27 07:13:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:13:45 --> Final output sent to browser
DEBUG - 2018-10-27 07:13:45 --> Total execution time: 0.0590
INFO - 2018-10-27 07:24:33 --> Config Class Initialized
INFO - 2018-10-27 07:24:33 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:24:33 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:24:33 --> Utf8 Class Initialized
INFO - 2018-10-27 07:24:33 --> URI Class Initialized
INFO - 2018-10-27 07:24:33 --> Router Class Initialized
INFO - 2018-10-27 07:24:33 --> Output Class Initialized
INFO - 2018-10-27 07:24:33 --> Security Class Initialized
DEBUG - 2018-10-27 07:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:24:33 --> Input Class Initialized
INFO - 2018-10-27 07:24:33 --> Language Class Initialized
ERROR - 2018-10-27 07:24:33 --> 404 Page Not Found: Forgot_password/index
INFO - 2018-10-27 07:24:34 --> Config Class Initialized
INFO - 2018-10-27 07:24:34 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:24:34 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:24:34 --> Utf8 Class Initialized
INFO - 2018-10-27 07:24:34 --> URI Class Initialized
INFO - 2018-10-27 07:24:34 --> Router Class Initialized
INFO - 2018-10-27 07:24:34 --> Output Class Initialized
INFO - 2018-10-27 07:24:34 --> Security Class Initialized
DEBUG - 2018-10-27 07:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:24:34 --> Input Class Initialized
INFO - 2018-10-27 07:24:34 --> Language Class Initialized
INFO - 2018-10-27 07:24:34 --> Loader Class Initialized
INFO - 2018-10-27 07:24:34 --> Helper loaded: url_helper
INFO - 2018-10-27 07:24:34 --> Helper loaded: form_helper
INFO - 2018-10-27 07:24:34 --> Helper loaded: html_helper
INFO - 2018-10-27 07:24:34 --> Database Driver Class Initialized
INFO - 2018-10-27 07:24:34 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:24:34 --> Model "User_model" initialized
INFO - 2018-10-27 07:24:34 --> Controller Class Initialized
INFO - 2018-10-27 07:24:34 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:24:34 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-27 07:24:34 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:24:34 --> Final output sent to browser
DEBUG - 2018-10-27 07:24:34 --> Total execution time: 0.0560
INFO - 2018-10-27 07:24:37 --> Config Class Initialized
INFO - 2018-10-27 07:24:37 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:24:37 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:24:37 --> Utf8 Class Initialized
INFO - 2018-10-27 07:24:37 --> URI Class Initialized
INFO - 2018-10-27 07:24:37 --> Router Class Initialized
INFO - 2018-10-27 07:24:37 --> Output Class Initialized
INFO - 2018-10-27 07:24:37 --> Security Class Initialized
DEBUG - 2018-10-27 07:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:24:37 --> Input Class Initialized
INFO - 2018-10-27 07:24:37 --> Language Class Initialized
ERROR - 2018-10-27 07:24:37 --> 404 Page Not Found: Forgot_password/index
INFO - 2018-10-27 07:24:39 --> Config Class Initialized
INFO - 2018-10-27 07:24:39 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:24:39 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:24:39 --> Utf8 Class Initialized
INFO - 2018-10-27 07:24:39 --> URI Class Initialized
INFO - 2018-10-27 07:24:39 --> Router Class Initialized
INFO - 2018-10-27 07:24:39 --> Output Class Initialized
INFO - 2018-10-27 07:24:39 --> Security Class Initialized
DEBUG - 2018-10-27 07:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:24:39 --> Input Class Initialized
INFO - 2018-10-27 07:24:39 --> Language Class Initialized
INFO - 2018-10-27 07:24:39 --> Loader Class Initialized
INFO - 2018-10-27 07:24:39 --> Helper loaded: url_helper
INFO - 2018-10-27 07:24:39 --> Helper loaded: form_helper
INFO - 2018-10-27 07:24:39 --> Helper loaded: html_helper
INFO - 2018-10-27 07:24:39 --> Database Driver Class Initialized
INFO - 2018-10-27 07:24:39 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:24:39 --> Model "User_model" initialized
INFO - 2018-10-27 07:24:39 --> Controller Class Initialized
INFO - 2018-10-27 07:24:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:24:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-27 07:24:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:24:39 --> Final output sent to browser
DEBUG - 2018-10-27 07:24:39 --> Total execution time: 0.0400
INFO - 2018-10-27 07:24:59 --> Config Class Initialized
INFO - 2018-10-27 07:24:59 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:24:59 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:24:59 --> Utf8 Class Initialized
INFO - 2018-10-27 07:24:59 --> URI Class Initialized
INFO - 2018-10-27 07:24:59 --> Router Class Initialized
INFO - 2018-10-27 07:24:59 --> Output Class Initialized
INFO - 2018-10-27 07:24:59 --> Security Class Initialized
DEBUG - 2018-10-27 07:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:24:59 --> Input Class Initialized
INFO - 2018-10-27 07:24:59 --> Language Class Initialized
INFO - 2018-10-27 07:24:59 --> Loader Class Initialized
INFO - 2018-10-27 07:24:59 --> Helper loaded: url_helper
INFO - 2018-10-27 07:24:59 --> Helper loaded: form_helper
INFO - 2018-10-27 07:24:59 --> Helper loaded: html_helper
INFO - 2018-10-27 07:24:59 --> Database Driver Class Initialized
INFO - 2018-10-27 07:24:59 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:24:59 --> Model "User_model" initialized
INFO - 2018-10-27 07:24:59 --> Controller Class Initialized
INFO - 2018-10-27 07:24:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:24:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 07:24:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:24:59 --> Final output sent to browser
DEBUG - 2018-10-27 07:24:59 --> Total execution time: 0.0650
INFO - 2018-10-27 07:25:01 --> Config Class Initialized
INFO - 2018-10-27 07:25:01 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:25:01 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:25:01 --> Utf8 Class Initialized
INFO - 2018-10-27 07:25:01 --> URI Class Initialized
INFO - 2018-10-27 07:25:01 --> Router Class Initialized
INFO - 2018-10-27 07:25:01 --> Output Class Initialized
INFO - 2018-10-27 07:25:01 --> Security Class Initialized
DEBUG - 2018-10-27 07:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:25:01 --> Input Class Initialized
INFO - 2018-10-27 07:25:01 --> Language Class Initialized
INFO - 2018-10-27 07:25:01 --> Loader Class Initialized
INFO - 2018-10-27 07:25:01 --> Helper loaded: url_helper
INFO - 2018-10-27 07:25:01 --> Helper loaded: form_helper
INFO - 2018-10-27 07:25:01 --> Helper loaded: html_helper
INFO - 2018-10-27 07:25:01 --> Database Driver Class Initialized
INFO - 2018-10-27 07:25:01 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:25:01 --> Model "User_model" initialized
INFO - 2018-10-27 07:25:01 --> Controller Class Initialized
INFO - 2018-10-27 07:25:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:25:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-27 07:25:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:25:01 --> Final output sent to browser
DEBUG - 2018-10-27 07:25:01 --> Total execution time: 0.0600
INFO - 2018-10-27 07:25:02 --> Config Class Initialized
INFO - 2018-10-27 07:25:02 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:25:02 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:25:02 --> Utf8 Class Initialized
INFO - 2018-10-27 07:25:02 --> URI Class Initialized
INFO - 2018-10-27 07:25:02 --> Router Class Initialized
INFO - 2018-10-27 07:25:02 --> Output Class Initialized
INFO - 2018-10-27 07:25:02 --> Security Class Initialized
DEBUG - 2018-10-27 07:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:25:02 --> Input Class Initialized
INFO - 2018-10-27 07:25:02 --> Language Class Initialized
INFO - 2018-10-27 07:25:02 --> Loader Class Initialized
INFO - 2018-10-27 07:25:02 --> Helper loaded: url_helper
INFO - 2018-10-27 07:25:02 --> Helper loaded: form_helper
INFO - 2018-10-27 07:25:02 --> Helper loaded: html_helper
INFO - 2018-10-27 07:25:02 --> Database Driver Class Initialized
INFO - 2018-10-27 07:25:02 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:25:02 --> Model "User_model" initialized
INFO - 2018-10-27 07:25:02 --> Controller Class Initialized
INFO - 2018-10-27 07:25:02 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:25:02 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 07:25:02 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:25:02 --> Final output sent to browser
DEBUG - 2018-10-27 07:25:02 --> Total execution time: 0.0620
INFO - 2018-10-27 07:25:04 --> Config Class Initialized
INFO - 2018-10-27 07:25:04 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:25:04 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:25:04 --> Utf8 Class Initialized
INFO - 2018-10-27 07:25:04 --> URI Class Initialized
INFO - 2018-10-27 07:25:04 --> Router Class Initialized
INFO - 2018-10-27 07:25:04 --> Output Class Initialized
INFO - 2018-10-27 07:25:04 --> Security Class Initialized
DEBUG - 2018-10-27 07:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:25:04 --> Input Class Initialized
INFO - 2018-10-27 07:25:04 --> Language Class Initialized
INFO - 2018-10-27 07:25:04 --> Loader Class Initialized
INFO - 2018-10-27 07:25:04 --> Helper loaded: url_helper
INFO - 2018-10-27 07:25:04 --> Helper loaded: form_helper
INFO - 2018-10-27 07:25:04 --> Helper loaded: html_helper
INFO - 2018-10-27 07:25:04 --> Database Driver Class Initialized
INFO - 2018-10-27 07:25:04 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:25:04 --> Model "User_model" initialized
INFO - 2018-10-27 07:25:04 --> Controller Class Initialized
INFO - 2018-10-27 07:25:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:25:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-27 07:25:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:25:04 --> Final output sent to browser
DEBUG - 2018-10-27 07:25:04 --> Total execution time: 0.0600
INFO - 2018-10-27 07:25:29 --> Config Class Initialized
INFO - 2018-10-27 07:25:29 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:25:29 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:25:29 --> Utf8 Class Initialized
INFO - 2018-10-27 07:25:29 --> URI Class Initialized
INFO - 2018-10-27 07:25:29 --> Router Class Initialized
INFO - 2018-10-27 07:25:29 --> Output Class Initialized
INFO - 2018-10-27 07:25:29 --> Security Class Initialized
DEBUG - 2018-10-27 07:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:25:29 --> Input Class Initialized
INFO - 2018-10-27 07:25:29 --> Language Class Initialized
INFO - 2018-10-27 07:25:29 --> Loader Class Initialized
INFO - 2018-10-27 07:25:29 --> Helper loaded: url_helper
INFO - 2018-10-27 07:25:29 --> Helper loaded: form_helper
INFO - 2018-10-27 07:25:29 --> Helper loaded: html_helper
INFO - 2018-10-27 07:25:29 --> Database Driver Class Initialized
INFO - 2018-10-27 07:25:29 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:25:29 --> Model "User_model" initialized
INFO - 2018-10-27 07:25:29 --> Controller Class Initialized
INFO - 2018-10-27 07:25:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:25:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 07:25:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:25:29 --> Final output sent to browser
DEBUG - 2018-10-27 07:25:29 --> Total execution time: 0.0540
INFO - 2018-10-27 07:30:01 --> Config Class Initialized
INFO - 2018-10-27 07:30:01 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:30:01 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:30:01 --> Utf8 Class Initialized
INFO - 2018-10-27 07:30:01 --> URI Class Initialized
INFO - 2018-10-27 07:30:01 --> Router Class Initialized
INFO - 2018-10-27 07:30:01 --> Output Class Initialized
INFO - 2018-10-27 07:30:01 --> Security Class Initialized
DEBUG - 2018-10-27 07:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:30:01 --> Input Class Initialized
INFO - 2018-10-27 07:30:01 --> Language Class Initialized
INFO - 2018-10-27 07:30:01 --> Loader Class Initialized
INFO - 2018-10-27 07:30:01 --> Helper loaded: url_helper
INFO - 2018-10-27 07:30:01 --> Helper loaded: form_helper
INFO - 2018-10-27 07:30:01 --> Helper loaded: html_helper
INFO - 2018-10-27 07:30:01 --> Database Driver Class Initialized
INFO - 2018-10-27 07:30:01 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:30:01 --> Model "User_model" initialized
INFO - 2018-10-27 07:30:01 --> Controller Class Initialized
INFO - 2018-10-27 07:30:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:30:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-27 07:30:01 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:30:01 --> Final output sent to browser
DEBUG - 2018-10-27 07:30:01 --> Total execution time: 0.0590
INFO - 2018-10-27 07:30:02 --> Config Class Initialized
INFO - 2018-10-27 07:30:02 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:30:02 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:30:02 --> Utf8 Class Initialized
INFO - 2018-10-27 07:30:02 --> URI Class Initialized
INFO - 2018-10-27 07:30:02 --> Router Class Initialized
INFO - 2018-10-27 07:30:02 --> Output Class Initialized
INFO - 2018-10-27 07:30:02 --> Security Class Initialized
DEBUG - 2018-10-27 07:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:30:02 --> Input Class Initialized
INFO - 2018-10-27 07:30:02 --> Language Class Initialized
INFO - 2018-10-27 07:30:02 --> Loader Class Initialized
INFO - 2018-10-27 07:30:02 --> Helper loaded: url_helper
INFO - 2018-10-27 07:30:02 --> Helper loaded: form_helper
INFO - 2018-10-27 07:30:02 --> Helper loaded: html_helper
INFO - 2018-10-27 07:30:02 --> Database Driver Class Initialized
INFO - 2018-10-27 07:30:02 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:30:02 --> Model "User_model" initialized
INFO - 2018-10-27 07:30:02 --> Controller Class Initialized
INFO - 2018-10-27 07:30:02 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:30:02 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 07:30:02 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:30:02 --> Final output sent to browser
DEBUG - 2018-10-27 07:30:02 --> Total execution time: 0.0630
INFO - 2018-10-27 07:31:29 --> Config Class Initialized
INFO - 2018-10-27 07:31:29 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:31:29 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:31:29 --> Utf8 Class Initialized
INFO - 2018-10-27 07:31:29 --> URI Class Initialized
INFO - 2018-10-27 07:31:29 --> Router Class Initialized
INFO - 2018-10-27 07:31:29 --> Output Class Initialized
INFO - 2018-10-27 07:31:29 --> Security Class Initialized
DEBUG - 2018-10-27 07:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:31:29 --> Input Class Initialized
INFO - 2018-10-27 07:31:29 --> Language Class Initialized
INFO - 2018-10-27 07:31:29 --> Loader Class Initialized
INFO - 2018-10-27 07:31:29 --> Helper loaded: url_helper
INFO - 2018-10-27 07:31:29 --> Helper loaded: form_helper
INFO - 2018-10-27 07:31:29 --> Helper loaded: html_helper
INFO - 2018-10-27 07:31:29 --> Database Driver Class Initialized
INFO - 2018-10-27 07:31:29 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:31:29 --> Model "User_model" initialized
INFO - 2018-10-27 07:31:29 --> Controller Class Initialized
INFO - 2018-10-27 07:31:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:31:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 07:31:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:31:29 --> Final output sent to browser
DEBUG - 2018-10-27 07:31:29 --> Total execution time: 0.0600
INFO - 2018-10-27 07:31:30 --> Config Class Initialized
INFO - 2018-10-27 07:31:30 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:31:30 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:31:30 --> Utf8 Class Initialized
INFO - 2018-10-27 07:31:30 --> URI Class Initialized
INFO - 2018-10-27 07:31:30 --> Router Class Initialized
INFO - 2018-10-27 07:31:30 --> Output Class Initialized
INFO - 2018-10-27 07:31:30 --> Security Class Initialized
DEBUG - 2018-10-27 07:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:31:30 --> Input Class Initialized
INFO - 2018-10-27 07:31:30 --> Language Class Initialized
ERROR - 2018-10-27 07:31:30 --> 404 Page Not Found: Forgot_password/index
INFO - 2018-10-27 07:31:33 --> Config Class Initialized
INFO - 2018-10-27 07:31:33 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:31:33 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:31:33 --> Utf8 Class Initialized
INFO - 2018-10-27 07:31:33 --> URI Class Initialized
INFO - 2018-10-27 07:31:33 --> Router Class Initialized
INFO - 2018-10-27 07:31:33 --> Output Class Initialized
INFO - 2018-10-27 07:31:33 --> Security Class Initialized
DEBUG - 2018-10-27 07:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:31:33 --> Input Class Initialized
INFO - 2018-10-27 07:31:33 --> Language Class Initialized
INFO - 2018-10-27 07:31:33 --> Loader Class Initialized
INFO - 2018-10-27 07:31:33 --> Helper loaded: url_helper
INFO - 2018-10-27 07:31:33 --> Helper loaded: form_helper
INFO - 2018-10-27 07:31:33 --> Helper loaded: html_helper
INFO - 2018-10-27 07:31:33 --> Database Driver Class Initialized
INFO - 2018-10-27 07:31:33 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:31:33 --> Model "User_model" initialized
INFO - 2018-10-27 07:31:33 --> Controller Class Initialized
INFO - 2018-10-27 07:31:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:31:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 07:31:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:31:33 --> Final output sent to browser
DEBUG - 2018-10-27 07:31:33 --> Total execution time: 0.0650
INFO - 2018-10-27 07:31:41 --> Config Class Initialized
INFO - 2018-10-27 07:31:41 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:31:41 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:31:41 --> Utf8 Class Initialized
INFO - 2018-10-27 07:31:41 --> URI Class Initialized
INFO - 2018-10-27 07:31:41 --> Router Class Initialized
INFO - 2018-10-27 07:31:41 --> Output Class Initialized
INFO - 2018-10-27 07:31:41 --> Security Class Initialized
DEBUG - 2018-10-27 07:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:31:41 --> Input Class Initialized
INFO - 2018-10-27 07:31:41 --> Language Class Initialized
ERROR - 2018-10-27 07:31:41 --> 404 Page Not Found: Forgot_password/index
INFO - 2018-10-27 07:32:40 --> Config Class Initialized
INFO - 2018-10-27 07:32:40 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:32:40 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:32:40 --> Utf8 Class Initialized
INFO - 2018-10-27 07:32:40 --> URI Class Initialized
INFO - 2018-10-27 07:32:40 --> Router Class Initialized
INFO - 2018-10-27 07:32:40 --> Output Class Initialized
INFO - 2018-10-27 07:32:40 --> Security Class Initialized
DEBUG - 2018-10-27 07:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:32:40 --> Input Class Initialized
INFO - 2018-10-27 07:32:40 --> Language Class Initialized
INFO - 2018-10-27 07:32:40 --> Loader Class Initialized
INFO - 2018-10-27 07:32:40 --> Helper loaded: url_helper
INFO - 2018-10-27 07:32:40 --> Helper loaded: form_helper
INFO - 2018-10-27 07:32:40 --> Helper loaded: html_helper
INFO - 2018-10-27 07:32:40 --> Database Driver Class Initialized
INFO - 2018-10-27 07:32:40 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:32:40 --> Model "User_model" initialized
INFO - 2018-10-27 07:32:40 --> Controller Class Initialized
INFO - 2018-10-27 07:32:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:32:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 07:32:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:32:40 --> Final output sent to browser
DEBUG - 2018-10-27 07:32:40 --> Total execution time: 0.0550
INFO - 2018-10-27 07:32:41 --> Config Class Initialized
INFO - 2018-10-27 07:32:41 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:32:41 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:32:41 --> Utf8 Class Initialized
INFO - 2018-10-27 07:32:41 --> URI Class Initialized
INFO - 2018-10-27 07:32:41 --> Router Class Initialized
INFO - 2018-10-27 07:32:41 --> Output Class Initialized
INFO - 2018-10-27 07:32:41 --> Security Class Initialized
DEBUG - 2018-10-27 07:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:32:41 --> Input Class Initialized
INFO - 2018-10-27 07:32:41 --> Language Class Initialized
INFO - 2018-10-27 07:32:41 --> Loader Class Initialized
INFO - 2018-10-27 07:32:41 --> Helper loaded: url_helper
INFO - 2018-10-27 07:32:41 --> Helper loaded: form_helper
INFO - 2018-10-27 07:32:41 --> Helper loaded: html_helper
INFO - 2018-10-27 07:32:41 --> Database Driver Class Initialized
INFO - 2018-10-27 07:32:41 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:32:41 --> Model "User_model" initialized
INFO - 2018-10-27 07:32:41 --> Controller Class Initialized
INFO - 2018-10-27 07:32:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:32:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 07:32:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:32:41 --> Final output sent to browser
DEBUG - 2018-10-27 07:32:41 --> Total execution time: 0.0630
INFO - 2018-10-27 07:32:43 --> Config Class Initialized
INFO - 2018-10-27 07:32:43 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:32:43 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:32:43 --> Utf8 Class Initialized
INFO - 2018-10-27 07:32:43 --> URI Class Initialized
INFO - 2018-10-27 07:32:43 --> Router Class Initialized
INFO - 2018-10-27 07:32:43 --> Output Class Initialized
INFO - 2018-10-27 07:32:43 --> Security Class Initialized
DEBUG - 2018-10-27 07:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:32:43 --> Input Class Initialized
INFO - 2018-10-27 07:32:43 --> Language Class Initialized
INFO - 2018-10-27 07:32:43 --> Loader Class Initialized
INFO - 2018-10-27 07:32:43 --> Helper loaded: url_helper
INFO - 2018-10-27 07:32:43 --> Helper loaded: form_helper
INFO - 2018-10-27 07:32:43 --> Helper loaded: html_helper
INFO - 2018-10-27 07:32:43 --> Database Driver Class Initialized
INFO - 2018-10-27 07:32:43 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:32:43 --> Model "User_model" initialized
INFO - 2018-10-27 07:32:43 --> Controller Class Initialized
INFO - 2018-10-27 07:32:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:32:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/forgot_password.php
INFO - 2018-10-27 07:32:43 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:32:43 --> Final output sent to browser
DEBUG - 2018-10-27 07:32:43 --> Total execution time: 0.0630
INFO - 2018-10-27 07:38:51 --> Config Class Initialized
INFO - 2018-10-27 07:38:51 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:38:51 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:38:51 --> Utf8 Class Initialized
INFO - 2018-10-27 07:38:51 --> URI Class Initialized
INFO - 2018-10-27 07:38:51 --> Router Class Initialized
INFO - 2018-10-27 07:38:51 --> Output Class Initialized
INFO - 2018-10-27 07:38:51 --> Security Class Initialized
DEBUG - 2018-10-27 07:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:38:51 --> Input Class Initialized
INFO - 2018-10-27 07:38:51 --> Language Class Initialized
INFO - 2018-10-27 07:38:51 --> Loader Class Initialized
INFO - 2018-10-27 07:38:51 --> Helper loaded: url_helper
INFO - 2018-10-27 07:38:51 --> Helper loaded: form_helper
INFO - 2018-10-27 07:38:51 --> Helper loaded: html_helper
INFO - 2018-10-27 07:38:51 --> Database Driver Class Initialized
INFO - 2018-10-27 07:38:51 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:38:51 --> Model "User_model" initialized
INFO - 2018-10-27 07:38:51 --> Controller Class Initialized
INFO - 2018-10-27 07:38:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-27 07:38:51 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:38:51 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 07:38:51 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:38:51 --> Final output sent to browser
DEBUG - 2018-10-27 07:38:51 --> Total execution time: 0.0510
INFO - 2018-10-27 07:38:55 --> Config Class Initialized
INFO - 2018-10-27 07:38:55 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:38:55 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:38:55 --> Utf8 Class Initialized
INFO - 2018-10-27 07:38:55 --> URI Class Initialized
INFO - 2018-10-27 07:38:55 --> Router Class Initialized
INFO - 2018-10-27 07:38:55 --> Output Class Initialized
INFO - 2018-10-27 07:38:55 --> Security Class Initialized
DEBUG - 2018-10-27 07:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:38:55 --> Input Class Initialized
INFO - 2018-10-27 07:38:55 --> Language Class Initialized
INFO - 2018-10-27 07:38:55 --> Loader Class Initialized
INFO - 2018-10-27 07:38:55 --> Helper loaded: url_helper
INFO - 2018-10-27 07:38:55 --> Helper loaded: form_helper
INFO - 2018-10-27 07:38:55 --> Helper loaded: html_helper
INFO - 2018-10-27 07:38:55 --> Database Driver Class Initialized
INFO - 2018-10-27 07:38:55 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:38:55 --> Model "User_model" initialized
INFO - 2018-10-27 07:38:55 --> Controller Class Initialized
INFO - 2018-10-27 07:38:55 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:38:55 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/forgot_password.php
INFO - 2018-10-27 07:38:55 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:38:55 --> Final output sent to browser
DEBUG - 2018-10-27 07:38:55 --> Total execution time: 0.0830
INFO - 2018-10-27 07:38:56 --> Config Class Initialized
INFO - 2018-10-27 07:38:56 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:38:56 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:38:56 --> Utf8 Class Initialized
INFO - 2018-10-27 07:38:56 --> URI Class Initialized
INFO - 2018-10-27 07:38:56 --> Router Class Initialized
INFO - 2018-10-27 07:38:56 --> Output Class Initialized
INFO - 2018-10-27 07:38:56 --> Security Class Initialized
DEBUG - 2018-10-27 07:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:38:56 --> Input Class Initialized
INFO - 2018-10-27 07:38:56 --> Language Class Initialized
INFO - 2018-10-27 07:38:56 --> Loader Class Initialized
INFO - 2018-10-27 07:38:56 --> Helper loaded: url_helper
INFO - 2018-10-27 07:38:56 --> Helper loaded: form_helper
INFO - 2018-10-27 07:38:56 --> Helper loaded: html_helper
INFO - 2018-10-27 07:38:56 --> Database Driver Class Initialized
INFO - 2018-10-27 07:38:56 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:38:56 --> Model "User_model" initialized
INFO - 2018-10-27 07:38:56 --> Controller Class Initialized
INFO - 2018-10-27 07:38:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-27 07:38:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:38:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 07:38:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:38:56 --> Final output sent to browser
DEBUG - 2018-10-27 07:38:56 --> Total execution time: 0.0570
INFO - 2018-10-27 07:38:58 --> Config Class Initialized
INFO - 2018-10-27 07:38:58 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:38:58 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:38:58 --> Utf8 Class Initialized
INFO - 2018-10-27 07:38:58 --> URI Class Initialized
INFO - 2018-10-27 07:38:58 --> Router Class Initialized
INFO - 2018-10-27 07:38:58 --> Output Class Initialized
INFO - 2018-10-27 07:38:58 --> Security Class Initialized
DEBUG - 2018-10-27 07:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:38:58 --> Input Class Initialized
INFO - 2018-10-27 07:38:58 --> Language Class Initialized
INFO - 2018-10-27 07:38:58 --> Loader Class Initialized
INFO - 2018-10-27 07:38:58 --> Helper loaded: url_helper
INFO - 2018-10-27 07:38:58 --> Helper loaded: form_helper
INFO - 2018-10-27 07:38:58 --> Helper loaded: html_helper
INFO - 2018-10-27 07:38:58 --> Database Driver Class Initialized
INFO - 2018-10-27 07:38:58 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:38:58 --> Model "User_model" initialized
INFO - 2018-10-27 07:38:58 --> Controller Class Initialized
INFO - 2018-10-27 07:38:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:38:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/forgot_password.php
INFO - 2018-10-27 07:38:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:38:58 --> Final output sent to browser
DEBUG - 2018-10-27 07:38:58 --> Total execution time: 0.0510
INFO - 2018-10-27 07:39:10 --> Config Class Initialized
INFO - 2018-10-27 07:39:10 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:39:10 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:39:10 --> Utf8 Class Initialized
INFO - 2018-10-27 07:39:10 --> URI Class Initialized
INFO - 2018-10-27 07:39:10 --> Router Class Initialized
INFO - 2018-10-27 07:39:10 --> Output Class Initialized
INFO - 2018-10-27 07:39:10 --> Security Class Initialized
DEBUG - 2018-10-27 07:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:39:10 --> Input Class Initialized
INFO - 2018-10-27 07:39:10 --> Language Class Initialized
INFO - 2018-10-27 07:39:10 --> Loader Class Initialized
INFO - 2018-10-27 07:39:10 --> Helper loaded: url_helper
INFO - 2018-10-27 07:39:10 --> Helper loaded: form_helper
INFO - 2018-10-27 07:39:10 --> Helper loaded: html_helper
INFO - 2018-10-27 07:39:10 --> Database Driver Class Initialized
INFO - 2018-10-27 07:39:10 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:39:10 --> Model "User_model" initialized
INFO - 2018-10-27 07:39:10 --> Controller Class Initialized
INFO - 2018-10-27 07:39:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-27 07:39:10 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:39:10 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 07:39:10 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:39:10 --> Final output sent to browser
DEBUG - 2018-10-27 07:39:10 --> Total execution time: 0.0580
INFO - 2018-10-27 07:39:14 --> Config Class Initialized
INFO - 2018-10-27 07:39:14 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:39:14 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:39:14 --> Utf8 Class Initialized
INFO - 2018-10-27 07:39:14 --> URI Class Initialized
INFO - 2018-10-27 07:39:14 --> Router Class Initialized
INFO - 2018-10-27 07:39:14 --> Output Class Initialized
INFO - 2018-10-27 07:39:14 --> Security Class Initialized
DEBUG - 2018-10-27 07:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:39:14 --> Input Class Initialized
INFO - 2018-10-27 07:39:14 --> Language Class Initialized
INFO - 2018-10-27 07:39:14 --> Loader Class Initialized
INFO - 2018-10-27 07:39:14 --> Helper loaded: url_helper
INFO - 2018-10-27 07:39:14 --> Helper loaded: form_helper
INFO - 2018-10-27 07:39:14 --> Helper loaded: html_helper
INFO - 2018-10-27 07:39:14 --> Database Driver Class Initialized
INFO - 2018-10-27 07:39:14 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:39:14 --> Model "User_model" initialized
INFO - 2018-10-27 07:39:14 --> Controller Class Initialized
INFO - 2018-10-27 07:39:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:39:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 07:39:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:39:14 --> Final output sent to browser
DEBUG - 2018-10-27 07:39:14 --> Total execution time: 0.0630
INFO - 2018-10-27 07:39:16 --> Config Class Initialized
INFO - 2018-10-27 07:39:16 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:39:16 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:39:16 --> Utf8 Class Initialized
INFO - 2018-10-27 07:39:16 --> URI Class Initialized
INFO - 2018-10-27 07:39:16 --> Router Class Initialized
INFO - 2018-10-27 07:39:16 --> Output Class Initialized
INFO - 2018-10-27 07:39:16 --> Security Class Initialized
DEBUG - 2018-10-27 07:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:39:16 --> Input Class Initialized
INFO - 2018-10-27 07:39:16 --> Language Class Initialized
INFO - 2018-10-27 07:39:16 --> Loader Class Initialized
INFO - 2018-10-27 07:39:16 --> Helper loaded: url_helper
INFO - 2018-10-27 07:39:16 --> Helper loaded: form_helper
INFO - 2018-10-27 07:39:16 --> Helper loaded: html_helper
INFO - 2018-10-27 07:39:16 --> Database Driver Class Initialized
INFO - 2018-10-27 07:39:16 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:39:16 --> Model "User_model" initialized
INFO - 2018-10-27 07:39:16 --> Controller Class Initialized
INFO - 2018-10-27 07:39:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:39:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/forgot_password.php
INFO - 2018-10-27 07:39:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:39:16 --> Final output sent to browser
DEBUG - 2018-10-27 07:39:16 --> Total execution time: 0.0710
INFO - 2018-10-27 07:39:18 --> Config Class Initialized
INFO - 2018-10-27 07:39:18 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:39:18 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:39:18 --> Utf8 Class Initialized
INFO - 2018-10-27 07:39:18 --> URI Class Initialized
INFO - 2018-10-27 07:39:18 --> Router Class Initialized
INFO - 2018-10-27 07:39:18 --> Output Class Initialized
INFO - 2018-10-27 07:39:18 --> Security Class Initialized
DEBUG - 2018-10-27 07:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:39:18 --> Input Class Initialized
INFO - 2018-10-27 07:39:18 --> Language Class Initialized
INFO - 2018-10-27 07:39:18 --> Loader Class Initialized
INFO - 2018-10-27 07:39:18 --> Helper loaded: url_helper
INFO - 2018-10-27 07:39:18 --> Helper loaded: form_helper
INFO - 2018-10-27 07:39:18 --> Helper loaded: html_helper
INFO - 2018-10-27 07:39:18 --> Database Driver Class Initialized
INFO - 2018-10-27 07:39:18 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:39:18 --> Model "User_model" initialized
INFO - 2018-10-27 07:39:18 --> Controller Class Initialized
INFO - 2018-10-27 07:39:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-27 07:39:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:39:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 07:39:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:39:18 --> Final output sent to browser
DEBUG - 2018-10-27 07:39:18 --> Total execution time: 0.0570
INFO - 2018-10-27 07:39:20 --> Config Class Initialized
INFO - 2018-10-27 07:39:20 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:39:20 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:39:20 --> Utf8 Class Initialized
INFO - 2018-10-27 07:39:20 --> URI Class Initialized
INFO - 2018-10-27 07:39:20 --> Router Class Initialized
INFO - 2018-10-27 07:39:20 --> Output Class Initialized
INFO - 2018-10-27 07:39:20 --> Security Class Initialized
DEBUG - 2018-10-27 07:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:39:20 --> Input Class Initialized
INFO - 2018-10-27 07:39:20 --> Language Class Initialized
INFO - 2018-10-27 07:39:20 --> Loader Class Initialized
INFO - 2018-10-27 07:39:20 --> Helper loaded: url_helper
INFO - 2018-10-27 07:39:20 --> Helper loaded: form_helper
INFO - 2018-10-27 07:39:20 --> Helper loaded: html_helper
INFO - 2018-10-27 07:39:20 --> Database Driver Class Initialized
INFO - 2018-10-27 07:39:20 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:39:20 --> Model "User_model" initialized
INFO - 2018-10-27 07:39:20 --> Controller Class Initialized
INFO - 2018-10-27 07:39:20 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:39:20 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/forgot_password.php
INFO - 2018-10-27 07:39:20 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:39:20 --> Final output sent to browser
DEBUG - 2018-10-27 07:39:20 --> Total execution time: 0.0640
INFO - 2018-10-27 07:45:10 --> Config Class Initialized
INFO - 2018-10-27 07:45:10 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:45:10 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:45:10 --> Utf8 Class Initialized
INFO - 2018-10-27 07:45:10 --> URI Class Initialized
INFO - 2018-10-27 07:45:10 --> Router Class Initialized
INFO - 2018-10-27 07:45:10 --> Output Class Initialized
INFO - 2018-10-27 07:45:10 --> Security Class Initialized
DEBUG - 2018-10-27 07:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:45:10 --> Input Class Initialized
INFO - 2018-10-27 07:45:10 --> Language Class Initialized
INFO - 2018-10-27 07:45:10 --> Loader Class Initialized
INFO - 2018-10-27 07:45:10 --> Helper loaded: url_helper
INFO - 2018-10-27 07:45:10 --> Helper loaded: form_helper
INFO - 2018-10-27 07:45:10 --> Helper loaded: html_helper
INFO - 2018-10-27 07:45:10 --> Database Driver Class Initialized
INFO - 2018-10-27 07:45:10 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:45:10 --> Model "User_model" initialized
INFO - 2018-10-27 07:45:10 --> Controller Class Initialized
INFO - 2018-10-27 07:45:10 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:45:10 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/forgot_password.php
INFO - 2018-10-27 07:45:10 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:45:10 --> Final output sent to browser
DEBUG - 2018-10-27 07:45:10 --> Total execution time: 0.0650
INFO - 2018-10-27 07:45:11 --> Config Class Initialized
INFO - 2018-10-27 07:45:11 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:45:11 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:45:11 --> Utf8 Class Initialized
INFO - 2018-10-27 07:45:11 --> URI Class Initialized
INFO - 2018-10-27 07:45:11 --> Router Class Initialized
INFO - 2018-10-27 07:45:11 --> Output Class Initialized
INFO - 2018-10-27 07:45:11 --> Security Class Initialized
DEBUG - 2018-10-27 07:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:45:11 --> Input Class Initialized
INFO - 2018-10-27 07:45:11 --> Language Class Initialized
INFO - 2018-10-27 07:45:11 --> Loader Class Initialized
INFO - 2018-10-27 07:45:11 --> Helper loaded: url_helper
INFO - 2018-10-27 07:45:11 --> Helper loaded: form_helper
INFO - 2018-10-27 07:45:11 --> Helper loaded: html_helper
INFO - 2018-10-27 07:45:11 --> Database Driver Class Initialized
INFO - 2018-10-27 07:45:11 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:45:11 --> Model "User_model" initialized
INFO - 2018-10-27 07:45:11 --> Controller Class Initialized
INFO - 2018-10-27 07:45:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-27 07:45:11 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:45:11 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 07:45:11 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:45:11 --> Final output sent to browser
DEBUG - 2018-10-27 07:45:11 --> Total execution time: 0.0750
INFO - 2018-10-27 07:49:07 --> Config Class Initialized
INFO - 2018-10-27 07:49:07 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:49:07 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:49:07 --> Utf8 Class Initialized
INFO - 2018-10-27 07:49:07 --> URI Class Initialized
INFO - 2018-10-27 07:49:07 --> Router Class Initialized
INFO - 2018-10-27 07:49:07 --> Output Class Initialized
INFO - 2018-10-27 07:49:07 --> Security Class Initialized
DEBUG - 2018-10-27 07:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:49:07 --> Input Class Initialized
INFO - 2018-10-27 07:49:07 --> Language Class Initialized
INFO - 2018-10-27 07:49:07 --> Loader Class Initialized
INFO - 2018-10-27 07:49:07 --> Helper loaded: url_helper
INFO - 2018-10-27 07:49:07 --> Helper loaded: form_helper
INFO - 2018-10-27 07:49:07 --> Helper loaded: html_helper
INFO - 2018-10-27 07:49:07 --> Database Driver Class Initialized
INFO - 2018-10-27 07:49:07 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:49:07 --> Model "User_model" initialized
INFO - 2018-10-27 07:49:07 --> Controller Class Initialized
INFO - 2018-10-27 07:49:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-27 07:49:07 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:49:07 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 07:49:07 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:49:07 --> Final output sent to browser
DEBUG - 2018-10-27 07:49:07 --> Total execution time: 0.0580
INFO - 2018-10-27 07:49:08 --> Config Class Initialized
INFO - 2018-10-27 07:49:08 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:49:08 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:49:08 --> Utf8 Class Initialized
INFO - 2018-10-27 07:49:08 --> URI Class Initialized
INFO - 2018-10-27 07:49:08 --> Router Class Initialized
INFO - 2018-10-27 07:49:08 --> Output Class Initialized
INFO - 2018-10-27 07:49:08 --> Security Class Initialized
DEBUG - 2018-10-27 07:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:49:08 --> Input Class Initialized
INFO - 2018-10-27 07:49:08 --> Language Class Initialized
INFO - 2018-10-27 07:49:08 --> Loader Class Initialized
INFO - 2018-10-27 07:49:08 --> Helper loaded: url_helper
INFO - 2018-10-27 07:49:08 --> Helper loaded: form_helper
INFO - 2018-10-27 07:49:08 --> Helper loaded: html_helper
INFO - 2018-10-27 07:49:08 --> Database Driver Class Initialized
INFO - 2018-10-27 07:49:08 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:49:08 --> Model "User_model" initialized
INFO - 2018-10-27 07:49:08 --> Controller Class Initialized
INFO - 2018-10-27 07:49:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:49:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-27 07:49:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:49:08 --> Final output sent to browser
DEBUG - 2018-10-27 07:49:08 --> Total execution time: 0.0570
INFO - 2018-10-27 07:49:09 --> Config Class Initialized
INFO - 2018-10-27 07:49:09 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:49:09 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:49:09 --> Utf8 Class Initialized
INFO - 2018-10-27 07:49:09 --> URI Class Initialized
INFO - 2018-10-27 07:49:09 --> Router Class Initialized
INFO - 2018-10-27 07:49:09 --> Output Class Initialized
INFO - 2018-10-27 07:49:09 --> Security Class Initialized
DEBUG - 2018-10-27 07:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:49:09 --> Input Class Initialized
INFO - 2018-10-27 07:49:09 --> Language Class Initialized
INFO - 2018-10-27 07:49:09 --> Loader Class Initialized
INFO - 2018-10-27 07:49:09 --> Helper loaded: url_helper
INFO - 2018-10-27 07:49:09 --> Helper loaded: form_helper
INFO - 2018-10-27 07:49:09 --> Helper loaded: html_helper
INFO - 2018-10-27 07:49:09 --> Database Driver Class Initialized
INFO - 2018-10-27 07:49:09 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:49:09 --> Model "User_model" initialized
INFO - 2018-10-27 07:49:09 --> Controller Class Initialized
INFO - 2018-10-27 07:49:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:49:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 07:49:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:49:09 --> Final output sent to browser
DEBUG - 2018-10-27 07:49:09 --> Total execution time: 0.0600
INFO - 2018-10-27 07:49:19 --> Config Class Initialized
INFO - 2018-10-27 07:49:19 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:49:19 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:49:19 --> Utf8 Class Initialized
INFO - 2018-10-27 07:49:19 --> URI Class Initialized
INFO - 2018-10-27 07:49:19 --> Router Class Initialized
INFO - 2018-10-27 07:49:19 --> Output Class Initialized
INFO - 2018-10-27 07:49:19 --> Security Class Initialized
DEBUG - 2018-10-27 07:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:49:19 --> Input Class Initialized
INFO - 2018-10-27 07:49:19 --> Language Class Initialized
INFO - 2018-10-27 07:49:19 --> Loader Class Initialized
INFO - 2018-10-27 07:49:19 --> Helper loaded: url_helper
INFO - 2018-10-27 07:49:20 --> Helper loaded: form_helper
INFO - 2018-10-27 07:49:20 --> Helper loaded: html_helper
INFO - 2018-10-27 07:49:20 --> Database Driver Class Initialized
INFO - 2018-10-27 07:49:20 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:49:20 --> Model "User_model" initialized
INFO - 2018-10-27 07:49:20 --> Controller Class Initialized
INFO - 2018-10-27 07:49:20 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:49:20 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-27 07:49:20 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:49:20 --> Final output sent to browser
DEBUG - 2018-10-27 07:49:20 --> Total execution time: 0.0600
INFO - 2018-10-27 07:49:23 --> Config Class Initialized
INFO - 2018-10-27 07:49:23 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:49:23 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:49:23 --> Utf8 Class Initialized
INFO - 2018-10-27 07:49:23 --> URI Class Initialized
INFO - 2018-10-27 07:49:23 --> Router Class Initialized
INFO - 2018-10-27 07:49:23 --> Output Class Initialized
INFO - 2018-10-27 07:49:23 --> Security Class Initialized
DEBUG - 2018-10-27 07:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:49:23 --> Input Class Initialized
INFO - 2018-10-27 07:49:23 --> Language Class Initialized
INFO - 2018-10-27 07:49:23 --> Loader Class Initialized
INFO - 2018-10-27 07:49:23 --> Helper loaded: url_helper
INFO - 2018-10-27 07:49:23 --> Helper loaded: form_helper
INFO - 2018-10-27 07:49:23 --> Helper loaded: html_helper
INFO - 2018-10-27 07:49:23 --> Database Driver Class Initialized
INFO - 2018-10-27 07:49:23 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:49:23 --> Model "User_model" initialized
INFO - 2018-10-27 07:49:23 --> Controller Class Initialized
INFO - 2018-10-27 07:49:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:49:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 07:49:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:49:23 --> Final output sent to browser
DEBUG - 2018-10-27 07:49:23 --> Total execution time: 0.0720
INFO - 2018-10-27 07:50:00 --> Config Class Initialized
INFO - 2018-10-27 07:50:00 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:50:00 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:50:00 --> Utf8 Class Initialized
INFO - 2018-10-27 07:50:00 --> URI Class Initialized
INFO - 2018-10-27 07:50:00 --> Router Class Initialized
INFO - 2018-10-27 07:50:00 --> Output Class Initialized
INFO - 2018-10-27 07:50:00 --> Security Class Initialized
DEBUG - 2018-10-27 07:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:50:00 --> Input Class Initialized
INFO - 2018-10-27 07:50:00 --> Language Class Initialized
INFO - 2018-10-27 07:50:00 --> Loader Class Initialized
INFO - 2018-10-27 07:50:00 --> Helper loaded: url_helper
INFO - 2018-10-27 07:50:00 --> Helper loaded: form_helper
INFO - 2018-10-27 07:50:00 --> Helper loaded: html_helper
INFO - 2018-10-27 07:50:00 --> Database Driver Class Initialized
INFO - 2018-10-27 07:50:00 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:50:00 --> Model "User_model" initialized
INFO - 2018-10-27 07:50:00 --> Controller Class Initialized
INFO - 2018-10-27 07:50:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-27 07:50:00 --> Config Class Initialized
INFO - 2018-10-27 07:50:00 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:50:00 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:50:00 --> Utf8 Class Initialized
INFO - 2018-10-27 07:50:00 --> URI Class Initialized
INFO - 2018-10-27 07:50:00 --> Router Class Initialized
INFO - 2018-10-27 07:50:00 --> Output Class Initialized
INFO - 2018-10-27 07:50:00 --> Security Class Initialized
DEBUG - 2018-10-27 07:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:50:00 --> Input Class Initialized
INFO - 2018-10-27 07:50:00 --> Language Class Initialized
INFO - 2018-10-27 07:50:00 --> Loader Class Initialized
INFO - 2018-10-27 07:50:00 --> Helper loaded: url_helper
INFO - 2018-10-27 07:50:00 --> Helper loaded: form_helper
INFO - 2018-10-27 07:50:00 --> Helper loaded: html_helper
INFO - 2018-10-27 07:50:00 --> Database Driver Class Initialized
INFO - 2018-10-27 07:50:00 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:50:00 --> Model "User_model" initialized
INFO - 2018-10-27 07:50:00 --> Controller Class Initialized
INFO - 2018-10-27 07:50:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:50:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-27 07:50:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:50:00 --> Final output sent to browser
DEBUG - 2018-10-27 07:50:00 --> Total execution time: 0.0410
INFO - 2018-10-27 07:50:08 --> Config Class Initialized
INFO - 2018-10-27 07:50:08 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:50:08 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:50:08 --> Utf8 Class Initialized
INFO - 2018-10-27 07:50:08 --> URI Class Initialized
INFO - 2018-10-27 07:50:08 --> Router Class Initialized
INFO - 2018-10-27 07:50:08 --> Output Class Initialized
INFO - 2018-10-27 07:50:08 --> Security Class Initialized
DEBUG - 2018-10-27 07:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:50:08 --> Input Class Initialized
INFO - 2018-10-27 07:50:08 --> Language Class Initialized
INFO - 2018-10-27 07:50:08 --> Loader Class Initialized
INFO - 2018-10-27 07:50:08 --> Helper loaded: url_helper
INFO - 2018-10-27 07:50:08 --> Helper loaded: form_helper
INFO - 2018-10-27 07:50:08 --> Helper loaded: html_helper
INFO - 2018-10-27 07:50:08 --> Database Driver Class Initialized
INFO - 2018-10-27 07:50:08 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:50:08 --> Model "User_model" initialized
INFO - 2018-10-27 07:50:08 --> Controller Class Initialized
INFO - 2018-10-27 07:50:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:50:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-27 07:50:08 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:50:08 --> Final output sent to browser
DEBUG - 2018-10-27 07:50:08 --> Total execution time: 0.0660
INFO - 2018-10-27 07:50:09 --> Config Class Initialized
INFO - 2018-10-27 07:50:09 --> Hooks Class Initialized
DEBUG - 2018-10-27 07:50:09 --> UTF-8 Support Enabled
INFO - 2018-10-27 07:50:09 --> Utf8 Class Initialized
INFO - 2018-10-27 07:50:09 --> URI Class Initialized
INFO - 2018-10-27 07:50:09 --> Router Class Initialized
INFO - 2018-10-27 07:50:09 --> Output Class Initialized
INFO - 2018-10-27 07:50:09 --> Security Class Initialized
DEBUG - 2018-10-27 07:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-27 07:50:09 --> Input Class Initialized
INFO - 2018-10-27 07:50:09 --> Language Class Initialized
INFO - 2018-10-27 07:50:09 --> Loader Class Initialized
INFO - 2018-10-27 07:50:09 --> Helper loaded: url_helper
INFO - 2018-10-27 07:50:09 --> Helper loaded: form_helper
INFO - 2018-10-27 07:50:09 --> Helper loaded: html_helper
INFO - 2018-10-27 07:50:09 --> Database Driver Class Initialized
INFO - 2018-10-27 07:50:09 --> Form Validation Class Initialized
DEBUG - 2018-10-27 07:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-27 07:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-27 07:50:09 --> Model "User_model" initialized
INFO - 2018-10-27 07:50:09 --> Controller Class Initialized
INFO - 2018-10-27 07:50:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-27 07:50:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-27 07:50:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-27 07:50:09 --> Final output sent to browser
DEBUG - 2018-10-27 07:50:09 --> Total execution time: 0.0600
