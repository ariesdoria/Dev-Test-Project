<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-09-29 05:08:49 --> Config Class Initialized
INFO - 2018-09-29 05:08:49 --> Hooks Class Initialized
DEBUG - 2018-09-29 05:08:49 --> UTF-8 Support Enabled
INFO - 2018-09-29 05:08:49 --> Utf8 Class Initialized
INFO - 2018-09-29 05:08:49 --> URI Class Initialized
INFO - 2018-09-29 05:08:49 --> Router Class Initialized
INFO - 2018-09-29 05:08:49 --> Output Class Initialized
INFO - 2018-09-29 05:08:49 --> Security Class Initialized
DEBUG - 2018-09-29 05:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 05:08:49 --> Input Class Initialized
INFO - 2018-09-29 05:08:49 --> Language Class Initialized
INFO - 2018-09-29 05:08:49 --> Loader Class Initialized
INFO - 2018-09-29 05:08:49 --> Helper loaded: url_helper
INFO - 2018-09-29 05:08:49 --> Helper loaded: form_helper
INFO - 2018-09-29 05:08:49 --> Helper loaded: html_helper
INFO - 2018-09-29 05:08:49 --> Database Driver Class Initialized
INFO - 2018-09-29 05:08:49 --> Form Validation Class Initialized
DEBUG - 2018-09-29 05:08:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 05:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 05:08:49 --> Model "User_model" initialized
INFO - 2018-09-29 05:08:49 --> Model "Project_model" initialized
INFO - 2018-09-29 05:08:49 --> Model "Tasks_model" initialized
INFO - 2018-09-29 05:08:49 --> Model "Lists_model" initialized
INFO - 2018-09-29 05:08:49 --> Controller Class Initialized
INFO - 2018-09-29 05:08:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 05:08:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-29 05:08:49 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 05:08:49 --> Final output sent to browser
DEBUG - 2018-09-29 05:08:49 --> Total execution time: 0.2060
INFO - 2018-09-29 05:57:16 --> Config Class Initialized
INFO - 2018-09-29 05:57:16 --> Hooks Class Initialized
DEBUG - 2018-09-29 05:57:16 --> UTF-8 Support Enabled
INFO - 2018-09-29 05:57:16 --> Utf8 Class Initialized
INFO - 2018-09-29 05:57:16 --> URI Class Initialized
INFO - 2018-09-29 05:57:16 --> Router Class Initialized
INFO - 2018-09-29 05:57:16 --> Output Class Initialized
INFO - 2018-09-29 05:57:16 --> Security Class Initialized
DEBUG - 2018-09-29 05:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 05:57:16 --> Input Class Initialized
INFO - 2018-09-29 05:57:16 --> Language Class Initialized
INFO - 2018-09-29 05:57:16 --> Loader Class Initialized
INFO - 2018-09-29 05:57:16 --> Helper loaded: url_helper
INFO - 2018-09-29 05:57:16 --> Helper loaded: form_helper
INFO - 2018-09-29 05:57:16 --> Helper loaded: html_helper
INFO - 2018-09-29 05:57:16 --> Database Driver Class Initialized
INFO - 2018-09-29 05:57:16 --> Form Validation Class Initialized
DEBUG - 2018-09-29 05:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 05:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 05:57:16 --> Model "User_model" initialized
INFO - 2018-09-29 05:57:16 --> Model "Project_model" initialized
INFO - 2018-09-29 05:57:16 --> Model "Tasks_model" initialized
INFO - 2018-09-29 05:57:16 --> Model "Lists_model" initialized
INFO - 2018-09-29 05:57:16 --> Controller Class Initialized
INFO - 2018-09-29 05:57:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-29 05:57:17 --> Config Class Initialized
INFO - 2018-09-29 05:57:17 --> Hooks Class Initialized
DEBUG - 2018-09-29 05:57:17 --> UTF-8 Support Enabled
INFO - 2018-09-29 05:57:17 --> Utf8 Class Initialized
INFO - 2018-09-29 05:57:17 --> URI Class Initialized
INFO - 2018-09-29 05:57:17 --> Router Class Initialized
INFO - 2018-09-29 05:57:17 --> Output Class Initialized
INFO - 2018-09-29 05:57:17 --> Security Class Initialized
DEBUG - 2018-09-29 05:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 05:57:17 --> Input Class Initialized
INFO - 2018-09-29 05:57:17 --> Language Class Initialized
INFO - 2018-09-29 05:57:17 --> Loader Class Initialized
INFO - 2018-09-29 05:57:17 --> Helper loaded: url_helper
INFO - 2018-09-29 05:57:17 --> Helper loaded: form_helper
INFO - 2018-09-29 05:57:17 --> Helper loaded: html_helper
INFO - 2018-09-29 05:57:17 --> Database Driver Class Initialized
INFO - 2018-09-29 05:57:17 --> Form Validation Class Initialized
DEBUG - 2018-09-29 05:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 05:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 05:57:17 --> Model "User_model" initialized
INFO - 2018-09-29 05:57:17 --> Model "Project_model" initialized
INFO - 2018-09-29 05:57:17 --> Model "Tasks_model" initialized
INFO - 2018-09-29 05:57:17 --> Model "Lists_model" initialized
INFO - 2018-09-29 05:57:17 --> Controller Class Initialized
INFO - 2018-09-29 05:57:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 05:57:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-29 05:57:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 05:57:17 --> Final output sent to browser
DEBUG - 2018-09-29 05:57:17 --> Total execution time: 0.1670
INFO - 2018-09-29 05:57:25 --> Config Class Initialized
INFO - 2018-09-29 05:57:25 --> Hooks Class Initialized
DEBUG - 2018-09-29 05:57:25 --> UTF-8 Support Enabled
INFO - 2018-09-29 05:57:25 --> Utf8 Class Initialized
INFO - 2018-09-29 05:57:25 --> URI Class Initialized
INFO - 2018-09-29 05:57:25 --> Router Class Initialized
INFO - 2018-09-29 05:57:25 --> Output Class Initialized
INFO - 2018-09-29 05:57:25 --> Security Class Initialized
DEBUG - 2018-09-29 05:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 05:57:25 --> Input Class Initialized
INFO - 2018-09-29 05:57:25 --> Language Class Initialized
INFO - 2018-09-29 05:57:25 --> Loader Class Initialized
INFO - 2018-09-29 05:57:25 --> Helper loaded: url_helper
INFO - 2018-09-29 05:57:25 --> Helper loaded: form_helper
INFO - 2018-09-29 05:57:25 --> Helper loaded: html_helper
INFO - 2018-09-29 05:57:25 --> Database Driver Class Initialized
INFO - 2018-09-29 05:57:25 --> Form Validation Class Initialized
DEBUG - 2018-09-29 05:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 05:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 05:57:25 --> Model "User_model" initialized
INFO - 2018-09-29 05:57:25 --> Model "Project_model" initialized
INFO - 2018-09-29 05:57:25 --> Model "Tasks_model" initialized
INFO - 2018-09-29 05:57:25 --> Model "Lists_model" initialized
INFO - 2018-09-29 05:57:25 --> Controller Class Initialized
INFO - 2018-09-29 05:57:25 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 05:57:25 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/create_project.php
INFO - 2018-09-29 05:57:25 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 05:57:25 --> Final output sent to browser
DEBUG - 2018-09-29 05:57:25 --> Total execution time: 0.0710
INFO - 2018-09-29 05:57:48 --> Config Class Initialized
INFO - 2018-09-29 05:57:48 --> Hooks Class Initialized
DEBUG - 2018-09-29 05:57:48 --> UTF-8 Support Enabled
INFO - 2018-09-29 05:57:48 --> Utf8 Class Initialized
INFO - 2018-09-29 05:57:48 --> URI Class Initialized
INFO - 2018-09-29 05:57:48 --> Router Class Initialized
INFO - 2018-09-29 05:57:48 --> Output Class Initialized
INFO - 2018-09-29 05:57:48 --> Security Class Initialized
DEBUG - 2018-09-29 05:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 05:57:48 --> Input Class Initialized
INFO - 2018-09-29 05:57:48 --> Language Class Initialized
INFO - 2018-09-29 05:57:48 --> Loader Class Initialized
INFO - 2018-09-29 05:57:48 --> Helper loaded: url_helper
INFO - 2018-09-29 05:57:48 --> Helper loaded: form_helper
INFO - 2018-09-29 05:57:48 --> Helper loaded: html_helper
INFO - 2018-09-29 05:57:48 --> Database Driver Class Initialized
INFO - 2018-09-29 05:57:48 --> Form Validation Class Initialized
DEBUG - 2018-09-29 05:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 05:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 05:57:48 --> Model "User_model" initialized
INFO - 2018-09-29 05:57:48 --> Model "Project_model" initialized
INFO - 2018-09-29 05:57:48 --> Model "Tasks_model" initialized
INFO - 2018-09-29 05:57:48 --> Model "Lists_model" initialized
INFO - 2018-09-29 05:57:48 --> Controller Class Initialized
INFO - 2018-09-29 05:57:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-29 05:57:48 --> Config Class Initialized
INFO - 2018-09-29 05:57:48 --> Hooks Class Initialized
DEBUG - 2018-09-29 05:57:48 --> UTF-8 Support Enabled
INFO - 2018-09-29 05:57:48 --> Utf8 Class Initialized
INFO - 2018-09-29 05:57:48 --> URI Class Initialized
INFO - 2018-09-29 05:57:48 --> Router Class Initialized
INFO - 2018-09-29 05:57:48 --> Output Class Initialized
INFO - 2018-09-29 05:57:48 --> Security Class Initialized
DEBUG - 2018-09-29 05:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 05:57:48 --> Input Class Initialized
INFO - 2018-09-29 05:57:48 --> Language Class Initialized
INFO - 2018-09-29 05:57:48 --> Loader Class Initialized
INFO - 2018-09-29 05:57:48 --> Helper loaded: url_helper
INFO - 2018-09-29 05:57:48 --> Helper loaded: form_helper
INFO - 2018-09-29 05:57:48 --> Helper loaded: html_helper
INFO - 2018-09-29 05:57:48 --> Database Driver Class Initialized
INFO - 2018-09-29 05:57:48 --> Form Validation Class Initialized
DEBUG - 2018-09-29 05:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 05:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 05:57:48 --> Model "User_model" initialized
INFO - 2018-09-29 05:57:48 --> Model "Project_model" initialized
INFO - 2018-09-29 05:57:48 --> Model "Tasks_model" initialized
INFO - 2018-09-29 05:57:48 --> Model "Lists_model" initialized
INFO - 2018-09-29 05:57:48 --> Controller Class Initialized
INFO - 2018-09-29 05:57:48 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 05:57:48 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-29 05:57:48 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 05:57:48 --> Final output sent to browser
DEBUG - 2018-09-29 05:57:48 --> Total execution time: 0.0610
INFO - 2018-09-29 05:57:52 --> Config Class Initialized
INFO - 2018-09-29 05:57:52 --> Hooks Class Initialized
DEBUG - 2018-09-29 05:57:52 --> UTF-8 Support Enabled
INFO - 2018-09-29 05:57:52 --> Utf8 Class Initialized
INFO - 2018-09-29 05:57:52 --> URI Class Initialized
INFO - 2018-09-29 05:57:52 --> Router Class Initialized
INFO - 2018-09-29 05:57:52 --> Output Class Initialized
INFO - 2018-09-29 05:57:52 --> Security Class Initialized
DEBUG - 2018-09-29 05:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 05:57:52 --> Input Class Initialized
INFO - 2018-09-29 05:57:52 --> Language Class Initialized
INFO - 2018-09-29 05:57:52 --> Loader Class Initialized
INFO - 2018-09-29 05:57:52 --> Helper loaded: url_helper
INFO - 2018-09-29 05:57:52 --> Helper loaded: form_helper
INFO - 2018-09-29 05:57:52 --> Helper loaded: html_helper
INFO - 2018-09-29 05:57:52 --> Database Driver Class Initialized
INFO - 2018-09-29 05:57:52 --> Form Validation Class Initialized
DEBUG - 2018-09-29 05:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 05:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 05:57:52 --> Model "User_model" initialized
INFO - 2018-09-29 05:57:52 --> Model "Project_model" initialized
INFO - 2018-09-29 05:57:52 --> Model "Tasks_model" initialized
INFO - 2018-09-29 05:57:52 --> Model "Lists_model" initialized
INFO - 2018-09-29 05:57:52 --> Controller Class Initialized
INFO - 2018-09-29 05:57:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 05:57:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-29 05:57:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 05:57:52 --> Final output sent to browser
DEBUG - 2018-09-29 05:57:52 --> Total execution time: 0.0560
INFO - 2018-09-29 05:57:54 --> Config Class Initialized
INFO - 2018-09-29 05:57:54 --> Hooks Class Initialized
DEBUG - 2018-09-29 05:57:54 --> UTF-8 Support Enabled
INFO - 2018-09-29 05:57:54 --> Utf8 Class Initialized
INFO - 2018-09-29 05:57:54 --> URI Class Initialized
INFO - 2018-09-29 05:57:54 --> Router Class Initialized
INFO - 2018-09-29 05:57:54 --> Output Class Initialized
INFO - 2018-09-29 05:57:54 --> Security Class Initialized
DEBUG - 2018-09-29 05:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 05:57:54 --> Input Class Initialized
INFO - 2018-09-29 05:57:54 --> Language Class Initialized
INFO - 2018-09-29 05:57:54 --> Loader Class Initialized
INFO - 2018-09-29 05:57:54 --> Helper loaded: url_helper
INFO - 2018-09-29 05:57:54 --> Helper loaded: form_helper
INFO - 2018-09-29 05:57:54 --> Helper loaded: html_helper
INFO - 2018-09-29 05:57:54 --> Database Driver Class Initialized
INFO - 2018-09-29 05:57:54 --> Form Validation Class Initialized
DEBUG - 2018-09-29 05:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 05:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 05:57:54 --> Model "User_model" initialized
INFO - 2018-09-29 05:57:54 --> Model "Project_model" initialized
INFO - 2018-09-29 05:57:54 --> Model "Tasks_model" initialized
INFO - 2018-09-29 05:57:54 --> Model "Lists_model" initialized
INFO - 2018-09-29 05:57:54 --> Controller Class Initialized
INFO - 2018-09-29 05:57:54 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 05:57:54 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-29 05:57:54 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 05:57:54 --> Final output sent to browser
DEBUG - 2018-09-29 05:57:54 --> Total execution time: 0.0640
INFO - 2018-09-29 05:59:07 --> Config Class Initialized
INFO - 2018-09-29 05:59:07 --> Hooks Class Initialized
DEBUG - 2018-09-29 05:59:07 --> UTF-8 Support Enabled
INFO - 2018-09-29 05:59:07 --> Utf8 Class Initialized
INFO - 2018-09-29 05:59:07 --> URI Class Initialized
INFO - 2018-09-29 05:59:07 --> Router Class Initialized
INFO - 2018-09-29 05:59:07 --> Output Class Initialized
INFO - 2018-09-29 05:59:07 --> Security Class Initialized
DEBUG - 2018-09-29 05:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 05:59:07 --> Input Class Initialized
INFO - 2018-09-29 05:59:07 --> Language Class Initialized
INFO - 2018-09-29 05:59:07 --> Loader Class Initialized
INFO - 2018-09-29 05:59:07 --> Helper loaded: url_helper
INFO - 2018-09-29 05:59:07 --> Helper loaded: form_helper
INFO - 2018-09-29 05:59:07 --> Helper loaded: html_helper
INFO - 2018-09-29 05:59:07 --> Database Driver Class Initialized
INFO - 2018-09-29 05:59:07 --> Form Validation Class Initialized
DEBUG - 2018-09-29 05:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 05:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 05:59:07 --> Model "User_model" initialized
ERROR - 2018-09-29 05:59:07 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' D:\xampp\htdocs\code_igniter\application\models\project_models\project_model.php 16
INFO - 2018-09-29 05:59:14 --> Config Class Initialized
INFO - 2018-09-29 05:59:14 --> Hooks Class Initialized
DEBUG - 2018-09-29 05:59:14 --> UTF-8 Support Enabled
INFO - 2018-09-29 05:59:14 --> Utf8 Class Initialized
INFO - 2018-09-29 05:59:14 --> URI Class Initialized
INFO - 2018-09-29 05:59:14 --> Router Class Initialized
INFO - 2018-09-29 05:59:14 --> Output Class Initialized
INFO - 2018-09-29 05:59:14 --> Security Class Initialized
DEBUG - 2018-09-29 05:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 05:59:14 --> Input Class Initialized
INFO - 2018-09-29 05:59:14 --> Language Class Initialized
INFO - 2018-09-29 05:59:14 --> Loader Class Initialized
INFO - 2018-09-29 05:59:14 --> Helper loaded: url_helper
INFO - 2018-09-29 05:59:14 --> Helper loaded: form_helper
INFO - 2018-09-29 05:59:14 --> Helper loaded: html_helper
INFO - 2018-09-29 05:59:14 --> Database Driver Class Initialized
INFO - 2018-09-29 05:59:14 --> Form Validation Class Initialized
DEBUG - 2018-09-29 05:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 05:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 05:59:14 --> Model "User_model" initialized
INFO - 2018-09-29 05:59:14 --> Model "Project_model" initialized
INFO - 2018-09-29 05:59:14 --> Model "Tasks_model" initialized
INFO - 2018-09-29 05:59:14 --> Model "Lists_model" initialized
INFO - 2018-09-29 05:59:14 --> Controller Class Initialized
INFO - 2018-09-29 05:59:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 05:59:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/create_project.php
INFO - 2018-09-29 05:59:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 05:59:14 --> Final output sent to browser
DEBUG - 2018-09-29 05:59:14 --> Total execution time: 0.0610
INFO - 2018-09-29 05:59:29 --> Config Class Initialized
INFO - 2018-09-29 05:59:29 --> Hooks Class Initialized
DEBUG - 2018-09-29 05:59:29 --> UTF-8 Support Enabled
INFO - 2018-09-29 05:59:29 --> Utf8 Class Initialized
INFO - 2018-09-29 05:59:29 --> URI Class Initialized
INFO - 2018-09-29 05:59:29 --> Router Class Initialized
INFO - 2018-09-29 05:59:29 --> Output Class Initialized
INFO - 2018-09-29 05:59:29 --> Security Class Initialized
DEBUG - 2018-09-29 05:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 05:59:29 --> Input Class Initialized
INFO - 2018-09-29 05:59:29 --> Language Class Initialized
INFO - 2018-09-29 05:59:29 --> Loader Class Initialized
INFO - 2018-09-29 05:59:29 --> Helper loaded: url_helper
INFO - 2018-09-29 05:59:29 --> Helper loaded: form_helper
INFO - 2018-09-29 05:59:29 --> Helper loaded: html_helper
INFO - 2018-09-29 05:59:29 --> Database Driver Class Initialized
INFO - 2018-09-29 05:59:29 --> Form Validation Class Initialized
DEBUG - 2018-09-29 05:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 05:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 05:59:29 --> Model "User_model" initialized
INFO - 2018-09-29 05:59:29 --> Model "Project_model" initialized
INFO - 2018-09-29 05:59:29 --> Model "Tasks_model" initialized
INFO - 2018-09-29 05:59:29 --> Model "Lists_model" initialized
INFO - 2018-09-29 05:59:29 --> Controller Class Initialized
INFO - 2018-09-29 05:59:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-29 05:59:29 --> Config Class Initialized
INFO - 2018-09-29 05:59:29 --> Hooks Class Initialized
DEBUG - 2018-09-29 05:59:29 --> UTF-8 Support Enabled
INFO - 2018-09-29 05:59:29 --> Utf8 Class Initialized
INFO - 2018-09-29 05:59:29 --> URI Class Initialized
INFO - 2018-09-29 05:59:29 --> Router Class Initialized
INFO - 2018-09-29 05:59:29 --> Output Class Initialized
INFO - 2018-09-29 05:59:29 --> Security Class Initialized
DEBUG - 2018-09-29 05:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 05:59:29 --> Input Class Initialized
INFO - 2018-09-29 05:59:29 --> Language Class Initialized
INFO - 2018-09-29 05:59:29 --> Loader Class Initialized
INFO - 2018-09-29 05:59:29 --> Helper loaded: url_helper
INFO - 2018-09-29 05:59:29 --> Helper loaded: form_helper
INFO - 2018-09-29 05:59:29 --> Helper loaded: html_helper
INFO - 2018-09-29 05:59:29 --> Database Driver Class Initialized
INFO - 2018-09-29 05:59:29 --> Form Validation Class Initialized
DEBUG - 2018-09-29 05:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 05:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 05:59:29 --> Model "User_model" initialized
INFO - 2018-09-29 05:59:29 --> Model "Project_model" initialized
INFO - 2018-09-29 05:59:29 --> Model "Tasks_model" initialized
INFO - 2018-09-29 05:59:29 --> Model "Lists_model" initialized
INFO - 2018-09-29 05:59:29 --> Controller Class Initialized
INFO - 2018-09-29 05:59:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 05:59:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-29 05:59:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 05:59:29 --> Final output sent to browser
DEBUG - 2018-09-29 05:59:29 --> Total execution time: 0.0380
INFO - 2018-09-29 05:59:32 --> Config Class Initialized
INFO - 2018-09-29 05:59:32 --> Hooks Class Initialized
DEBUG - 2018-09-29 05:59:32 --> UTF-8 Support Enabled
INFO - 2018-09-29 05:59:32 --> Utf8 Class Initialized
INFO - 2018-09-29 05:59:32 --> URI Class Initialized
INFO - 2018-09-29 05:59:32 --> Router Class Initialized
INFO - 2018-09-29 05:59:32 --> Output Class Initialized
INFO - 2018-09-29 05:59:32 --> Security Class Initialized
DEBUG - 2018-09-29 05:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 05:59:32 --> Input Class Initialized
INFO - 2018-09-29 05:59:32 --> Language Class Initialized
INFO - 2018-09-29 05:59:32 --> Loader Class Initialized
INFO - 2018-09-29 05:59:32 --> Helper loaded: url_helper
INFO - 2018-09-29 05:59:32 --> Helper loaded: form_helper
INFO - 2018-09-29 05:59:32 --> Helper loaded: html_helper
INFO - 2018-09-29 05:59:32 --> Database Driver Class Initialized
INFO - 2018-09-29 05:59:32 --> Form Validation Class Initialized
DEBUG - 2018-09-29 05:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 05:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 05:59:32 --> Model "User_model" initialized
INFO - 2018-09-29 05:59:32 --> Model "Project_model" initialized
INFO - 2018-09-29 05:59:32 --> Model "Tasks_model" initialized
INFO - 2018-09-29 05:59:32 --> Model "Lists_model" initialized
INFO - 2018-09-29 05:59:32 --> Controller Class Initialized
INFO - 2018-09-29 05:59:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 05:59:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-29 05:59:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 05:59:32 --> Final output sent to browser
DEBUG - 2018-09-29 05:59:32 --> Total execution time: 0.0560
INFO - 2018-09-29 06:07:17 --> Config Class Initialized
INFO - 2018-09-29 06:07:17 --> Hooks Class Initialized
DEBUG - 2018-09-29 06:07:17 --> UTF-8 Support Enabled
INFO - 2018-09-29 06:07:17 --> Utf8 Class Initialized
INFO - 2018-09-29 06:07:17 --> URI Class Initialized
INFO - 2018-09-29 06:07:17 --> Router Class Initialized
INFO - 2018-09-29 06:07:17 --> Output Class Initialized
INFO - 2018-09-29 06:07:17 --> Security Class Initialized
DEBUG - 2018-09-29 06:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 06:07:17 --> Input Class Initialized
INFO - 2018-09-29 06:07:17 --> Language Class Initialized
INFO - 2018-09-29 06:07:17 --> Loader Class Initialized
INFO - 2018-09-29 06:07:17 --> Helper loaded: url_helper
INFO - 2018-09-29 06:07:17 --> Helper loaded: form_helper
INFO - 2018-09-29 06:07:17 --> Helper loaded: html_helper
INFO - 2018-09-29 06:07:17 --> Database Driver Class Initialized
INFO - 2018-09-29 06:07:17 --> Form Validation Class Initialized
DEBUG - 2018-09-29 06:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 06:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 06:07:17 --> Model "User_model" initialized
INFO - 2018-09-29 06:07:17 --> Model "Project_model" initialized
INFO - 2018-09-29 06:07:17 --> Model "Tasks_model" initialized
INFO - 2018-09-29 06:07:17 --> Model "Lists_model" initialized
INFO - 2018-09-29 06:07:17 --> Controller Class Initialized
INFO - 2018-09-29 06:07:17 --> Config Class Initialized
INFO - 2018-09-29 06:07:17 --> Hooks Class Initialized
DEBUG - 2018-09-29 06:07:17 --> UTF-8 Support Enabled
INFO - 2018-09-29 06:07:17 --> Utf8 Class Initialized
INFO - 2018-09-29 06:07:17 --> URI Class Initialized
INFO - 2018-09-29 06:07:17 --> Router Class Initialized
INFO - 2018-09-29 06:07:17 --> Output Class Initialized
INFO - 2018-09-29 06:07:17 --> Security Class Initialized
DEBUG - 2018-09-29 06:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 06:07:17 --> Input Class Initialized
INFO - 2018-09-29 06:07:17 --> Language Class Initialized
INFO - 2018-09-29 06:07:17 --> Loader Class Initialized
INFO - 2018-09-29 06:07:17 --> Helper loaded: url_helper
INFO - 2018-09-29 06:07:17 --> Helper loaded: form_helper
INFO - 2018-09-29 06:07:17 --> Helper loaded: html_helper
INFO - 2018-09-29 06:07:17 --> Database Driver Class Initialized
INFO - 2018-09-29 06:07:17 --> Form Validation Class Initialized
DEBUG - 2018-09-29 06:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 06:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 06:07:17 --> Model "User_model" initialized
INFO - 2018-09-29 06:07:17 --> Model "Project_model" initialized
INFO - 2018-09-29 06:07:17 --> Model "Tasks_model" initialized
INFO - 2018-09-29 06:07:17 --> Model "Lists_model" initialized
INFO - 2018-09-29 06:07:17 --> Controller Class Initialized
INFO - 2018-09-29 06:07:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 06:07:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-29 06:07:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 06:07:17 --> Final output sent to browser
DEBUG - 2018-09-29 06:07:17 --> Total execution time: 0.0440
INFO - 2018-09-29 12:05:09 --> Config Class Initialized
INFO - 2018-09-29 12:05:09 --> Hooks Class Initialized
DEBUG - 2018-09-29 12:05:09 --> UTF-8 Support Enabled
INFO - 2018-09-29 12:05:09 --> Utf8 Class Initialized
INFO - 2018-09-29 12:05:09 --> URI Class Initialized
INFO - 2018-09-29 12:05:09 --> Router Class Initialized
INFO - 2018-09-29 12:05:09 --> Output Class Initialized
INFO - 2018-09-29 12:05:09 --> Security Class Initialized
DEBUG - 2018-09-29 12:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 12:05:09 --> Input Class Initialized
INFO - 2018-09-29 12:05:09 --> Language Class Initialized
INFO - 2018-09-29 12:05:09 --> Loader Class Initialized
INFO - 2018-09-29 12:05:09 --> Helper loaded: url_helper
INFO - 2018-09-29 12:05:09 --> Helper loaded: form_helper
INFO - 2018-09-29 12:05:09 --> Helper loaded: html_helper
INFO - 2018-09-29 12:05:09 --> Database Driver Class Initialized
INFO - 2018-09-29 12:05:09 --> Form Validation Class Initialized
DEBUG - 2018-09-29 12:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 12:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 12:05:09 --> Model "User_model" initialized
INFO - 2018-09-29 12:05:09 --> Model "Project_model" initialized
INFO - 2018-09-29 12:05:09 --> Model "Tasks_model" initialized
INFO - 2018-09-29 12:05:09 --> Model "Lists_model" initialized
INFO - 2018-09-29 12:05:09 --> Controller Class Initialized
INFO - 2018-09-29 12:05:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-29 12:05:09 --> Config Class Initialized
INFO - 2018-09-29 12:05:09 --> Hooks Class Initialized
DEBUG - 2018-09-29 12:05:09 --> UTF-8 Support Enabled
INFO - 2018-09-29 12:05:09 --> Utf8 Class Initialized
INFO - 2018-09-29 12:05:09 --> URI Class Initialized
INFO - 2018-09-29 12:05:09 --> Router Class Initialized
INFO - 2018-09-29 12:05:09 --> Output Class Initialized
INFO - 2018-09-29 12:05:09 --> Security Class Initialized
DEBUG - 2018-09-29 12:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 12:05:09 --> Input Class Initialized
INFO - 2018-09-29 12:05:09 --> Language Class Initialized
INFO - 2018-09-29 12:05:09 --> Loader Class Initialized
INFO - 2018-09-29 12:05:09 --> Helper loaded: url_helper
INFO - 2018-09-29 12:05:09 --> Helper loaded: form_helper
INFO - 2018-09-29 12:05:09 --> Helper loaded: html_helper
INFO - 2018-09-29 12:05:09 --> Database Driver Class Initialized
INFO - 2018-09-29 12:05:09 --> Form Validation Class Initialized
DEBUG - 2018-09-29 12:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 12:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 12:05:09 --> Model "User_model" initialized
INFO - 2018-09-29 12:05:09 --> Model "Project_model" initialized
INFO - 2018-09-29 12:05:09 --> Model "Tasks_model" initialized
INFO - 2018-09-29 12:05:09 --> Model "Lists_model" initialized
INFO - 2018-09-29 12:05:09 --> Controller Class Initialized
INFO - 2018-09-29 12:05:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 12:05:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-29 12:05:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 12:05:09 --> Final output sent to browser
DEBUG - 2018-09-29 12:05:09 --> Total execution time: 0.0450
INFO - 2018-09-29 13:22:16 --> Config Class Initialized
INFO - 2018-09-29 13:22:16 --> Hooks Class Initialized
DEBUG - 2018-09-29 13:22:16 --> UTF-8 Support Enabled
INFO - 2018-09-29 13:22:16 --> Utf8 Class Initialized
INFO - 2018-09-29 13:22:16 --> URI Class Initialized
INFO - 2018-09-29 13:22:16 --> Router Class Initialized
INFO - 2018-09-29 13:22:17 --> Output Class Initialized
INFO - 2018-09-29 13:22:17 --> Security Class Initialized
DEBUG - 2018-09-29 13:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 13:22:17 --> Input Class Initialized
INFO - 2018-09-29 13:22:17 --> Language Class Initialized
ERROR - 2018-09-29 13:22:17 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file D:\xampp\htdocs\code_igniter\application\controllers\project_controllers\projects.php 59
INFO - 2018-09-29 13:23:13 --> Config Class Initialized
INFO - 2018-09-29 13:23:13 --> Hooks Class Initialized
DEBUG - 2018-09-29 13:23:13 --> UTF-8 Support Enabled
INFO - 2018-09-29 13:23:13 --> Utf8 Class Initialized
INFO - 2018-09-29 13:23:13 --> URI Class Initialized
INFO - 2018-09-29 13:23:13 --> Router Class Initialized
INFO - 2018-09-29 13:23:13 --> Output Class Initialized
INFO - 2018-09-29 13:23:13 --> Security Class Initialized
DEBUG - 2018-09-29 13:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 13:23:13 --> Input Class Initialized
INFO - 2018-09-29 13:23:13 --> Language Class Initialized
INFO - 2018-09-29 13:23:13 --> Loader Class Initialized
INFO - 2018-09-29 13:23:13 --> Helper loaded: url_helper
INFO - 2018-09-29 13:23:13 --> Helper loaded: form_helper
INFO - 2018-09-29 13:23:13 --> Helper loaded: html_helper
INFO - 2018-09-29 13:23:13 --> Database Driver Class Initialized
INFO - 2018-09-29 13:23:13 --> Form Validation Class Initialized
DEBUG - 2018-09-29 13:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 13:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 13:23:13 --> Model "User_model" initialized
ERROR - 2018-09-29 13:23:13 --> Severity: error --> Exception: syntax error, unexpected '$project_name' (T_VARIABLE) D:\xampp\htdocs\code_igniter\application\models\project_models\project_model.php 25
INFO - 2018-09-29 13:23:41 --> Config Class Initialized
INFO - 2018-09-29 13:23:41 --> Hooks Class Initialized
DEBUG - 2018-09-29 13:23:41 --> UTF-8 Support Enabled
INFO - 2018-09-29 13:23:41 --> Utf8 Class Initialized
INFO - 2018-09-29 13:23:41 --> URI Class Initialized
INFO - 2018-09-29 13:23:41 --> Router Class Initialized
INFO - 2018-09-29 13:23:41 --> Output Class Initialized
INFO - 2018-09-29 13:23:41 --> Security Class Initialized
DEBUG - 2018-09-29 13:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 13:23:41 --> Input Class Initialized
INFO - 2018-09-29 13:23:41 --> Language Class Initialized
INFO - 2018-09-29 13:23:41 --> Loader Class Initialized
INFO - 2018-09-29 13:23:41 --> Helper loaded: url_helper
INFO - 2018-09-29 13:23:41 --> Helper loaded: form_helper
INFO - 2018-09-29 13:23:41 --> Helper loaded: html_helper
INFO - 2018-09-29 13:23:41 --> Database Driver Class Initialized
INFO - 2018-09-29 13:23:41 --> Form Validation Class Initialized
DEBUG - 2018-09-29 13:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 13:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 13:23:41 --> Model "User_model" initialized
ERROR - 2018-09-29 13:23:41 --> Severity: error --> Exception: syntax error, unexpected 'query' (T_STRING) D:\xampp\htdocs\code_igniter\application\models\project_models\project_model.php 38
INFO - 2018-09-29 13:24:15 --> Config Class Initialized
INFO - 2018-09-29 13:24:15 --> Hooks Class Initialized
DEBUG - 2018-09-29 13:24:15 --> UTF-8 Support Enabled
INFO - 2018-09-29 13:24:15 --> Utf8 Class Initialized
INFO - 2018-09-29 13:24:15 --> URI Class Initialized
INFO - 2018-09-29 13:24:15 --> Router Class Initialized
INFO - 2018-09-29 13:24:15 --> Output Class Initialized
INFO - 2018-09-29 13:24:15 --> Security Class Initialized
DEBUG - 2018-09-29 13:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 13:24:15 --> Input Class Initialized
INFO - 2018-09-29 13:24:15 --> Language Class Initialized
INFO - 2018-09-29 13:24:15 --> Loader Class Initialized
INFO - 2018-09-29 13:24:15 --> Helper loaded: url_helper
INFO - 2018-09-29 13:24:15 --> Helper loaded: form_helper
INFO - 2018-09-29 13:24:15 --> Helper loaded: html_helper
INFO - 2018-09-29 13:24:15 --> Database Driver Class Initialized
INFO - 2018-09-29 13:24:15 --> Form Validation Class Initialized
DEBUG - 2018-09-29 13:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 13:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 13:24:15 --> Model "User_model" initialized
INFO - 2018-09-29 13:24:15 --> Model "Project_model" initialized
INFO - 2018-09-29 13:24:15 --> Model "Tasks_model" initialized
INFO - 2018-09-29 13:24:15 --> Model "Lists_model" initialized
INFO - 2018-09-29 13:24:15 --> Controller Class Initialized
INFO - 2018-09-29 13:24:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 13:24:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-29 13:24:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 13:24:15 --> Final output sent to browser
DEBUG - 2018-09-29 13:24:15 --> Total execution time: 0.0520
INFO - 2018-09-29 13:24:17 --> Config Class Initialized
INFO - 2018-09-29 13:24:17 --> Hooks Class Initialized
DEBUG - 2018-09-29 13:24:17 --> UTF-8 Support Enabled
INFO - 2018-09-29 13:24:17 --> Utf8 Class Initialized
INFO - 2018-09-29 13:24:17 --> URI Class Initialized
INFO - 2018-09-29 13:24:17 --> Router Class Initialized
INFO - 2018-09-29 13:24:17 --> Output Class Initialized
INFO - 2018-09-29 13:24:17 --> Security Class Initialized
DEBUG - 2018-09-29 13:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 13:24:17 --> Input Class Initialized
INFO - 2018-09-29 13:24:17 --> Language Class Initialized
INFO - 2018-09-29 13:24:17 --> Loader Class Initialized
INFO - 2018-09-29 13:24:17 --> Helper loaded: url_helper
INFO - 2018-09-29 13:24:17 --> Helper loaded: form_helper
INFO - 2018-09-29 13:24:17 --> Helper loaded: html_helper
INFO - 2018-09-29 13:24:17 --> Database Driver Class Initialized
INFO - 2018-09-29 13:24:17 --> Form Validation Class Initialized
DEBUG - 2018-09-29 13:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 13:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 13:24:17 --> Model "User_model" initialized
INFO - 2018-09-29 13:24:17 --> Model "Project_model" initialized
INFO - 2018-09-29 13:24:17 --> Model "Tasks_model" initialized
INFO - 2018-09-29 13:24:17 --> Model "Lists_model" initialized
INFO - 2018-09-29 13:24:17 --> Controller Class Initialized
INFO - 2018-09-29 13:24:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 13:24:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/create_project.php
INFO - 2018-09-29 13:24:17 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 13:24:17 --> Final output sent to browser
DEBUG - 2018-09-29 13:24:17 --> Total execution time: 0.0880
INFO - 2018-09-29 13:24:37 --> Config Class Initialized
INFO - 2018-09-29 13:24:37 --> Hooks Class Initialized
DEBUG - 2018-09-29 13:24:37 --> UTF-8 Support Enabled
INFO - 2018-09-29 13:24:37 --> Utf8 Class Initialized
INFO - 2018-09-29 13:24:37 --> URI Class Initialized
INFO - 2018-09-29 13:24:37 --> Router Class Initialized
INFO - 2018-09-29 13:24:37 --> Output Class Initialized
INFO - 2018-09-29 13:24:37 --> Security Class Initialized
DEBUG - 2018-09-29 13:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 13:24:37 --> Input Class Initialized
INFO - 2018-09-29 13:24:37 --> Language Class Initialized
INFO - 2018-09-29 13:24:37 --> Loader Class Initialized
INFO - 2018-09-29 13:24:37 --> Helper loaded: url_helper
INFO - 2018-09-29 13:24:37 --> Helper loaded: form_helper
INFO - 2018-09-29 13:24:37 --> Helper loaded: html_helper
INFO - 2018-09-29 13:24:37 --> Database Driver Class Initialized
INFO - 2018-09-29 13:24:37 --> Form Validation Class Initialized
DEBUG - 2018-09-29 13:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 13:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 13:24:37 --> Model "User_model" initialized
INFO - 2018-09-29 13:24:37 --> Model "Project_model" initialized
INFO - 2018-09-29 13:24:37 --> Model "Tasks_model" initialized
INFO - 2018-09-29 13:24:37 --> Model "Lists_model" initialized
INFO - 2018-09-29 13:24:37 --> Controller Class Initialized
INFO - 2018-09-29 13:24:37 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-09-29 13:24:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''Zend Framework'}, {'Another popular PHP framework'})' at line 1 - Invalid query: INSERT INTO projects(project_user_id, project_name, project_body) VALUES(2, {'Zend Framework'}, {'Another popular PHP framework'}) 
INFO - 2018-09-29 13:24:37 --> Language file loaded: language/english/db_lang.php
INFO - 2018-09-29 13:26:55 --> Config Class Initialized
INFO - 2018-09-29 13:26:55 --> Hooks Class Initialized
DEBUG - 2018-09-29 13:26:55 --> UTF-8 Support Enabled
INFO - 2018-09-29 13:26:55 --> Utf8 Class Initialized
INFO - 2018-09-29 13:26:55 --> URI Class Initialized
INFO - 2018-09-29 13:26:55 --> Router Class Initialized
INFO - 2018-09-29 13:26:55 --> Output Class Initialized
INFO - 2018-09-29 13:26:55 --> Security Class Initialized
DEBUG - 2018-09-29 13:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 13:26:55 --> Input Class Initialized
INFO - 2018-09-29 13:26:55 --> Language Class Initialized
INFO - 2018-09-29 13:26:55 --> Loader Class Initialized
INFO - 2018-09-29 13:26:55 --> Helper loaded: url_helper
INFO - 2018-09-29 13:26:55 --> Helper loaded: form_helper
INFO - 2018-09-29 13:26:55 --> Helper loaded: html_helper
INFO - 2018-09-29 13:26:55 --> Database Driver Class Initialized
INFO - 2018-09-29 13:26:55 --> Form Validation Class Initialized
DEBUG - 2018-09-29 13:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 13:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 13:26:55 --> Model "User_model" initialized
INFO - 2018-09-29 13:26:55 --> Model "Project_model" initialized
INFO - 2018-09-29 13:26:55 --> Model "Tasks_model" initialized
INFO - 2018-09-29 13:26:55 --> Model "Lists_model" initialized
INFO - 2018-09-29 13:26:55 --> Controller Class Initialized
INFO - 2018-09-29 13:26:55 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 13:26:55 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-29 13:26:55 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 13:26:55 --> Final output sent to browser
DEBUG - 2018-09-29 13:26:55 --> Total execution time: 0.0590
INFO - 2018-09-29 13:26:57 --> Config Class Initialized
INFO - 2018-09-29 13:26:57 --> Hooks Class Initialized
DEBUG - 2018-09-29 13:26:57 --> UTF-8 Support Enabled
INFO - 2018-09-29 13:26:57 --> Utf8 Class Initialized
INFO - 2018-09-29 13:26:57 --> URI Class Initialized
INFO - 2018-09-29 13:26:57 --> Router Class Initialized
INFO - 2018-09-29 13:26:57 --> Output Class Initialized
INFO - 2018-09-29 13:26:57 --> Security Class Initialized
DEBUG - 2018-09-29 13:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 13:26:57 --> Input Class Initialized
INFO - 2018-09-29 13:26:57 --> Language Class Initialized
INFO - 2018-09-29 13:26:57 --> Loader Class Initialized
INFO - 2018-09-29 13:26:57 --> Helper loaded: url_helper
INFO - 2018-09-29 13:26:57 --> Helper loaded: form_helper
INFO - 2018-09-29 13:26:57 --> Helper loaded: html_helper
INFO - 2018-09-29 13:26:57 --> Database Driver Class Initialized
INFO - 2018-09-29 13:26:57 --> Form Validation Class Initialized
DEBUG - 2018-09-29 13:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 13:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 13:26:57 --> Model "User_model" initialized
INFO - 2018-09-29 13:26:57 --> Model "Project_model" initialized
INFO - 2018-09-29 13:26:57 --> Model "Tasks_model" initialized
INFO - 2018-09-29 13:26:57 --> Model "Lists_model" initialized
INFO - 2018-09-29 13:26:57 --> Controller Class Initialized
INFO - 2018-09-29 13:26:57 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 13:26:57 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/create_project.php
INFO - 2018-09-29 13:26:57 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 13:26:57 --> Final output sent to browser
DEBUG - 2018-09-29 13:26:57 --> Total execution time: 0.0550
INFO - 2018-09-29 13:27:14 --> Config Class Initialized
INFO - 2018-09-29 13:27:14 --> Hooks Class Initialized
DEBUG - 2018-09-29 13:27:14 --> UTF-8 Support Enabled
INFO - 2018-09-29 13:27:14 --> Utf8 Class Initialized
INFO - 2018-09-29 13:27:14 --> URI Class Initialized
INFO - 2018-09-29 13:27:14 --> Router Class Initialized
INFO - 2018-09-29 13:27:14 --> Output Class Initialized
INFO - 2018-09-29 13:27:14 --> Security Class Initialized
DEBUG - 2018-09-29 13:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 13:27:14 --> Input Class Initialized
INFO - 2018-09-29 13:27:14 --> Language Class Initialized
INFO - 2018-09-29 13:27:14 --> Loader Class Initialized
INFO - 2018-09-29 13:27:14 --> Helper loaded: url_helper
INFO - 2018-09-29 13:27:14 --> Helper loaded: form_helper
INFO - 2018-09-29 13:27:14 --> Helper loaded: html_helper
INFO - 2018-09-29 13:27:14 --> Database Driver Class Initialized
INFO - 2018-09-29 13:27:14 --> Form Validation Class Initialized
DEBUG - 2018-09-29 13:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 13:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 13:27:14 --> Model "User_model" initialized
INFO - 2018-09-29 13:27:14 --> Model "Project_model" initialized
INFO - 2018-09-29 13:27:14 --> Model "Tasks_model" initialized
INFO - 2018-09-29 13:27:14 --> Model "Lists_model" initialized
INFO - 2018-09-29 13:27:14 --> Controller Class Initialized
INFO - 2018-09-29 13:27:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-29 13:27:14 --> Config Class Initialized
INFO - 2018-09-29 13:27:14 --> Hooks Class Initialized
DEBUG - 2018-09-29 13:27:14 --> UTF-8 Support Enabled
INFO - 2018-09-29 13:27:14 --> Utf8 Class Initialized
INFO - 2018-09-29 13:27:14 --> URI Class Initialized
INFO - 2018-09-29 13:27:14 --> Router Class Initialized
INFO - 2018-09-29 13:27:14 --> Output Class Initialized
INFO - 2018-09-29 13:27:14 --> Security Class Initialized
DEBUG - 2018-09-29 13:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 13:27:14 --> Input Class Initialized
INFO - 2018-09-29 13:27:14 --> Language Class Initialized
INFO - 2018-09-29 13:27:14 --> Loader Class Initialized
INFO - 2018-09-29 13:27:14 --> Helper loaded: url_helper
INFO - 2018-09-29 13:27:14 --> Helper loaded: form_helper
INFO - 2018-09-29 13:27:14 --> Helper loaded: html_helper
INFO - 2018-09-29 13:27:14 --> Database Driver Class Initialized
INFO - 2018-09-29 13:27:14 --> Form Validation Class Initialized
DEBUG - 2018-09-29 13:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 13:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 13:27:14 --> Model "User_model" initialized
INFO - 2018-09-29 13:27:14 --> Model "Project_model" initialized
INFO - 2018-09-29 13:27:14 --> Model "Tasks_model" initialized
INFO - 2018-09-29 13:27:14 --> Model "Lists_model" initialized
INFO - 2018-09-29 13:27:14 --> Controller Class Initialized
INFO - 2018-09-29 13:27:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 13:27:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-29 13:27:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 13:27:14 --> Final output sent to browser
DEBUG - 2018-09-29 13:27:14 --> Total execution time: 0.0700
INFO - 2018-09-29 13:57:06 --> Config Class Initialized
INFO - 2018-09-29 13:57:06 --> Hooks Class Initialized
DEBUG - 2018-09-29 13:57:06 --> UTF-8 Support Enabled
INFO - 2018-09-29 13:57:06 --> Utf8 Class Initialized
INFO - 2018-09-29 13:57:06 --> URI Class Initialized
INFO - 2018-09-29 13:57:06 --> Router Class Initialized
INFO - 2018-09-29 13:57:06 --> Output Class Initialized
INFO - 2018-09-29 13:57:06 --> Security Class Initialized
DEBUG - 2018-09-29 13:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 13:57:06 --> Input Class Initialized
INFO - 2018-09-29 13:57:06 --> Language Class Initialized
INFO - 2018-09-29 13:57:06 --> Loader Class Initialized
INFO - 2018-09-29 13:57:06 --> Helper loaded: url_helper
INFO - 2018-09-29 13:57:06 --> Helper loaded: form_helper
INFO - 2018-09-29 13:57:06 --> Helper loaded: html_helper
INFO - 2018-09-29 13:57:06 --> Database Driver Class Initialized
INFO - 2018-09-29 13:57:06 --> Form Validation Class Initialized
DEBUG - 2018-09-29 13:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 13:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 13:57:06 --> Model "User_model" initialized
INFO - 2018-09-29 13:57:06 --> Model "Project_model" initialized
INFO - 2018-09-29 13:57:06 --> Model "Tasks_model" initialized
INFO - 2018-09-29 13:57:06 --> Model "Lists_model" initialized
INFO - 2018-09-29 13:57:06 --> Controller Class Initialized
INFO - 2018-09-29 13:57:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 13:57:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/create_project.php
INFO - 2018-09-29 13:57:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 13:57:06 --> Final output sent to browser
DEBUG - 2018-09-29 13:57:06 --> Total execution time: 0.0600
INFO - 2018-09-29 13:57:10 --> Config Class Initialized
INFO - 2018-09-29 13:57:10 --> Hooks Class Initialized
DEBUG - 2018-09-29 13:57:10 --> UTF-8 Support Enabled
INFO - 2018-09-29 13:57:10 --> Utf8 Class Initialized
INFO - 2018-09-29 13:57:10 --> URI Class Initialized
INFO - 2018-09-29 13:57:10 --> Router Class Initialized
INFO - 2018-09-29 13:57:10 --> Output Class Initialized
INFO - 2018-09-29 13:57:10 --> Security Class Initialized
DEBUG - 2018-09-29 13:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 13:57:10 --> Input Class Initialized
INFO - 2018-09-29 13:57:10 --> Language Class Initialized
INFO - 2018-09-29 13:57:10 --> Loader Class Initialized
INFO - 2018-09-29 13:57:10 --> Helper loaded: url_helper
INFO - 2018-09-29 13:57:10 --> Helper loaded: form_helper
INFO - 2018-09-29 13:57:10 --> Helper loaded: html_helper
INFO - 2018-09-29 13:57:10 --> Database Driver Class Initialized
INFO - 2018-09-29 13:57:10 --> Form Validation Class Initialized
DEBUG - 2018-09-29 13:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 13:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 13:57:10 --> Model "User_model" initialized
INFO - 2018-09-29 13:57:10 --> Model "Project_model" initialized
INFO - 2018-09-29 13:57:10 --> Model "Tasks_model" initialized
INFO - 2018-09-29 13:57:10 --> Model "Lists_model" initialized
INFO - 2018-09-29 13:57:10 --> Controller Class Initialized
INFO - 2018-09-29 13:57:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-29 13:57:10 --> Final output sent to browser
DEBUG - 2018-09-29 13:57:10 --> Total execution time: 0.0850
INFO - 2018-09-29 14:24:36 --> Config Class Initialized
INFO - 2018-09-29 14:24:36 --> Hooks Class Initialized
DEBUG - 2018-09-29 14:24:36 --> UTF-8 Support Enabled
INFO - 2018-09-29 14:24:36 --> Utf8 Class Initialized
INFO - 2018-09-29 14:24:36 --> URI Class Initialized
INFO - 2018-09-29 14:24:36 --> Router Class Initialized
INFO - 2018-09-29 14:24:36 --> Output Class Initialized
INFO - 2018-09-29 14:24:36 --> Security Class Initialized
DEBUG - 2018-09-29 14:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 14:24:36 --> Input Class Initialized
INFO - 2018-09-29 14:24:36 --> Language Class Initialized
INFO - 2018-09-29 14:24:36 --> Loader Class Initialized
INFO - 2018-09-29 14:24:36 --> Helper loaded: url_helper
INFO - 2018-09-29 14:24:36 --> Helper loaded: form_helper
INFO - 2018-09-29 14:24:36 --> Helper loaded: html_helper
INFO - 2018-09-29 14:24:36 --> Database Driver Class Initialized
INFO - 2018-09-29 14:24:36 --> Form Validation Class Initialized
DEBUG - 2018-09-29 14:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 14:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 14:24:36 --> Model "User_model" initialized
INFO - 2018-09-29 14:24:36 --> Model "Project_model" initialized
INFO - 2018-09-29 14:24:36 --> Model "Tasks_model" initialized
INFO - 2018-09-29 14:24:36 --> Model "Lists_model" initialized
INFO - 2018-09-29 14:24:36 --> Controller Class Initialized
INFO - 2018-09-29 14:24:36 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 14:24:36 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/create_project.php
INFO - 2018-09-29 14:24:36 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 14:24:36 --> Final output sent to browser
DEBUG - 2018-09-29 14:24:36 --> Total execution time: 0.0530
INFO - 2018-09-29 14:39:38 --> Config Class Initialized
INFO - 2018-09-29 14:39:38 --> Hooks Class Initialized
DEBUG - 2018-09-29 14:39:38 --> UTF-8 Support Enabled
INFO - 2018-09-29 14:39:38 --> Utf8 Class Initialized
INFO - 2018-09-29 14:39:38 --> URI Class Initialized
INFO - 2018-09-29 14:39:38 --> Router Class Initialized
INFO - 2018-09-29 14:39:38 --> Output Class Initialized
INFO - 2018-09-29 14:39:38 --> Security Class Initialized
DEBUG - 2018-09-29 14:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 14:39:38 --> Input Class Initialized
INFO - 2018-09-29 14:39:38 --> Language Class Initialized
INFO - 2018-09-29 14:39:38 --> Loader Class Initialized
INFO - 2018-09-29 14:39:38 --> Helper loaded: url_helper
INFO - 2018-09-29 14:39:38 --> Helper loaded: form_helper
INFO - 2018-09-29 14:39:38 --> Helper loaded: html_helper
INFO - 2018-09-29 14:39:38 --> Database Driver Class Initialized
INFO - 2018-09-29 14:39:38 --> Form Validation Class Initialized
DEBUG - 2018-09-29 14:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 14:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 14:39:38 --> Model "User_model" initialized
INFO - 2018-09-29 14:39:38 --> Model "Project_model" initialized
INFO - 2018-09-29 14:39:38 --> Model "Tasks_model" initialized
INFO - 2018-09-29 14:39:38 --> Model "Lists_model" initialized
INFO - 2018-09-29 14:39:38 --> Controller Class Initialized
INFO - 2018-09-29 14:39:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 14:39:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-29 14:39:38 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 14:39:38 --> Final output sent to browser
DEBUG - 2018-09-29 14:39:38 --> Total execution time: 0.0610
INFO - 2018-09-29 14:39:39 --> Config Class Initialized
INFO - 2018-09-29 14:39:39 --> Hooks Class Initialized
DEBUG - 2018-09-29 14:39:39 --> UTF-8 Support Enabled
INFO - 2018-09-29 14:39:39 --> Utf8 Class Initialized
INFO - 2018-09-29 14:39:39 --> URI Class Initialized
INFO - 2018-09-29 14:39:39 --> Router Class Initialized
INFO - 2018-09-29 14:39:39 --> Output Class Initialized
INFO - 2018-09-29 14:39:39 --> Security Class Initialized
DEBUG - 2018-09-29 14:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 14:39:39 --> Input Class Initialized
INFO - 2018-09-29 14:39:39 --> Language Class Initialized
INFO - 2018-09-29 14:39:40 --> Loader Class Initialized
INFO - 2018-09-29 14:39:40 --> Helper loaded: url_helper
INFO - 2018-09-29 14:39:40 --> Helper loaded: form_helper
INFO - 2018-09-29 14:39:40 --> Helper loaded: html_helper
INFO - 2018-09-29 14:39:40 --> Database Driver Class Initialized
INFO - 2018-09-29 14:39:40 --> Form Validation Class Initialized
DEBUG - 2018-09-29 14:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 14:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 14:39:40 --> Model "User_model" initialized
INFO - 2018-09-29 14:39:40 --> Model "Project_model" initialized
INFO - 2018-09-29 14:39:40 --> Model "Tasks_model" initialized
INFO - 2018-09-29 14:39:40 --> Model "Lists_model" initialized
INFO - 2018-09-29 14:39:40 --> Controller Class Initialized
INFO - 2018-09-29 14:39:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 14:39:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/create_project.php
INFO - 2018-09-29 14:39:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 14:39:40 --> Final output sent to browser
DEBUG - 2018-09-29 14:39:40 --> Total execution time: 0.0700
INFO - 2018-09-29 14:42:44 --> Config Class Initialized
INFO - 2018-09-29 14:42:44 --> Hooks Class Initialized
DEBUG - 2018-09-29 14:42:44 --> UTF-8 Support Enabled
INFO - 2018-09-29 14:42:44 --> Utf8 Class Initialized
INFO - 2018-09-29 14:42:44 --> URI Class Initialized
INFO - 2018-09-29 14:42:44 --> Router Class Initialized
INFO - 2018-09-29 14:42:44 --> Output Class Initialized
INFO - 2018-09-29 14:42:44 --> Security Class Initialized
DEBUG - 2018-09-29 14:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 14:42:44 --> Input Class Initialized
INFO - 2018-09-29 14:42:44 --> Language Class Initialized
INFO - 2018-09-29 14:42:44 --> Loader Class Initialized
INFO - 2018-09-29 14:42:44 --> Helper loaded: url_helper
INFO - 2018-09-29 14:42:44 --> Helper loaded: form_helper
INFO - 2018-09-29 14:42:44 --> Helper loaded: html_helper
INFO - 2018-09-29 14:42:44 --> Database Driver Class Initialized
INFO - 2018-09-29 14:42:44 --> Form Validation Class Initialized
DEBUG - 2018-09-29 14:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 14:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 14:42:44 --> Model "User_model" initialized
INFO - 2018-09-29 14:42:44 --> Model "Project_model" initialized
INFO - 2018-09-29 14:42:44 --> Model "Tasks_model" initialized
INFO - 2018-09-29 14:42:44 --> Model "Lists_model" initialized
INFO - 2018-09-29 14:42:44 --> Controller Class Initialized
INFO - 2018-09-29 14:42:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-29 14:42:44 --> Final output sent to browser
DEBUG - 2018-09-29 14:42:44 --> Total execution time: 0.1050
INFO - 2018-09-29 14:45:53 --> Config Class Initialized
INFO - 2018-09-29 14:45:53 --> Hooks Class Initialized
DEBUG - 2018-09-29 14:45:53 --> UTF-8 Support Enabled
INFO - 2018-09-29 14:45:53 --> Utf8 Class Initialized
INFO - 2018-09-29 14:45:53 --> URI Class Initialized
INFO - 2018-09-29 14:45:53 --> Router Class Initialized
INFO - 2018-09-29 14:45:53 --> Output Class Initialized
INFO - 2018-09-29 14:45:53 --> Security Class Initialized
DEBUG - 2018-09-29 14:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 14:45:53 --> Input Class Initialized
INFO - 2018-09-29 14:45:53 --> Language Class Initialized
INFO - 2018-09-29 14:45:53 --> Loader Class Initialized
INFO - 2018-09-29 14:45:53 --> Helper loaded: url_helper
INFO - 2018-09-29 14:45:53 --> Helper loaded: form_helper
INFO - 2018-09-29 14:45:53 --> Helper loaded: html_helper
INFO - 2018-09-29 14:45:53 --> Database Driver Class Initialized
INFO - 2018-09-29 14:45:53 --> Form Validation Class Initialized
DEBUG - 2018-09-29 14:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 14:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 14:45:53 --> Model "User_model" initialized
INFO - 2018-09-29 14:45:53 --> Model "Project_model" initialized
INFO - 2018-09-29 14:45:53 --> Model "Tasks_model" initialized
INFO - 2018-09-29 14:45:53 --> Model "Lists_model" initialized
INFO - 2018-09-29 14:45:53 --> Controller Class Initialized
INFO - 2018-09-29 14:45:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 14:45:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/create_project.php
INFO - 2018-09-29 14:45:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 14:45:53 --> Final output sent to browser
DEBUG - 2018-09-29 14:45:53 --> Total execution time: 0.0610
INFO - 2018-09-29 14:52:45 --> Config Class Initialized
INFO - 2018-09-29 14:52:45 --> Hooks Class Initialized
DEBUG - 2018-09-29 14:52:45 --> UTF-8 Support Enabled
INFO - 2018-09-29 14:52:45 --> Utf8 Class Initialized
INFO - 2018-09-29 14:52:45 --> URI Class Initialized
INFO - 2018-09-29 14:52:45 --> Router Class Initialized
INFO - 2018-09-29 14:52:45 --> Output Class Initialized
INFO - 2018-09-29 14:52:45 --> Security Class Initialized
DEBUG - 2018-09-29 14:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 14:52:45 --> Input Class Initialized
INFO - 2018-09-29 14:52:45 --> Language Class Initialized
INFO - 2018-09-29 14:52:45 --> Loader Class Initialized
INFO - 2018-09-29 14:52:45 --> Helper loaded: url_helper
INFO - 2018-09-29 14:52:45 --> Helper loaded: form_helper
INFO - 2018-09-29 14:52:45 --> Helper loaded: html_helper
INFO - 2018-09-29 14:52:45 --> Database Driver Class Initialized
INFO - 2018-09-29 14:52:45 --> Form Validation Class Initialized
DEBUG - 2018-09-29 14:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 14:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 14:52:45 --> Model "User_model" initialized
INFO - 2018-09-29 14:52:45 --> Model "Project_model" initialized
INFO - 2018-09-29 14:52:45 --> Model "Tasks_model" initialized
INFO - 2018-09-29 14:52:45 --> Model "Lists_model" initialized
INFO - 2018-09-29 14:52:45 --> Controller Class Initialized
INFO - 2018-09-29 14:52:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 14:52:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/create_project.php
INFO - 2018-09-29 14:52:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 14:52:45 --> Final output sent to browser
DEBUG - 2018-09-29 14:52:45 --> Total execution time: 0.0440
INFO - 2018-09-29 14:53:01 --> Config Class Initialized
INFO - 2018-09-29 14:53:01 --> Hooks Class Initialized
DEBUG - 2018-09-29 14:53:01 --> UTF-8 Support Enabled
INFO - 2018-09-29 14:53:01 --> Utf8 Class Initialized
INFO - 2018-09-29 14:53:01 --> URI Class Initialized
INFO - 2018-09-29 14:53:01 --> Router Class Initialized
INFO - 2018-09-29 14:53:01 --> Output Class Initialized
INFO - 2018-09-29 14:53:01 --> Security Class Initialized
DEBUG - 2018-09-29 14:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 14:53:01 --> Input Class Initialized
INFO - 2018-09-29 14:53:01 --> Language Class Initialized
INFO - 2018-09-29 14:53:01 --> Loader Class Initialized
INFO - 2018-09-29 14:53:01 --> Helper loaded: url_helper
INFO - 2018-09-29 14:53:01 --> Helper loaded: form_helper
INFO - 2018-09-29 14:53:01 --> Helper loaded: html_helper
INFO - 2018-09-29 14:53:01 --> Database Driver Class Initialized
INFO - 2018-09-29 14:53:01 --> Form Validation Class Initialized
DEBUG - 2018-09-29 14:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 14:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 14:53:01 --> Model "User_model" initialized
INFO - 2018-09-29 14:53:01 --> Model "Project_model" initialized
INFO - 2018-09-29 14:53:01 --> Model "Tasks_model" initialized
INFO - 2018-09-29 14:53:01 --> Model "Lists_model" initialized
INFO - 2018-09-29 14:53:01 --> Controller Class Initialized
INFO - 2018-09-29 14:53:01 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-09-29 14:53:01 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\code_igniter\system\database\DB_driver.php 1477
ERROR - 2018-09-29 14:53:01 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\code_igniter\system\database\DB_driver.php 1477
ERROR - 2018-09-29 14:53:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0, 1) VALUES (Array, Array)' at line 1 - Invalid query: INSERT INTO `projects` (0, 1) VALUES (Array, Array)
INFO - 2018-09-29 14:53:01 --> Language file loaded: language/english/db_lang.php
INFO - 2018-09-29 14:57:03 --> Config Class Initialized
INFO - 2018-09-29 14:57:03 --> Hooks Class Initialized
DEBUG - 2018-09-29 14:57:03 --> UTF-8 Support Enabled
INFO - 2018-09-29 14:57:03 --> Utf8 Class Initialized
INFO - 2018-09-29 14:57:03 --> URI Class Initialized
INFO - 2018-09-29 14:57:03 --> Router Class Initialized
INFO - 2018-09-29 14:57:03 --> Output Class Initialized
INFO - 2018-09-29 14:57:03 --> Security Class Initialized
DEBUG - 2018-09-29 14:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 14:57:03 --> Input Class Initialized
INFO - 2018-09-29 14:57:03 --> Language Class Initialized
INFO - 2018-09-29 14:57:03 --> Loader Class Initialized
INFO - 2018-09-29 14:57:03 --> Helper loaded: url_helper
INFO - 2018-09-29 14:57:03 --> Helper loaded: form_helper
INFO - 2018-09-29 14:57:03 --> Helper loaded: html_helper
INFO - 2018-09-29 14:57:03 --> Database Driver Class Initialized
INFO - 2018-09-29 14:57:03 --> Form Validation Class Initialized
DEBUG - 2018-09-29 14:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 14:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 14:57:03 --> Model "User_model" initialized
ERROR - 2018-09-29 14:57:03 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' D:\xampp\htdocs\code_igniter\application\models\project_models\project_model.php 60
INFO - 2018-09-29 14:57:20 --> Config Class Initialized
INFO - 2018-09-29 14:57:20 --> Hooks Class Initialized
DEBUG - 2018-09-29 14:57:20 --> UTF-8 Support Enabled
INFO - 2018-09-29 14:57:20 --> Utf8 Class Initialized
INFO - 2018-09-29 14:57:20 --> URI Class Initialized
INFO - 2018-09-29 14:57:20 --> Router Class Initialized
INFO - 2018-09-29 14:57:20 --> Output Class Initialized
INFO - 2018-09-29 14:57:20 --> Security Class Initialized
DEBUG - 2018-09-29 14:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 14:57:20 --> Input Class Initialized
INFO - 2018-09-29 14:57:20 --> Language Class Initialized
INFO - 2018-09-29 14:57:20 --> Loader Class Initialized
INFO - 2018-09-29 14:57:20 --> Helper loaded: url_helper
INFO - 2018-09-29 14:57:20 --> Helper loaded: form_helper
INFO - 2018-09-29 14:57:20 --> Helper loaded: html_helper
INFO - 2018-09-29 14:57:20 --> Database Driver Class Initialized
INFO - 2018-09-29 14:57:20 --> Form Validation Class Initialized
DEBUG - 2018-09-29 14:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 14:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 14:57:20 --> Model "User_model" initialized
ERROR - 2018-09-29 14:57:20 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' D:\xampp\htdocs\code_igniter\application\models\project_models\project_model.php 61
INFO - 2018-09-29 14:57:32 --> Config Class Initialized
INFO - 2018-09-29 14:57:32 --> Hooks Class Initialized
DEBUG - 2018-09-29 14:57:32 --> UTF-8 Support Enabled
INFO - 2018-09-29 14:57:32 --> Utf8 Class Initialized
INFO - 2018-09-29 14:57:32 --> URI Class Initialized
INFO - 2018-09-29 14:57:32 --> Router Class Initialized
INFO - 2018-09-29 14:57:32 --> Output Class Initialized
INFO - 2018-09-29 14:57:32 --> Security Class Initialized
DEBUG - 2018-09-29 14:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 14:57:32 --> Input Class Initialized
INFO - 2018-09-29 14:57:32 --> Language Class Initialized
INFO - 2018-09-29 14:57:32 --> Loader Class Initialized
INFO - 2018-09-29 14:57:32 --> Helper loaded: url_helper
INFO - 2018-09-29 14:57:32 --> Helper loaded: form_helper
INFO - 2018-09-29 14:57:32 --> Helper loaded: html_helper
INFO - 2018-09-29 14:57:32 --> Database Driver Class Initialized
INFO - 2018-09-29 14:57:32 --> Form Validation Class Initialized
DEBUG - 2018-09-29 14:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 14:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 14:57:32 --> Model "User_model" initialized
INFO - 2018-09-29 14:57:32 --> Model "Project_model" initialized
INFO - 2018-09-29 14:57:32 --> Model "Tasks_model" initialized
INFO - 2018-09-29 14:57:32 --> Model "Lists_model" initialized
INFO - 2018-09-29 14:57:32 --> Controller Class Initialized
INFO - 2018-09-29 14:57:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 14:57:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/create_project.php
INFO - 2018-09-29 14:57:32 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 14:57:32 --> Final output sent to browser
DEBUG - 2018-09-29 14:57:32 --> Total execution time: 0.0530
INFO - 2018-09-29 14:57:57 --> Config Class Initialized
INFO - 2018-09-29 14:57:57 --> Hooks Class Initialized
DEBUG - 2018-09-29 14:57:57 --> UTF-8 Support Enabled
INFO - 2018-09-29 14:57:57 --> Utf8 Class Initialized
INFO - 2018-09-29 14:57:57 --> URI Class Initialized
INFO - 2018-09-29 14:57:57 --> Router Class Initialized
INFO - 2018-09-29 14:57:57 --> Output Class Initialized
INFO - 2018-09-29 14:57:57 --> Security Class Initialized
DEBUG - 2018-09-29 14:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 14:57:57 --> Input Class Initialized
INFO - 2018-09-29 14:57:57 --> Language Class Initialized
INFO - 2018-09-29 14:57:57 --> Loader Class Initialized
INFO - 2018-09-29 14:57:57 --> Helper loaded: url_helper
INFO - 2018-09-29 14:57:57 --> Helper loaded: form_helper
INFO - 2018-09-29 14:57:57 --> Helper loaded: html_helper
INFO - 2018-09-29 14:57:57 --> Database Driver Class Initialized
INFO - 2018-09-29 14:57:57 --> Form Validation Class Initialized
DEBUG - 2018-09-29 14:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 14:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 14:57:57 --> Model "User_model" initialized
INFO - 2018-09-29 14:57:57 --> Model "Project_model" initialized
INFO - 2018-09-29 14:57:57 --> Model "Tasks_model" initialized
INFO - 2018-09-29 14:57:57 --> Model "Lists_model" initialized
INFO - 2018-09-29 14:57:57 --> Controller Class Initialized
INFO - 2018-09-29 14:57:57 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-09-29 14:57:57 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\code_igniter\system\database\DB_driver.php 1477
ERROR - 2018-09-29 14:57:57 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\code_igniter\system\database\DB_driver.php 1477
ERROR - 2018-09-29 14:57:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0, 1) VALUES (Array, Array)' at line 1 - Invalid query: INSERT INTO `projects` (0, 1) VALUES (Array, Array)
INFO - 2018-09-29 14:57:57 --> Language file loaded: language/english/db_lang.php
INFO - 2018-09-29 14:58:33 --> Config Class Initialized
INFO - 2018-09-29 14:58:33 --> Hooks Class Initialized
DEBUG - 2018-09-29 14:58:33 --> UTF-8 Support Enabled
INFO - 2018-09-29 14:58:33 --> Utf8 Class Initialized
INFO - 2018-09-29 14:58:33 --> URI Class Initialized
INFO - 2018-09-29 14:58:33 --> Router Class Initialized
INFO - 2018-09-29 14:58:33 --> Output Class Initialized
INFO - 2018-09-29 14:58:33 --> Security Class Initialized
DEBUG - 2018-09-29 14:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 14:58:33 --> Input Class Initialized
INFO - 2018-09-29 14:58:33 --> Language Class Initialized
INFO - 2018-09-29 14:58:33 --> Loader Class Initialized
INFO - 2018-09-29 14:58:33 --> Helper loaded: url_helper
INFO - 2018-09-29 14:58:33 --> Helper loaded: form_helper
INFO - 2018-09-29 14:58:33 --> Helper loaded: html_helper
INFO - 2018-09-29 14:58:33 --> Database Driver Class Initialized
INFO - 2018-09-29 14:58:33 --> Form Validation Class Initialized
DEBUG - 2018-09-29 14:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 14:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 14:58:33 --> Model "User_model" initialized
INFO - 2018-09-29 14:58:33 --> Model "Project_model" initialized
INFO - 2018-09-29 14:58:33 --> Model "Tasks_model" initialized
INFO - 2018-09-29 14:58:33 --> Model "Lists_model" initialized
INFO - 2018-09-29 14:58:33 --> Controller Class Initialized
INFO - 2018-09-29 14:58:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 14:58:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/create_project.php
INFO - 2018-09-29 14:58:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 14:58:33 --> Final output sent to browser
DEBUG - 2018-09-29 14:58:33 --> Total execution time: 0.0680
INFO - 2018-09-29 14:58:45 --> Config Class Initialized
INFO - 2018-09-29 14:58:45 --> Hooks Class Initialized
DEBUG - 2018-09-29 14:58:45 --> UTF-8 Support Enabled
INFO - 2018-09-29 14:58:45 --> Utf8 Class Initialized
INFO - 2018-09-29 14:58:45 --> URI Class Initialized
INFO - 2018-09-29 14:58:45 --> Router Class Initialized
INFO - 2018-09-29 14:58:45 --> Output Class Initialized
INFO - 2018-09-29 14:58:45 --> Security Class Initialized
DEBUG - 2018-09-29 14:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 14:58:45 --> Input Class Initialized
INFO - 2018-09-29 14:58:45 --> Language Class Initialized
INFO - 2018-09-29 14:58:45 --> Loader Class Initialized
INFO - 2018-09-29 14:58:45 --> Helper loaded: url_helper
INFO - 2018-09-29 14:58:45 --> Helper loaded: form_helper
INFO - 2018-09-29 14:58:45 --> Helper loaded: html_helper
INFO - 2018-09-29 14:58:46 --> Database Driver Class Initialized
INFO - 2018-09-29 14:58:46 --> Form Validation Class Initialized
DEBUG - 2018-09-29 14:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 14:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 14:58:46 --> Model "User_model" initialized
INFO - 2018-09-29 14:58:46 --> Model "Project_model" initialized
INFO - 2018-09-29 14:58:46 --> Model "Tasks_model" initialized
INFO - 2018-09-29 14:58:46 --> Model "Lists_model" initialized
INFO - 2018-09-29 14:58:46 --> Controller Class Initialized
INFO - 2018-09-29 14:58:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-29 14:58:46 --> Config Class Initialized
INFO - 2018-09-29 14:58:46 --> Hooks Class Initialized
DEBUG - 2018-09-29 14:58:46 --> UTF-8 Support Enabled
INFO - 2018-09-29 14:58:46 --> Utf8 Class Initialized
INFO - 2018-09-29 14:58:46 --> URI Class Initialized
INFO - 2018-09-29 14:58:46 --> Router Class Initialized
INFO - 2018-09-29 14:58:46 --> Output Class Initialized
INFO - 2018-09-29 14:58:46 --> Security Class Initialized
DEBUG - 2018-09-29 14:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 14:58:46 --> Input Class Initialized
INFO - 2018-09-29 14:58:46 --> Language Class Initialized
INFO - 2018-09-29 14:58:46 --> Loader Class Initialized
INFO - 2018-09-29 14:58:46 --> Helper loaded: url_helper
INFO - 2018-09-29 14:58:46 --> Helper loaded: form_helper
INFO - 2018-09-29 14:58:46 --> Helper loaded: html_helper
INFO - 2018-09-29 14:58:46 --> Database Driver Class Initialized
INFO - 2018-09-29 14:58:46 --> Form Validation Class Initialized
DEBUG - 2018-09-29 14:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 14:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 14:58:46 --> Model "User_model" initialized
INFO - 2018-09-29 14:58:46 --> Model "Project_model" initialized
INFO - 2018-09-29 14:58:46 --> Model "Tasks_model" initialized
INFO - 2018-09-29 14:58:46 --> Model "Lists_model" initialized
INFO - 2018-09-29 14:58:46 --> Controller Class Initialized
INFO - 2018-09-29 14:58:46 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 14:58:46 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-29 14:58:46 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 14:58:46 --> Final output sent to browser
DEBUG - 2018-09-29 14:58:46 --> Total execution time: 0.0350
INFO - 2018-09-29 15:01:24 --> Config Class Initialized
INFO - 2018-09-29 15:01:24 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:01:24 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:01:24 --> Utf8 Class Initialized
INFO - 2018-09-29 15:01:24 --> URI Class Initialized
INFO - 2018-09-29 15:01:24 --> Router Class Initialized
INFO - 2018-09-29 15:01:24 --> Output Class Initialized
INFO - 2018-09-29 15:01:24 --> Security Class Initialized
DEBUG - 2018-09-29 15:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:01:24 --> Input Class Initialized
INFO - 2018-09-29 15:01:24 --> Language Class Initialized
INFO - 2018-09-29 15:01:24 --> Loader Class Initialized
INFO - 2018-09-29 15:01:24 --> Helper loaded: url_helper
INFO - 2018-09-29 15:01:24 --> Helper loaded: form_helper
INFO - 2018-09-29 15:01:24 --> Helper loaded: html_helper
INFO - 2018-09-29 15:01:24 --> Database Driver Class Initialized
INFO - 2018-09-29 15:01:24 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:01:24 --> Model "User_model" initialized
INFO - 2018-09-29 15:01:24 --> Model "Project_model" initialized
INFO - 2018-09-29 15:01:24 --> Model "Tasks_model" initialized
INFO - 2018-09-29 15:01:24 --> Model "Lists_model" initialized
INFO - 2018-09-29 15:01:24 --> Controller Class Initialized
INFO - 2018-09-29 15:01:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 15:01:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-29 15:01:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 15:01:24 --> Final output sent to browser
DEBUG - 2018-09-29 15:01:24 --> Total execution time: 0.0620
INFO - 2018-09-29 15:04:48 --> Config Class Initialized
INFO - 2018-09-29 15:04:48 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:04:48 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:04:48 --> Utf8 Class Initialized
INFO - 2018-09-29 15:04:48 --> URI Class Initialized
INFO - 2018-09-29 15:04:48 --> Router Class Initialized
INFO - 2018-09-29 15:04:48 --> Output Class Initialized
INFO - 2018-09-29 15:04:48 --> Security Class Initialized
DEBUG - 2018-09-29 15:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:04:48 --> Input Class Initialized
INFO - 2018-09-29 15:04:48 --> Language Class Initialized
INFO - 2018-09-29 15:04:48 --> Loader Class Initialized
INFO - 2018-09-29 15:04:48 --> Helper loaded: url_helper
INFO - 2018-09-29 15:04:48 --> Helper loaded: form_helper
INFO - 2018-09-29 15:04:48 --> Helper loaded: html_helper
INFO - 2018-09-29 15:04:48 --> Database Driver Class Initialized
INFO - 2018-09-29 15:04:48 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:04:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:04:48 --> Model "User_model" initialized
INFO - 2018-09-29 15:04:48 --> Model "Project_model" initialized
INFO - 2018-09-29 15:04:48 --> Model "Tasks_model" initialized
INFO - 2018-09-29 15:04:48 --> Model "Lists_model" initialized
INFO - 2018-09-29 15:04:48 --> Controller Class Initialized
INFO - 2018-09-29 15:04:48 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 15:04:48 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/create_project.php
INFO - 2018-09-29 15:04:48 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 15:04:48 --> Final output sent to browser
DEBUG - 2018-09-29 15:04:48 --> Total execution time: 0.0600
INFO - 2018-09-29 15:05:03 --> Config Class Initialized
INFO - 2018-09-29 15:05:03 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:05:03 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:05:03 --> Utf8 Class Initialized
INFO - 2018-09-29 15:05:03 --> URI Class Initialized
INFO - 2018-09-29 15:05:03 --> Router Class Initialized
INFO - 2018-09-29 15:05:03 --> Output Class Initialized
INFO - 2018-09-29 15:05:03 --> Security Class Initialized
DEBUG - 2018-09-29 15:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:05:03 --> Input Class Initialized
INFO - 2018-09-29 15:05:03 --> Language Class Initialized
INFO - 2018-09-29 15:05:03 --> Loader Class Initialized
INFO - 2018-09-29 15:05:03 --> Helper loaded: url_helper
INFO - 2018-09-29 15:05:03 --> Helper loaded: form_helper
INFO - 2018-09-29 15:05:03 --> Helper loaded: html_helper
INFO - 2018-09-29 15:05:03 --> Database Driver Class Initialized
INFO - 2018-09-29 15:05:03 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:05:03 --> Model "User_model" initialized
INFO - 2018-09-29 15:05:03 --> Model "Project_model" initialized
INFO - 2018-09-29 15:05:03 --> Model "Tasks_model" initialized
INFO - 2018-09-29 15:05:03 --> Model "Lists_model" initialized
INFO - 2018-09-29 15:05:03 --> Controller Class Initialized
INFO - 2018-09-29 15:05:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-29 15:05:03 --> Config Class Initialized
INFO - 2018-09-29 15:05:03 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:05:03 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:05:03 --> Utf8 Class Initialized
INFO - 2018-09-29 15:05:03 --> URI Class Initialized
INFO - 2018-09-29 15:05:03 --> Router Class Initialized
INFO - 2018-09-29 15:05:03 --> Output Class Initialized
INFO - 2018-09-29 15:05:03 --> Security Class Initialized
DEBUG - 2018-09-29 15:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:05:03 --> Input Class Initialized
INFO - 2018-09-29 15:05:03 --> Language Class Initialized
INFO - 2018-09-29 15:05:03 --> Loader Class Initialized
INFO - 2018-09-29 15:05:03 --> Helper loaded: url_helper
INFO - 2018-09-29 15:05:03 --> Helper loaded: form_helper
INFO - 2018-09-29 15:05:03 --> Helper loaded: html_helper
INFO - 2018-09-29 15:05:03 --> Database Driver Class Initialized
INFO - 2018-09-29 15:05:03 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:05:03 --> Model "User_model" initialized
INFO - 2018-09-29 15:05:03 --> Model "Project_model" initialized
INFO - 2018-09-29 15:05:03 --> Model "Tasks_model" initialized
INFO - 2018-09-29 15:05:03 --> Model "Lists_model" initialized
INFO - 2018-09-29 15:05:03 --> Controller Class Initialized
INFO - 2018-09-29 15:05:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 15:05:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-29 15:05:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 15:05:03 --> Final output sent to browser
DEBUG - 2018-09-29 15:05:03 --> Total execution time: 0.0480
INFO - 2018-09-29 15:06:21 --> Config Class Initialized
INFO - 2018-09-29 15:06:21 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:06:21 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:06:21 --> Utf8 Class Initialized
INFO - 2018-09-29 15:06:21 --> URI Class Initialized
INFO - 2018-09-29 15:06:21 --> Router Class Initialized
INFO - 2018-09-29 15:06:21 --> Output Class Initialized
INFO - 2018-09-29 15:06:21 --> Security Class Initialized
DEBUG - 2018-09-29 15:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:06:21 --> Input Class Initialized
INFO - 2018-09-29 15:06:21 --> Language Class Initialized
INFO - 2018-09-29 15:06:21 --> Loader Class Initialized
INFO - 2018-09-29 15:06:21 --> Helper loaded: url_helper
INFO - 2018-09-29 15:06:21 --> Helper loaded: form_helper
INFO - 2018-09-29 15:06:21 --> Helper loaded: html_helper
INFO - 2018-09-29 15:06:21 --> Database Driver Class Initialized
INFO - 2018-09-29 15:06:21 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:06:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:06:21 --> Model "User_model" initialized
ERROR - 2018-09-29 15:06:21 --> Severity: error --> Exception: syntax error, unexpected '{', expecting ')' D:\xampp\htdocs\code_igniter\application\models\project_models\project_model.php 79
INFO - 2018-09-29 15:13:03 --> Config Class Initialized
INFO - 2018-09-29 15:13:03 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:13:03 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:13:03 --> Utf8 Class Initialized
INFO - 2018-09-29 15:13:03 --> URI Class Initialized
INFO - 2018-09-29 15:13:03 --> Router Class Initialized
INFO - 2018-09-29 15:13:03 --> Output Class Initialized
INFO - 2018-09-29 15:13:03 --> Security Class Initialized
DEBUG - 2018-09-29 15:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:13:03 --> Input Class Initialized
INFO - 2018-09-29 15:13:03 --> Language Class Initialized
INFO - 2018-09-29 15:13:03 --> Loader Class Initialized
INFO - 2018-09-29 15:13:03 --> Helper loaded: url_helper
INFO - 2018-09-29 15:13:03 --> Helper loaded: form_helper
INFO - 2018-09-29 15:13:03 --> Helper loaded: html_helper
INFO - 2018-09-29 15:13:03 --> Database Driver Class Initialized
INFO - 2018-09-29 15:13:03 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:13:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:13:03 --> Model "User_model" initialized
INFO - 2018-09-29 15:13:03 --> Model "Project_model" initialized
INFO - 2018-09-29 15:13:03 --> Model "Tasks_model" initialized
INFO - 2018-09-29 15:13:03 --> Model "Lists_model" initialized
INFO - 2018-09-29 15:13:03 --> Controller Class Initialized
INFO - 2018-09-29 15:13:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 15:13:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/create_project.php
INFO - 2018-09-29 15:13:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 15:13:03 --> Final output sent to browser
DEBUG - 2018-09-29 15:13:03 --> Total execution time: 0.0520
INFO - 2018-09-29 15:13:18 --> Config Class Initialized
INFO - 2018-09-29 15:13:18 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:13:18 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:13:18 --> Utf8 Class Initialized
INFO - 2018-09-29 15:13:18 --> URI Class Initialized
INFO - 2018-09-29 15:13:18 --> Router Class Initialized
INFO - 2018-09-29 15:13:18 --> Output Class Initialized
INFO - 2018-09-29 15:13:18 --> Security Class Initialized
DEBUG - 2018-09-29 15:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:13:18 --> Input Class Initialized
INFO - 2018-09-29 15:13:18 --> Language Class Initialized
INFO - 2018-09-29 15:13:18 --> Loader Class Initialized
INFO - 2018-09-29 15:13:18 --> Helper loaded: url_helper
INFO - 2018-09-29 15:13:18 --> Helper loaded: form_helper
INFO - 2018-09-29 15:13:18 --> Helper loaded: html_helper
INFO - 2018-09-29 15:13:18 --> Database Driver Class Initialized
INFO - 2018-09-29 15:13:18 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:13:18 --> Model "User_model" initialized
INFO - 2018-09-29 15:13:18 --> Model "Project_model" initialized
INFO - 2018-09-29 15:13:18 --> Model "Tasks_model" initialized
INFO - 2018-09-29 15:13:18 --> Model "Lists_model" initialized
INFO - 2018-09-29 15:13:18 --> Controller Class Initialized
INFO - 2018-09-29 15:13:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-29 15:13:18 --> Config Class Initialized
INFO - 2018-09-29 15:13:18 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:13:18 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:13:18 --> Utf8 Class Initialized
INFO - 2018-09-29 15:13:18 --> URI Class Initialized
INFO - 2018-09-29 15:13:18 --> Router Class Initialized
INFO - 2018-09-29 15:13:18 --> Output Class Initialized
INFO - 2018-09-29 15:13:18 --> Security Class Initialized
DEBUG - 2018-09-29 15:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:13:18 --> Input Class Initialized
INFO - 2018-09-29 15:13:18 --> Language Class Initialized
INFO - 2018-09-29 15:13:18 --> Loader Class Initialized
INFO - 2018-09-29 15:13:18 --> Helper loaded: url_helper
INFO - 2018-09-29 15:13:18 --> Helper loaded: form_helper
INFO - 2018-09-29 15:13:18 --> Helper loaded: html_helper
INFO - 2018-09-29 15:13:18 --> Database Driver Class Initialized
INFO - 2018-09-29 15:13:18 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:13:18 --> Model "User_model" initialized
INFO - 2018-09-29 15:13:18 --> Model "Project_model" initialized
INFO - 2018-09-29 15:13:18 --> Model "Tasks_model" initialized
INFO - 2018-09-29 15:13:18 --> Model "Lists_model" initialized
INFO - 2018-09-29 15:13:18 --> Controller Class Initialized
INFO - 2018-09-29 15:13:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 15:13:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-29 15:13:18 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 15:13:18 --> Final output sent to browser
DEBUG - 2018-09-29 15:13:18 --> Total execution time: 0.0470
INFO - 2018-09-29 15:13:40 --> Config Class Initialized
INFO - 2018-09-29 15:13:40 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:13:40 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:13:40 --> Utf8 Class Initialized
INFO - 2018-09-29 15:13:40 --> URI Class Initialized
INFO - 2018-09-29 15:13:40 --> Router Class Initialized
INFO - 2018-09-29 15:13:40 --> Output Class Initialized
INFO - 2018-09-29 15:13:40 --> Security Class Initialized
DEBUG - 2018-09-29 15:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:13:40 --> Input Class Initialized
INFO - 2018-09-29 15:13:40 --> Language Class Initialized
INFO - 2018-09-29 15:13:40 --> Loader Class Initialized
INFO - 2018-09-29 15:13:40 --> Helper loaded: url_helper
INFO - 2018-09-29 15:13:40 --> Helper loaded: form_helper
INFO - 2018-09-29 15:13:40 --> Helper loaded: html_helper
INFO - 2018-09-29 15:13:40 --> Database Driver Class Initialized
INFO - 2018-09-29 15:13:40 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:13:40 --> Model "User_model" initialized
INFO - 2018-09-29 15:13:40 --> Model "Project_model" initialized
INFO - 2018-09-29 15:13:40 --> Model "Tasks_model" initialized
INFO - 2018-09-29 15:13:40 --> Model "Lists_model" initialized
INFO - 2018-09-29 15:13:40 --> Controller Class Initialized
INFO - 2018-09-29 15:13:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 15:13:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-29 15:13:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 15:13:40 --> Final output sent to browser
DEBUG - 2018-09-29 15:13:40 --> Total execution time: 0.0570
INFO - 2018-09-29 15:14:14 --> Config Class Initialized
INFO - 2018-09-29 15:14:14 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:14:14 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:14:14 --> Utf8 Class Initialized
INFO - 2018-09-29 15:14:14 --> URI Class Initialized
INFO - 2018-09-29 15:14:14 --> Router Class Initialized
INFO - 2018-09-29 15:14:14 --> Output Class Initialized
INFO - 2018-09-29 15:14:14 --> Security Class Initialized
DEBUG - 2018-09-29 15:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:14:14 --> Input Class Initialized
INFO - 2018-09-29 15:14:14 --> Language Class Initialized
INFO - 2018-09-29 15:14:14 --> Loader Class Initialized
INFO - 2018-09-29 15:14:14 --> Helper loaded: url_helper
INFO - 2018-09-29 15:14:14 --> Helper loaded: form_helper
INFO - 2018-09-29 15:14:14 --> Helper loaded: html_helper
INFO - 2018-09-29 15:14:14 --> Database Driver Class Initialized
INFO - 2018-09-29 15:14:14 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:14:14 --> Model "User_model" initialized
INFO - 2018-09-29 15:14:14 --> Model "Project_model" initialized
INFO - 2018-09-29 15:14:14 --> Model "Tasks_model" initialized
INFO - 2018-09-29 15:14:14 --> Model "Lists_model" initialized
INFO - 2018-09-29 15:14:14 --> Controller Class Initialized
INFO - 2018-09-29 15:14:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 15:14:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/create_project.php
INFO - 2018-09-29 15:14:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 15:14:14 --> Final output sent to browser
DEBUG - 2018-09-29 15:14:14 --> Total execution time: 0.0630
INFO - 2018-09-29 15:14:26 --> Config Class Initialized
INFO - 2018-09-29 15:14:26 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:14:26 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:14:26 --> Utf8 Class Initialized
INFO - 2018-09-29 15:14:26 --> URI Class Initialized
INFO - 2018-09-29 15:14:26 --> Router Class Initialized
INFO - 2018-09-29 15:14:26 --> Output Class Initialized
INFO - 2018-09-29 15:14:26 --> Security Class Initialized
DEBUG - 2018-09-29 15:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:14:26 --> Input Class Initialized
INFO - 2018-09-29 15:14:26 --> Language Class Initialized
INFO - 2018-09-29 15:14:26 --> Loader Class Initialized
INFO - 2018-09-29 15:14:26 --> Helper loaded: url_helper
INFO - 2018-09-29 15:14:26 --> Helper loaded: form_helper
INFO - 2018-09-29 15:14:26 --> Helper loaded: html_helper
INFO - 2018-09-29 15:14:26 --> Database Driver Class Initialized
INFO - 2018-09-29 15:14:26 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:14:26 --> Model "User_model" initialized
INFO - 2018-09-29 15:14:26 --> Model "Project_model" initialized
INFO - 2018-09-29 15:14:26 --> Model "Tasks_model" initialized
INFO - 2018-09-29 15:14:26 --> Model "Lists_model" initialized
INFO - 2018-09-29 15:14:26 --> Controller Class Initialized
INFO - 2018-09-29 15:14:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-29 15:14:26 --> Config Class Initialized
INFO - 2018-09-29 15:14:26 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:14:26 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:14:26 --> Utf8 Class Initialized
INFO - 2018-09-29 15:14:26 --> URI Class Initialized
INFO - 2018-09-29 15:14:26 --> Router Class Initialized
INFO - 2018-09-29 15:14:26 --> Output Class Initialized
INFO - 2018-09-29 15:14:26 --> Security Class Initialized
DEBUG - 2018-09-29 15:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:14:26 --> Input Class Initialized
INFO - 2018-09-29 15:14:26 --> Language Class Initialized
INFO - 2018-09-29 15:14:26 --> Loader Class Initialized
INFO - 2018-09-29 15:14:26 --> Helper loaded: url_helper
INFO - 2018-09-29 15:14:26 --> Helper loaded: form_helper
INFO - 2018-09-29 15:14:26 --> Helper loaded: html_helper
INFO - 2018-09-29 15:14:26 --> Database Driver Class Initialized
INFO - 2018-09-29 15:14:26 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:14:26 --> Model "User_model" initialized
INFO - 2018-09-29 15:14:26 --> Model "Project_model" initialized
INFO - 2018-09-29 15:14:26 --> Model "Tasks_model" initialized
INFO - 2018-09-29 15:14:26 --> Model "Lists_model" initialized
INFO - 2018-09-29 15:14:26 --> Controller Class Initialized
INFO - 2018-09-29 15:14:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 15:14:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-29 15:14:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 15:14:26 --> Final output sent to browser
DEBUG - 2018-09-29 15:14:26 --> Total execution time: 0.0440
INFO - 2018-09-29 15:14:29 --> Config Class Initialized
INFO - 2018-09-29 15:14:29 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:14:29 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:14:29 --> Utf8 Class Initialized
INFO - 2018-09-29 15:14:29 --> URI Class Initialized
INFO - 2018-09-29 15:14:29 --> Router Class Initialized
INFO - 2018-09-29 15:14:29 --> Output Class Initialized
INFO - 2018-09-29 15:14:29 --> Security Class Initialized
DEBUG - 2018-09-29 15:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:14:29 --> Input Class Initialized
INFO - 2018-09-29 15:14:29 --> Language Class Initialized
INFO - 2018-09-29 15:14:29 --> Loader Class Initialized
INFO - 2018-09-29 15:14:29 --> Helper loaded: url_helper
INFO - 2018-09-29 15:14:29 --> Helper loaded: form_helper
INFO - 2018-09-29 15:14:29 --> Helper loaded: html_helper
INFO - 2018-09-29 15:14:29 --> Database Driver Class Initialized
INFO - 2018-09-29 15:14:29 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:14:29 --> Model "User_model" initialized
INFO - 2018-09-29 15:14:29 --> Model "Project_model" initialized
INFO - 2018-09-29 15:14:29 --> Model "Tasks_model" initialized
INFO - 2018-09-29 15:14:29 --> Model "Lists_model" initialized
INFO - 2018-09-29 15:14:29 --> Controller Class Initialized
INFO - 2018-09-29 15:14:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 15:14:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-29 15:14:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 15:14:29 --> Final output sent to browser
DEBUG - 2018-09-29 15:14:29 --> Total execution time: 0.0620
INFO - 2018-09-29 15:18:54 --> Config Class Initialized
INFO - 2018-09-29 15:18:54 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:18:54 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:18:54 --> Utf8 Class Initialized
INFO - 2018-09-29 15:18:54 --> URI Class Initialized
INFO - 2018-09-29 15:18:54 --> Router Class Initialized
INFO - 2018-09-29 15:18:54 --> Output Class Initialized
INFO - 2018-09-29 15:18:54 --> Security Class Initialized
DEBUG - 2018-09-29 15:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:18:54 --> Input Class Initialized
INFO - 2018-09-29 15:18:54 --> Language Class Initialized
INFO - 2018-09-29 15:18:54 --> Loader Class Initialized
INFO - 2018-09-29 15:18:54 --> Helper loaded: url_helper
INFO - 2018-09-29 15:18:54 --> Helper loaded: form_helper
INFO - 2018-09-29 15:18:54 --> Helper loaded: html_helper
INFO - 2018-09-29 15:18:54 --> Database Driver Class Initialized
INFO - 2018-09-29 15:18:54 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:18:54 --> Model "User_model" initialized
ERROR - 2018-09-29 15:18:54 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) D:\xampp\htdocs\code_igniter\application\models\project_models\project_model.php 93
INFO - 2018-09-29 15:19:24 --> Config Class Initialized
INFO - 2018-09-29 15:19:24 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:19:24 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:19:24 --> Utf8 Class Initialized
INFO - 2018-09-29 15:19:24 --> URI Class Initialized
INFO - 2018-09-29 15:19:24 --> Router Class Initialized
INFO - 2018-09-29 15:19:24 --> Output Class Initialized
INFO - 2018-09-29 15:19:24 --> Security Class Initialized
DEBUG - 2018-09-29 15:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:19:24 --> Input Class Initialized
INFO - 2018-09-29 15:19:24 --> Language Class Initialized
INFO - 2018-09-29 15:19:24 --> Loader Class Initialized
INFO - 2018-09-29 15:19:24 --> Helper loaded: url_helper
INFO - 2018-09-29 15:19:24 --> Helper loaded: form_helper
INFO - 2018-09-29 15:19:24 --> Helper loaded: html_helper
INFO - 2018-09-29 15:19:24 --> Database Driver Class Initialized
INFO - 2018-09-29 15:19:24 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:19:24 --> Model "User_model" initialized
INFO - 2018-09-29 15:19:24 --> Model "Project_model" initialized
INFO - 2018-09-29 15:19:24 --> Model "Tasks_model" initialized
INFO - 2018-09-29 15:19:24 --> Model "Lists_model" initialized
INFO - 2018-09-29 15:19:24 --> Controller Class Initialized
INFO - 2018-09-29 15:19:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 15:19:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/create_project.php
INFO - 2018-09-29 15:19:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 15:19:24 --> Final output sent to browser
DEBUG - 2018-09-29 15:19:24 --> Total execution time: 0.0630
INFO - 2018-09-29 15:19:27 --> Config Class Initialized
INFO - 2018-09-29 15:19:27 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:19:27 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:19:27 --> Utf8 Class Initialized
INFO - 2018-09-29 15:19:27 --> URI Class Initialized
INFO - 2018-09-29 15:19:27 --> Router Class Initialized
INFO - 2018-09-29 15:19:27 --> Output Class Initialized
INFO - 2018-09-29 15:19:27 --> Security Class Initialized
DEBUG - 2018-09-29 15:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:19:27 --> Input Class Initialized
INFO - 2018-09-29 15:19:27 --> Language Class Initialized
INFO - 2018-09-29 15:19:27 --> Loader Class Initialized
INFO - 2018-09-29 15:19:27 --> Helper loaded: url_helper
INFO - 2018-09-29 15:19:27 --> Helper loaded: form_helper
INFO - 2018-09-29 15:19:27 --> Helper loaded: html_helper
INFO - 2018-09-29 15:19:27 --> Database Driver Class Initialized
INFO - 2018-09-29 15:19:27 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:19:27 --> Model "User_model" initialized
INFO - 2018-09-29 15:19:27 --> Model "Project_model" initialized
INFO - 2018-09-29 15:19:27 --> Model "Tasks_model" initialized
INFO - 2018-09-29 15:19:27 --> Model "Lists_model" initialized
INFO - 2018-09-29 15:19:27 --> Controller Class Initialized
INFO - 2018-09-29 15:19:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-29 15:19:27 --> Config Class Initialized
INFO - 2018-09-29 15:19:27 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:19:27 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:19:27 --> Utf8 Class Initialized
INFO - 2018-09-29 15:19:27 --> URI Class Initialized
INFO - 2018-09-29 15:19:27 --> Router Class Initialized
INFO - 2018-09-29 15:19:27 --> Output Class Initialized
INFO - 2018-09-29 15:19:27 --> Security Class Initialized
DEBUG - 2018-09-29 15:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:19:27 --> Input Class Initialized
INFO - 2018-09-29 15:19:27 --> Language Class Initialized
INFO - 2018-09-29 15:19:27 --> Loader Class Initialized
INFO - 2018-09-29 15:19:27 --> Helper loaded: url_helper
INFO - 2018-09-29 15:19:27 --> Helper loaded: form_helper
INFO - 2018-09-29 15:19:27 --> Helper loaded: html_helper
INFO - 2018-09-29 15:19:27 --> Database Driver Class Initialized
INFO - 2018-09-29 15:19:27 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:19:27 --> Model "User_model" initialized
INFO - 2018-09-29 15:19:27 --> Model "Project_model" initialized
INFO - 2018-09-29 15:19:27 --> Model "Tasks_model" initialized
INFO - 2018-09-29 15:19:27 --> Model "Lists_model" initialized
INFO - 2018-09-29 15:19:27 --> Controller Class Initialized
INFO - 2018-09-29 15:19:27 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 15:19:27 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-29 15:19:27 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 15:19:27 --> Final output sent to browser
DEBUG - 2018-09-29 15:19:27 --> Total execution time: 0.0340
INFO - 2018-09-29 15:21:30 --> Config Class Initialized
INFO - 2018-09-29 15:21:30 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:21:30 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:21:30 --> Utf8 Class Initialized
INFO - 2018-09-29 15:21:30 --> URI Class Initialized
INFO - 2018-09-29 15:21:30 --> Router Class Initialized
INFO - 2018-09-29 15:21:30 --> Output Class Initialized
INFO - 2018-09-29 15:21:30 --> Security Class Initialized
DEBUG - 2018-09-29 15:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:21:30 --> Input Class Initialized
INFO - 2018-09-29 15:21:30 --> Language Class Initialized
INFO - 2018-09-29 15:21:30 --> Loader Class Initialized
INFO - 2018-09-29 15:21:30 --> Helper loaded: url_helper
INFO - 2018-09-29 15:21:30 --> Helper loaded: form_helper
INFO - 2018-09-29 15:21:30 --> Helper loaded: html_helper
INFO - 2018-09-29 15:21:30 --> Database Driver Class Initialized
INFO - 2018-09-29 15:21:30 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:21:30 --> Model "User_model" initialized
INFO - 2018-09-29 15:21:30 --> Model "Project_model" initialized
INFO - 2018-09-29 15:21:30 --> Model "Tasks_model" initialized
INFO - 2018-09-29 15:21:30 --> Model "Lists_model" initialized
INFO - 2018-09-29 15:21:30 --> Controller Class Initialized
INFO - 2018-09-29 15:21:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 15:21:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/create_project.php
INFO - 2018-09-29 15:21:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 15:21:30 --> Final output sent to browser
DEBUG - 2018-09-29 15:21:30 --> Total execution time: 0.0580
INFO - 2018-09-29 15:21:33 --> Config Class Initialized
INFO - 2018-09-29 15:21:33 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:21:33 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:21:33 --> Utf8 Class Initialized
INFO - 2018-09-29 15:21:33 --> URI Class Initialized
INFO - 2018-09-29 15:21:33 --> Router Class Initialized
INFO - 2018-09-29 15:21:33 --> Output Class Initialized
INFO - 2018-09-29 15:21:33 --> Security Class Initialized
DEBUG - 2018-09-29 15:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:21:33 --> Input Class Initialized
INFO - 2018-09-29 15:21:33 --> Language Class Initialized
INFO - 2018-09-29 15:21:33 --> Loader Class Initialized
INFO - 2018-09-29 15:21:33 --> Helper loaded: url_helper
INFO - 2018-09-29 15:21:33 --> Helper loaded: form_helper
INFO - 2018-09-29 15:21:33 --> Helper loaded: html_helper
INFO - 2018-09-29 15:21:33 --> Database Driver Class Initialized
INFO - 2018-09-29 15:21:33 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:21:33 --> Model "User_model" initialized
INFO - 2018-09-29 15:21:33 --> Model "Project_model" initialized
INFO - 2018-09-29 15:21:33 --> Model "Tasks_model" initialized
INFO - 2018-09-29 15:21:33 --> Model "Lists_model" initialized
INFO - 2018-09-29 15:21:33 --> Controller Class Initialized
INFO - 2018-09-29 15:21:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-29 15:21:33 --> Config Class Initialized
INFO - 2018-09-29 15:21:33 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:21:33 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:21:33 --> Utf8 Class Initialized
INFO - 2018-09-29 15:21:33 --> URI Class Initialized
INFO - 2018-09-29 15:21:33 --> Router Class Initialized
INFO - 2018-09-29 15:21:33 --> Output Class Initialized
INFO - 2018-09-29 15:21:33 --> Security Class Initialized
DEBUG - 2018-09-29 15:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:21:33 --> Input Class Initialized
INFO - 2018-09-29 15:21:33 --> Language Class Initialized
INFO - 2018-09-29 15:21:33 --> Loader Class Initialized
INFO - 2018-09-29 15:21:33 --> Helper loaded: url_helper
INFO - 2018-09-29 15:21:33 --> Helper loaded: form_helper
INFO - 2018-09-29 15:21:33 --> Helper loaded: html_helper
INFO - 2018-09-29 15:21:33 --> Database Driver Class Initialized
INFO - 2018-09-29 15:21:33 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:21:33 --> Model "User_model" initialized
INFO - 2018-09-29 15:21:33 --> Model "Project_model" initialized
INFO - 2018-09-29 15:21:33 --> Model "Tasks_model" initialized
INFO - 2018-09-29 15:21:33 --> Model "Lists_model" initialized
INFO - 2018-09-29 15:21:33 --> Controller Class Initialized
INFO - 2018-09-29 15:21:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 15:21:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-29 15:21:33 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 15:21:33 --> Final output sent to browser
DEBUG - 2018-09-29 15:21:33 --> Total execution time: 0.1170
INFO - 2018-09-29 15:23:53 --> Config Class Initialized
INFO - 2018-09-29 15:23:53 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:23:53 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:23:53 --> Utf8 Class Initialized
INFO - 2018-09-29 15:23:53 --> URI Class Initialized
INFO - 2018-09-29 15:23:53 --> Router Class Initialized
INFO - 2018-09-29 15:23:53 --> Output Class Initialized
INFO - 2018-09-29 15:23:53 --> Security Class Initialized
DEBUG - 2018-09-29 15:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:23:53 --> Input Class Initialized
INFO - 2018-09-29 15:23:53 --> Language Class Initialized
INFO - 2018-09-29 15:23:53 --> Loader Class Initialized
INFO - 2018-09-29 15:23:53 --> Helper loaded: url_helper
INFO - 2018-09-29 15:23:53 --> Helper loaded: form_helper
INFO - 2018-09-29 15:23:53 --> Helper loaded: html_helper
INFO - 2018-09-29 15:23:53 --> Database Driver Class Initialized
INFO - 2018-09-29 15:23:53 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:23:53 --> Model "User_model" initialized
INFO - 2018-09-29 15:23:53 --> Model "Project_model" initialized
INFO - 2018-09-29 15:23:53 --> Model "Tasks_model" initialized
INFO - 2018-09-29 15:23:53 --> Model "Lists_model" initialized
INFO - 2018-09-29 15:23:53 --> Controller Class Initialized
INFO - 2018-09-29 15:23:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 15:23:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/create_project.php
INFO - 2018-09-29 15:23:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 15:23:53 --> Final output sent to browser
DEBUG - 2018-09-29 15:23:53 --> Total execution time: 0.0610
INFO - 2018-09-29 15:23:56 --> Config Class Initialized
INFO - 2018-09-29 15:23:56 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:23:56 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:23:56 --> Utf8 Class Initialized
INFO - 2018-09-29 15:23:56 --> URI Class Initialized
INFO - 2018-09-29 15:23:56 --> Router Class Initialized
INFO - 2018-09-29 15:23:56 --> Output Class Initialized
INFO - 2018-09-29 15:23:56 --> Security Class Initialized
DEBUG - 2018-09-29 15:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:23:56 --> Input Class Initialized
INFO - 2018-09-29 15:23:56 --> Language Class Initialized
INFO - 2018-09-29 15:23:56 --> Loader Class Initialized
INFO - 2018-09-29 15:23:56 --> Helper loaded: url_helper
INFO - 2018-09-29 15:23:56 --> Helper loaded: form_helper
INFO - 2018-09-29 15:23:56 --> Helper loaded: html_helper
INFO - 2018-09-29 15:23:56 --> Database Driver Class Initialized
INFO - 2018-09-29 15:23:56 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:23:56 --> Model "User_model" initialized
INFO - 2018-09-29 15:23:56 --> Model "Project_model" initialized
INFO - 2018-09-29 15:23:56 --> Model "Tasks_model" initialized
INFO - 2018-09-29 15:23:56 --> Model "Lists_model" initialized
INFO - 2018-09-29 15:23:56 --> Controller Class Initialized
INFO - 2018-09-29 15:23:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-29 15:23:56 --> Config Class Initialized
INFO - 2018-09-29 15:23:56 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:23:56 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:23:56 --> Utf8 Class Initialized
INFO - 2018-09-29 15:23:56 --> URI Class Initialized
INFO - 2018-09-29 15:23:56 --> Router Class Initialized
INFO - 2018-09-29 15:23:56 --> Output Class Initialized
INFO - 2018-09-29 15:23:56 --> Security Class Initialized
DEBUG - 2018-09-29 15:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:23:56 --> Input Class Initialized
INFO - 2018-09-29 15:23:56 --> Language Class Initialized
INFO - 2018-09-29 15:23:56 --> Loader Class Initialized
INFO - 2018-09-29 15:23:56 --> Helper loaded: url_helper
INFO - 2018-09-29 15:23:56 --> Helper loaded: form_helper
INFO - 2018-09-29 15:23:56 --> Helper loaded: html_helper
INFO - 2018-09-29 15:23:56 --> Database Driver Class Initialized
INFO - 2018-09-29 15:23:56 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:23:56 --> Model "User_model" initialized
INFO - 2018-09-29 15:23:56 --> Model "Project_model" initialized
INFO - 2018-09-29 15:23:56 --> Model "Tasks_model" initialized
INFO - 2018-09-29 15:23:56 --> Model "Lists_model" initialized
INFO - 2018-09-29 15:23:56 --> Controller Class Initialized
INFO - 2018-09-29 15:23:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 15:23:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-29 15:23:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 15:23:56 --> Final output sent to browser
DEBUG - 2018-09-29 15:23:56 --> Total execution time: 0.0330
INFO - 2018-09-29 15:23:59 --> Config Class Initialized
INFO - 2018-09-29 15:23:59 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:23:59 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:23:59 --> Utf8 Class Initialized
INFO - 2018-09-29 15:23:59 --> URI Class Initialized
INFO - 2018-09-29 15:23:59 --> Router Class Initialized
INFO - 2018-09-29 15:23:59 --> Output Class Initialized
INFO - 2018-09-29 15:23:59 --> Security Class Initialized
DEBUG - 2018-09-29 15:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:23:59 --> Input Class Initialized
INFO - 2018-09-29 15:23:59 --> Language Class Initialized
INFO - 2018-09-29 15:23:59 --> Loader Class Initialized
INFO - 2018-09-29 15:23:59 --> Helper loaded: url_helper
INFO - 2018-09-29 15:23:59 --> Helper loaded: form_helper
INFO - 2018-09-29 15:23:59 --> Helper loaded: html_helper
INFO - 2018-09-29 15:23:59 --> Database Driver Class Initialized
INFO - 2018-09-29 15:23:59 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:23:59 --> Model "User_model" initialized
INFO - 2018-09-29 15:23:59 --> Model "Project_model" initialized
INFO - 2018-09-29 15:23:59 --> Model "Tasks_model" initialized
INFO - 2018-09-29 15:23:59 --> Model "Lists_model" initialized
INFO - 2018-09-29 15:23:59 --> Controller Class Initialized
INFO - 2018-09-29 15:23:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 15:23:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-29 15:23:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 15:23:59 --> Final output sent to browser
DEBUG - 2018-09-29 15:23:59 --> Total execution time: 0.0600
INFO - 2018-09-29 15:27:23 --> Config Class Initialized
INFO - 2018-09-29 15:27:23 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:27:23 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:27:23 --> Utf8 Class Initialized
INFO - 2018-09-29 15:27:23 --> URI Class Initialized
INFO - 2018-09-29 15:27:23 --> Router Class Initialized
INFO - 2018-09-29 15:27:23 --> Output Class Initialized
INFO - 2018-09-29 15:27:23 --> Security Class Initialized
DEBUG - 2018-09-29 15:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:27:23 --> Input Class Initialized
INFO - 2018-09-29 15:27:23 --> Language Class Initialized
INFO - 2018-09-29 15:27:23 --> Loader Class Initialized
INFO - 2018-09-29 15:27:23 --> Helper loaded: url_helper
INFO - 2018-09-29 15:27:23 --> Helper loaded: form_helper
INFO - 2018-09-29 15:27:23 --> Helper loaded: html_helper
INFO - 2018-09-29 15:27:23 --> Database Driver Class Initialized
INFO - 2018-09-29 15:27:23 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:27:23 --> Model "User_model" initialized
INFO - 2018-09-29 15:27:23 --> Model "Project_model" initialized
INFO - 2018-09-29 15:27:23 --> Model "Tasks_model" initialized
INFO - 2018-09-29 15:27:23 --> Model "Lists_model" initialized
INFO - 2018-09-29 15:27:23 --> Controller Class Initialized
INFO - 2018-09-29 15:27:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 15:27:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/create_project.php
INFO - 2018-09-29 15:27:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 15:27:23 --> Final output sent to browser
DEBUG - 2018-09-29 15:27:23 --> Total execution time: 0.0560
INFO - 2018-09-29 15:27:26 --> Config Class Initialized
INFO - 2018-09-29 15:27:26 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:27:26 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:27:26 --> Utf8 Class Initialized
INFO - 2018-09-29 15:27:26 --> URI Class Initialized
INFO - 2018-09-29 15:27:26 --> Router Class Initialized
INFO - 2018-09-29 15:27:26 --> Output Class Initialized
INFO - 2018-09-29 15:27:26 --> Security Class Initialized
DEBUG - 2018-09-29 15:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:27:26 --> Input Class Initialized
INFO - 2018-09-29 15:27:26 --> Language Class Initialized
INFO - 2018-09-29 15:27:26 --> Loader Class Initialized
INFO - 2018-09-29 15:27:26 --> Helper loaded: url_helper
INFO - 2018-09-29 15:27:26 --> Helper loaded: form_helper
INFO - 2018-09-29 15:27:26 --> Helper loaded: html_helper
INFO - 2018-09-29 15:27:26 --> Database Driver Class Initialized
INFO - 2018-09-29 15:27:26 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:27:26 --> Model "User_model" initialized
INFO - 2018-09-29 15:27:26 --> Model "Project_model" initialized
INFO - 2018-09-29 15:27:26 --> Model "Tasks_model" initialized
INFO - 2018-09-29 15:27:26 --> Model "Lists_model" initialized
INFO - 2018-09-29 15:27:26 --> Controller Class Initialized
INFO - 2018-09-29 15:27:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-09-29 15:27:26 --> Config Class Initialized
INFO - 2018-09-29 15:27:26 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:27:26 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:27:26 --> Utf8 Class Initialized
INFO - 2018-09-29 15:27:26 --> URI Class Initialized
INFO - 2018-09-29 15:27:26 --> Router Class Initialized
INFO - 2018-09-29 15:27:26 --> Output Class Initialized
INFO - 2018-09-29 15:27:26 --> Security Class Initialized
DEBUG - 2018-09-29 15:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:27:26 --> Input Class Initialized
INFO - 2018-09-29 15:27:26 --> Language Class Initialized
INFO - 2018-09-29 15:27:26 --> Loader Class Initialized
INFO - 2018-09-29 15:27:26 --> Helper loaded: url_helper
INFO - 2018-09-29 15:27:26 --> Helper loaded: form_helper
INFO - 2018-09-29 15:27:26 --> Helper loaded: html_helper
INFO - 2018-09-29 15:27:26 --> Database Driver Class Initialized
INFO - 2018-09-29 15:27:26 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:27:26 --> Model "User_model" initialized
INFO - 2018-09-29 15:27:26 --> Model "Project_model" initialized
INFO - 2018-09-29 15:27:26 --> Model "Tasks_model" initialized
INFO - 2018-09-29 15:27:26 --> Model "Lists_model" initialized
INFO - 2018-09-29 15:27:26 --> Controller Class Initialized
INFO - 2018-09-29 15:27:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 15:27:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-29 15:27:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 15:27:26 --> Final output sent to browser
DEBUG - 2018-09-29 15:27:26 --> Total execution time: 0.0450
INFO - 2018-09-29 15:27:30 --> Config Class Initialized
INFO - 2018-09-29 15:27:30 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:27:30 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:27:30 --> Utf8 Class Initialized
INFO - 2018-09-29 15:27:30 --> URI Class Initialized
INFO - 2018-09-29 15:27:30 --> Router Class Initialized
INFO - 2018-09-29 15:27:30 --> Output Class Initialized
INFO - 2018-09-29 15:27:30 --> Security Class Initialized
DEBUG - 2018-09-29 15:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:27:30 --> Input Class Initialized
INFO - 2018-09-29 15:27:30 --> Language Class Initialized
INFO - 2018-09-29 15:27:30 --> Loader Class Initialized
INFO - 2018-09-29 15:27:30 --> Helper loaded: url_helper
INFO - 2018-09-29 15:27:30 --> Helper loaded: form_helper
INFO - 2018-09-29 15:27:30 --> Helper loaded: html_helper
INFO - 2018-09-29 15:27:30 --> Database Driver Class Initialized
INFO - 2018-09-29 15:27:30 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:27:30 --> Model "User_model" initialized
INFO - 2018-09-29 15:27:30 --> Model "Project_model" initialized
INFO - 2018-09-29 15:27:30 --> Model "Tasks_model" initialized
INFO - 2018-09-29 15:27:30 --> Model "Lists_model" initialized
INFO - 2018-09-29 15:27:30 --> Controller Class Initialized
INFO - 2018-09-29 15:27:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 15:27:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/display.php
INFO - 2018-09-29 15:27:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 15:27:30 --> Final output sent to browser
DEBUG - 2018-09-29 15:27:30 --> Total execution time: 0.1340
INFO - 2018-09-29 15:27:31 --> Config Class Initialized
INFO - 2018-09-29 15:27:31 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:27:31 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:27:31 --> Utf8 Class Initialized
INFO - 2018-09-29 15:27:31 --> URI Class Initialized
INFO - 2018-09-29 15:27:31 --> Router Class Initialized
INFO - 2018-09-29 15:27:31 --> Output Class Initialized
INFO - 2018-09-29 15:27:31 --> Security Class Initialized
DEBUG - 2018-09-29 15:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:27:31 --> Input Class Initialized
INFO - 2018-09-29 15:27:31 --> Language Class Initialized
INFO - 2018-09-29 15:27:31 --> Loader Class Initialized
INFO - 2018-09-29 15:27:31 --> Helper loaded: url_helper
INFO - 2018-09-29 15:27:31 --> Helper loaded: form_helper
INFO - 2018-09-29 15:27:31 --> Helper loaded: html_helper
INFO - 2018-09-29 15:27:31 --> Database Driver Class Initialized
INFO - 2018-09-29 15:27:31 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:27:31 --> Model "User_model" initialized
INFO - 2018-09-29 15:27:31 --> Model "Project_model" initialized
INFO - 2018-09-29 15:27:31 --> Model "Tasks_model" initialized
INFO - 2018-09-29 15:27:31 --> Model "Lists_model" initialized
INFO - 2018-09-29 15:27:31 --> Controller Class Initialized
INFO - 2018-09-29 15:27:31 --> Config Class Initialized
INFO - 2018-09-29 15:27:31 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:27:31 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:27:31 --> Utf8 Class Initialized
INFO - 2018-09-29 15:27:31 --> URI Class Initialized
INFO - 2018-09-29 15:27:31 --> Router Class Initialized
INFO - 2018-09-29 15:27:31 --> Output Class Initialized
INFO - 2018-09-29 15:27:31 --> Security Class Initialized
DEBUG - 2018-09-29 15:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:27:31 --> Input Class Initialized
INFO - 2018-09-29 15:27:31 --> Language Class Initialized
INFO - 2018-09-29 15:27:31 --> Loader Class Initialized
INFO - 2018-09-29 15:27:31 --> Helper loaded: url_helper
INFO - 2018-09-29 15:27:31 --> Helper loaded: form_helper
INFO - 2018-09-29 15:27:31 --> Helper loaded: html_helper
INFO - 2018-09-29 15:27:31 --> Database Driver Class Initialized
INFO - 2018-09-29 15:27:31 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:27:31 --> Model "User_model" initialized
INFO - 2018-09-29 15:27:31 --> Model "Project_model" initialized
INFO - 2018-09-29 15:27:31 --> Model "Tasks_model" initialized
INFO - 2018-09-29 15:27:31 --> Model "Lists_model" initialized
INFO - 2018-09-29 15:27:31 --> Controller Class Initialized
INFO - 2018-09-29 15:27:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 15:27:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-29 15:27:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 15:27:31 --> Final output sent to browser
DEBUG - 2018-09-29 15:27:31 --> Total execution time: 0.0460
INFO - 2018-09-29 15:28:41 --> Config Class Initialized
INFO - 2018-09-29 15:28:41 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:28:41 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:28:41 --> Utf8 Class Initialized
INFO - 2018-09-29 15:28:41 --> URI Class Initialized
INFO - 2018-09-29 15:28:41 --> Router Class Initialized
INFO - 2018-09-29 15:28:41 --> Output Class Initialized
INFO - 2018-09-29 15:28:41 --> Security Class Initialized
DEBUG - 2018-09-29 15:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:28:41 --> Input Class Initialized
INFO - 2018-09-29 15:28:41 --> Language Class Initialized
INFO - 2018-09-29 15:28:41 --> Loader Class Initialized
INFO - 2018-09-29 15:28:41 --> Helper loaded: url_helper
INFO - 2018-09-29 15:28:41 --> Helper loaded: form_helper
INFO - 2018-09-29 15:28:41 --> Helper loaded: html_helper
INFO - 2018-09-29 15:28:41 --> Database Driver Class Initialized
INFO - 2018-09-29 15:28:41 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:28:41 --> Model "User_model" initialized
INFO - 2018-09-29 15:28:41 --> Model "Project_model" initialized
INFO - 2018-09-29 15:28:41 --> Model "Tasks_model" initialized
INFO - 2018-09-29 15:28:41 --> Model "Lists_model" initialized
INFO - 2018-09-29 15:28:41 --> Controller Class Initialized
INFO - 2018-09-29 15:28:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 15:28:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-09-29 15:28:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 15:28:41 --> Final output sent to browser
DEBUG - 2018-09-29 15:28:41 --> Total execution time: 0.0420
INFO - 2018-09-29 15:29:54 --> Config Class Initialized
INFO - 2018-09-29 15:29:54 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:29:54 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:29:54 --> Utf8 Class Initialized
INFO - 2018-09-29 15:29:54 --> URI Class Initialized
INFO - 2018-09-29 15:29:54 --> Router Class Initialized
INFO - 2018-09-29 15:29:54 --> Output Class Initialized
INFO - 2018-09-29 15:29:54 --> Security Class Initialized
DEBUG - 2018-09-29 15:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:29:54 --> Input Class Initialized
INFO - 2018-09-29 15:29:54 --> Language Class Initialized
INFO - 2018-09-29 15:29:54 --> Loader Class Initialized
INFO - 2018-09-29 15:29:54 --> Helper loaded: url_helper
INFO - 2018-09-29 15:29:54 --> Helper loaded: form_helper
INFO - 2018-09-29 15:29:54 --> Helper loaded: html_helper
INFO - 2018-09-29 15:29:54 --> Database Driver Class Initialized
INFO - 2018-09-29 15:29:54 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:29:54 --> Model "User_model" initialized
INFO - 2018-09-29 15:29:54 --> Model "Project_model" initialized
INFO - 2018-09-29 15:29:54 --> Model "Tasks_model" initialized
INFO - 2018-09-29 15:29:54 --> Model "Lists_model" initialized
INFO - 2018-09-29 15:29:54 --> Controller Class Initialized
INFO - 2018-09-29 15:29:54 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 15:29:54 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/create_project.php
INFO - 2018-09-29 15:29:54 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 15:29:54 --> Final output sent to browser
DEBUG - 2018-09-29 15:29:54 --> Total execution time: 0.0630
INFO - 2018-09-29 15:36:46 --> Config Class Initialized
INFO - 2018-09-29 15:36:46 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:36:46 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:36:46 --> Utf8 Class Initialized
INFO - 2018-09-29 15:36:46 --> URI Class Initialized
INFO - 2018-09-29 15:36:46 --> Router Class Initialized
INFO - 2018-09-29 15:36:46 --> Output Class Initialized
INFO - 2018-09-29 15:36:46 --> Security Class Initialized
DEBUG - 2018-09-29 15:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:36:46 --> Input Class Initialized
INFO - 2018-09-29 15:36:46 --> Language Class Initialized
INFO - 2018-09-29 15:36:46 --> Loader Class Initialized
INFO - 2018-09-29 15:36:46 --> Helper loaded: url_helper
INFO - 2018-09-29 15:36:46 --> Helper loaded: form_helper
INFO - 2018-09-29 15:36:46 --> Helper loaded: html_helper
INFO - 2018-09-29 15:36:46 --> Database Driver Class Initialized
INFO - 2018-09-29 15:36:46 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:36:46 --> Model "User_model" initialized
INFO - 2018-09-29 15:36:46 --> Model "Project_model" initialized
INFO - 2018-09-29 15:36:46 --> Model "Tasks_model" initialized
INFO - 2018-09-29 15:36:46 --> Model "Lists_model" initialized
INFO - 2018-09-29 15:36:46 --> Controller Class Initialized
INFO - 2018-09-29 15:36:46 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 15:36:46 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/create_project.php
INFO - 2018-09-29 15:36:46 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 15:36:46 --> Final output sent to browser
DEBUG - 2018-09-29 15:36:46 --> Total execution time: 0.0520
INFO - 2018-09-29 15:39:23 --> Config Class Initialized
INFO - 2018-09-29 15:39:23 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:39:23 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:39:23 --> Utf8 Class Initialized
INFO - 2018-09-29 15:39:23 --> URI Class Initialized
INFO - 2018-09-29 15:39:23 --> Router Class Initialized
INFO - 2018-09-29 15:39:23 --> Output Class Initialized
INFO - 2018-09-29 15:39:23 --> Security Class Initialized
DEBUG - 2018-09-29 15:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:39:23 --> Input Class Initialized
INFO - 2018-09-29 15:39:23 --> Language Class Initialized
INFO - 2018-09-29 15:39:23 --> Loader Class Initialized
INFO - 2018-09-29 15:39:23 --> Helper loaded: url_helper
INFO - 2018-09-29 15:39:23 --> Helper loaded: form_helper
INFO - 2018-09-29 15:39:23 --> Helper loaded: html_helper
INFO - 2018-09-29 15:39:23 --> Database Driver Class Initialized
INFO - 2018-09-29 15:39:23 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:39:23 --> Model "User_model" initialized
INFO - 2018-09-29 15:39:23 --> Model "Project_model" initialized
INFO - 2018-09-29 15:39:23 --> Model "Tasks_model" initialized
INFO - 2018-09-29 15:39:23 --> Model "Lists_model" initialized
INFO - 2018-09-29 15:39:23 --> Controller Class Initialized
INFO - 2018-09-29 15:39:23 --> Config Class Initialized
INFO - 2018-09-29 15:39:23 --> Hooks Class Initialized
DEBUG - 2018-09-29 15:39:23 --> UTF-8 Support Enabled
INFO - 2018-09-29 15:39:23 --> Utf8 Class Initialized
INFO - 2018-09-29 15:39:23 --> URI Class Initialized
INFO - 2018-09-29 15:39:23 --> Router Class Initialized
INFO - 2018-09-29 15:39:23 --> Output Class Initialized
INFO - 2018-09-29 15:39:23 --> Security Class Initialized
DEBUG - 2018-09-29 15:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-09-29 15:39:23 --> Input Class Initialized
INFO - 2018-09-29 15:39:23 --> Language Class Initialized
INFO - 2018-09-29 15:39:23 --> Loader Class Initialized
INFO - 2018-09-29 15:39:23 --> Helper loaded: url_helper
INFO - 2018-09-29 15:39:23 --> Helper loaded: form_helper
INFO - 2018-09-29 15:39:23 --> Helper loaded: html_helper
INFO - 2018-09-29 15:39:23 --> Database Driver Class Initialized
INFO - 2018-09-29 15:39:23 --> Form Validation Class Initialized
DEBUG - 2018-09-29 15:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-09-29 15:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-09-29 15:39:23 --> Model "User_model" initialized
INFO - 2018-09-29 15:39:23 --> Model "Project_model" initialized
INFO - 2018-09-29 15:39:23 --> Model "Tasks_model" initialized
INFO - 2018-09-29 15:39:23 --> Model "Lists_model" initialized
INFO - 2018-09-29 15:39:23 --> Controller Class Initialized
INFO - 2018-09-29 15:39:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-09-29 15:39:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-09-29 15:39:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-09-29 15:39:23 --> Final output sent to browser
DEBUG - 2018-09-29 15:39:23 --> Total execution time: 0.0700
