<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-01 05:02:29 --> Config Class Initialized
INFO - 2018-10-01 05:02:29 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:02:29 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:02:29 --> Utf8 Class Initialized
INFO - 2018-10-01 05:02:29 --> URI Class Initialized
INFO - 2018-10-01 05:02:30 --> Router Class Initialized
INFO - 2018-10-01 05:02:30 --> Output Class Initialized
INFO - 2018-10-01 05:02:30 --> Security Class Initialized
DEBUG - 2018-10-01 05:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:02:30 --> Input Class Initialized
INFO - 2018-10-01 05:02:30 --> Language Class Initialized
INFO - 2018-10-01 05:02:30 --> Loader Class Initialized
INFO - 2018-10-01 05:02:30 --> Helper loaded: url_helper
INFO - 2018-10-01 05:02:30 --> Helper loaded: form_helper
INFO - 2018-10-01 05:02:30 --> Helper loaded: html_helper
INFO - 2018-10-01 05:02:30 --> Database Driver Class Initialized
INFO - 2018-10-01 05:02:30 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:02:30 --> Model "User_model" initialized
INFO - 2018-10-01 05:02:30 --> Model "Project_model" initialized
INFO - 2018-10-01 05:02:30 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:02:30 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:02:30 --> Controller Class Initialized
INFO - 2018-10-01 05:02:30 --> Config Class Initialized
INFO - 2018-10-01 05:02:30 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:02:30 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:02:30 --> Utf8 Class Initialized
INFO - 2018-10-01 05:02:30 --> URI Class Initialized
INFO - 2018-10-01 05:02:30 --> Router Class Initialized
INFO - 2018-10-01 05:02:30 --> Output Class Initialized
INFO - 2018-10-01 05:02:30 --> Security Class Initialized
DEBUG - 2018-10-01 05:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:02:30 --> Input Class Initialized
INFO - 2018-10-01 05:02:30 --> Language Class Initialized
INFO - 2018-10-01 05:02:30 --> Loader Class Initialized
INFO - 2018-10-01 05:02:30 --> Helper loaded: url_helper
INFO - 2018-10-01 05:02:30 --> Helper loaded: form_helper
INFO - 2018-10-01 05:02:30 --> Helper loaded: html_helper
INFO - 2018-10-01 05:02:30 --> Database Driver Class Initialized
INFO - 2018-10-01 05:02:30 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:02:30 --> Model "User_model" initialized
INFO - 2018-10-01 05:02:30 --> Model "Project_model" initialized
INFO - 2018-10-01 05:02:30 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:02:30 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:02:30 --> Controller Class Initialized
INFO - 2018-10-01 05:02:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:02:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-01 05:02:30 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:02:30 --> Final output sent to browser
DEBUG - 2018-10-01 05:02:30 --> Total execution time: 0.0510
INFO - 2018-10-01 05:02:38 --> Config Class Initialized
INFO - 2018-10-01 05:02:38 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:02:38 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:02:38 --> Utf8 Class Initialized
INFO - 2018-10-01 05:02:38 --> URI Class Initialized
INFO - 2018-10-01 05:02:38 --> Router Class Initialized
INFO - 2018-10-01 05:02:38 --> Output Class Initialized
INFO - 2018-10-01 05:02:38 --> Security Class Initialized
DEBUG - 2018-10-01 05:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:02:38 --> Input Class Initialized
INFO - 2018-10-01 05:02:38 --> Language Class Initialized
INFO - 2018-10-01 05:02:38 --> Loader Class Initialized
INFO - 2018-10-01 05:02:38 --> Helper loaded: url_helper
INFO - 2018-10-01 05:02:38 --> Helper loaded: form_helper
INFO - 2018-10-01 05:02:38 --> Helper loaded: html_helper
INFO - 2018-10-01 05:02:38 --> Database Driver Class Initialized
INFO - 2018-10-01 05:02:38 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:02:38 --> Model "User_model" initialized
INFO - 2018-10-01 05:02:38 --> Model "Project_model" initialized
INFO - 2018-10-01 05:02:38 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:02:38 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:02:38 --> Controller Class Initialized
INFO - 2018-10-01 05:02:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-01 05:02:39 --> Config Class Initialized
INFO - 2018-10-01 05:02:39 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:02:39 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:02:39 --> Utf8 Class Initialized
INFO - 2018-10-01 05:02:39 --> URI Class Initialized
INFO - 2018-10-01 05:02:39 --> Router Class Initialized
INFO - 2018-10-01 05:02:39 --> Output Class Initialized
INFO - 2018-10-01 05:02:39 --> Security Class Initialized
DEBUG - 2018-10-01 05:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:02:39 --> Input Class Initialized
INFO - 2018-10-01 05:02:39 --> Language Class Initialized
INFO - 2018-10-01 05:02:39 --> Loader Class Initialized
INFO - 2018-10-01 05:02:39 --> Helper loaded: url_helper
INFO - 2018-10-01 05:02:39 --> Helper loaded: form_helper
INFO - 2018-10-01 05:02:39 --> Helper loaded: html_helper
INFO - 2018-10-01 05:02:39 --> Database Driver Class Initialized
INFO - 2018-10-01 05:02:39 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:02:39 --> Model "User_model" initialized
INFO - 2018-10-01 05:02:39 --> Model "Project_model" initialized
INFO - 2018-10-01 05:02:39 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:02:39 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:02:39 --> Controller Class Initialized
INFO - 2018-10-01 05:02:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:02:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-01 05:02:39 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:02:39 --> Final output sent to browser
DEBUG - 2018-10-01 05:02:39 --> Total execution time: 0.0450
INFO - 2018-10-01 05:02:41 --> Config Class Initialized
INFO - 2018-10-01 05:02:41 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:02:41 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:02:41 --> Utf8 Class Initialized
INFO - 2018-10-01 05:02:41 --> URI Class Initialized
INFO - 2018-10-01 05:02:41 --> Router Class Initialized
INFO - 2018-10-01 05:02:41 --> Output Class Initialized
INFO - 2018-10-01 05:02:41 --> Security Class Initialized
DEBUG - 2018-10-01 05:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:02:41 --> Input Class Initialized
INFO - 2018-10-01 05:02:41 --> Language Class Initialized
INFO - 2018-10-01 05:02:41 --> Loader Class Initialized
INFO - 2018-10-01 05:02:41 --> Helper loaded: url_helper
INFO - 2018-10-01 05:02:41 --> Helper loaded: form_helper
INFO - 2018-10-01 05:02:41 --> Helper loaded: html_helper
INFO - 2018-10-01 05:02:41 --> Database Driver Class Initialized
INFO - 2018-10-01 05:02:42 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:02:42 --> Model "User_model" initialized
INFO - 2018-10-01 05:02:42 --> Model "Project_model" initialized
INFO - 2018-10-01 05:02:42 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:02:42 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:02:42 --> Controller Class Initialized
INFO - 2018-10-01 05:02:42 --> Config Class Initialized
INFO - 2018-10-01 05:02:42 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:02:42 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:02:42 --> Utf8 Class Initialized
INFO - 2018-10-01 05:02:42 --> URI Class Initialized
INFO - 2018-10-01 05:02:42 --> Router Class Initialized
INFO - 2018-10-01 05:02:42 --> Output Class Initialized
INFO - 2018-10-01 05:02:42 --> Security Class Initialized
DEBUG - 2018-10-01 05:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:02:42 --> Input Class Initialized
INFO - 2018-10-01 05:02:42 --> Language Class Initialized
INFO - 2018-10-01 05:02:42 --> Loader Class Initialized
INFO - 2018-10-01 05:02:42 --> Helper loaded: url_helper
INFO - 2018-10-01 05:02:42 --> Helper loaded: form_helper
INFO - 2018-10-01 05:02:42 --> Helper loaded: html_helper
INFO - 2018-10-01 05:02:42 --> Database Driver Class Initialized
INFO - 2018-10-01 05:02:42 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:02:42 --> Model "User_model" initialized
INFO - 2018-10-01 05:02:42 --> Model "Project_model" initialized
INFO - 2018-10-01 05:02:42 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:02:42 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:02:42 --> Controller Class Initialized
INFO - 2018-10-01 05:02:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:02:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-01 05:02:42 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:02:42 --> Final output sent to browser
DEBUG - 2018-10-01 05:02:42 --> Total execution time: 0.0430
INFO - 2018-10-01 05:09:03 --> Config Class Initialized
INFO - 2018-10-01 05:09:03 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:09:03 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:09:03 --> Utf8 Class Initialized
INFO - 2018-10-01 05:09:03 --> URI Class Initialized
INFO - 2018-10-01 05:09:03 --> Router Class Initialized
INFO - 2018-10-01 05:09:03 --> Output Class Initialized
INFO - 2018-10-01 05:09:03 --> Security Class Initialized
DEBUG - 2018-10-01 05:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:09:03 --> Input Class Initialized
INFO - 2018-10-01 05:09:03 --> Language Class Initialized
INFO - 2018-10-01 05:09:03 --> Loader Class Initialized
INFO - 2018-10-01 05:09:03 --> Helper loaded: url_helper
INFO - 2018-10-01 05:09:03 --> Helper loaded: form_helper
INFO - 2018-10-01 05:09:03 --> Helper loaded: html_helper
INFO - 2018-10-01 05:09:03 --> Database Driver Class Initialized
INFO - 2018-10-01 05:09:03 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:09:03 --> Model "User_model" initialized
INFO - 2018-10-01 05:09:03 --> Model "Project_model" initialized
INFO - 2018-10-01 05:09:03 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:09:03 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:09:03 --> Controller Class Initialized
INFO - 2018-10-01 05:09:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:09:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-01 05:09:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:09:03 --> Final output sent to browser
DEBUG - 2018-10-01 05:09:03 --> Total execution time: 0.0520
INFO - 2018-10-01 05:09:04 --> Config Class Initialized
INFO - 2018-10-01 05:09:04 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:09:04 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:09:04 --> Utf8 Class Initialized
INFO - 2018-10-01 05:09:04 --> URI Class Initialized
INFO - 2018-10-01 05:09:04 --> Router Class Initialized
INFO - 2018-10-01 05:09:04 --> Output Class Initialized
INFO - 2018-10-01 05:09:04 --> Security Class Initialized
DEBUG - 2018-10-01 05:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:09:04 --> Input Class Initialized
INFO - 2018-10-01 05:09:04 --> Language Class Initialized
INFO - 2018-10-01 05:09:04 --> Loader Class Initialized
INFO - 2018-10-01 05:09:04 --> Helper loaded: url_helper
INFO - 2018-10-01 05:09:04 --> Helper loaded: form_helper
INFO - 2018-10-01 05:09:04 --> Helper loaded: html_helper
INFO - 2018-10-01 05:09:04 --> Database Driver Class Initialized
INFO - 2018-10-01 05:09:04 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:09:04 --> Model "User_model" initialized
INFO - 2018-10-01 05:09:04 --> Model "Project_model" initialized
INFO - 2018-10-01 05:09:04 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:09:04 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:09:04 --> Controller Class Initialized
INFO - 2018-10-01 05:09:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:09:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-01 05:09:04 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:09:04 --> Final output sent to browser
DEBUG - 2018-10-01 05:09:04 --> Total execution time: 0.0780
INFO - 2018-10-01 05:09:36 --> Config Class Initialized
INFO - 2018-10-01 05:09:36 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:09:36 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:09:36 --> Utf8 Class Initialized
INFO - 2018-10-01 05:09:36 --> URI Class Initialized
INFO - 2018-10-01 05:09:36 --> Router Class Initialized
INFO - 2018-10-01 05:09:36 --> Output Class Initialized
INFO - 2018-10-01 05:09:36 --> Security Class Initialized
DEBUG - 2018-10-01 05:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:09:36 --> Input Class Initialized
INFO - 2018-10-01 05:09:36 --> Language Class Initialized
INFO - 2018-10-01 05:09:36 --> Loader Class Initialized
INFO - 2018-10-01 05:09:36 --> Helper loaded: url_helper
INFO - 2018-10-01 05:09:36 --> Helper loaded: form_helper
INFO - 2018-10-01 05:09:36 --> Helper loaded: html_helper
INFO - 2018-10-01 05:09:36 --> Database Driver Class Initialized
INFO - 2018-10-01 05:09:36 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:09:36 --> Model "User_model" initialized
INFO - 2018-10-01 05:09:36 --> Model "Project_model" initialized
INFO - 2018-10-01 05:09:36 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:09:36 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:09:36 --> Controller Class Initialized
INFO - 2018-10-01 05:09:36 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:09:36 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-01 05:09:36 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:09:36 --> Final output sent to browser
DEBUG - 2018-10-01 05:09:36 --> Total execution time: 0.0530
INFO - 2018-10-01 05:09:44 --> Config Class Initialized
INFO - 2018-10-01 05:09:44 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:09:44 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:09:44 --> Utf8 Class Initialized
INFO - 2018-10-01 05:09:44 --> URI Class Initialized
INFO - 2018-10-01 05:09:44 --> Router Class Initialized
INFO - 2018-10-01 05:09:44 --> Output Class Initialized
INFO - 2018-10-01 05:09:44 --> Security Class Initialized
DEBUG - 2018-10-01 05:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:09:44 --> Input Class Initialized
INFO - 2018-10-01 05:09:44 --> Language Class Initialized
INFO - 2018-10-01 05:09:44 --> Loader Class Initialized
INFO - 2018-10-01 05:09:44 --> Helper loaded: url_helper
INFO - 2018-10-01 05:09:44 --> Helper loaded: form_helper
INFO - 2018-10-01 05:09:44 --> Helper loaded: html_helper
INFO - 2018-10-01 05:09:44 --> Database Driver Class Initialized
INFO - 2018-10-01 05:09:44 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:09:44 --> Model "User_model" initialized
INFO - 2018-10-01 05:09:44 --> Model "Project_model" initialized
INFO - 2018-10-01 05:09:44 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:09:44 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:09:44 --> Controller Class Initialized
INFO - 2018-10-01 05:09:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-01 05:09:44 --> Config Class Initialized
INFO - 2018-10-01 05:09:44 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:09:44 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:09:44 --> Utf8 Class Initialized
INFO - 2018-10-01 05:09:44 --> URI Class Initialized
INFO - 2018-10-01 05:09:44 --> Router Class Initialized
INFO - 2018-10-01 05:09:44 --> Output Class Initialized
INFO - 2018-10-01 05:09:44 --> Security Class Initialized
DEBUG - 2018-10-01 05:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:09:44 --> Input Class Initialized
INFO - 2018-10-01 05:09:44 --> Language Class Initialized
INFO - 2018-10-01 05:09:44 --> Loader Class Initialized
INFO - 2018-10-01 05:09:44 --> Helper loaded: url_helper
INFO - 2018-10-01 05:09:44 --> Helper loaded: form_helper
INFO - 2018-10-01 05:09:44 --> Helper loaded: html_helper
INFO - 2018-10-01 05:09:44 --> Database Driver Class Initialized
INFO - 2018-10-01 05:09:44 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:09:44 --> Model "User_model" initialized
INFO - 2018-10-01 05:09:44 --> Model "Project_model" initialized
INFO - 2018-10-01 05:09:44 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:09:44 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:09:44 --> Controller Class Initialized
INFO - 2018-10-01 05:09:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:09:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-01 05:09:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:09:44 --> Final output sent to browser
DEBUG - 2018-10-01 05:09:44 --> Total execution time: 0.0440
INFO - 2018-10-01 05:09:47 --> Config Class Initialized
INFO - 2018-10-01 05:09:47 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:09:47 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:09:47 --> Utf8 Class Initialized
INFO - 2018-10-01 05:09:47 --> URI Class Initialized
INFO - 2018-10-01 05:09:47 --> Router Class Initialized
INFO - 2018-10-01 05:09:47 --> Output Class Initialized
INFO - 2018-10-01 05:09:47 --> Security Class Initialized
DEBUG - 2018-10-01 05:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:09:47 --> Input Class Initialized
INFO - 2018-10-01 05:09:47 --> Language Class Initialized
INFO - 2018-10-01 05:09:47 --> Loader Class Initialized
INFO - 2018-10-01 05:09:47 --> Helper loaded: url_helper
INFO - 2018-10-01 05:09:47 --> Helper loaded: form_helper
INFO - 2018-10-01 05:09:47 --> Helper loaded: html_helper
INFO - 2018-10-01 05:09:47 --> Database Driver Class Initialized
INFO - 2018-10-01 05:09:47 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:09:47 --> Model "User_model" initialized
INFO - 2018-10-01 05:09:47 --> Model "Project_model" initialized
INFO - 2018-10-01 05:09:47 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:09:47 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:09:47 --> Controller Class Initialized
INFO - 2018-10-01 05:09:47 --> Config Class Initialized
INFO - 2018-10-01 05:09:47 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:09:47 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:09:47 --> Utf8 Class Initialized
INFO - 2018-10-01 05:09:47 --> URI Class Initialized
INFO - 2018-10-01 05:09:47 --> Router Class Initialized
INFO - 2018-10-01 05:09:47 --> Output Class Initialized
INFO - 2018-10-01 05:09:47 --> Security Class Initialized
DEBUG - 2018-10-01 05:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:09:47 --> Input Class Initialized
INFO - 2018-10-01 05:09:47 --> Language Class Initialized
INFO - 2018-10-01 05:09:47 --> Loader Class Initialized
INFO - 2018-10-01 05:09:47 --> Helper loaded: url_helper
INFO - 2018-10-01 05:09:47 --> Helper loaded: form_helper
INFO - 2018-10-01 05:09:47 --> Helper loaded: html_helper
INFO - 2018-10-01 05:09:47 --> Database Driver Class Initialized
INFO - 2018-10-01 05:09:47 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:09:47 --> Model "User_model" initialized
INFO - 2018-10-01 05:09:47 --> Model "Project_model" initialized
INFO - 2018-10-01 05:09:47 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:09:47 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:09:47 --> Controller Class Initialized
INFO - 2018-10-01 05:09:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:09:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-01 05:09:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:09:47 --> Final output sent to browser
DEBUG - 2018-10-01 05:09:47 --> Total execution time: 0.0440
INFO - 2018-10-01 05:10:37 --> Config Class Initialized
INFO - 2018-10-01 05:10:37 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:10:37 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:10:37 --> Utf8 Class Initialized
INFO - 2018-10-01 05:10:37 --> URI Class Initialized
INFO - 2018-10-01 05:10:37 --> Router Class Initialized
INFO - 2018-10-01 05:10:37 --> Output Class Initialized
INFO - 2018-10-01 05:10:37 --> Security Class Initialized
DEBUG - 2018-10-01 05:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:10:37 --> Input Class Initialized
INFO - 2018-10-01 05:10:37 --> Language Class Initialized
INFO - 2018-10-01 05:10:37 --> Loader Class Initialized
INFO - 2018-10-01 05:10:37 --> Helper loaded: url_helper
INFO - 2018-10-01 05:10:37 --> Helper loaded: form_helper
INFO - 2018-10-01 05:10:37 --> Helper loaded: html_helper
INFO - 2018-10-01 05:10:37 --> Database Driver Class Initialized
INFO - 2018-10-01 05:10:37 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:10:37 --> Model "User_model" initialized
INFO - 2018-10-01 05:10:37 --> Model "Project_model" initialized
INFO - 2018-10-01 05:10:37 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:10:37 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:10:37 --> Controller Class Initialized
INFO - 2018-10-01 05:10:37 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:10:37 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-01 05:10:37 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:10:37 --> Final output sent to browser
DEBUG - 2018-10-01 05:10:37 --> Total execution time: 0.0400
INFO - 2018-10-01 05:10:43 --> Config Class Initialized
INFO - 2018-10-01 05:10:43 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:10:43 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:10:43 --> Utf8 Class Initialized
INFO - 2018-10-01 05:10:43 --> URI Class Initialized
INFO - 2018-10-01 05:10:43 --> Router Class Initialized
INFO - 2018-10-01 05:10:43 --> Output Class Initialized
INFO - 2018-10-01 05:10:43 --> Security Class Initialized
DEBUG - 2018-10-01 05:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:10:43 --> Input Class Initialized
INFO - 2018-10-01 05:10:43 --> Language Class Initialized
INFO - 2018-10-01 05:10:43 --> Loader Class Initialized
INFO - 2018-10-01 05:10:43 --> Helper loaded: url_helper
INFO - 2018-10-01 05:10:43 --> Helper loaded: form_helper
INFO - 2018-10-01 05:10:43 --> Helper loaded: html_helper
INFO - 2018-10-01 05:10:43 --> Database Driver Class Initialized
INFO - 2018-10-01 05:10:43 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:10:43 --> Model "User_model" initialized
INFO - 2018-10-01 05:10:43 --> Model "Project_model" initialized
INFO - 2018-10-01 05:10:43 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:10:43 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:10:43 --> Controller Class Initialized
INFO - 2018-10-01 05:10:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-01 05:10:44 --> Config Class Initialized
INFO - 2018-10-01 05:10:44 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:10:44 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:10:44 --> Utf8 Class Initialized
INFO - 2018-10-01 05:10:44 --> URI Class Initialized
INFO - 2018-10-01 05:10:44 --> Router Class Initialized
INFO - 2018-10-01 05:10:44 --> Output Class Initialized
INFO - 2018-10-01 05:10:44 --> Security Class Initialized
DEBUG - 2018-10-01 05:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:10:44 --> Input Class Initialized
INFO - 2018-10-01 05:10:44 --> Language Class Initialized
INFO - 2018-10-01 05:10:44 --> Loader Class Initialized
INFO - 2018-10-01 05:10:44 --> Helper loaded: url_helper
INFO - 2018-10-01 05:10:44 --> Helper loaded: form_helper
INFO - 2018-10-01 05:10:44 --> Helper loaded: html_helper
INFO - 2018-10-01 05:10:44 --> Database Driver Class Initialized
INFO - 2018-10-01 05:10:44 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:10:44 --> Model "User_model" initialized
INFO - 2018-10-01 05:10:44 --> Model "Project_model" initialized
INFO - 2018-10-01 05:10:44 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:10:44 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:10:44 --> Controller Class Initialized
INFO - 2018-10-01 05:10:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:10:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-01 05:10:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:10:44 --> Final output sent to browser
DEBUG - 2018-10-01 05:10:44 --> Total execution time: 0.0350
INFO - 2018-10-01 05:10:47 --> Config Class Initialized
INFO - 2018-10-01 05:10:47 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:10:47 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:10:47 --> Utf8 Class Initialized
INFO - 2018-10-01 05:10:47 --> URI Class Initialized
INFO - 2018-10-01 05:10:47 --> Router Class Initialized
INFO - 2018-10-01 05:10:47 --> Output Class Initialized
INFO - 2018-10-01 05:10:47 --> Security Class Initialized
DEBUG - 2018-10-01 05:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:10:47 --> Input Class Initialized
INFO - 2018-10-01 05:10:47 --> Language Class Initialized
INFO - 2018-10-01 05:10:47 --> Loader Class Initialized
INFO - 2018-10-01 05:10:47 --> Helper loaded: url_helper
INFO - 2018-10-01 05:10:47 --> Helper loaded: form_helper
INFO - 2018-10-01 05:10:47 --> Helper loaded: html_helper
INFO - 2018-10-01 05:10:47 --> Database Driver Class Initialized
INFO - 2018-10-01 05:10:47 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:10:47 --> Model "User_model" initialized
INFO - 2018-10-01 05:10:47 --> Model "Project_model" initialized
INFO - 2018-10-01 05:10:47 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:10:47 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:10:47 --> Controller Class Initialized
INFO - 2018-10-01 05:10:47 --> Config Class Initialized
INFO - 2018-10-01 05:10:47 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:10:47 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:10:47 --> Utf8 Class Initialized
INFO - 2018-10-01 05:10:47 --> URI Class Initialized
INFO - 2018-10-01 05:10:47 --> Router Class Initialized
INFO - 2018-10-01 05:10:47 --> Output Class Initialized
INFO - 2018-10-01 05:10:47 --> Security Class Initialized
DEBUG - 2018-10-01 05:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:10:47 --> Input Class Initialized
INFO - 2018-10-01 05:10:47 --> Language Class Initialized
INFO - 2018-10-01 05:10:47 --> Loader Class Initialized
INFO - 2018-10-01 05:10:47 --> Helper loaded: url_helper
INFO - 2018-10-01 05:10:47 --> Helper loaded: form_helper
INFO - 2018-10-01 05:10:47 --> Helper loaded: html_helper
INFO - 2018-10-01 05:10:47 --> Database Driver Class Initialized
INFO - 2018-10-01 05:10:47 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:10:47 --> Model "User_model" initialized
INFO - 2018-10-01 05:10:47 --> Model "Project_model" initialized
INFO - 2018-10-01 05:10:47 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:10:47 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:10:47 --> Controller Class Initialized
INFO - 2018-10-01 05:10:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:10:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-01 05:10:47 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:10:47 --> Final output sent to browser
DEBUG - 2018-10-01 05:10:47 --> Total execution time: 0.0430
INFO - 2018-10-01 05:11:03 --> Config Class Initialized
INFO - 2018-10-01 05:11:03 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:11:03 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:11:03 --> Utf8 Class Initialized
INFO - 2018-10-01 05:11:03 --> URI Class Initialized
INFO - 2018-10-01 05:11:03 --> Router Class Initialized
INFO - 2018-10-01 05:11:03 --> Output Class Initialized
INFO - 2018-10-01 05:11:03 --> Security Class Initialized
DEBUG - 2018-10-01 05:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:11:03 --> Input Class Initialized
INFO - 2018-10-01 05:11:03 --> Language Class Initialized
INFO - 2018-10-01 05:11:03 --> Loader Class Initialized
INFO - 2018-10-01 05:11:03 --> Helper loaded: url_helper
INFO - 2018-10-01 05:11:03 --> Helper loaded: form_helper
INFO - 2018-10-01 05:11:03 --> Helper loaded: html_helper
INFO - 2018-10-01 05:11:03 --> Database Driver Class Initialized
INFO - 2018-10-01 05:11:03 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:11:03 --> Model "User_model" initialized
INFO - 2018-10-01 05:11:03 --> Model "Project_model" initialized
INFO - 2018-10-01 05:11:03 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:11:03 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:11:03 --> Controller Class Initialized
INFO - 2018-10-01 05:11:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:11:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-01 05:11:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:11:03 --> Final output sent to browser
DEBUG - 2018-10-01 05:11:03 --> Total execution time: 0.0580
INFO - 2018-10-01 05:11:09 --> Config Class Initialized
INFO - 2018-10-01 05:11:09 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:11:09 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:11:09 --> Utf8 Class Initialized
INFO - 2018-10-01 05:11:09 --> URI Class Initialized
INFO - 2018-10-01 05:11:09 --> Router Class Initialized
INFO - 2018-10-01 05:11:09 --> Output Class Initialized
INFO - 2018-10-01 05:11:09 --> Security Class Initialized
DEBUG - 2018-10-01 05:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:11:09 --> Input Class Initialized
INFO - 2018-10-01 05:11:09 --> Language Class Initialized
INFO - 2018-10-01 05:11:09 --> Loader Class Initialized
INFO - 2018-10-01 05:11:09 --> Helper loaded: url_helper
INFO - 2018-10-01 05:11:09 --> Helper loaded: form_helper
INFO - 2018-10-01 05:11:09 --> Helper loaded: html_helper
INFO - 2018-10-01 05:11:09 --> Database Driver Class Initialized
INFO - 2018-10-01 05:11:09 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:11:09 --> Model "User_model" initialized
INFO - 2018-10-01 05:11:09 --> Model "Project_model" initialized
INFO - 2018-10-01 05:11:09 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:11:09 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:11:09 --> Controller Class Initialized
INFO - 2018-10-01 05:11:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:11:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-01 05:11:09 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:11:09 --> Final output sent to browser
DEBUG - 2018-10-01 05:11:09 --> Total execution time: 0.0400
INFO - 2018-10-01 05:12:02 --> Config Class Initialized
INFO - 2018-10-01 05:12:02 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:12:02 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:12:03 --> Utf8 Class Initialized
INFO - 2018-10-01 05:12:03 --> URI Class Initialized
INFO - 2018-10-01 05:12:03 --> Router Class Initialized
INFO - 2018-10-01 05:12:03 --> Output Class Initialized
INFO - 2018-10-01 05:12:03 --> Security Class Initialized
DEBUG - 2018-10-01 05:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:12:03 --> Input Class Initialized
INFO - 2018-10-01 05:12:03 --> Language Class Initialized
INFO - 2018-10-01 05:12:03 --> Loader Class Initialized
INFO - 2018-10-01 05:12:03 --> Helper loaded: url_helper
INFO - 2018-10-01 05:12:03 --> Helper loaded: form_helper
INFO - 2018-10-01 05:12:03 --> Helper loaded: html_helper
INFO - 2018-10-01 05:12:03 --> Database Driver Class Initialized
INFO - 2018-10-01 05:12:03 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:12:03 --> Model "User_model" initialized
INFO - 2018-10-01 05:12:03 --> Model "Project_model" initialized
INFO - 2018-10-01 05:12:03 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:12:03 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:12:03 --> Controller Class Initialized
INFO - 2018-10-01 05:12:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:12:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-01 05:12:03 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:12:03 --> Final output sent to browser
DEBUG - 2018-10-01 05:12:03 --> Total execution time: 0.1290
INFO - 2018-10-01 05:19:45 --> Config Class Initialized
INFO - 2018-10-01 05:19:45 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:19:45 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:19:45 --> Utf8 Class Initialized
INFO - 2018-10-01 05:19:45 --> URI Class Initialized
INFO - 2018-10-01 05:19:45 --> Router Class Initialized
INFO - 2018-10-01 05:19:45 --> Output Class Initialized
INFO - 2018-10-01 05:19:45 --> Security Class Initialized
DEBUG - 2018-10-01 05:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:19:45 --> Input Class Initialized
INFO - 2018-10-01 05:19:45 --> Language Class Initialized
INFO - 2018-10-01 05:19:45 --> Loader Class Initialized
INFO - 2018-10-01 05:19:45 --> Helper loaded: url_helper
INFO - 2018-10-01 05:19:45 --> Helper loaded: form_helper
INFO - 2018-10-01 05:19:45 --> Helper loaded: html_helper
INFO - 2018-10-01 05:19:45 --> Database Driver Class Initialized
INFO - 2018-10-01 05:19:45 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:19:45 --> Model "User_model" initialized
INFO - 2018-10-01 05:19:45 --> Model "Project_model" initialized
INFO - 2018-10-01 05:19:45 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:19:45 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:19:45 --> Controller Class Initialized
INFO - 2018-10-01 05:19:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:19:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-01 05:19:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:19:45 --> Final output sent to browser
DEBUG - 2018-10-01 05:19:45 --> Total execution time: 0.0570
INFO - 2018-10-01 05:19:51 --> Config Class Initialized
INFO - 2018-10-01 05:19:51 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:19:51 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:19:51 --> Utf8 Class Initialized
INFO - 2018-10-01 05:19:51 --> URI Class Initialized
INFO - 2018-10-01 05:19:51 --> Router Class Initialized
INFO - 2018-10-01 05:19:51 --> Output Class Initialized
INFO - 2018-10-01 05:19:51 --> Security Class Initialized
DEBUG - 2018-10-01 05:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:19:51 --> Input Class Initialized
INFO - 2018-10-01 05:19:51 --> Language Class Initialized
INFO - 2018-10-01 05:19:51 --> Loader Class Initialized
INFO - 2018-10-01 05:19:51 --> Helper loaded: url_helper
INFO - 2018-10-01 05:19:51 --> Helper loaded: form_helper
INFO - 2018-10-01 05:19:51 --> Helper loaded: html_helper
INFO - 2018-10-01 05:19:51 --> Database Driver Class Initialized
INFO - 2018-10-01 05:19:51 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:19:51 --> Model "User_model" initialized
INFO - 2018-10-01 05:19:51 --> Model "Project_model" initialized
INFO - 2018-10-01 05:19:51 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:19:51 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:19:51 --> Controller Class Initialized
INFO - 2018-10-01 05:19:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-01 05:19:52 --> Config Class Initialized
INFO - 2018-10-01 05:19:52 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:19:52 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:19:52 --> Utf8 Class Initialized
INFO - 2018-10-01 05:19:52 --> URI Class Initialized
INFO - 2018-10-01 05:19:52 --> Router Class Initialized
INFO - 2018-10-01 05:19:52 --> Output Class Initialized
INFO - 2018-10-01 05:19:52 --> Security Class Initialized
DEBUG - 2018-10-01 05:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:19:52 --> Input Class Initialized
INFO - 2018-10-01 05:19:52 --> Language Class Initialized
INFO - 2018-10-01 05:19:52 --> Loader Class Initialized
INFO - 2018-10-01 05:19:52 --> Helper loaded: url_helper
INFO - 2018-10-01 05:19:52 --> Helper loaded: form_helper
INFO - 2018-10-01 05:19:52 --> Helper loaded: html_helper
INFO - 2018-10-01 05:19:52 --> Database Driver Class Initialized
INFO - 2018-10-01 05:19:52 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:19:52 --> Model "User_model" initialized
INFO - 2018-10-01 05:19:52 --> Model "Project_model" initialized
INFO - 2018-10-01 05:19:52 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:19:52 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:19:52 --> Controller Class Initialized
INFO - 2018-10-01 05:19:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:19:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-01 05:19:52 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:19:52 --> Final output sent to browser
DEBUG - 2018-10-01 05:19:52 --> Total execution time: 0.1200
INFO - 2018-10-01 05:19:53 --> Config Class Initialized
INFO - 2018-10-01 05:19:53 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:19:53 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:19:53 --> Utf8 Class Initialized
INFO - 2018-10-01 05:19:53 --> URI Class Initialized
INFO - 2018-10-01 05:19:53 --> Router Class Initialized
INFO - 2018-10-01 05:19:53 --> Output Class Initialized
INFO - 2018-10-01 05:19:53 --> Security Class Initialized
DEBUG - 2018-10-01 05:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:19:53 --> Input Class Initialized
INFO - 2018-10-01 05:19:53 --> Language Class Initialized
INFO - 2018-10-01 05:19:53 --> Loader Class Initialized
INFO - 2018-10-01 05:19:53 --> Helper loaded: url_helper
INFO - 2018-10-01 05:19:53 --> Helper loaded: form_helper
INFO - 2018-10-01 05:19:53 --> Helper loaded: html_helper
INFO - 2018-10-01 05:19:53 --> Database Driver Class Initialized
INFO - 2018-10-01 05:19:53 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:19:53 --> Model "User_model" initialized
INFO - 2018-10-01 05:19:53 --> Model "Project_model" initialized
INFO - 2018-10-01 05:19:53 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:19:53 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:19:53 --> Controller Class Initialized
INFO - 2018-10-01 05:19:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:19:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-10-01 05:19:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:19:53 --> Final output sent to browser
DEBUG - 2018-10-01 05:19:53 --> Total execution time: 0.0750
INFO - 2018-10-01 05:19:55 --> Config Class Initialized
INFO - 2018-10-01 05:19:55 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:19:55 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:19:55 --> Utf8 Class Initialized
INFO - 2018-10-01 05:19:55 --> URI Class Initialized
INFO - 2018-10-01 05:19:55 --> Router Class Initialized
INFO - 2018-10-01 05:19:55 --> Output Class Initialized
INFO - 2018-10-01 05:19:55 --> Security Class Initialized
DEBUG - 2018-10-01 05:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:19:55 --> Input Class Initialized
INFO - 2018-10-01 05:19:55 --> Language Class Initialized
INFO - 2018-10-01 05:19:55 --> Loader Class Initialized
INFO - 2018-10-01 05:19:55 --> Helper loaded: url_helper
INFO - 2018-10-01 05:19:55 --> Helper loaded: form_helper
INFO - 2018-10-01 05:19:55 --> Helper loaded: html_helper
INFO - 2018-10-01 05:19:55 --> Database Driver Class Initialized
INFO - 2018-10-01 05:19:55 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:19:55 --> Model "User_model" initialized
INFO - 2018-10-01 05:19:55 --> Model "Project_model" initialized
INFO - 2018-10-01 05:19:55 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:19:55 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:19:55 --> Controller Class Initialized
INFO - 2018-10-01 05:19:55 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:19:55 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/tasks/index.php
INFO - 2018-10-01 05:19:55 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:19:55 --> Final output sent to browser
DEBUG - 2018-10-01 05:19:55 --> Total execution time: 0.1140
INFO - 2018-10-01 05:19:55 --> Config Class Initialized
INFO - 2018-10-01 05:19:55 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:19:55 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:19:55 --> Utf8 Class Initialized
INFO - 2018-10-01 05:19:55 --> URI Class Initialized
INFO - 2018-10-01 05:19:55 --> Router Class Initialized
INFO - 2018-10-01 05:19:55 --> Output Class Initialized
INFO - 2018-10-01 05:19:55 --> Security Class Initialized
DEBUG - 2018-10-01 05:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:19:55 --> Input Class Initialized
INFO - 2018-10-01 05:19:55 --> Language Class Initialized
INFO - 2018-10-01 05:19:55 --> Loader Class Initialized
INFO - 2018-10-01 05:19:55 --> Helper loaded: url_helper
INFO - 2018-10-01 05:19:55 --> Helper loaded: form_helper
INFO - 2018-10-01 05:19:55 --> Helper loaded: html_helper
INFO - 2018-10-01 05:19:56 --> Database Driver Class Initialized
INFO - 2018-10-01 05:19:56 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:19:56 --> Model "User_model" initialized
INFO - 2018-10-01 05:19:56 --> Model "Project_model" initialized
INFO - 2018-10-01 05:19:56 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:19:56 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:19:56 --> Controller Class Initialized
INFO - 2018-10-01 05:19:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:19:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/lists/index.php
INFO - 2018-10-01 05:19:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:19:56 --> Final output sent to browser
DEBUG - 2018-10-01 05:19:56 --> Total execution time: 0.0910
INFO - 2018-10-01 05:19:56 --> Config Class Initialized
INFO - 2018-10-01 05:19:56 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:19:56 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:19:56 --> Utf8 Class Initialized
INFO - 2018-10-01 05:19:56 --> URI Class Initialized
INFO - 2018-10-01 05:19:56 --> Router Class Initialized
INFO - 2018-10-01 05:19:56 --> Output Class Initialized
INFO - 2018-10-01 05:19:56 --> Security Class Initialized
DEBUG - 2018-10-01 05:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:19:56 --> Input Class Initialized
INFO - 2018-10-01 05:19:56 --> Language Class Initialized
INFO - 2018-10-01 05:19:56 --> Loader Class Initialized
INFO - 2018-10-01 05:19:56 --> Helper loaded: url_helper
INFO - 2018-10-01 05:19:56 --> Helper loaded: form_helper
INFO - 2018-10-01 05:19:56 --> Helper loaded: html_helper
INFO - 2018-10-01 05:19:56 --> Database Driver Class Initialized
INFO - 2018-10-01 05:19:56 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:19:56 --> Model "User_model" initialized
INFO - 2018-10-01 05:19:56 --> Model "Project_model" initialized
INFO - 2018-10-01 05:19:56 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:19:56 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:19:56 --> Controller Class Initialized
INFO - 2018-10-01 05:19:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:19:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-10-01 05:19:56 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:19:56 --> Final output sent to browser
DEBUG - 2018-10-01 05:19:56 --> Total execution time: 0.0530
INFO - 2018-10-01 05:19:57 --> Config Class Initialized
INFO - 2018-10-01 05:19:57 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:19:57 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:19:57 --> Utf8 Class Initialized
INFO - 2018-10-01 05:19:57 --> URI Class Initialized
INFO - 2018-10-01 05:19:57 --> Router Class Initialized
INFO - 2018-10-01 05:19:57 --> Output Class Initialized
INFO - 2018-10-01 05:19:57 --> Security Class Initialized
DEBUG - 2018-10-01 05:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:19:57 --> Input Class Initialized
INFO - 2018-10-01 05:19:57 --> Language Class Initialized
INFO - 2018-10-01 05:19:57 --> Loader Class Initialized
INFO - 2018-10-01 05:19:57 --> Helper loaded: url_helper
INFO - 2018-10-01 05:19:57 --> Helper loaded: form_helper
INFO - 2018-10-01 05:19:57 --> Helper loaded: html_helper
INFO - 2018-10-01 05:19:57 --> Database Driver Class Initialized
INFO - 2018-10-01 05:19:57 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:19:57 --> Model "User_model" initialized
INFO - 2018-10-01 05:19:57 --> Model "Project_model" initialized
INFO - 2018-10-01 05:19:57 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:19:57 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:19:57 --> Controller Class Initialized
INFO - 2018-10-01 05:19:57 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:19:57 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-01 05:19:57 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:19:57 --> Final output sent to browser
DEBUG - 2018-10-01 05:19:57 --> Total execution time: 0.0390
INFO - 2018-10-01 05:20:03 --> Config Class Initialized
INFO - 2018-10-01 05:20:03 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:20:03 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:20:03 --> Utf8 Class Initialized
INFO - 2018-10-01 05:20:03 --> URI Class Initialized
INFO - 2018-10-01 05:20:03 --> Router Class Initialized
INFO - 2018-10-01 05:20:03 --> Output Class Initialized
INFO - 2018-10-01 05:20:03 --> Security Class Initialized
DEBUG - 2018-10-01 05:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:20:03 --> Input Class Initialized
INFO - 2018-10-01 05:20:03 --> Language Class Initialized
INFO - 2018-10-01 05:20:03 --> Loader Class Initialized
INFO - 2018-10-01 05:20:03 --> Helper loaded: url_helper
INFO - 2018-10-01 05:20:03 --> Helper loaded: form_helper
INFO - 2018-10-01 05:20:03 --> Helper loaded: html_helper
INFO - 2018-10-01 05:20:03 --> Database Driver Class Initialized
INFO - 2018-10-01 05:20:03 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:20:03 --> Model "User_model" initialized
INFO - 2018-10-01 05:20:03 --> Model "Project_model" initialized
INFO - 2018-10-01 05:20:03 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:20:03 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:20:03 --> Controller Class Initialized
ERROR - 2018-10-01 05:20:03 --> Severity: Compile Error --> Can't use method return value in write context D:\xampp\htdocs\code_igniter\application\views\project_views\layouts\main.php 8
INFO - 2018-10-01 05:20:14 --> Config Class Initialized
INFO - 2018-10-01 05:20:14 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:20:14 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:20:14 --> Utf8 Class Initialized
INFO - 2018-10-01 05:20:14 --> URI Class Initialized
INFO - 2018-10-01 05:20:14 --> Router Class Initialized
INFO - 2018-10-01 05:20:14 --> Output Class Initialized
INFO - 2018-10-01 05:20:14 --> Security Class Initialized
DEBUG - 2018-10-01 05:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:20:14 --> Input Class Initialized
INFO - 2018-10-01 05:20:14 --> Language Class Initialized
INFO - 2018-10-01 05:20:14 --> Loader Class Initialized
INFO - 2018-10-01 05:20:14 --> Helper loaded: url_helper
INFO - 2018-10-01 05:20:14 --> Helper loaded: form_helper
INFO - 2018-10-01 05:20:14 --> Helper loaded: html_helper
INFO - 2018-10-01 05:20:14 --> Database Driver Class Initialized
INFO - 2018-10-01 05:20:14 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:20:14 --> Model "User_model" initialized
INFO - 2018-10-01 05:20:14 --> Model "Project_model" initialized
INFO - 2018-10-01 05:20:14 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:20:14 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:20:14 --> Controller Class Initialized
INFO - 2018-10-01 05:20:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:20:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-01 05:20:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:20:14 --> Final output sent to browser
DEBUG - 2018-10-01 05:20:14 --> Total execution time: 0.0580
INFO - 2018-10-01 05:20:15 --> Config Class Initialized
INFO - 2018-10-01 05:20:15 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:20:15 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:20:15 --> Utf8 Class Initialized
INFO - 2018-10-01 05:20:15 --> URI Class Initialized
INFO - 2018-10-01 05:20:15 --> Router Class Initialized
INFO - 2018-10-01 05:20:15 --> Output Class Initialized
INFO - 2018-10-01 05:20:15 --> Security Class Initialized
DEBUG - 2018-10-01 05:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:20:15 --> Input Class Initialized
INFO - 2018-10-01 05:20:15 --> Language Class Initialized
INFO - 2018-10-01 05:20:15 --> Loader Class Initialized
INFO - 2018-10-01 05:20:15 --> Helper loaded: url_helper
INFO - 2018-10-01 05:20:15 --> Helper loaded: form_helper
INFO - 2018-10-01 05:20:15 --> Helper loaded: html_helper
INFO - 2018-10-01 05:20:15 --> Database Driver Class Initialized
INFO - 2018-10-01 05:20:15 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:20:15 --> Model "User_model" initialized
INFO - 2018-10-01 05:20:15 --> Model "Project_model" initialized
INFO - 2018-10-01 05:20:15 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:20:15 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:20:15 --> Controller Class Initialized
INFO - 2018-10-01 05:20:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:20:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-10-01 05:20:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:20:15 --> Final output sent to browser
DEBUG - 2018-10-01 05:20:15 --> Total execution time: 0.0570
INFO - 2018-10-01 05:20:16 --> Config Class Initialized
INFO - 2018-10-01 05:20:16 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:20:16 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:20:16 --> Utf8 Class Initialized
INFO - 2018-10-01 05:20:16 --> URI Class Initialized
INFO - 2018-10-01 05:20:16 --> Router Class Initialized
INFO - 2018-10-01 05:20:16 --> Output Class Initialized
INFO - 2018-10-01 05:20:16 --> Security Class Initialized
DEBUG - 2018-10-01 05:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:20:16 --> Input Class Initialized
INFO - 2018-10-01 05:20:16 --> Language Class Initialized
INFO - 2018-10-01 05:20:16 --> Loader Class Initialized
INFO - 2018-10-01 05:20:16 --> Helper loaded: url_helper
INFO - 2018-10-01 05:20:16 --> Helper loaded: form_helper
INFO - 2018-10-01 05:20:16 --> Helper loaded: html_helper
INFO - 2018-10-01 05:20:16 --> Database Driver Class Initialized
INFO - 2018-10-01 05:20:16 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:20:16 --> Model "User_model" initialized
INFO - 2018-10-01 05:20:16 --> Model "Project_model" initialized
INFO - 2018-10-01 05:20:16 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:20:16 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:20:16 --> Controller Class Initialized
INFO - 2018-10-01 05:20:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:20:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-01 05:20:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:20:16 --> Final output sent to browser
DEBUG - 2018-10-01 05:20:16 --> Total execution time: 0.0670
INFO - 2018-10-01 05:20:22 --> Config Class Initialized
INFO - 2018-10-01 05:20:22 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:20:22 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:20:22 --> Utf8 Class Initialized
INFO - 2018-10-01 05:20:22 --> URI Class Initialized
INFO - 2018-10-01 05:20:22 --> Router Class Initialized
INFO - 2018-10-01 05:20:22 --> Output Class Initialized
INFO - 2018-10-01 05:20:22 --> Security Class Initialized
DEBUG - 2018-10-01 05:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:20:22 --> Input Class Initialized
INFO - 2018-10-01 05:20:22 --> Language Class Initialized
INFO - 2018-10-01 05:20:22 --> Loader Class Initialized
INFO - 2018-10-01 05:20:22 --> Helper loaded: url_helper
INFO - 2018-10-01 05:20:22 --> Helper loaded: form_helper
INFO - 2018-10-01 05:20:22 --> Helper loaded: html_helper
INFO - 2018-10-01 05:20:22 --> Database Driver Class Initialized
INFO - 2018-10-01 05:20:22 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:20:22 --> Model "User_model" initialized
INFO - 2018-10-01 05:20:22 --> Model "Project_model" initialized
INFO - 2018-10-01 05:20:22 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:20:22 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:20:22 --> Controller Class Initialized
INFO - 2018-10-01 05:20:22 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:20:22 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-01 05:20:22 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:20:22 --> Final output sent to browser
DEBUG - 2018-10-01 05:20:22 --> Total execution time: 0.0560
INFO - 2018-10-01 05:20:23 --> Config Class Initialized
INFO - 2018-10-01 05:20:23 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:20:23 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:20:23 --> Utf8 Class Initialized
INFO - 2018-10-01 05:20:23 --> URI Class Initialized
INFO - 2018-10-01 05:20:23 --> Router Class Initialized
INFO - 2018-10-01 05:20:23 --> Output Class Initialized
INFO - 2018-10-01 05:20:23 --> Security Class Initialized
DEBUG - 2018-10-01 05:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:20:23 --> Input Class Initialized
INFO - 2018-10-01 05:20:23 --> Language Class Initialized
INFO - 2018-10-01 05:20:23 --> Loader Class Initialized
INFO - 2018-10-01 05:20:23 --> Helper loaded: url_helper
INFO - 2018-10-01 05:20:23 --> Helper loaded: form_helper
INFO - 2018-10-01 05:20:23 --> Helper loaded: html_helper
INFO - 2018-10-01 05:20:23 --> Database Driver Class Initialized
INFO - 2018-10-01 05:20:23 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:20:23 --> Model "User_model" initialized
INFO - 2018-10-01 05:20:23 --> Model "Project_model" initialized
INFO - 2018-10-01 05:20:23 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:20:23 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:20:23 --> Controller Class Initialized
INFO - 2018-10-01 05:20:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:20:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/projects/index.php
INFO - 2018-10-01 05:20:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:20:23 --> Final output sent to browser
DEBUG - 2018-10-01 05:20:23 --> Total execution time: 0.0800
INFO - 2018-10-01 05:20:23 --> Config Class Initialized
INFO - 2018-10-01 05:20:23 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:20:23 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:20:23 --> Utf8 Class Initialized
INFO - 2018-10-01 05:20:23 --> URI Class Initialized
INFO - 2018-10-01 05:20:23 --> Router Class Initialized
INFO - 2018-10-01 05:20:23 --> Output Class Initialized
INFO - 2018-10-01 05:20:23 --> Security Class Initialized
DEBUG - 2018-10-01 05:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:20:23 --> Input Class Initialized
INFO - 2018-10-01 05:20:23 --> Language Class Initialized
INFO - 2018-10-01 05:20:23 --> Loader Class Initialized
INFO - 2018-10-01 05:20:23 --> Helper loaded: url_helper
INFO - 2018-10-01 05:20:23 --> Helper loaded: form_helper
INFO - 2018-10-01 05:20:23 --> Helper loaded: html_helper
INFO - 2018-10-01 05:20:23 --> Database Driver Class Initialized
INFO - 2018-10-01 05:20:23 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:20:23 --> Model "User_model" initialized
INFO - 2018-10-01 05:20:23 --> Model "Project_model" initialized
INFO - 2018-10-01 05:20:23 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:20:23 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:20:23 --> Controller Class Initialized
INFO - 2018-10-01 05:20:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:20:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/tasks/index.php
INFO - 2018-10-01 05:20:23 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:20:23 --> Final output sent to browser
DEBUG - 2018-10-01 05:20:23 --> Total execution time: 0.0560
INFO - 2018-10-01 05:20:24 --> Config Class Initialized
INFO - 2018-10-01 05:20:24 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:20:24 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:20:24 --> Utf8 Class Initialized
INFO - 2018-10-01 05:20:24 --> URI Class Initialized
INFO - 2018-10-01 05:20:24 --> Router Class Initialized
INFO - 2018-10-01 05:20:24 --> Output Class Initialized
INFO - 2018-10-01 05:20:24 --> Security Class Initialized
DEBUG - 2018-10-01 05:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:20:24 --> Input Class Initialized
INFO - 2018-10-01 05:20:24 --> Language Class Initialized
INFO - 2018-10-01 05:20:24 --> Loader Class Initialized
INFO - 2018-10-01 05:20:24 --> Helper loaded: url_helper
INFO - 2018-10-01 05:20:24 --> Helper loaded: form_helper
INFO - 2018-10-01 05:20:24 --> Helper loaded: html_helper
INFO - 2018-10-01 05:20:24 --> Database Driver Class Initialized
INFO - 2018-10-01 05:20:24 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:20:24 --> Model "User_model" initialized
INFO - 2018-10-01 05:20:24 --> Model "Project_model" initialized
INFO - 2018-10-01 05:20:24 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:20:24 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:20:24 --> Controller Class Initialized
INFO - 2018-10-01 05:20:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:20:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-01 05:20:24 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:20:24 --> Final output sent to browser
DEBUG - 2018-10-01 05:20:24 --> Total execution time: 0.0590
INFO - 2018-10-01 05:20:25 --> Config Class Initialized
INFO - 2018-10-01 05:20:25 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:20:25 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:20:25 --> Utf8 Class Initialized
INFO - 2018-10-01 05:20:25 --> URI Class Initialized
INFO - 2018-10-01 05:20:25 --> Router Class Initialized
INFO - 2018-10-01 05:20:25 --> Output Class Initialized
INFO - 2018-10-01 05:20:25 --> Security Class Initialized
DEBUG - 2018-10-01 05:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:20:25 --> Input Class Initialized
INFO - 2018-10-01 05:20:25 --> Language Class Initialized
INFO - 2018-10-01 05:20:25 --> Loader Class Initialized
INFO - 2018-10-01 05:20:25 --> Helper loaded: url_helper
INFO - 2018-10-01 05:20:25 --> Helper loaded: form_helper
INFO - 2018-10-01 05:20:25 --> Helper loaded: html_helper
INFO - 2018-10-01 05:20:25 --> Database Driver Class Initialized
INFO - 2018-10-01 05:20:25 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:20:25 --> Model "User_model" initialized
INFO - 2018-10-01 05:20:25 --> Model "Project_model" initialized
INFO - 2018-10-01 05:20:25 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:20:25 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:20:25 --> Controller Class Initialized
INFO - 2018-10-01 05:20:25 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:20:25 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/lists/index.php
INFO - 2018-10-01 05:20:25 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:20:25 --> Final output sent to browser
DEBUG - 2018-10-01 05:20:25 --> Total execution time: 0.0620
INFO - 2018-10-01 05:20:26 --> Config Class Initialized
INFO - 2018-10-01 05:20:26 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:20:26 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:20:26 --> Utf8 Class Initialized
INFO - 2018-10-01 05:20:26 --> URI Class Initialized
INFO - 2018-10-01 05:20:26 --> Router Class Initialized
INFO - 2018-10-01 05:20:26 --> Output Class Initialized
INFO - 2018-10-01 05:20:26 --> Security Class Initialized
DEBUG - 2018-10-01 05:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:20:26 --> Input Class Initialized
INFO - 2018-10-01 05:20:26 --> Language Class Initialized
INFO - 2018-10-01 05:20:26 --> Loader Class Initialized
INFO - 2018-10-01 05:20:26 --> Helper loaded: url_helper
INFO - 2018-10-01 05:20:26 --> Helper loaded: form_helper
INFO - 2018-10-01 05:20:26 --> Helper loaded: html_helper
INFO - 2018-10-01 05:20:26 --> Database Driver Class Initialized
INFO - 2018-10-01 05:20:26 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:20:26 --> Model "User_model" initialized
INFO - 2018-10-01 05:20:26 --> Model "Project_model" initialized
INFO - 2018-10-01 05:20:26 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:20:26 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:20:26 --> Controller Class Initialized
INFO - 2018-10-01 05:20:26 --> Config Class Initialized
INFO - 2018-10-01 05:20:26 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:20:26 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:20:26 --> Utf8 Class Initialized
INFO - 2018-10-01 05:20:26 --> URI Class Initialized
INFO - 2018-10-01 05:20:26 --> Router Class Initialized
INFO - 2018-10-01 05:20:26 --> Output Class Initialized
INFO - 2018-10-01 05:20:26 --> Security Class Initialized
DEBUG - 2018-10-01 05:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:20:26 --> Input Class Initialized
INFO - 2018-10-01 05:20:26 --> Language Class Initialized
INFO - 2018-10-01 05:20:26 --> Loader Class Initialized
INFO - 2018-10-01 05:20:26 --> Helper loaded: url_helper
INFO - 2018-10-01 05:20:26 --> Helper loaded: form_helper
INFO - 2018-10-01 05:20:26 --> Helper loaded: html_helper
INFO - 2018-10-01 05:20:26 --> Database Driver Class Initialized
INFO - 2018-10-01 05:20:26 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:20:26 --> Model "User_model" initialized
INFO - 2018-10-01 05:20:26 --> Model "Project_model" initialized
INFO - 2018-10-01 05:20:26 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:20:26 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:20:26 --> Controller Class Initialized
INFO - 2018-10-01 05:20:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:20:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-01 05:20:26 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:20:26 --> Final output sent to browser
DEBUG - 2018-10-01 05:20:26 --> Total execution time: 0.0360
INFO - 2018-10-01 05:20:40 --> Config Class Initialized
INFO - 2018-10-01 05:20:40 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:20:40 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:20:40 --> Utf8 Class Initialized
INFO - 2018-10-01 05:20:40 --> URI Class Initialized
INFO - 2018-10-01 05:20:40 --> Router Class Initialized
INFO - 2018-10-01 05:20:40 --> Output Class Initialized
INFO - 2018-10-01 05:20:40 --> Security Class Initialized
DEBUG - 2018-10-01 05:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:20:40 --> Input Class Initialized
INFO - 2018-10-01 05:20:40 --> Language Class Initialized
INFO - 2018-10-01 05:20:40 --> Loader Class Initialized
INFO - 2018-10-01 05:20:40 --> Helper loaded: url_helper
INFO - 2018-10-01 05:20:40 --> Helper loaded: form_helper
INFO - 2018-10-01 05:20:40 --> Helper loaded: html_helper
INFO - 2018-10-01 05:20:40 --> Database Driver Class Initialized
INFO - 2018-10-01 05:20:40 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:20:40 --> Model "User_model" initialized
INFO - 2018-10-01 05:20:40 --> Model "Project_model" initialized
INFO - 2018-10-01 05:20:40 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:20:40 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:20:40 --> Controller Class Initialized
ERROR - 2018-10-01 05:20:40 --> Severity: Notice --> Undefined variable: list_library D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 69
INFO - 2018-10-01 05:20:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:20:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-01 05:20:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:20:40 --> Final output sent to browser
DEBUG - 2018-10-01 05:20:40 --> Total execution time: 0.0570
INFO - 2018-10-01 05:21:16 --> Config Class Initialized
INFO - 2018-10-01 05:21:16 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:21:16 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:21:16 --> Utf8 Class Initialized
INFO - 2018-10-01 05:21:16 --> URI Class Initialized
INFO - 2018-10-01 05:21:16 --> Router Class Initialized
INFO - 2018-10-01 05:21:16 --> Output Class Initialized
INFO - 2018-10-01 05:21:16 --> Security Class Initialized
DEBUG - 2018-10-01 05:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:21:16 --> Input Class Initialized
INFO - 2018-10-01 05:21:16 --> Language Class Initialized
INFO - 2018-10-01 05:21:16 --> Loader Class Initialized
INFO - 2018-10-01 05:21:16 --> Helper loaded: url_helper
INFO - 2018-10-01 05:21:16 --> Helper loaded: form_helper
INFO - 2018-10-01 05:21:16 --> Helper loaded: html_helper
INFO - 2018-10-01 05:21:16 --> Database Driver Class Initialized
INFO - 2018-10-01 05:21:16 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:21:16 --> Model "User_model" initialized
INFO - 2018-10-01 05:21:16 --> Model "Project_model" initialized
INFO - 2018-10-01 05:21:16 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:21:16 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:21:16 --> Controller Class Initialized
ERROR - 2018-10-01 05:21:16 --> Severity: Notice --> Undefined variable: list_library D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 72
INFO - 2018-10-01 05:21:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:21:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-01 05:21:16 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:21:16 --> Final output sent to browser
DEBUG - 2018-10-01 05:21:16 --> Total execution time: 0.0520
INFO - 2018-10-01 05:21:59 --> Config Class Initialized
INFO - 2018-10-01 05:21:59 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:21:59 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:21:59 --> Utf8 Class Initialized
INFO - 2018-10-01 05:21:59 --> URI Class Initialized
INFO - 2018-10-01 05:21:59 --> Router Class Initialized
INFO - 2018-10-01 05:21:59 --> Output Class Initialized
INFO - 2018-10-01 05:21:59 --> Security Class Initialized
DEBUG - 2018-10-01 05:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:21:59 --> Input Class Initialized
INFO - 2018-10-01 05:21:59 --> Language Class Initialized
INFO - 2018-10-01 05:21:59 --> Loader Class Initialized
INFO - 2018-10-01 05:21:59 --> Helper loaded: url_helper
INFO - 2018-10-01 05:21:59 --> Helper loaded: form_helper
INFO - 2018-10-01 05:21:59 --> Helper loaded: html_helper
INFO - 2018-10-01 05:21:59 --> Database Driver Class Initialized
INFO - 2018-10-01 05:21:59 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:21:59 --> Model "User_model" initialized
INFO - 2018-10-01 05:21:59 --> Model "Project_model" initialized
INFO - 2018-10-01 05:21:59 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:21:59 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:21:59 --> Controller Class Initialized
ERROR - 2018-10-01 05:21:59 --> Severity: Notice --> Undefined variable: list_library D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 69
INFO - 2018-10-01 05:21:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
ERROR - 2018-10-01 05:21:59 --> Severity: Notice --> Undefined variable: list_library D:\xampp\htdocs\code_igniter\application\views\project_views\users\register_view.php 60
INFO - 2018-10-01 05:21:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-01 05:21:59 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:21:59 --> Final output sent to browser
DEBUG - 2018-10-01 05:21:59 --> Total execution time: 0.0620
INFO - 2018-10-01 05:22:10 --> Config Class Initialized
INFO - 2018-10-01 05:22:10 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:22:10 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:22:10 --> Utf8 Class Initialized
INFO - 2018-10-01 05:22:10 --> URI Class Initialized
INFO - 2018-10-01 05:22:10 --> Router Class Initialized
INFO - 2018-10-01 05:22:10 --> Output Class Initialized
INFO - 2018-10-01 05:22:10 --> Security Class Initialized
DEBUG - 2018-10-01 05:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:22:10 --> Input Class Initialized
INFO - 2018-10-01 05:22:10 --> Language Class Initialized
INFO - 2018-10-01 05:22:10 --> Loader Class Initialized
INFO - 2018-10-01 05:22:10 --> Helper loaded: url_helper
INFO - 2018-10-01 05:22:10 --> Helper loaded: form_helper
INFO - 2018-10-01 05:22:10 --> Helper loaded: html_helper
INFO - 2018-10-01 05:22:10 --> Database Driver Class Initialized
INFO - 2018-10-01 05:22:10 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:22:10 --> Model "User_model" initialized
INFO - 2018-10-01 05:22:10 --> Model "Project_model" initialized
INFO - 2018-10-01 05:22:10 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:22:10 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:22:10 --> Controller Class Initialized
ERROR - 2018-10-01 05:22:10 --> Severity: Notice --> Undefined variable: list_library D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 69
INFO - 2018-10-01 05:22:10 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:22:10 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-01 05:22:10 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:22:10 --> Final output sent to browser
DEBUG - 2018-10-01 05:22:10 --> Total execution time: 0.0420
INFO - 2018-10-01 05:22:44 --> Config Class Initialized
INFO - 2018-10-01 05:22:44 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:22:44 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:22:44 --> Utf8 Class Initialized
INFO - 2018-10-01 05:22:44 --> URI Class Initialized
INFO - 2018-10-01 05:22:44 --> Router Class Initialized
INFO - 2018-10-01 05:22:44 --> Output Class Initialized
INFO - 2018-10-01 05:22:44 --> Security Class Initialized
DEBUG - 2018-10-01 05:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:22:44 --> Input Class Initialized
INFO - 2018-10-01 05:22:44 --> Language Class Initialized
INFO - 2018-10-01 05:22:44 --> Loader Class Initialized
INFO - 2018-10-01 05:22:44 --> Helper loaded: url_helper
INFO - 2018-10-01 05:22:44 --> Helper loaded: form_helper
INFO - 2018-10-01 05:22:44 --> Helper loaded: html_helper
INFO - 2018-10-01 05:22:44 --> Database Driver Class Initialized
INFO - 2018-10-01 05:22:44 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:22:44 --> Model "User_model" initialized
INFO - 2018-10-01 05:22:44 --> Model "Project_model" initialized
INFO - 2018-10-01 05:22:44 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:22:44 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:22:44 --> Controller Class Initialized
ERROR - 2018-10-01 05:22:44 --> Severity: Notice --> Undefined variable: list_library D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 72
INFO - 2018-10-01 05:22:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:22:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-01 05:22:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:22:44 --> Final output sent to browser
DEBUG - 2018-10-01 05:22:44 --> Total execution time: 0.0400
INFO - 2018-10-01 05:22:53 --> Config Class Initialized
INFO - 2018-10-01 05:22:53 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:22:53 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:22:53 --> Utf8 Class Initialized
INFO - 2018-10-01 05:22:53 --> URI Class Initialized
INFO - 2018-10-01 05:22:53 --> Router Class Initialized
INFO - 2018-10-01 05:22:53 --> Output Class Initialized
INFO - 2018-10-01 05:22:53 --> Security Class Initialized
DEBUG - 2018-10-01 05:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:22:53 --> Input Class Initialized
INFO - 2018-10-01 05:22:53 --> Language Class Initialized
INFO - 2018-10-01 05:22:53 --> Loader Class Initialized
INFO - 2018-10-01 05:22:53 --> Helper loaded: url_helper
INFO - 2018-10-01 05:22:53 --> Helper loaded: form_helper
INFO - 2018-10-01 05:22:53 --> Helper loaded: html_helper
INFO - 2018-10-01 05:22:53 --> Database Driver Class Initialized
INFO - 2018-10-01 05:22:53 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:22:53 --> Model "User_model" initialized
INFO - 2018-10-01 05:22:53 --> Model "Project_model" initialized
INFO - 2018-10-01 05:22:53 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:22:53 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:22:53 --> Controller Class Initialized
INFO - 2018-10-01 05:22:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:22:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-01 05:22:53 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:22:53 --> Final output sent to browser
DEBUG - 2018-10-01 05:22:53 --> Total execution time: 0.0680
INFO - 2018-10-01 05:23:15 --> Config Class Initialized
INFO - 2018-10-01 05:23:15 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:23:15 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:23:15 --> Utf8 Class Initialized
INFO - 2018-10-01 05:23:15 --> URI Class Initialized
INFO - 2018-10-01 05:23:15 --> Router Class Initialized
INFO - 2018-10-01 05:23:15 --> Output Class Initialized
INFO - 2018-10-01 05:23:15 --> Security Class Initialized
DEBUG - 2018-10-01 05:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:23:15 --> Input Class Initialized
INFO - 2018-10-01 05:23:15 --> Language Class Initialized
INFO - 2018-10-01 05:23:15 --> Loader Class Initialized
INFO - 2018-10-01 05:23:15 --> Helper loaded: url_helper
INFO - 2018-10-01 05:23:15 --> Helper loaded: form_helper
INFO - 2018-10-01 05:23:15 --> Helper loaded: html_helper
INFO - 2018-10-01 05:23:15 --> Database Driver Class Initialized
INFO - 2018-10-01 05:23:15 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:23:15 --> Model "User_model" initialized
INFO - 2018-10-01 05:23:15 --> Model "Project_model" initialized
INFO - 2018-10-01 05:23:15 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:23:15 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:23:15 --> Controller Class Initialized
ERROR - 2018-10-01 05:23:15 --> Severity: Notice --> Undefined variable: list_library D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 72
INFO - 2018-10-01 05:23:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:23:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-01 05:23:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:23:15 --> Final output sent to browser
DEBUG - 2018-10-01 05:23:15 --> Total execution time: 0.0510
INFO - 2018-10-01 05:24:27 --> Config Class Initialized
INFO - 2018-10-01 05:24:27 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:24:27 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:24:27 --> Utf8 Class Initialized
INFO - 2018-10-01 05:24:27 --> URI Class Initialized
INFO - 2018-10-01 05:24:27 --> Router Class Initialized
INFO - 2018-10-01 05:24:27 --> Output Class Initialized
INFO - 2018-10-01 05:24:27 --> Security Class Initialized
DEBUG - 2018-10-01 05:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:24:27 --> Input Class Initialized
INFO - 2018-10-01 05:24:27 --> Language Class Initialized
INFO - 2018-10-01 05:24:27 --> Loader Class Initialized
INFO - 2018-10-01 05:24:27 --> Helper loaded: url_helper
INFO - 2018-10-01 05:24:27 --> Helper loaded: form_helper
INFO - 2018-10-01 05:24:27 --> Helper loaded: html_helper
INFO - 2018-10-01 05:24:27 --> Database Driver Class Initialized
INFO - 2018-10-01 05:24:27 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:24:27 --> Model "User_model" initialized
INFO - 2018-10-01 05:24:27 --> Model "Project_model" initialized
INFO - 2018-10-01 05:24:27 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:24:27 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:24:27 --> Controller Class Initialized
INFO - 2018-10-01 05:24:27 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:24:27 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-01 05:24:27 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:24:27 --> Final output sent to browser
DEBUG - 2018-10-01 05:24:27 --> Total execution time: 0.0440
INFO - 2018-10-01 05:24:29 --> Config Class Initialized
INFO - 2018-10-01 05:24:29 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:24:29 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:24:29 --> Utf8 Class Initialized
INFO - 2018-10-01 05:24:29 --> URI Class Initialized
INFO - 2018-10-01 05:24:29 --> Router Class Initialized
INFO - 2018-10-01 05:24:29 --> Output Class Initialized
INFO - 2018-10-01 05:24:29 --> Security Class Initialized
DEBUG - 2018-10-01 05:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:24:29 --> Input Class Initialized
INFO - 2018-10-01 05:24:29 --> Language Class Initialized
INFO - 2018-10-01 05:24:29 --> Loader Class Initialized
INFO - 2018-10-01 05:24:29 --> Helper loaded: url_helper
INFO - 2018-10-01 05:24:29 --> Helper loaded: form_helper
INFO - 2018-10-01 05:24:29 --> Helper loaded: html_helper
INFO - 2018-10-01 05:24:29 --> Database Driver Class Initialized
INFO - 2018-10-01 05:24:29 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:24:29 --> Model "User_model" initialized
INFO - 2018-10-01 05:24:29 --> Model "Project_model" initialized
INFO - 2018-10-01 05:24:29 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:24:29 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:24:29 --> Controller Class Initialized
INFO - 2018-10-01 05:24:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:24:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-01 05:24:29 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:24:29 --> Final output sent to browser
DEBUG - 2018-10-01 05:24:29 --> Total execution time: 0.0630
INFO - 2018-10-01 05:24:31 --> Config Class Initialized
INFO - 2018-10-01 05:24:31 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:24:31 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:24:31 --> Utf8 Class Initialized
INFO - 2018-10-01 05:24:31 --> URI Class Initialized
INFO - 2018-10-01 05:24:31 --> Router Class Initialized
INFO - 2018-10-01 05:24:31 --> Output Class Initialized
INFO - 2018-10-01 05:24:31 --> Security Class Initialized
DEBUG - 2018-10-01 05:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:24:31 --> Input Class Initialized
INFO - 2018-10-01 05:24:31 --> Language Class Initialized
INFO - 2018-10-01 05:24:31 --> Loader Class Initialized
INFO - 2018-10-01 05:24:31 --> Helper loaded: url_helper
INFO - 2018-10-01 05:24:31 --> Helper loaded: form_helper
INFO - 2018-10-01 05:24:31 --> Helper loaded: html_helper
INFO - 2018-10-01 05:24:31 --> Database Driver Class Initialized
INFO - 2018-10-01 05:24:31 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:24:31 --> Model "User_model" initialized
INFO - 2018-10-01 05:24:31 --> Model "Project_model" initialized
INFO - 2018-10-01 05:24:31 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:24:31 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:24:31 --> Controller Class Initialized
INFO - 2018-10-01 05:24:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:24:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-01 05:24:31 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:24:31 --> Final output sent to browser
DEBUG - 2018-10-01 05:24:31 --> Total execution time: 0.0620
INFO - 2018-10-01 05:24:40 --> Config Class Initialized
INFO - 2018-10-01 05:24:40 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:24:40 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:24:40 --> Utf8 Class Initialized
INFO - 2018-10-01 05:24:40 --> URI Class Initialized
INFO - 2018-10-01 05:24:40 --> Router Class Initialized
INFO - 2018-10-01 05:24:40 --> Output Class Initialized
INFO - 2018-10-01 05:24:40 --> Security Class Initialized
DEBUG - 2018-10-01 05:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:24:40 --> Input Class Initialized
INFO - 2018-10-01 05:24:40 --> Language Class Initialized
INFO - 2018-10-01 05:24:40 --> Loader Class Initialized
INFO - 2018-10-01 05:24:40 --> Helper loaded: url_helper
INFO - 2018-10-01 05:24:40 --> Helper loaded: form_helper
INFO - 2018-10-01 05:24:40 --> Helper loaded: html_helper
INFO - 2018-10-01 05:24:40 --> Database Driver Class Initialized
INFO - 2018-10-01 05:24:40 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:24:40 --> Model "User_model" initialized
INFO - 2018-10-01 05:24:40 --> Model "Project_model" initialized
INFO - 2018-10-01 05:24:40 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:24:40 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:24:40 --> Controller Class Initialized
INFO - 2018-10-01 05:24:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:24:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-01 05:24:40 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:24:40 --> Final output sent to browser
DEBUG - 2018-10-01 05:24:40 --> Total execution time: 0.0580
INFO - 2018-10-01 05:24:41 --> Config Class Initialized
INFO - 2018-10-01 05:24:41 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:24:41 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:24:41 --> Utf8 Class Initialized
INFO - 2018-10-01 05:24:41 --> URI Class Initialized
INFO - 2018-10-01 05:24:41 --> Router Class Initialized
INFO - 2018-10-01 05:24:41 --> Output Class Initialized
INFO - 2018-10-01 05:24:41 --> Security Class Initialized
DEBUG - 2018-10-01 05:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:24:41 --> Input Class Initialized
INFO - 2018-10-01 05:24:41 --> Language Class Initialized
INFO - 2018-10-01 05:24:41 --> Loader Class Initialized
INFO - 2018-10-01 05:24:41 --> Helper loaded: url_helper
INFO - 2018-10-01 05:24:41 --> Helper loaded: form_helper
INFO - 2018-10-01 05:24:41 --> Helper loaded: html_helper
INFO - 2018-10-01 05:24:41 --> Database Driver Class Initialized
INFO - 2018-10-01 05:24:41 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:24:41 --> Model "User_model" initialized
INFO - 2018-10-01 05:24:41 --> Model "Project_model" initialized
INFO - 2018-10-01 05:24:41 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:24:41 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:24:41 --> Controller Class Initialized
INFO - 2018-10-01 05:24:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:24:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-01 05:24:41 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:24:41 --> Final output sent to browser
DEBUG - 2018-10-01 05:24:41 --> Total execution time: 0.0540
INFO - 2018-10-01 05:24:55 --> Config Class Initialized
INFO - 2018-10-01 05:24:55 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:24:55 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:24:55 --> Utf8 Class Initialized
INFO - 2018-10-01 05:24:55 --> URI Class Initialized
INFO - 2018-10-01 05:24:55 --> Router Class Initialized
INFO - 2018-10-01 05:24:55 --> Output Class Initialized
INFO - 2018-10-01 05:24:55 --> Security Class Initialized
DEBUG - 2018-10-01 05:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:24:55 --> Input Class Initialized
INFO - 2018-10-01 05:24:55 --> Language Class Initialized
INFO - 2018-10-01 05:24:55 --> Loader Class Initialized
INFO - 2018-10-01 05:24:55 --> Helper loaded: url_helper
INFO - 2018-10-01 05:24:55 --> Helper loaded: form_helper
INFO - 2018-10-01 05:24:55 --> Helper loaded: html_helper
INFO - 2018-10-01 05:24:55 --> Database Driver Class Initialized
INFO - 2018-10-01 05:24:55 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:24:55 --> Model "User_model" initialized
INFO - 2018-10-01 05:24:55 --> Model "Project_model" initialized
INFO - 2018-10-01 05:24:55 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:24:55 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:24:55 --> Controller Class Initialized
INFO - 2018-10-01 05:24:55 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:24:55 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-01 05:24:55 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:24:55 --> Final output sent to browser
DEBUG - 2018-10-01 05:24:55 --> Total execution time: 0.0520
INFO - 2018-10-01 05:24:58 --> Config Class Initialized
INFO - 2018-10-01 05:24:58 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:24:58 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:24:58 --> Utf8 Class Initialized
INFO - 2018-10-01 05:24:58 --> URI Class Initialized
INFO - 2018-10-01 05:24:58 --> Router Class Initialized
INFO - 2018-10-01 05:24:58 --> Output Class Initialized
INFO - 2018-10-01 05:24:58 --> Security Class Initialized
DEBUG - 2018-10-01 05:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:24:58 --> Input Class Initialized
INFO - 2018-10-01 05:24:58 --> Language Class Initialized
INFO - 2018-10-01 05:24:58 --> Loader Class Initialized
INFO - 2018-10-01 05:24:58 --> Helper loaded: url_helper
INFO - 2018-10-01 05:24:58 --> Helper loaded: form_helper
INFO - 2018-10-01 05:24:58 --> Helper loaded: html_helper
INFO - 2018-10-01 05:24:58 --> Database Driver Class Initialized
INFO - 2018-10-01 05:24:58 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:24:58 --> Model "User_model" initialized
INFO - 2018-10-01 05:24:58 --> Model "Project_model" initialized
INFO - 2018-10-01 05:24:58 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:24:58 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:24:58 --> Controller Class Initialized
INFO - 2018-10-01 05:24:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:24:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-01 05:24:58 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:24:58 --> Final output sent to browser
DEBUG - 2018-10-01 05:24:58 --> Total execution time: 0.0490
INFO - 2018-10-01 05:25:00 --> Config Class Initialized
INFO - 2018-10-01 05:25:00 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:25:00 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:25:00 --> Utf8 Class Initialized
INFO - 2018-10-01 05:25:00 --> URI Class Initialized
INFO - 2018-10-01 05:25:00 --> Router Class Initialized
INFO - 2018-10-01 05:25:00 --> Output Class Initialized
INFO - 2018-10-01 05:25:00 --> Security Class Initialized
DEBUG - 2018-10-01 05:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:25:00 --> Input Class Initialized
INFO - 2018-10-01 05:25:00 --> Language Class Initialized
INFO - 2018-10-01 05:25:00 --> Loader Class Initialized
INFO - 2018-10-01 05:25:00 --> Helper loaded: url_helper
INFO - 2018-10-01 05:25:00 --> Helper loaded: form_helper
INFO - 2018-10-01 05:25:00 --> Helper loaded: html_helper
INFO - 2018-10-01 05:25:00 --> Database Driver Class Initialized
INFO - 2018-10-01 05:25:00 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:25:00 --> Model "User_model" initialized
INFO - 2018-10-01 05:25:00 --> Model "Project_model" initialized
INFO - 2018-10-01 05:25:00 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:25:00 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:25:00 --> Controller Class Initialized
INFO - 2018-10-01 05:25:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:25:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-01 05:25:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:25:00 --> Final output sent to browser
DEBUG - 2018-10-01 05:25:00 --> Total execution time: 0.0610
INFO - 2018-10-01 05:25:00 --> Config Class Initialized
INFO - 2018-10-01 05:25:00 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:25:00 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:25:00 --> Utf8 Class Initialized
INFO - 2018-10-01 05:25:00 --> URI Class Initialized
INFO - 2018-10-01 05:25:00 --> Router Class Initialized
INFO - 2018-10-01 05:25:00 --> Output Class Initialized
INFO - 2018-10-01 05:25:00 --> Security Class Initialized
DEBUG - 2018-10-01 05:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:25:00 --> Input Class Initialized
INFO - 2018-10-01 05:25:00 --> Language Class Initialized
INFO - 2018-10-01 05:25:00 --> Loader Class Initialized
INFO - 2018-10-01 05:25:00 --> Helper loaded: url_helper
INFO - 2018-10-01 05:25:00 --> Helper loaded: form_helper
INFO - 2018-10-01 05:25:00 --> Helper loaded: html_helper
INFO - 2018-10-01 05:25:00 --> Database Driver Class Initialized
INFO - 2018-10-01 05:25:00 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:25:00 --> Model "User_model" initialized
INFO - 2018-10-01 05:25:00 --> Model "Project_model" initialized
INFO - 2018-10-01 05:25:00 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:25:00 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:25:00 --> Controller Class Initialized
INFO - 2018-10-01 05:25:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:25:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-01 05:25:00 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:25:00 --> Final output sent to browser
DEBUG - 2018-10-01 05:25:00 --> Total execution time: 0.0610
INFO - 2018-10-01 05:25:06 --> Config Class Initialized
INFO - 2018-10-01 05:25:06 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:25:06 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:25:06 --> Utf8 Class Initialized
INFO - 2018-10-01 05:25:06 --> URI Class Initialized
INFO - 2018-10-01 05:25:06 --> Router Class Initialized
INFO - 2018-10-01 05:25:06 --> Output Class Initialized
INFO - 2018-10-01 05:25:06 --> Security Class Initialized
DEBUG - 2018-10-01 05:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:25:06 --> Input Class Initialized
INFO - 2018-10-01 05:25:06 --> Language Class Initialized
INFO - 2018-10-01 05:25:06 --> Loader Class Initialized
INFO - 2018-10-01 05:25:06 --> Helper loaded: url_helper
INFO - 2018-10-01 05:25:06 --> Helper loaded: form_helper
INFO - 2018-10-01 05:25:06 --> Helper loaded: html_helper
INFO - 2018-10-01 05:25:06 --> Database Driver Class Initialized
INFO - 2018-10-01 05:25:06 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:25:06 --> Model "User_model" initialized
INFO - 2018-10-01 05:25:06 --> Model "Project_model" initialized
INFO - 2018-10-01 05:25:06 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:25:06 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:25:06 --> Controller Class Initialized
INFO - 2018-10-01 05:25:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:25:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-01 05:25:06 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:25:06 --> Final output sent to browser
DEBUG - 2018-10-01 05:25:06 --> Total execution time: 0.0680
INFO - 2018-10-01 05:25:14 --> Config Class Initialized
INFO - 2018-10-01 05:25:14 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:25:14 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:25:14 --> Utf8 Class Initialized
INFO - 2018-10-01 05:25:14 --> URI Class Initialized
INFO - 2018-10-01 05:25:14 --> Router Class Initialized
INFO - 2018-10-01 05:25:14 --> Output Class Initialized
INFO - 2018-10-01 05:25:14 --> Security Class Initialized
DEBUG - 2018-10-01 05:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:25:14 --> Input Class Initialized
INFO - 2018-10-01 05:25:14 --> Language Class Initialized
INFO - 2018-10-01 05:25:14 --> Loader Class Initialized
INFO - 2018-10-01 05:25:14 --> Helper loaded: url_helper
INFO - 2018-10-01 05:25:14 --> Helper loaded: form_helper
INFO - 2018-10-01 05:25:14 --> Helper loaded: html_helper
INFO - 2018-10-01 05:25:14 --> Database Driver Class Initialized
INFO - 2018-10-01 05:25:14 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:25:14 --> Model "User_model" initialized
INFO - 2018-10-01 05:25:14 --> Model "Project_model" initialized
INFO - 2018-10-01 05:25:14 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:25:14 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:25:14 --> Controller Class Initialized
INFO - 2018-10-01 05:25:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:25:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-01 05:25:14 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:25:14 --> Final output sent to browser
DEBUG - 2018-10-01 05:25:14 --> Total execution time: 0.0560
INFO - 2018-10-01 05:25:15 --> Config Class Initialized
INFO - 2018-10-01 05:25:15 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:25:15 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:25:15 --> Utf8 Class Initialized
INFO - 2018-10-01 05:25:15 --> URI Class Initialized
INFO - 2018-10-01 05:25:15 --> Router Class Initialized
INFO - 2018-10-01 05:25:15 --> Output Class Initialized
INFO - 2018-10-01 05:25:15 --> Security Class Initialized
DEBUG - 2018-10-01 05:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:25:15 --> Input Class Initialized
INFO - 2018-10-01 05:25:15 --> Language Class Initialized
INFO - 2018-10-01 05:25:15 --> Loader Class Initialized
INFO - 2018-10-01 05:25:15 --> Helper loaded: url_helper
INFO - 2018-10-01 05:25:15 --> Helper loaded: form_helper
INFO - 2018-10-01 05:25:15 --> Helper loaded: html_helper
INFO - 2018-10-01 05:25:15 --> Database Driver Class Initialized
INFO - 2018-10-01 05:25:15 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:25:15 --> Model "User_model" initialized
INFO - 2018-10-01 05:25:15 --> Model "Project_model" initialized
INFO - 2018-10-01 05:25:15 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:25:15 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:25:15 --> Controller Class Initialized
INFO - 2018-10-01 05:25:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:25:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-01 05:25:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:25:15 --> Final output sent to browser
DEBUG - 2018-10-01 05:25:15 --> Total execution time: 0.0510
INFO - 2018-10-01 05:25:19 --> Config Class Initialized
INFO - 2018-10-01 05:25:19 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:25:19 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:25:19 --> Utf8 Class Initialized
INFO - 2018-10-01 05:25:19 --> URI Class Initialized
INFO - 2018-10-01 05:25:19 --> Router Class Initialized
INFO - 2018-10-01 05:25:19 --> Output Class Initialized
INFO - 2018-10-01 05:25:19 --> Security Class Initialized
DEBUG - 2018-10-01 05:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:25:19 --> Input Class Initialized
INFO - 2018-10-01 05:25:19 --> Language Class Initialized
INFO - 2018-10-01 05:25:19 --> Loader Class Initialized
INFO - 2018-10-01 05:25:19 --> Helper loaded: url_helper
INFO - 2018-10-01 05:25:19 --> Helper loaded: form_helper
INFO - 2018-10-01 05:25:19 --> Helper loaded: html_helper
INFO - 2018-10-01 05:25:19 --> Database Driver Class Initialized
INFO - 2018-10-01 05:25:19 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:25:19 --> Model "User_model" initialized
INFO - 2018-10-01 05:25:19 --> Model "Project_model" initialized
INFO - 2018-10-01 05:25:19 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:25:19 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:25:19 --> Controller Class Initialized
INFO - 2018-10-01 05:25:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:25:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-01 05:25:19 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:25:19 --> Final output sent to browser
DEBUG - 2018-10-01 05:25:19 --> Total execution time: 0.0560
INFO - 2018-10-01 05:25:44 --> Config Class Initialized
INFO - 2018-10-01 05:25:44 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:25:44 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:25:44 --> Utf8 Class Initialized
INFO - 2018-10-01 05:25:44 --> URI Class Initialized
INFO - 2018-10-01 05:25:44 --> Router Class Initialized
INFO - 2018-10-01 05:25:44 --> Output Class Initialized
INFO - 2018-10-01 05:25:44 --> Security Class Initialized
DEBUG - 2018-10-01 05:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:25:44 --> Input Class Initialized
INFO - 2018-10-01 05:25:44 --> Language Class Initialized
INFO - 2018-10-01 05:25:44 --> Loader Class Initialized
INFO - 2018-10-01 05:25:44 --> Helper loaded: url_helper
INFO - 2018-10-01 05:25:44 --> Helper loaded: form_helper
INFO - 2018-10-01 05:25:44 --> Helper loaded: html_helper
INFO - 2018-10-01 05:25:44 --> Database Driver Class Initialized
INFO - 2018-10-01 05:25:44 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:25:44 --> Model "User_model" initialized
INFO - 2018-10-01 05:25:44 --> Model "Project_model" initialized
INFO - 2018-10-01 05:25:44 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:25:44 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:25:44 --> Controller Class Initialized
INFO - 2018-10-01 05:25:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:25:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-01 05:25:44 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:25:44 --> Final output sent to browser
DEBUG - 2018-10-01 05:25:44 --> Total execution time: 0.0380
INFO - 2018-10-01 05:25:45 --> Config Class Initialized
INFO - 2018-10-01 05:25:45 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:25:45 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:25:45 --> Utf8 Class Initialized
INFO - 2018-10-01 05:25:45 --> URI Class Initialized
INFO - 2018-10-01 05:25:45 --> Router Class Initialized
INFO - 2018-10-01 05:25:45 --> Output Class Initialized
INFO - 2018-10-01 05:25:45 --> Security Class Initialized
DEBUG - 2018-10-01 05:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:25:45 --> Input Class Initialized
INFO - 2018-10-01 05:25:45 --> Language Class Initialized
INFO - 2018-10-01 05:25:45 --> Loader Class Initialized
INFO - 2018-10-01 05:25:45 --> Helper loaded: url_helper
INFO - 2018-10-01 05:25:45 --> Helper loaded: form_helper
INFO - 2018-10-01 05:25:45 --> Helper loaded: html_helper
INFO - 2018-10-01 05:25:45 --> Database Driver Class Initialized
INFO - 2018-10-01 05:25:45 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:25:45 --> Model "User_model" initialized
INFO - 2018-10-01 05:25:45 --> Model "Project_model" initialized
INFO - 2018-10-01 05:25:45 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:25:45 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:25:45 --> Controller Class Initialized
ERROR - 2018-10-01 05:25:45 --> Severity: Notice --> Undefined variable: list_library D:\xampp\htdocs\code_igniter\application\views\project_views\users\login_view.php 74
INFO - 2018-10-01 05:25:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:25:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-01 05:25:45 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:25:45 --> Final output sent to browser
DEBUG - 2018-10-01 05:25:45 --> Total execution time: 0.0580
INFO - 2018-10-01 05:33:12 --> Config Class Initialized
INFO - 2018-10-01 05:33:12 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:33:12 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:33:12 --> Utf8 Class Initialized
INFO - 2018-10-01 05:33:12 --> URI Class Initialized
INFO - 2018-10-01 05:33:12 --> Router Class Initialized
INFO - 2018-10-01 05:33:12 --> Output Class Initialized
INFO - 2018-10-01 05:33:12 --> Security Class Initialized
DEBUG - 2018-10-01 05:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:33:12 --> Input Class Initialized
INFO - 2018-10-01 05:33:12 --> Language Class Initialized
INFO - 2018-10-01 05:33:12 --> Loader Class Initialized
INFO - 2018-10-01 05:33:12 --> Helper loaded: url_helper
INFO - 2018-10-01 05:33:12 --> Helper loaded: form_helper
INFO - 2018-10-01 05:33:12 --> Helper loaded: html_helper
INFO - 2018-10-01 05:33:12 --> Database Driver Class Initialized
INFO - 2018-10-01 05:33:13 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:33:13 --> Model "User_model" initialized
INFO - 2018-10-01 05:33:13 --> Model "Project_model" initialized
INFO - 2018-10-01 05:33:13 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:33:13 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:33:13 --> Controller Class Initialized
INFO - 2018-10-01 05:33:13 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:33:13 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/register_view.php
INFO - 2018-10-01 05:33:13 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:33:13 --> Final output sent to browser
DEBUG - 2018-10-01 05:33:13 --> Total execution time: 0.7750
INFO - 2018-10-01 05:33:15 --> Config Class Initialized
INFO - 2018-10-01 05:33:15 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:33:15 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:33:15 --> Utf8 Class Initialized
INFO - 2018-10-01 05:33:15 --> URI Class Initialized
INFO - 2018-10-01 05:33:15 --> Router Class Initialized
INFO - 2018-10-01 05:33:15 --> Output Class Initialized
INFO - 2018-10-01 05:33:15 --> Security Class Initialized
DEBUG - 2018-10-01 05:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:33:15 --> Input Class Initialized
INFO - 2018-10-01 05:33:15 --> Language Class Initialized
INFO - 2018-10-01 05:33:15 --> Loader Class Initialized
INFO - 2018-10-01 05:33:15 --> Helper loaded: url_helper
INFO - 2018-10-01 05:33:15 --> Helper loaded: form_helper
INFO - 2018-10-01 05:33:15 --> Helper loaded: html_helper
INFO - 2018-10-01 05:33:15 --> Database Driver Class Initialized
INFO - 2018-10-01 05:33:15 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:33:15 --> Model "User_model" initialized
INFO - 2018-10-01 05:33:15 --> Model "Project_model" initialized
INFO - 2018-10-01 05:33:15 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:33:15 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:33:15 --> Controller Class Initialized
INFO - 2018-10-01 05:33:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:33:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-01 05:33:15 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:33:15 --> Final output sent to browser
DEBUG - 2018-10-01 05:33:15 --> Total execution time: 0.0820
INFO - 2018-10-01 05:33:22 --> Config Class Initialized
INFO - 2018-10-01 05:33:22 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:33:22 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:33:22 --> Utf8 Class Initialized
INFO - 2018-10-01 05:33:22 --> URI Class Initialized
INFO - 2018-10-01 05:33:22 --> Router Class Initialized
INFO - 2018-10-01 05:33:22 --> Output Class Initialized
INFO - 2018-10-01 05:33:22 --> Security Class Initialized
DEBUG - 2018-10-01 05:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:33:22 --> Input Class Initialized
INFO - 2018-10-01 05:33:22 --> Language Class Initialized
INFO - 2018-10-01 05:33:22 --> Loader Class Initialized
INFO - 2018-10-01 05:33:22 --> Helper loaded: url_helper
INFO - 2018-10-01 05:33:22 --> Helper loaded: form_helper
INFO - 2018-10-01 05:33:22 --> Helper loaded: html_helper
INFO - 2018-10-01 05:33:22 --> Database Driver Class Initialized
INFO - 2018-10-01 05:33:22 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:33:22 --> Model "User_model" initialized
INFO - 2018-10-01 05:33:22 --> Model "Project_model" initialized
INFO - 2018-10-01 05:33:22 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:33:22 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:33:22 --> Controller Class Initialized
INFO - 2018-10-01 05:33:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-10-01 05:33:22 --> Config Class Initialized
INFO - 2018-10-01 05:33:22 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:33:22 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:33:22 --> Utf8 Class Initialized
INFO - 2018-10-01 05:33:22 --> URI Class Initialized
INFO - 2018-10-01 05:33:22 --> Router Class Initialized
INFO - 2018-10-01 05:33:22 --> Output Class Initialized
INFO - 2018-10-01 05:33:22 --> Security Class Initialized
DEBUG - 2018-10-01 05:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:33:22 --> Input Class Initialized
INFO - 2018-10-01 05:33:22 --> Language Class Initialized
INFO - 2018-10-01 05:33:22 --> Loader Class Initialized
INFO - 2018-10-01 05:33:22 --> Helper loaded: url_helper
INFO - 2018-10-01 05:33:22 --> Helper loaded: form_helper
INFO - 2018-10-01 05:33:22 --> Helper loaded: html_helper
INFO - 2018-10-01 05:33:22 --> Database Driver Class Initialized
INFO - 2018-10-01 05:33:22 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:33:22 --> Model "User_model" initialized
INFO - 2018-10-01 05:33:22 --> Model "Project_model" initialized
INFO - 2018-10-01 05:33:22 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:33:22 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:33:22 --> Controller Class Initialized
INFO - 2018-10-01 05:33:22 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:33:22 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-01 05:33:22 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:33:22 --> Final output sent to browser
DEBUG - 2018-10-01 05:33:22 --> Total execution time: 0.0430
INFO - 2018-10-01 05:33:25 --> Config Class Initialized
INFO - 2018-10-01 05:33:25 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:33:25 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:33:25 --> Utf8 Class Initialized
INFO - 2018-10-01 05:33:25 --> URI Class Initialized
INFO - 2018-10-01 05:33:25 --> Router Class Initialized
INFO - 2018-10-01 05:33:25 --> Output Class Initialized
INFO - 2018-10-01 05:33:25 --> Security Class Initialized
DEBUG - 2018-10-01 05:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:33:25 --> Input Class Initialized
INFO - 2018-10-01 05:33:25 --> Language Class Initialized
INFO - 2018-10-01 05:33:25 --> Loader Class Initialized
INFO - 2018-10-01 05:33:25 --> Helper loaded: url_helper
INFO - 2018-10-01 05:33:25 --> Helper loaded: form_helper
INFO - 2018-10-01 05:33:25 --> Helper loaded: html_helper
INFO - 2018-10-01 05:33:25 --> Database Driver Class Initialized
INFO - 2018-10-01 05:33:25 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:33:25 --> Model "User_model" initialized
INFO - 2018-10-01 05:33:25 --> Model "Project_model" initialized
INFO - 2018-10-01 05:33:25 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:33:25 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:33:25 --> Controller Class Initialized
INFO - 2018-10-01 05:33:25 --> Config Class Initialized
INFO - 2018-10-01 05:33:25 --> Hooks Class Initialized
DEBUG - 2018-10-01 05:33:25 --> UTF-8 Support Enabled
INFO - 2018-10-01 05:33:25 --> Utf8 Class Initialized
INFO - 2018-10-01 05:33:25 --> URI Class Initialized
INFO - 2018-10-01 05:33:25 --> Router Class Initialized
INFO - 2018-10-01 05:33:25 --> Output Class Initialized
INFO - 2018-10-01 05:33:25 --> Security Class Initialized
DEBUG - 2018-10-01 05:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-01 05:33:25 --> Input Class Initialized
INFO - 2018-10-01 05:33:25 --> Language Class Initialized
INFO - 2018-10-01 05:33:25 --> Loader Class Initialized
INFO - 2018-10-01 05:33:25 --> Helper loaded: url_helper
INFO - 2018-10-01 05:33:25 --> Helper loaded: form_helper
INFO - 2018-10-01 05:33:25 --> Helper loaded: html_helper
INFO - 2018-10-01 05:33:25 --> Database Driver Class Initialized
INFO - 2018-10-01 05:33:25 --> Form Validation Class Initialized
DEBUG - 2018-10-01 05:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2018-10-01 05:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-01 05:33:25 --> Model "User_model" initialized
INFO - 2018-10-01 05:33:25 --> Model "Project_model" initialized
INFO - 2018-10-01 05:33:25 --> Model "Tasks_model" initialized
INFO - 2018-10-01 05:33:25 --> Model "Lists_model" initialized
INFO - 2018-10-01 05:33:25 --> Controller Class Initialized
INFO - 2018-10-01 05:33:25 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/login_view.php
INFO - 2018-10-01 05:33:25 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/users/home_view.php
INFO - 2018-10-01 05:33:25 --> File loaded: D:\xampp\htdocs\code_igniter\application\views\project_views/layouts/main.php
INFO - 2018-10-01 05:33:25 --> Final output sent to browser
DEBUG - 2018-10-01 05:33:25 --> Total execution time: 0.0410
