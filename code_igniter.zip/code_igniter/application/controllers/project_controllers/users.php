<?php 

class Users extends CI_Controller{

	public function isEmailExist($email){
		$verify_email = $this->user_model->verify_email($email);

		if ($verify_email == true) {
			$this->form_validation->set_message('isEmailExist', 'Email already exist');
			return false;
		}else{
			return true;
		}
	}

	public function forgot_password(){
		$this->form_validation->set_rules('email', 'Email', 'trim|required|callback_isEmailExist|max_length[60]|min_length[10]');
		$this->form_validation->set_rules('new_password', 'New Password', 'trim|required|max_length[60]|min_length[8]');
		$this->form_validation->set_rules('confirm_new_password', 'Confirm New Password', 'trim|required|max_length[60]|min_length[8]');

		if ($this->form_validation->run() == FALSE) {
			$data['main_view'] = 'project_views/users/forgot_password';
			$this->load->view('project_views/layouts/main', $data);
		}
		else{
			
		}
	}

	public function register_view(){
		//form validation of user inputs for registration

		$this->form_validation->set_rules('firstname', 'Firstname', 'trim|required|max_length[60]|min_length[5]');
		$this->form_validation->set_rules('lastname', 'Lastname', 'trim|required|max_length[60]|min_length[5]');
		$this->form_validation->set_rules('email', 'Email', 'trim|required|callback_isEmailExist|max_length[60]|min_length[10]');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|max_length[60]|min_length[8]');
		$this->form_validation->set_rules('confirm_password', 'Confirm Password', 'trim|required|max_length[60]|min_length[8]');
		
		 if ($this->form_validation->run() == FALSE) {

			$data['main_view'] = 'project_views/users/register_view';

			$this->load->view('project_views/layouts/main', $data);

			}
			else{
				$this->load->model('project_models/user_model');

				if($this->user_model->create_user()){
					$this->session->set_flashdata('user_registered', 'User has successfully registered');
					redirect('project_controllers/home');
				}else{
					$this->session->set_flashdata('user_unregistered', 'Unable to register the user. Please check the values to make sure its correct');
					redirect('project_controllers/users/register_view');
				}
				
			}
	}

	public function login_view(){

		//form validation rules of user inputs for login
		$this->form_validation->set_rules('email', 'Email', 'trim|required|max_length[60]');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|max_length[60]');

		if($this->form_validation->run() == FALSE){
			$data = array('errors' => validation_errors());
			
			$this->session->set_flashdata($data);
			redirect('project_controllers/home');

		}
		else{
			$email = htmlspecialchars($this->input->post('email'));
			$password = htmlspecialchars($this->input->post('password'));

			$this->load->model('project_models/user_model');
			$email_id = $this->user_model->login_user($email,$password);

			if ($email_id) {
				
				//create a session
				$user_data = array('email_id' => $email_id, 'email' => $email, 'logged_in' => true);

				$this->session->set_userdata($user_data);

				//set session data that will only available for next request
				$this->session->set_flashdata('login_success', 'You are now logged in');
	
				redirect('project_controllers/home/index');

			}else{
				$this->session->set_flashdata('login_failed','Your email and password combination is incorrect! Please try again.');

				redirect('project_controllers/home');
			}
		}
	}

	public function logout(){
		$this->session->sess_destroy();
		redirect('project_controllers/home');
	}
}

 ?>