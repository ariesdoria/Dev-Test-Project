<?php 

class Home extends CI_Controller{

	public function index(){		

		if($this->session->userdata('logged_in')){
			$user_id = $this->session->userdata('user_id');
		}
			$data['main_view'] = "project_views/users/home_view";
			$data['title'] = 'Usertest';
			$this->load->view('project_views/layouts/main', $data);
	}
}
 ?>