<?php 

	class User_model extends CI_Model{

		public function verify_email($email){
			$this->db->select("*");
			$this->db->from('users');
			$this->db->where('email',$email);

			$query = $this->db->get();

			if ($query->num_rows() == 1) {
				return true;
			}else{
				return false;
			}

		}

		public function create_user(){

			$firstname = $this->input->post('firstname');
			$lastname = $this->input->post('lastname');
			$email = $this->input->post('email');

			$password = $this->input->post('password');
			$password_verify = $this->input->post('confirm_password');

			//amount of time it takes to rewrite the password string
			$options = ['cost' => 12];
			//encrypt the password when registering a new user
			$encrypted_pass = password_hash(htmlspecialchars($password), PASSWORD_BCRYPT, $options);

			if($password === $password_verify){
					$data = [	'first_name' => htmlspecialchars($firstname), 
								'last_name' => htmlspecialchars($lastname), 
								'email' => htmlspecialchars($email), 
								'password' => $encrypted_pass	];

					$insert_data = $this->db->insert('users', $data);
					return $insert_data;
				}
				return false;
		}

		public function login_user($email = null, $password = null){
			if(is_null($email) || is_null($password)){
				return false;
			}else{
				$this->db->where('email', $email);

				$result = $this->db->get('users');

				$db_password = $result->row(6)->password;

				if(!empty($result)){
		//Verify if the password matches and decrypt password from database when the user logs in 
					if (password_verify($password, $db_password)) {

						return $result->row(0)->id;

					}return false;
					
				}return false;	
			}
		}
	}

 ?>