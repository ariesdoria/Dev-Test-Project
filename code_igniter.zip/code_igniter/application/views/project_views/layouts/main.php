<?php 
  $home = "";
  $register = "";
      
      if($this->uri->segment(3) == 'register_view'){
        $register = "active";
      }else{
        $home = "active";
      }

 ?>


<?php echo doctype('html5'); ?>
<html lang="en">
<head>
	<?php 
      $meta = ['charset' => 'UTF-8'];

      echo meta($meta); 
  ?>
	<title>Usertest</title>
  <?php echo link_tag('assets/css/bootstrap.min.css'); ?>
  <?php echo link_tag('assets/css/custom.css'); ?>
  <?php echo link_tag('assets/js/bootstrap.min.js'); ?>
  <?php echo link_tag('assets/js/jquery.js'); ?>
</head>
<body>
	
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="<?php echo base_url('project_controllers/home');?>">Usertest</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="<?php echo $home;?>">
          <a href="<?php echo base_url('project_controllers/home');?>">Home 
            <span class="sr-only">(current)</span>
          </a>
        </li>
                
        <?php if(!$this->session->userdata('logged_in')):?>
          <li class="<?php echo $register;?>">  
            <a href="<?php echo base_url('project_controllers/users/register_view');?>">Register</a>
          </li>
        <?php endif; ?>
      </ul>

      
      <ul class="nav navbar-nav navbar-right">
        <?php if($this->session->userdata('logged_in')):?>
          <li><a href="<?php echo base_url('project_controllers/users/logout');?>">Logout</a></li>
        <?php endif; ?>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

<div class="container">
	
	<div class="col-xs-3">
		<?php $this->load->view('project_views/users/login_view'); ?>

	</div>

	<div class="col-xs-9">
		<?php $this->load->view($main_view); ?>
	</div>

</div>


</body>
</html>