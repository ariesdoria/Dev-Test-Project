<?php if (!$this->session->userdata('logged_in')): ?>
<div class="alert alert-info">
	<strong>Tip!</strong> Please don't use your personal email and password in registering for this app. 
</div>
<h2>Register</h2>

	<?php $attributes = array('id' => 'register_form' , 'class' => 'form-vertical'); ?>

	<?php 

	 	echo validation_errors("<p class='bg-danger'>"); 

	 ?>

	<?php
		//pass the values in the login_view function in the Users class in the project_controllers controller
		echo form_open('project_controllers/users/register_view', $attributes);
	 ?>
<!-- Registration Form -->
<div class="form">
	<div class="form-group">
		<?php echo form_label('Firstname'); ?>
		<?php $data = array('class' => 'form-control' , 'name' => 'firstname', 'placeholder' => 'Enter Firstname', 'value' => set_value('firstname')); ?>
		<?php echo form_input($data); ?>
	</div>
	<div class="form-group">
		<?php echo form_label('Lastname'); ?>
		<?php $data = array('class' => 'form-control' , 'name' => 'lastname', 'placeholder' => 'Enter Lastname', 'value' => set_value('lastname')); ?>
		<?php echo form_input($data); ?>
	</div>
	<div class="form-group">
		<?php echo form_label('Email'); ?>
		<?php $data = array('class' => 'form-control' , 'name' => 'email', 'placeholder' => 'Enter Email', 'type' => 'email', 'value' => set_value('email')); ?>
		<?php echo form_input($data); ?>
	</div>
	<div class="form-group">
		<?php echo form_label('Password'); ?>
		<?php $data = array('class' => 'form-control', 'name' => 'password', 'placeholder' => 'Enter Password', 'type' => 'password', 'value' => set_value('password')); ?>
		<?php echo form_input($data); ?>
	</div>
	<div class="form-group">
		<?php echo form_label('Confirm Password'); ?>
		<?php $data = array('class' => 'form-control', 'name' => 'confirm_password', 'placeholder' => 'Confirm Password', 'type' => 'password', 'value' => set_value('confirm_password')); ?>
		<?php echo form_input($data); ?>
	</div>
	<div class="form-group">
		<?php $data = array('class' => 'btn btn-success', 'name' => 'submit', 'value' => 'Register'); ?>
		<?php echo form_submit($data); ?>
	</div>

	<?php echo form_close(); ?>

</div>

<?php endif; ?>

 