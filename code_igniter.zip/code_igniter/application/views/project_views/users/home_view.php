<?php if($this->session->userdata('logged_in')): ?>
<?php echo "<div class='alert alert-success'>
				<strong>Welcome!</strong> This is the main page of the user that is logged in.
			</div>"; ?>
<?php endif; ?>

<p class="bg-success">
	<?php if($this->session->flashdata('user_registered')): ?>
	<?php echo $this->session->flashdata('user_registered'); ?>
	<?php endif; ?>
</p>

<p class="bg-danger">
	<?php if ($this->session->flashdata('user_unregistered')): ?>
	<?php echo $this->session->flashdata('user_unregistered'); ?>
	<?php endif; ?>
</p>

<p class="bg-danger">
	<?php if($this->session->flashdata('login_failed')): ?>
	<?php echo $this->session->flashdata('login_failed'); ?>
	<?php endif; ?>
</p>


<?php
	if(!$this->session->userdata('logged_in')){
		$no_access = $this->session->flashdata('no_access');

		if($this->session->flashdata('no_access')){
			echo "<div class='alert alert-danger'>
					<p>$no_access</p>
			 	  </div>";	
		}

		echo "<div class='jumbotron'>
				<h2 class='text-center'>Welcome to the User Test Application</h2>
			  </div>";
	}

 ?>
 
				</ul>
			</div>
	</div>
