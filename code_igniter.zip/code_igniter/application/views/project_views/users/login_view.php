<?php if($this->session->userdata('logged_in')): ?>

<h2>Welcome!</h2>

	<?php
		//retrieve the value of the session value stored in the login_view() function in the users controller
		$email = $this->session->userdata('email');
	?>	

	<?php if($email): ?>

	<?php echo form_open('project_controllers/users/logout'); ?>

<p>
	<?php echo "You're now logged in with the email: " . $email; ?>

	<?php endif; ?>
</p>

	<?php 
			$data = array('class' => 'btn btn-danger', 'name' => 'submit','value' => 'Logout');
	 ?>

	<?php echo form_submit($data); ?>

	<?php echo form_close(); ?>

	<?php else: ?>

<h2>Login</h2>

	<?php $attributes = array('id' => 'login_form' , 'class' => 'form-horizontal'); ?>

	<!-- retrieve the flashdata  -->
	<?php if($this->session->flashdata('errors')):?>
	<?php echo $this->session->flashdata('errors'); ?>
	<?php endif; ?>

	<?php
		//pass the values in the login_view function in the Users class in the project_controllers controller
		echo form_open('project_controllers/users/login_view', $attributes);
	 ?>

<div class="form">
	<div class="form-group">
		<?php echo form_label('Email'); ?>
		<?php $data = array('class' => 'form-control' , 'name' => 'email', 'placeholder' => 'Enter Email'); ?>
		<?php echo form_input($data); ?>
	</div>
	<div class="form-group">
		<?php echo form_label('Password'); ?>
		<?php $data = array('class' => 'form-control', 'name' => 'password', 'placeholder' => 'Enter Password', 'type' => 'password'); ?>
		<?php echo form_input($data); ?>
	</div>
	<div class="form-group">
		<?php $data = array('class' => 'btn btn-primary', 'name' => 'submit', 'value' => 'Login'); ?>
		<?php echo form_submit($data); ?>
	</div>

	<?php echo form_close(); ?>


</div>

<div class="alert alert-info">
	<strong>Tip!</strong> Please don't use your bank account or other personal passwords to login to this app. 
</div>
	

	<?php endif; ?>


 